# NI 43-101 Technical Report LaRonde Complex <br> Québec, Canada 

## Prepared by

![img-0.jpeg](img-0.jpeg)

## AGNICO EAGLE

Agnico Eagle Mines Limited<br>LaRonde Division<br>10200 Route de Preissac<br>Rouyn-Noranda, QC J0Y 1C0

Project Location
Latitude $48^{\circ} 15^{\prime}$ North and Longitude $78^{\circ} 15^{\prime}$ West
Province of Québec, Canada

## Prepared by:

David Pitre, P.Eng., P.Geo.
Vincent Dagenais, P.Eng.
Devin Wilson, P.Eng.
Claude Bolduc, P.Eng.
Yanick Létourneau, P.Eng.# SIGNATURE PAGE 

This report entitled "NI 43-101 Technical Report, LaRonde Complex, Québec, Canada" dated March 24, 2023 with an Effective Date of December 31, 2022 was prepared for Agnico Eagle Mines Limited. The data on which the contained Mineral Reserve and Mineral Resource estimate for LaRonde Complex is based were current as at the Effective Date on December 31, 2022. The undersigned are all Qualified Persons as defined by National Instrument 43-101 ("NI 43-101") and were responsible for preparing or supervising the preparation of parts of this Technical Report.

Signed, sealed and submitted on March 24, 2023:

Prepared By:
(signed and sealed) David Pitre, P.Eng., P.Geo.
David Pitre, P.Eng., P.Geo. Signed at Rouyn-Noranda on March 24, 2023
(OIQ \#121977) (OGQ \#00735)
(signed and sealed) Vincent Dagenais, P.Eng.
Vincent Dagenais, P.Eng. Signed at Rouyn-Noranda on March 24, 2023
(OIQ \#5054313)
(signed and sealed) Devin Wilson, P.Eng.
Devin Wilson, P.Eng. Signed at Rouyn-Noranda on March 24, 2023
(OIQ \#146530)
(signed) Claude Bolduc, P.Eng.
Claude Bolduc, P.Eng. Signed at Rouyn-Noranda on March 24, 2023
(OIQ \#133200)
(signed) Yanick Létourneau, P.Eng.
Yanick Létourneau, P.Eng. Signed at Rouyn-Noranda on March 24, 2023
(OIQ \#116279)# CERTIFICATE OF QUALIFIED PERSON - DAVID PITRE 

I, David Pitre, P.Eng., P.Geo., as an author of this report entitled "NI 43-101 Technical Report of the LaRonde Complex in Québec, Canada" (the Technical Report) prepared for Agnico Eagle Mines Limited (the Issuer) and dated effective as at December 31, 2022, do hereby certify the following:

1. I am Senior Resource Geologist at LaRonde Complex, with an office at 10 200, Route de Preissac, Rouyn-Noranda, Québec, J0Y 1C0.
2. I graduated from the Université Laval at Québec City with a Bachelor of Science degree in Geology in 1995, a bachelor's degree in Geological Engineering in 1997 and a master's degree in Earth Sciences in 2000. I am a member of the Ordre des Ingénieurs du Québec (OIQ No.121977) and of the Ordre des Géologues du Québec (OGQ No. 735). I have practiced my profession continuously since 1998. My relevant experience for the purpose of the Technical Report includes the following:

- I have worked as a Mine Geologist in Bouchard-Hébert mine for Cambior and Breakwater Resources from 1998 to 2002 (Abitibi polymetallic U/G mine).
- I have worked as a Geologist at LaRonde Complex since 2002, starting as Production Geologist and progressing to Senior Geologist and currently Senior Resource Geologist.

3. I have read the definition of "Qualified Person" set out in National Instrument 43-101 Standards of Disclosure for Minerals Projects (NI 43-101) and certify that by reason of my education, affiliation with a professional association (as defined in NI 43-101), and past relevant work experience, I fulfill the requirements to be a Qualified Person for the purposes of NI 43-101.
4. I have worked at the project since 2002 as a full-time employee.
5. I am responsible for Sections 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 15 and 23 and share responsibility for related disclosure in Sections 1 to 3, and 24 to 27 of the Technical Report.
6. I am not independent of the Issuer.
7. I have had prior involvement with the Property that is the subject of the Technical Report in my role as Senior Resource Geologist at the project.
8. I have read NI 43-101 and the sections of the Technical Report for which I am responsible have been prepared in compliance with NI 43-101 and Form 43-101F1.
9. At the effective date of the Technical Report, to the best of my knowledge, information and belief, Sections 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 15 and 23 and related disclosure in Sections 1 to 3, and 24 to 27 in the Technical Report for which I am responsible contain all the scientific and technical information that is required to be disclosed to make the Technical Report not misleading.
(signed and sealed) David Pitre

David Pitre, P.Eng., P.Geo.
Dated this $24^{\text {th }}$ day of March 2023# CERTIFICATE OF QUALIFIED PERSON - VINCENT DAGENAIS 

I, Vincent Dagenais, P.Eng., as an author of this report entitled "NI 43-101 Technical Report, LaRonde Complex, Québec, Canada" (the Technical Report) prepared for Agnico Eagle Mines Limited (the Issuer) and dated effective as at December 31, 2022, do hereby certify the following:

1. I am the Engineering Superintendent for the LaRonde Mine at LaRonde Complex, with an office at 10 200, Route de Preissac, Rouyn-Noranda, Québec, J0Y 1C0.
2. I graduated from Polytechnique Montreal with a Bachelor's Degree in Mining Engineering. I am a member of the Ordre des Ingénieurs du Québec (OIQ No. 5054313). I have practiced my profession continuously since 2014. My relevant experience for the purpose of the Technical Report includes the following:

- At LaRonde Mine, I worked as a ground control Engineer from 2014 to 2019, as a planning engineer and Engineer coordinator from 2019 to 2021, as the AssistantSuperintendent Engineer from 2021 to 2022, and currently as the Superintendent of Engineering.

3. I have read the definition of "Qualified Person" set out in National Instrument 43-101 Standards of Disclosure for Minerals Projects (NI 43-101) and certify that by reason of my education, affiliation with a professional association (as defined in NI 43-101), and past relevant work experience, I fulfill the requirements to be a Qualified Person for the purposes of NI 43-101.
4. I have worked at the project since 2014 as a full-time employee.
5. I share responsibility for Sections 16, 18, 19, 21 and 22 and share responsibility for related disclosure in Sections 1 to 3, and 24 to 27 of the Technical Report.
6. I am not independent of the Issuer.
7. I have had prior involvement with the Property that is subject to this Technical Report in my role as Engineering Superintendent at the project.
8. I have read NI 43-101 and the sections of the Technical Report for which I am responsible have been prepared in compliance with NI 43-101 and Form 43-101F1.
9. At the effective date of the Technical Report, to the best of my knowledge, information and belief, Sections 16, 18, 19, 21 and 22 and related disclosure in Sections 1 to 3, and 24 to 27 in the Technical Report for which I am responsible contain all the scientific and technical information that is required to be disclosed to make the Technical Report not misleading.
(signed and sealed) Vincent Dagenais

Vincent Dagenais, P.Eng.
Dated this $24^{\text {th }}$ day of March 2023# CERTIFICATE OF QUALIFIED PERSON - DEVIN WILSON 

I, Devin Wilson, P.Eng., as an author of this report entitled "NI 43-101 Technical Report, LaRonde Complex, Québec, Canada" (the Technical Report) prepared for Agnico Eagle Mines Limited (the Issuer) and dated effective as at December 31, 2022, do hereby certify the following:

1. I am the Chief Engineer for the LZ5 Mine at LaRonde Complex, with an office at 10 200, Route de Preissac, Rouyn-Noranda, Québec, J0Y 1C0.
2. I graduated from Queen's University with a Bachelor of Science degree in MineMechanical Engineering in 2007. I am a member of the Ordre des Ingénieurs du Québec (OIQ No.146350). I have practiced my profession continuously since 2007. My relevant experience for the purpose of the Technical Report includes the following:

- I worked as a mining engineer for Agnico Eagle at the Lapa mine from 2007 to 2015.
- I worked as a mining engineer for Agnico Eagle at the LaRonde mine from 2015 to 2020.
- I have worked as a mining engineer for Agnico Eagle at the LZ5 mine from 2020 to present.

3. I have read the definition of "Qualified Person" set out in National Instrument 43-101 Standards of Disclosure for Minerals Projects (NI 43-101) and certify that by reason of my education, affiliation with a professional association (as defined in NI 43-101), and past relevant work experience, I fulfill the requirements to be a Qualified Person for the purposes of NI 43-101.
4. I have worked at the project since 2007 as a full-time employee.
5. I share responsibility for Sections 16, 18, 19, 21 and 22 of the Technical Report, and I share responsibility for related disclosure in Sections 1 to 3, and 24 to 27 of the Technical Report.
6. I am not independent of the Issuer.
7. I have had prior involvement with the Property that is the subject of the Technical Report in my role as Chief Engineer at the project.
8. I have read NI 43-101 and the sections of the Technical Report for which I am responsible have been prepared in compliance with NI 43-101 and Form 43-101F1.
9. At the effective date of the Technical Report, to the best of my knowledge, information and belief, Sections 16, 18, 19, 21, 22 and related disclosure in Sections 1 to 3, and 24 to 27 in the Technical Report for which I am responsible contain all the scientific and technical information that is required to be disclosed to make the Technical Report not misleading.
(signed and sealed) Devin Wilson

Devin Wilson, P.Eng.
Dated this $24^{\text {th }}$ day of March 2023# CERTIFICATE OF QUALIFIED PERSON - CLAUDE BOLDUC 

I, Claude Bolduc, P. Eng., as an author of this report entitled "NI 43-101 Technical Report, LaRonde Complex, Québec, Canada" (the Technical Report) prepared for Agnico Eagle Mines Limited (the Issuer) and dated effective as at December 31, 2022, do hereby certify the following:

1. I am the General Mills and Surface Superintendent at LaRonde Complex, with an office at 10 200, Route de Preissac, Rouyn-Noranda, Québec, J0Y 1C0.
2. I graduated from the Université Polytechnique at Montreal with a Bachelor of Chemical Engineering in 2004. I am a member of the Ordre des Ingénieurs du Québec (OIQ No.133200). I have practiced my profession continuously since 2004. My relevant experience for the purpose of the Technical Report includes the following:

- I have worked as a Process Engineer at Uniboard Canada, Val-d'Or, 2004-2008.
- I have worked as a Metallurgist at LaRonde Complex since 2008, starting as Production Metallurgist and progressing as Senior Metallurgist, Operation Supervisor, Operation and Metallurgy Superintendent and now General Mills and Surface Superintendent.

3. I have read the definition of "Qualified Person" set out in National Instrument 43-101 Standards of Disclosure for Minerals Projects (NI 43-101) and certify that by reason of my education, affiliation with a professional association (as defined in NI 43-101), and past relevant work experience, I fulfill the requirements to be a "Qualified Person" for the purposes of NI 43-101.
4. I have worked at the project since 2008 as a full-time employee.
5. I am responsible for Sections 13 and 17 and share responsibility for Section 18 and for related disclosure in Sections 1 to 3, and 24 to 27 of the Technical Report.
6. I am not independent of the Issuer.
7. I have had prior involvement with the Property that is the subject of the Technical Report in my role as General Mills and Surface Superintendent at the project.
8. I have read NI 43-101 and the sections of Technical Report for which I am responsible have been prepared in compliance with NI 43-101 and Form 43-101F1.
9. At the effective date of the Technical Report, to the best of my knowledge, information and belief, Sections 13, 17 and 18 and related disclosure in Sections 1 to 3, and 24 to 27 in the Technical Report for which I am responsible contain all the scientific and technical information that is required to be disclosed to make the Technical Report not misleading.
(signed) Claude Bolduc

Claude Bolduc, P.Eng.
Dated this $24^{\text {th }}$ day of March 2023# CERTIFICATE OF QUALIFIED PERSON - YANICK LÉTOURNEAU 

I, Yanick Létourneau, P.Eng., as an author of this report entitled "NI 43-101 Technical Report, LaRonde Complex, Québec, Canada" (the Technical Report) prepared for Agnico Eagle Mines Limited (the Issuer) and dated effective as at December 31, 2022, do hereby certify the following:

1. I am the Environment Superintendent at LaRonde Complex, with an office at 10 200, Route de Preissac, Rouyn-Noranda, Québec, J0Y 1C0.
2. I graduated from Sherbrooke University with a Bachelor of Chemical Engineering in December 1995. I am a member of the Ordre des Ingénieurs du Québec (OIQ No.116279). I have practiced my profession continuously since 1996. My relevant experience for the purpose of the Technical Report includes the following:

- I worked as Junior Process Engineer at the Horne Smelter (Noranda), 1996-1997.
- I worked at Louvicourt Mine (Aur Resources) from 1997 to 2002, first as a Metallurgist and finally as the Environment Coordinator from 1999 to 2002.
- I worked as Environment and Control Quality Coordinator for Uniboard Canada, Val-d'Or plant, and Process Engineer from 2002 to 2004 and then transferred to Uniboard's Unires plant as Process Engineer and Supervisor from 2004 to 2008.
- I worked for Genivar as Project Manager from 2008 to 2013. I was involved in several major mining projects including Westwood (Iamgold), Eleonore (Goldcorp), and Quebec Lithium.
- I have worked for Agnico Eagle's LaRonde Mining Complex since 2013 as Environment Superintendent.

3. I have read the definition of "Qualified Person" set out in National Instrument 43-101 Standards of Disclosure for Minerals Projects (NI 43-101) and certify that by reason of my education, affiliation with a professional association (as defined in NI 43-101) and past relevant work experience, I fulfill the requirements to be a "Qualified Person" for the purposes of NI 43-101.
4. I have worked at the project since 2013 as a full-time employee.
5. I am responsible for Section 20 and share responsibility for related disclosure in Sections 1 to 3, and 24 to 27 of the Technical Report.
6. I am not independent of the Issuer.
7. I have had prior involvement with the Property that is the subject of the Technical Report in my role as Environment Superintendent at the project.
8. I have read NI 43-101 and the sections of Technical Report for which I am responsible have been prepared in compliance with NI 43-101 and Form 43-101F1.
9. At the effective date of the Technical Report, to the best of my knowledge, information and belief, Section 20 and related disclosure in Sections 1 to 2, and 24 to 27 in the Technical Report for which I am responsible contain all the scientific and technical information that is required to be disclosed to make the Technical Report not misleading.
(signed and sealed) Yanick Létourneau

Yanick Létourneau, P.Eng.
Dated this $24^{\text {th }}$ day of March 2023# Cautionary Note Regarding Forward-Looking Statements 

This report contains or incorporates by reference "forward-looking statements" and "forwardlooking information" under applicable Canadian securities legislation within the meaning of the United States Private Securities Litigation Reform Act of 1995. Forward-looking information includes, but is not limited to: the success of using pillarless mining as a means of managing stress, cash flow forecasts, projected capital, operating and exploration expenditures, targeted cost reductions, mine life and production rates, grades, infrastructure, capital, operating and sustaining costs, the future price of gold, potential mineralization and metal or mineral recoveries, estimates of mineral resources and mineral reserves and the realization of such mineral resources and mineral reserves, information pertaining to potential improvements to financial and operating performance and mine life at the LaRonde Complex (as defined herein) that may result from expansion projects or other initiatives, maintenance and renewal of permits or mineral tenure, estimates of mine closure obligations and information with respect to Agnico Eagle Mines Limited's strategy, plans or future financial or operating performance. Forward-looking statements are characterized by words such as "anticipate", "believe", "budget", "estimate", "expect", "intend", "plan", "project", "target" and other similar words, or statements that certain events or conditions "may" or "will" occur, including the negative connotations of such terms. Forward-looking statements are statements that are not historical facts and are based on the opinions, assumptions and estimates of Qualified Persons (as defined herein) considered reasonable at the date the statements are made, and are inherently subject to a variety of risks and uncertainties and other known and unknown factors that could cause actual events or results to differ materially from those projected in the forward-looking statements. These factors include, but are not limited to: the impact of general domestic and foreign business; economic and political conditions; global liquidity and credit availability on the timing of cash flows and the values of assets and liabilities based on projected future conditions; fluctuating metal and commodity prices (such as gold, silver, diesel fuel, natural gas and electricity); risks associated with nature and climatic conditions including an increase in seismicity in the area; currency exchange rates (such as the Canadian dollar versus the United States dollar); changes in interest rates; possible variations in ore grade or recovery rates; the speculative nature of mineral exploration and development; changes in mineral production performance, exploitation and exploration successes; diminishing quantities or grades of mineral reserves; increased costs, delays, suspensions, and technical challenges associated with the construction of capital projects; operating or technical difficulties in connection with mining or development activities, including disruptions in the maintenance or provision of required infrastructure and information technology systems; damage to Agnico Eagle Mines Limited's reputation due to the actual or perceived occurrence of any number of events, including negative publicity with respect to the handling of environmental matters or dealings with community groups, First Nations groups or others, whether true or not; risk of loss due to acts of war, terrorism, sabotage and civil disturbances; risks associated with infectious diseases, including COVID-19; the impact of inflation; fluctuations in the currency markets; changes in national and local government legislation, taxation, controls or regulations and/or changes in the administration of laws, policies and practices, expropriation or nationalization of property and political or economic developments; failure to comply with environmental and health and safety laws and regulations; timing of receipt of, or failure to comply with, necessary permits and approvals; changes in project parameters as plans continue to be refined; changes in project development, construction, production and commissioning time frames; contests over title to properties or over access to water, power, and other required infrastructure; increased costs and physical risks including extreme weather events and resource shortages related to climate change; availability and increased costs associated with mining inputs and labour; the possibility of project cost overruns or unanticipated costs and expenses, potential impairment charges, higher prices for fuel, steel, power, labour, and other consumables contributing to higher costs; unexpected changes in minelife; final pricing for concentrate sales; unanticipated results of future studies; seasonality and unanticipated weather changes; costs and timing of the development of new deposits; success of exploration activities; unanticipated reclamation expenses; limitations on insurance coverage; timing and possible outcome of pending and outstanding litigation and labour disputes; risks related to the vulnerability of information systems and risks related to global financial conditions. In addition, there are risks and hazards associated with the business of mineral exploration, development and mining, including environmental hazards, industrial accidents, unusual or unexpected formations, pressures, cave-ins, flooding, failure of plant, equipment, or processes to operate as anticipated (and the risk of inadequate insurance, or inability to obtain insurance, to cover these risks), as well as those risk factors discussed or referred to herein and in the issuer's Annual Information Form filed with the securities regulatory authorities in all of the provinces and territories of Canada and available under the issuer's profile at www.sedar.com, and the issuer's Annual Reports on Form 40-F filed with the United States Securities and Exchange Commission at www.edgar.com. Although Agnico Eagle Mines Limited has attempted to identify important factors that could cause actual actions, events, or results to differ materially from those described in forward-looking statements, there may be other factors that cause actions, events, or results not to be anticipated, estimated or intended. There can be no assurance that forward-looking statements will prove to be accurate, as actual results and future events could differ materially from those anticipated in such statements. Agnico Eagle Mines Limited undertakes no obligation to update forward-looking statements if circumstances or management's estimates, assumptions, or opinions should change, except as required by applicable law. The reader is cautioned not to place undue reliance on forward-looking statements. The forward-looking information contained herein is presented for the purpose of assisting readers in understanding Agnico Eagle Mines Limited's expected financial and operational performance and results as at and for the periods ended on the dates presented herein and objectives and may not be appropriate for other purposes.

# Cautionary Note to United States Investors Concerning Estimates of Mineral Reserves and Mineral Resources 

The mineral reserve and mineral resource estimates contained in this report have been prepared in accordance with the Canadian securities administrators' (the "CSA") National Instrument 43101 - Standards of Disclosure for Mineral Projects ("NI 43-101"). These standards are similar to those used by the United States Securities and Exchange Commission's (the "SEC") Industry Guide No. 7, as interpreted by Staff at the SEC ("Guide 7"). However, the definitions in NI 43-101 differ in certain respects from those under Guide 7. Accordingly, mineral reserve and mineral resource information contained in this report may not be comparable to similar information disclosed by United States companies. Under Guide 7, mineralization may not be classified as a "reserve" unless the determination has been made that the mineralization could be economically and legally produced or extracted at the time the reserve determination is made. For United States reporting purposes, the SEC has adopted amendments to its disclosure rules to modernize the mining property disclosure requirements for issuers whose securities are registered with the SEC under the United States Securities Exchange Act of 1934, as amended (the "Exchange Act"), which became effective February 25, 2019. The SEC disclosure rules more closely align the SEC's disclosure requirements and policies for mining properties with current industry and global regulatory practices and standards, including NI 43-101, and replace the historical property disclosure requirements for mining registrants that were included in Guide 7. Issuers must comply with the SEC Modernization Rules in their first fiscal year beginning on or after January 1, 2021. However, Canadian issuers that report in the United States using the Multijurisdictional DisclosureSystem ("MJDS"), like Agnico Eagle Mines Limited, may still use NI 43-101 rather than the SEC disclosure rules when using the SEC's MJDS registration statement and annual report forms.
As a result of the adoption of the SEC Modernization Rules, the SEC now recognizes estimates of "measured mineral resources", "indicated mineral resources" and "inferred mineral resources." In addition, the SEC has amended the definitions of "proven mineral reserves" and "probable mineral reserves" in the SEC Modernization Rules, with definitions that are substantially similar to those used in NI 43-101. United States investors are cautioned that while the SEC now recognizes "measured mineral resources", "indicated mineral resources" and "inferred mineral resources", investors should not assume that any part or all of the mineral deposits in these categories will ever be converted into a higher category of mineral resources or into mineral reserves. These terms have a great amount of uncertainty as to their economic and legal feasibility. Under Canadian regulations, estimates of inferred mineral resources may not form the basis of feasibility or pre-feasibility studies, except in limited circumstances. Investors are cautioned not to assume that any "measured mineral resources", "indicated mineral resources", or "inferred mineral resources" that the Company reports in this report are or will be economically or legally mineable. Further, "inferred mineral resources" have a great amount of uncertainty as to their existence and as to their economic and legal feasibility. It cannot be assumed that any part or all of an inferred mineral resource will ever be upgraded to a higher category.
The mineral reserve and mineral resource data set out in this report are estimates, and no assurance can be given that the anticipated tonnages and grades will be achieved or that the indicated level of recovery will be realized.

# Non-GAAP Measures 

Agnico Eagle Mines Limited has included certain non-Generally Accepted Accounting Principles ("GAAP") financial measures and additional line items or subtotals, which Agnico Eagle Mines Limited believes that, together with measures determined in accordance with International Financial Reporting Standards ("IFRS"), provide readers with an improved ability to evaluate the underlying performance of Agnico Eagle Mines Limited. Non-GAAP financial measures do not have any standardized meaning prescribed under IFRS, and therefore they may not be comparable to similar measures employed by other companies. The data is intended to provide additional information and should not be considered in isolation or as a substitute for measures of performance prepared in accordance with IFRS. The non-GAAP financial measures in this report include: free cash flow and total cash costs. Please refer to the issuer's current annual Management's Discussion and Analysis, which is filed under the issuer's profiles on SEDAR at www.sedar.com and which includes a detailed discussion of the usefulness of the non-GAAP measures. Agnico Eagle Mines Limited believes that in addition to conventional measures prepared in accordance with IFRS, Agnico Eagle Mines Limited and certain investors and analysts use this information to evaluate Agnico Eagle Mines Limited's performance. In particular, management uses these measures for internal valuation for the period and to assist with planning and forecasting of future operations.# TABLE OF CONTENTS 

1. SUMMARY ..... 1
1.1 Overview ..... 1
1.2 Property Description and Location ..... 1
1.3 Accessibility, Local Resources, Climate, Physiography and Infrastructure ..... 1
1.4 History ..... 2
1.5 Geology and Mineralization ..... 2
1.6 Deposit Types ..... 3
1.7 Exploration and Drilling ..... 3
1.8 Sample Analyses ..... 3
1.9 Mineral Processing and Metallurgical Testing ..... 4
1.10 Mineral Resource Estimate ..... 5
1.11 Mineral Reserve Estimate ..... 9
1.12 Mining Methods, Production Rates and Expected Life of Mine ..... 13
1.12.1 Requirement for development ..... 14
1.12.2 Backfill ..... 14
1.12.3 Mining fleet and machinery ..... 14
1.12.4 Geotechnical parameters ..... 14
1.12.5 Mine Ventilation ..... 15
1.12.6 Dewatering ..... 15
1.13 Recovery Methods ..... 16
1.14 Infrastructure ..... 16
1.15 Market Studies and Contracts ..... 17
1.16 Environmental Studies, Permitting, and Social and Community Impact ..... 17
1.16.1 Permitting and authorizations ..... 18
1.16.2 Community Relations ..... 18
1.16.3 Closure Plan ..... 19
1.17 Capital and Operating Costs, and Economic Analysis ..... 20
1.18 Interpretations and Conclusions ..... 21
1.19 Recommendations ..... 22
2. INTRODUCTION ..... 23
2.1 Terms of Reference and Sources of Information ..... 23
2.2 Report Responsibility, Qualified Persons and Site Visits ..... 24
2.3 Abbreviations, Acronyms, Currency and Units of Measurements ..... 25
3. RELIANCE ON OTHER EXPERTS ..... 28
4. PROPERTY DESCRIPTION AND LOCATION ..... 29
4.1 Location ..... 29
4.2 Mining Title Status ..... 29
4.2.1 LaRonde property ..... 29
4.2.2 Bousquet property ..... 29
4.2.3 Ellison property ..... 31
4.2.4 El Coco property ..... 31
4.2.5 Terrex property ..... 31
4.2.6 Additional surface rights ..... 31
4.3 Agreements and Encumbrances ..... 34
4.4 Mining-Incompatible Territory ..... 34
4.5 Permitting and Authorization ..... 35
4.6 Environmental Liabilities ..... 35
5. ACCESSIBILITY, LOCAL RESOURCES, CLIMATE, PHYSIOGRAPHY \& INFRASTRUCTURE ..... 36
5.1 Accessibility ..... 36
5.2 Local Resources and Infrastructure ..... 36
5.3 Climate and Vegetation ..... 36
5.4 Physiography and Topography ..... 365.5 On-site Infrastructure ..... 37
6. HISTORY ..... 40
6.1 Exploration and Mine Development at LaRonde Property ..... 44
6.1.1 Historic exploration and discovery ..... 44
6.1.2 Mine development and exploration. ..... 46
6.1.3 Production at LaRonde Property ..... 47
6.2 Exploration and Mine Development at the Bousquet Property ..... 49
6.2.1 Historic exploration and discovery ..... 49
6.2.2 Mine development and exploration prior to Agnico Eagle (1977-2002) ..... 50
6.2.3 Mine development and exploration by Agnico Eagle (2003 to present) ..... 51
6.2.4 Production at Bousquet property ..... 54
6.2.5 Exploration and mine development at the El Coco and Terrex properties ..... 54
6.2.6 Historical exploration and discovery ..... 54
6.2.7 Production ..... 57
6.3 Exploration and Mine Development at the Ellison Property ..... 57
6.3.1 Historic exploration and discovery ..... 57
7. GEOLOGICAL SETTING AND MINERALIZATION ..... 59
7.1 Regional Geology ..... 59
7.2 Local and Property Geology ..... 60
7.3 Mineralization ..... 62
7.3.1 Mineralized zones at LaRonde Zone 5 (former Bousquet Shaft \#1) ..... 63
7.3.2 Mineralized zones at Bousquet No. 2 and LaRonde Shaft \#1 ..... 67
7.3.3 Mineralized zones at LaRonde Shaft \#2 ..... 69
7.3.4 Mineralized zones at the LaRonde Penna Shaft ..... 69
8. DEPOSIT TYPES ..... 75
9. EXPLORATION ..... 79
10. DRILLING ..... 80
10.1 Drilling Contractors ..... 83
10.2 Drilling Procedures ..... 84
10.2.1 Core size and core boxes ..... 84
10.2.2 Drill hole identification ..... 84
10.2.3 Core storage ..... 84
10.2.4 Drill hole collar surveys and downhole surveys ..... 85
10.2.5 Cementing of completed drill holes ..... 86
10.3 Drilling by Agnico Eagle ..... 87
10.3.1 Regional exploration drilling ..... 87
10.3.2 LaRonde deposit drilling ..... 87
10.3.3 LZ5 deposit drilling ..... 87
10.4 Note on Historical Drilling by Previous Owners and Agnico Eagle ..... 92
10.5 Conclusion ..... 92
11. SAMPLE PREPARATION, ANALYSES AND SECURITY ..... 93
11.1 Core Handling, Sample Preparation and Security ..... 93
11.2 Laboratory Accreditation and Certification ..... 94
11.3 Laboratory Preparation, Assays and Measurements ..... 95
11.3.1 Sample preparation ..... 95
11.3.2 Sample assaying ..... 95
11.3.3 Specific gravity ..... 96
11.4 Quality Assurance and Quality Control (QA/QC) Protocols ..... 98
11.4.1 Certified reference materials ..... 100
11.4.2 Blank samples ..... 101
11.4.3 Coarse duplicates ..... 102
11.4.4 Check assays ..... 104
11.5 Opinion on Adequacy of Sample Preparation, Security and Assay Procedures ..... 10412. DATA VERIFICATION ..... 105
12.1 Historical Database (Previous Owners) ..... 105
12.2 Validation of Current Work ..... 106
12.3 Conclusion ..... 107
13. MINERAL PROCESSING AND METALLURGICAL TESTING ..... 108
13.1 Mineral Processing at LaRonde Complex ..... 108
13.2 Metallurgical Testwork at LaRonde Complex ..... 110
13.2.1 LaRonde metallurgical testwork ..... 111
13.2.2 LaRonde and LZ5 cyanide destruction testwork ..... 113
13.2.3 LaRonde and LZ5 dewatering testwork ..... 113
13.2.4 LZ5 metallurgical testwork ..... 113
13.3 Mills Metals Recoveries ..... 114
13.3.1 LaRonde mill ..... 114
13.3.2 Leaching and CIP ..... 117
13.3.3 Goldex pyrite/gold concentrate (TCGO) in LaRonde mill ..... 119
13.3.4 LZ5 ore in LaRonde mill ..... 120
13.3.5 LZ5 mill ..... 120
14. MINERAL RESOURCE ESTIMATES ..... 121
14.1 Methodology ..... 121
14.2 Drill Hole Database ..... 122
14.2.1 QP specific validations in 2022 ..... 122
14.3 Geological Models ..... 123
14.4 Voids Model ..... 123
14.5 High-Grade Capping ..... 124
14.6 Compositing ..... 126
14.7 Specific Gravity (SG) and Density Data ..... 127
14.8 Variography and Search Ellipsoids ..... 129
14.9 Block Modelling ..... 133
14.10 Grade Estimation ..... 134
14.11 Validation of the Grade Estimation ..... 136
14.11.1 Visual validation ..... 136
14.11.2 Statistical validation ..... 138
14.11.3 Interpolation method comparison ..... 139
14.12 Mineral Resource Classification ..... 139
14.13 Economic Parameters (Cut-Off Grades) ..... 140
14.14 Constraining Surfaces and Volumes ..... 141
14.15 Mineral Resource Estimate ..... 143
15. MINERAL RESERVE ESTIMATES ..... 147
15.1 Reserve Block Model ..... 147
15.2 Methodology ..... 147
15.3 Mineable Shape Optimization (MSO) ..... 147
15.3.1 Summary of economic parameters ..... 148
15.3.2 Cut-off grades (NSR and gold) ..... 148
15.3.3 MSO parameters ..... 150
15.3.4 MSO visual validation ..... 150
15.4 Mineral Reserve Classification ..... 150
15.5 Underground Mining Plan Design ..... 153
15.6 Modifying Factors: Dilution and Mining Recovery ..... 153
15.7 Mineral Reserves ..... 157
15.8 Tonnage and Grade Reconciliation versus Mineral Reserves ..... 161
15.8.1 Reconciliation of stopes production versus Mineral Resource block model with CMS ..... 161
15.9 Sensitivity of Mineral Reserves to Gold Prices ..... 167
16. MINING METHODS ..... 168
16.1 Production Rate and Expected Life of Mine ..... 16816.1.1 LaRonde Mine ..... 168
16.1.2 LZ5 Mine ..... 169
16.2 Requirement for Development ..... 169
16.2.1 LaRonde Mine ..... 169
16.2.2 LZ5 Mine ..... 170
16.3 Backfill ..... 170
16.3.1 LaRonde Mine ..... 170
16.3.2 LZ5 Mine ..... 171
16.4 Mining Fleet and Machinery ..... 171
16.4.1 LaRonde Mine ..... 171
16.4.2 LZ5 Mine ..... 171
16.5 Geotechnical Parameters ..... 172
16.5.1 LaRonde Mine ..... 172
16.5.2 LZ5 Mine ..... 175
16.6 Mine Ventilation ..... 176
16.6.1 LaRonde Mine ..... 176
16.6.2 LZ5 Mine ..... 177
16.7 Mine Dewatering and Drainage ..... 177
16.7.1 LaRonde Mine ..... 177
16.7.2 LZ5 Mine ..... 178
17. RECOVERY METHODS ..... 179
17.1 Metallurgical Processes and Flowsheet at LaRonde Mill ..... 179
17.1.1 Crushing ..... 181
17.1.2 Grinding ..... 181
17.1.3 Copper flotation ..... 182
17.1.4 Zinc flotation ..... 182
17.1.5 Leaching and CIP ..... 182
17.1.6 Stripping and electrowinning ..... 182
17.1.7 Paste fill and cyanide destruction ..... 182
17.1.8 Residue filtration plant and preparation for dry stack ..... 183
17.1.9 Chemical Consumption ..... 186
17.2 Metallurgical Processes and Flowsheet at LZ5 Mill ..... 187
17.2.1 Crushing ..... 190
17.2.2 Grinding ..... 190
17.2.3 Leaching and CIL ..... 190
17.2.4 Stripping and electrowinning ..... 190
17.2.5 Paste fill ..... 190
17.2.6 Chemical Consumption ..... 190
17.3 Energy Management ..... 191
17.4 Water Management ..... 191
18. PROJECT INFRASTRUCTURE ..... 192
18.1 Mine Infrastructure ..... 192
18.1.1 LaRonde Mine ..... 192
18.1.2 LZ5 Mine ..... 195
18.2 Milling Facilities at LaRonde Complex ..... 196
18.3 Tailings management area and water treatment plants ..... 197
19. MARKET STUDIES AND CONTRACTS ..... 200
19.1 Marketing ..... 200
19.1.1 Doré ..... 200
19.1.2 Copper concentrate and zinc concentrate ..... 200
19.1.3 Marketing contracts ..... 200
19.2 Material supplier contracts ..... 200
20. ENVIRONMENTAL STUDIES, PERMITTING, AND SOCIAL \& COMMUNITY IMPACT ..... 202
20.1 Environmental Studies ..... 20220.2 Impact and Site Monitoring ..... 202
20.3 Vibrations and Air Overpressure ..... 205
20.4 Noise ..... 205
20.5 Final effluent ..... 206
20.6 Groundwater ..... 206
20.7 Solid and Hazardous Waste Management ..... 206
20.8 Spills ..... 207
20.9 Greenhouse Gas Emissions ..... 207
20.10 Emergency Response Plan ..... 207
20.11 Waste Rock Management ..... 207
20.12 Tailings Management ..... 207
20.12.1 General ..... 207
20.12.2 Tailings deposition ..... 208
20.12.3 Geotechnical investigation and monitoring. ..... 209
20.12.4 Overall stability of the tailings storage facility ..... 209
20.13 Water Management ..... 209
20.14 Permitting for LaRonde Complex ..... 210
20.15 Notices of Non-Compliance ..... 210
20.16 Community Relations ..... 210
20.16.1 Good Neighbour Framework ..... 211
20.16.2 Other local communication activities ..... 214
20.16.3 First Nation Collaboration Agreement ..... 215
20.17 Closure and Reclamation ..... 215
20.17.1 Closure and reclamation plan ..... 215
20.17.2 Closure and reclamation costs ..... 216
21. CAPITAL AND OPERATING COSTS ..... 218
21.1 Capital Cost (CAPEX) Estimates ..... 218
21.2 Mine Operating Cost (OPEX) Estimates ..... 218
21.2.1 LaRonde Mine ..... 218
21.2.2 LZ5 Mine ..... 218
22. ECONOMIC ANALYSIS ..... 223
23. ADJACENT PROPERTIES ..... 224
24. OTHER RELEVANT DATA AND INFORMATION ..... 225
25. INTERPRETATIONS AND CONCLUSIONS ..... 226
26. RECOMMENDATIONS ..... 228
27. REFERENCES ..... 229

# LIST OF FIGURES 

Figure 4.1 - Location and property boundaries of LaRonde Complex, Province of Quebec, as at December 31, 2022 ..... 30
Figure 4.2 - Map of active mining titles within the LaRonde Complex Property in 2022, showing mining lease and claim numbers ..... 32
Figure 5.1 - Surface plan map of LaRonde Complex as at December 31, 2022 ..... 38
Figure 5.2 - Infrastructure and landscape: Penna Shaft headframe and main office; Tailings storage facility; Mineral processing plant including LaRonde mill and LZ5 mill; LZ5 open pit \& portal, paste plant and mobile equipment garage ..... 39Figure 6.1 - Schematic composite longitudinal view (looking north) of underground mining infrastructure, historical production areas and locations of mineral resources and mineral reserves at LaRonde Complex at year-end 2022 ..... 42
Figure 7.1 - Regional geology of Doyon-Bousquet-LaRonde mining camp (from Mercier-Langevin et al., 2017) ..... 60
Figure 7.2 - Detailed surface geology of LaRonde Mine property at LaRonde Complex (from Mercier-Langevin, 2005) ..... 62
Figure 7.3 - Isometric view of mineralized lenses at LaRonde Complex, looking northwest ..... 63
Figure 7.4 - Cross section of mineralized zones at LZ5 Mine (section 6850E looking west, $\pm 20$ m) ..... 65
Figure 7.5 - Photographs of mineralized zones at Bousquet No. 1 and Bousquet No. 2 ..... 66
Figure 7.6 - Cross section 5810E ( $\pm 20 \mathrm{~m}$ ) of Massive Zone (Footwall and Hangingwall) at Bousquet No. 1 (LP1) from Level 131 to Level 149, looking west ..... 68
Figure 7.7 - Cross section 6800E ( $\pm 20 \mathrm{~m}$ ) of horizons of Zone 6, Zone 20 North (Domain or Zone 19N, 19, 20S) and Zone 20 South (Domain Zone 21) at the Penna Shaft from Level 245 to Level 311 (looking west) ..... 72
Figure 7.8 - Photographs of mineralization in Zone 20 North. ..... 73
Figure 8.1 - Schematic illustration of the geological setting and hydrothermal alteration of a gold- rich high-sulphidation volcanogenic massive sulphide hydrothermal system ..... 75
Figure 8.2 - Schematic east-west section showing simplified stratigraphy and possible pre- deformation structure of mineralized hydrothermal systems in LaRonde-Bousquet 2 gold-rich VMS complex ..... 76
Figure 8.3 - Simplified stratigraphic columns of DBL mining camp showing stratigraphic position of main mineralized zones ..... 77
Figure 10.1 - Composite longitudinal section showing all drill holes on the Property including validated diamond drill holes used in 2022 Mineral Resource Estimate ..... 82
Figure 10.2 - Plan view and cross-section showing diamond drill holes and pierce points below 2.45 km depth in Zone 20 North at LaRonde Mine ..... 89
Figure 10.3 - Plan view and cross-section showing diamond drill holes and pierce points in mineralized zones at LZ5 Mine ..... 90
Figure 10.4 - Example of longitudinal section showing pierce points by year in Zone 5 at LZ5 Mine ..... 91
Figure 11.1 - Performance and distribution of all CRM gold results expressed in Z-score relative to expected value for LaRonde Complex (November 1, 2019 to October 31, 2022) ..... 101
Figure 11.2 - Performance of blanks for gold at LaRonde Complex (November 1, 2019 to October 31, 2022) ..... 102
Figure 11.3 - Scatter plot of coarse duplicates for gold at LaRonde Complex (November 1, 2019 to October 31, 2022) ..... 103
Figure 11.4 - Scatter plot of check assays (Bourlamaque Laboratories) versus original assays of pulp duplicates for gold at LaRonde Complex (November 1, 2019 to October 31, 2022) ..... 103Figure 13.1 - Processing plant at LaRonde Complex, showing locations of major mill components (looking northwest) ..... 109
Figure 13.2 - Processing plant at LaRonde Complex, showing locations of major mill components (looking south) ..... 109
Figure 13.3 - Composite longitudinal section of LaRonde Complex (looking north) showing sampling locations for metallurgical testwork ..... 110
Figure 13.4 - Gold recovery rates in copper concentrate at LaRonde mill ..... 115
Figure 13.5 - Silver recovery rates in copper concentrate at LaRonde mill ..... 115
Figure 13.6 - Copper recovery rates in copper concentrate at LaRonde mill ..... 116
Figure 13.7 - Zinc recovery rates in zinc concentrate at LaRonde mill ..... 116
Figure 13.8 - Gold recovery rates in zinc concentrate at LaRonde mill ..... 117
Figure 13.9 - Gold reject in precious metals circuit (monthly) ..... 118
Figure 13.10 - Silver reject in precious metals circuit (monthly) ..... 118
Figure 13.11 - Liquid silver reject in precious metals circuit (monthly) ..... 119
Figure 13.12 - TCGO, gold reject versus gold feed grade at LaRonde mill ..... 119
Figure 13.13 - Gold recovery rates at LZ5 mill ..... 120
Figure 14.1 - Mineralized and void solids for the deposits on the Property ..... 124
Figure 14.2 - An example of grade capping treatment based on log probability curve, Domain 19W ..... 125
Figure 14.3 - Example of a sample length frequency histogram showing a majority of sample lengths at 1.5 m for Zone 5 ..... 127
Figure 14.4 - Example of histogram for measured SG for samples of LZ5 inside the resource (MSO) envelope, argument to fix density at $2.9 \mathrm{~g} / \mathrm{cm}^{3}$ ..... 128
Figure 14.5 - Example of experimental gold variogram for Zone 3 HW of LZ5 deposit: first row shows strike, dip and plunge continuity and second row shows NormalScores variograms along major, semi-major and minor axes ..... 131
Figure 14.6 - 3D view example of the search ellipse orientation based on variography domains of Zones 19, 19N, 19W and 20S in LaRonde deposit ..... 133
Figure 14.7 - Validation of Zone 5 area gold block model, comparing drill hole composites (coloured drill hole traces) and block model grade values (coloured cell) with the same gold grade legend (north-south section 6700E, looking west). ..... 137
Figure 14.8 - Validation of Zone 20 North copper block model, comparing drill hole composites (coloured drill hole traces) and block model grade values (coloured cell) with the same copper grade legend (plan view Level 275) ..... 138
Figure 14.9 - Swath plot in easting of the LP1 - Massive Zone HW block model, comparing OK, ID2 and NN block model gold grade values ..... 139
Figure 15.1 - Example of validation of MSO solids generated at specific COG and blocks of the block model above the COG in the isometric view of Level 314 at Zone 20 North at C\$198 NSR COG ..... 152Figure 15.2 - Isometric view (looking northeast) of Zone 20 North, levels 311 to 335, West mine, showing examples of MSO solids split into stope and development solids ..... 153
Figure 15.3 - Isometric view of categorized MSO solids and voids model, based on the December 31, 2022, Mineral Resource and Mineral Reserve estimate. ..... 157
Figure 16.1 - Illustration of the location of high stress environments on Level 272 and below Level 305 at LaRonde Mine ..... 174
Figure 16.2 - Illustration of stress changes in a primary-secondary mining approach versus a pillarless mining approach ..... 175
Figure 16.3 - Diagram of the ventilation network at LZ5 Mine, showing the ramp and raises ..... 177
Figure 16.4 - Schematic diagram of current dewatering network at LZ5 Mine ..... 178
Figure 17.1 - Flowsheet for LaRonde mill (7,200 tpd milling rate) ..... 180
Figure 17.2 - Dry stack flowsheet for LaRonde Complex ..... 184
Figure 17.3 - 3D representation of the dry stack mill at LaRonde Complex ..... 185
Figure 17.4 - Dry stack, filter press floor ..... 185
Figure 17.5 - Exterior view of dry stack mill under construction at LaRonde Complex ..... 186
Figure 17.6 - Flowsheet for LZ5 mill (2,000 tpd milling rate) ..... 189
Figure 18.1 - Section view of the main underground infrastructure at LaRonde Mine ..... 194
Figure 18.2 - Aerial view of LZ5 Mine site highlighting major surface infrastructure ..... 195
Figure 18.3 - Diagram of LZ5 Mine's 2022 LOM underground infrastructure and stopes (longitudinal view, looking north) ..... 196
Figure 18.4 - Aerial view of the milling facilities at LaRonde Complex, highlighting major surface infrastructure ..... 197
Figure 18.5 - Aerial view of the tailings management area at LaRonde Complex, highlighting major components. ..... 198
Figure 18.6 - Aerial view of ventilation and tailings infrastructure at surface at LaRonde Complex, highlighting major components ..... 198
Figure 18.7 - Aerial view of the water treatment infrastructure at LaRonde Complex, highlighting major components ..... 199
Figure 20.1 - Locations at LaRonde Complex's tailing storage facility of vibrating wire piezometers, survey monuments, inclinometers and monitoring wells (piezometers) installed on the tailings and water storage areas to monitor dike stability ..... 204
Figure 20.2 - Location of geophones installed in the communities near the Westwood, LaRonde and Goldex mining operations ..... 205
Figure 20.3 - Locations of the permanent noise monitoring stations near LaRonde Complex ..... 206

# LIST OF TABLES 

Table 1.1 - Mineral Resource Estimate at LaRonde Complex, exclusive of Mineral Reserves, as at December 31, 2022 ..... 6Table 1.2 - Mineral Resource Estimate for LaRonde deposit, exclusive of Mineral Reserves, as at December 31, 2022 ..... 7
Table 1.3 - Mineral Resource Estimate for LZ5 deposit, exclusive of Mineral Reserves, as at December 31, 2022 ..... 8
Table 1.4 - Economic assumption parameters used in 2022 MRMR ..... 9
Table 1.5 - Gold Mineral Reserve estimate at LaRonde Complex, as at December 31, 2022 ..... 11
Table 1.6 - Mineral Reserve estimate for LaRonde Deposit, as at December 31, 2022 ..... 12
Table 1.7 - Mineral Reserve estimate for LZ5 Deposit, as at December 31, 2022 ..... 13
Table 1.8 - Mineral Reserve sensitivity for the LaRonde Complex ..... 13
Table 1.9 - Closure costs for LaRonde Mine area ..... 20
Table 1.10 - Closure costs for Bousquet area (LZ5 Mine) ..... 20
Table 2.1 - Report responsibilities of each Qualified Person ..... 24
Table 2.2 - List of abbreviations and acronyms ..... 25
Table 2.3 - List of symbols and units of measurements ..... 27
Table 2.4 - Conversion factors for measurements ..... 27
Table 4.1 - Claims and mining leases at LaRonde Complex ..... 33
Table 4.2 - Public surface rights at LaRonde Complex ..... 34
Table 6.1 - Activity at LaRonde Complex since 1924, showing exploration and production periods, and property acquisitions / consolidations ..... 41
Table 6.2 - Summary of historical gold, silver and base metals production at LaRonde Complex (1978-2022) ..... 43
Table 6.3 - Historical exploration and mining at LaRonde property (1937-2022) ..... 45
Table 6.4 - LaRonde Mine milled annual production to December 31, 2022 ..... 48
Table 6.5 - LaRonde Mine cumulative production by shaft to December 31, 2022 ..... 49
Table 6.6 - Historical exploration and mining at Bousquet property (1937-2002) ..... 50
Table 6.7 - Bousquet No. 1 Mine milled production summary to December 31, 2022 ..... 52
Table 6.8 - Bousquet No. 2 Mine milled production summary to December 31, 2022 ..... 53
Table 6.9 - Total Bousquet property milled production summary to December 31, 2022 ..... 54
Table 6.10 - Summary of exploration programs at El Coco property (1963-2012) ..... 54
Table 6.11 - Summary of exploration programs on Terrex property (1924-2022) ..... 56
Table 6.12 - Summary of exploration programs at Ellison property (1936-2022) ..... 58
Table 10.1 - Summary of drilling at LaRonde Complex to December 31, 2022 ..... 81
Table 10.2 - Drilling contractors and drilling campaigns at LaRonde Complex (1929 to 2022) ..... 83
Table 11.1 - Summary of gold, silver, base metals and SG analysis at LaRonde Complex ..... 97
Table 11.2 - Specific gravity by rock type (field names) and percentage of sulphides in the rock unit at LaRonde Complex ..... 98Table 11.3 - Summary of the QA/QC protocols at LaRonde Complex ..... 99
Table 11.4 - Summary of insertion rates for QA/QC samples at LaRonde Complex between November 1, 2021 and October 31, 2022 ..... 99
Table 11.5 - Distribution of number of assays per laboratory and drill hole type for LaRonde Complex from November 1, 2021 to October 30, 2022 ..... 100
Table 13.1 - Metallurgical test results for gold, silver, copper and zinc at LaRonde Complex ..... 111
Table 13.2 - Metallurgical test results for gold, silver, copper and zinc at LZ5 Mine ..... 114
Table 14.1 - Drill hole database summary by deposit ..... 122
Table 14.2 - An example of capping treatment on Zone 20 North block model area based on CV criteria ..... 125
Table 14.3 - Summary of capping grades for drill hole samples by zone or domain ..... 126
Table 14.4 - Summary of densities by zone or domain ..... 129
Table 14.5 - List of geostatistical reports for the Property ..... 130
Table 14.6 - Search parameters for gold ..... 132
Table 14.7 - Datamine Block Model properties at the Property ..... 135
Table 14.8 - Summary of interpolation parameters typically used for gold grade estimation at the Property ..... 136
Table 14.9 - Validation of basic statistics of interpolated blocks and composite points (Au of LP1 - Massive Zone) by Domains ..... 138
Table 14.10 - Common drill hole spacing criteria for mineral resources classification ..... 140
Table 14.11 - Economic assumptions parameters used in 2022 MRE ..... 140
Table 14.12 - Input parameters used to determine the COG at LaRonde deposit ..... 142
Table 14.13 - Input parameters used to determine the COG at LZ5 deposit ..... 142
Table 14.14 - Mineral Resource Estimate for LaRonde Complex as at December 31, 2022 (exclusive of Mineral Reserves) ..... 144
Table 14.15 - Mineral Resource Estimate for LaRonde deposit, as at December 31, 2022 (exclusive of Mineral Reserves) ..... 145
Table 14.16 - Mineral Resource Estimate for LZ5 deposit, as at December 31, 2022 (exclusive of Mineral Reserves) ..... 146
Table 15.1 - Summary of MSO optimization parameters based on Mineral Reserves, as at December 31, 2022 ..... 151
Table 15.2 - Realized dilution and mining recovery estimated from CMS interpretations for LaRonde deposit per year (FW for footwall, HW for hanging wall) ..... 155
Table 15.3 - Realized dilution and mining recovery estimated from CMS interpretations for LZ5 deposit per year ..... 156
Table 15.4 - Mineral Reserve estimate for LaRonde Complex, as at December 31, 2022 (gold only) ..... 158
Table 15.5 - Mineral Reserve estimate for LaRonde deposit, as at December 31, 2022 ..... 159
Table 15.6 - Mineral Reserve estimate for LZ5 deposit, as at December 31, 2022 ..... 160Table 15.7 - Annual reconciliation between Mineral Reserves and production, reconciled with milling results for LaRonde deposit ..... 163
Table 15.8 - Annual reconciliation between Mineral Reserves and production, reconciled with milling results for LZ5 deposit ..... 164
Table 15.9 - Annual reconciliation between Actual Ore Mined from stopes and Mineral Resource block model interrogated within as-mined CMS shapes for LaRonde deposit ..... 165
Table 15.10 - Annual reconciliation between Actual Ore Mined from stopes and Mineral Resource block model interrogated within as-mined CMS shapes for LZ5 deposit ..... 166
Table 15.11 - Mineral Reserve sensitivity for LaRonde deposit ..... 167
Table 15.12 - Mineral Reserve sensitivity for LZ5 deposit ..... 167
Table 16.1 - 2023 LOM production at LaRonde Mine (2023-2036) ..... 169
Table 16.2 - 2023 LOM production at LZ5 Mine (2023-2032) ..... 169
Table 16.3 - 2023 LOM development at LaRonde Mine (2023-2036) ..... 170
Table 16.4 - 2023 LOM development at LZ5 Mine (2023-2032) ..... 170
Table 16.5 - Mining fleet and machinery utilized at LaRonde Mine ..... 171
Table 16.6 - Mining fleet and machinery utilized at LZ5 Mine ..... 172
Table 16.7 - Intact rock properties at LaRonde Mine at Level 290 ..... 173
Table 16.8 - Rock parameters by domain at LZ5 Mine ..... 176
Table 17.1 - Summary of performance at LaRonde mill (2010-22) ..... 179
Table 17.2 - Criteria for LaRonde mill ..... 181
Table 17.3 - Average consumption of mill reagents and consumables in 2022 at LaRonde Complex ..... 186
Table 17.4 - Summary of Lapa and LZ5 gold production (2013-22) ..... 188
Table 17.5 - Criteria for LZ5 mill ..... 188
Table 17.6 - Average consumption of mill reagents and consumables at LZ5 mill in 2022 ..... 191
Table 19.1 - Material supplier contracts exceeding C\$5M per year at LaRonde Complex ..... 201
Table 20.1 - Tailings characteristics for LaRonde Mine and LZ5 Mine ..... 208
Table 20.2 - Closure costs for LaRonde Mine area ..... 217
Table 20.3 - Closure costs for Bousquet area (LZ5 Mine) ..... 217
Table 21.1 - Capital costs (CAPEX) at LaRonde Complex (2023 to 2036) as estimated in 2023 LOM (C\$M) ..... 219
Table 21.2 - Operating costs (OPEX) at LaRonde Complex (2023 to 2036) as estimated in 2023 LOM (000 C\$) ..... 220
Table 21.3 - Operating costs (OPEX) at LaRonde Mine (2023 to 2036) as estimated in 2023 LOM (000 C\$) ..... 221
Table 21.4 - Operating costs (OPEX) at LZ5 Mine (2023 to 2036) as estimated in 2023 LOM (000 C\$) ..... 222

[[@~@]]
# 1 Summary

[[%~%]]
## 1.1 Overview

The LaRonde Division of Agnico Eagle Mines Limited prepared this technical report (the "Technical Report") to present and support the results of the updated Mineral Resource and Mineral Reserve estimates to December 31, 2022 (the "2022 MRMR"), and to summarize the current underground mining operations of the LaRonde Complex Property (the "Property"). The LaRonde Complex is 100\% owned by Agnico Eagle Mines Limited ("Agnico Eagle", "AEM" or the "Issuer").
The Property, located near the city of Rouyn-Noranda (Cadillac district) in the Province of Quebec, hosts the LaRonde Complex which is comprised of the LaRonde Mine and LaRonde Zone 5 (LZ5) Mine, which are both underground operations. LaRonde Complex forecasts annual gold production of up to 325,000 ounces during the next seven years and then declining toward the end of the underground mine lives.
The commercial production at the LaRonde Mine began in 1988 and production has been maintained since then with successful exploration programs leading to expansion from LaRonde Shaft \#1 to LaRonde Shaft \#2 and then to the current Penna Shaft (Shaft \#3) and Shaft \#4 operation.
The LZ5 Mine is the result of the acquisition of the former Bousquet Mining Complex by Agnico Eagle in 2003. Previous owners (Lac Minerals and Barrick Gold) operated Bousquet Complex from 1978 to its closure in 2002. After a positive internal pre-feasibility study in 2016, LZ5 Mine construction was approved and commercial production began in June 2018. The Lapa mill (renamed LZ5 mill), located adjacent to the LaRonde mill on the Property, started to process ore from the LZ5 Mine at a rate of 2,000 tpd, after the closure of the Lapa Mine at the end of 2017.
The Technical Report was prepared by David Pitre, P.Eng., P.Geo. (OIQ \# 121977, OGQ \#735); Vincent Dagenais, P.Eng. (OIQ \#5054313); Devin Wilson, P.Eng. (OIQ \#146530); Claude Bolduc, P.Eng. (OIQ \# 133200) and Yanick Létourneau, P.Eng. (OIQ \#116279). All are Qualified Persons ("QPs") as defined in National Instrument 43-101 ("NI 43-101") and are not independent as they are employed by Agnico Eagle's LaRonde Division and work full time on the Property.

[[%~%]]
## 1.2 Property Description And Location

The Property is located within the municipalities of Preissac and Cadillac, approximately 50 km west of the city of Val-d'Or and 45 km east of the city of Rouyn-Noranda, in the Province of Quebec, Canada. The approximate centre of the Property is at Latitude $48^{\circ} 15^{\prime} \mathrm{N}$ and Longitude $78^{\circ} 16^{\prime} \mathrm{W}$ and the approximate UTM coordinates are $690,850 \mathrm{~m} \mathrm{E}, 5,347,485 \mathrm{~m} \mathrm{~N}, \mathrm{NAD} 83$, Zone 17.

The Property consists of a contiguous block comprising five mining leases and 63 mining claims for a total of 3,324.86 hectares. All claims and mining leases are held 100\% by Agnico Eagle Mines Limited, and the Property is subject to various royalty agreements and encumbrances.

[[%~%]]
## 1.3 Accessibility, Local Resources, Climate, Physiography And Infrastructure

The Property can be accessed from Val-d'Or in the east and from Rouyn-Noranda in the west, each of which is located approximately 60 km from the LaRonde Complex via Quebec provincial Highway 117. The LaRonde Complex is situated approximately 2 km north of Highway 117 on Quebec regional Highway 395, which passes through the middle of the Property.The Abitibi region of northwestern Quebec is known as a mining region and it has sufficient experienced mining personnel to staff the Company's operations in the Abitibi region. This region also hosts numerous suppliers and fabricators for the mining industry.
All of the power requirements for the LaRonde Complex are supplied by Hydro-Québec through connections to its main power transmission grid. Water used in the LaRonde Mine's operations is sourced from Lac Preissac/Chassignolle and water for the LZ5 Mine operations is sourced from the Bousquet River, with water transported by pipelines.
The Abitibi region has a continental climate with an average annual precipitation of 927 mm . A boreal-type forest covers much of the undeveloped portions of the Property, and the topography is relatively flat, consisting of plains with a few small hills and maximum relief of about 40 metres.
Surface mining, milling and tailings infrastructure cover roughly 60\% of the LaRonde Complex leases. Since 2017, additional facilities have been constructed at the LZ5 Mine site including a paste plant, small tank farm, mobile equipment garage and an electrical substation. The LZ5 Mine tailings are directed from the LZ5 mill plant to the LaRonde tailings storage facility ("TSF"), and water is treated at the LaRonde water treatment plant before discharge.

[[%~%]]
## 1.4 History

The Property's mining history extends more than 80 years from the late 1930s to the present day. Its history reflects the evolution of the Doyon-Bousquet-LaRonde mining camp and the wider Cadillac mining district. The current limits of the Property cover and overlap many historical mining and exploration properties, and the current Property is the product of several consolidation phases.
The Property hosts five historical underground mines: Bousquet No. 1 (now related to current LZ5 operation); Bousquet No. 2; Dumagami / LaRonde Shaft \#1; LaRonde Shaft \#2; and the Penna Shaft which is still in production. In modern times, gold production on the Property has been continuous since 1978, and a series of small open pits have also been mined by owners.
As at the end of 2022, gold production from the Property totals 78.2 million tonnes grading at an average of $4.63 \mathrm{~g} / \mathrm{t}$ gold, for 10.8 million ounces of payable gold.
From 1974 to 2002, the Bousquet property ownership changed from Long Lac Exploration Ltd. to Lac Minerals Ltd. and then Barrick Gold. Ownership then passed to Agnico Eagle Mines Ltd. in 2003. In 2002, Agnico Eagle also acquired the Ellison property from Yorbeau Resources Inc.

Since 2003, Agnico Eagle Mines Ltd. has held a 100\% ownership in all the properties at the LaRonde Complex.

[[%~%]]
## 1.5 Geology And Mineralization

The LaRonde Complex forms part of the Doyon-Bousquet-LaRonde ("DBL") Mining Camp. The DBL Mining Camp is located in the southeastern portion of the Archean-age ( 2.7 Ga ) Abitibi Subprovince, which can be characterized as a typical greenstone belt. The Abitibi Subprovince is located in the southeastern part of the Superior Province of the Canadian Shield. The most important regional structure is the Larder Lake-Cadillac Deformation Zone which defines the contact between the Abitibi and Pontiac subprovinces and is located approximately 2 km the south of the Property.
The geology that underlies the LaRonde Complex consists of three east-west trending, steeply south-dipping and generally southward facing regional lithological units (geological groups). The units are, from north to south: the Kewagama Group, consisting of thick band of interbeddedwacke; the Blake River Group, which is the volcanic assemblage that hosts all the known economic mineralization on the Property; and the Cadillac Group, consisting of thick bands of wacke interbedded with pelitic schist and minor iron formation.
Rocks of the mine sequence in the Doyon-Bousquet-LaRonde mining camp are part of the upper part of the 2,703 to 2,694 Ma Blake River Group. The regional sequence shows a basaltic flows basement (Hébécourt Formation) overlain by andesitic to rhyolitic flows and fragmental rocks associated with local volcanic centres (Bousquet Formation, Lower and Upper Members).
Mineralization in the LaRonde Complex deposits consist of an assemblage of disseminated to massive sulphide lenses that are stacked within the Upper Member of the Bousquet Formation. These lenses are typically polymetallic with a pyrite $\pm$ sphalerite-chalcopyrite-galena-pyrrhotitegold assemblage. The lenses are stratiform, showing the same east-west dipping south attitude as the host rocks. The principal deformation affecting ore lenses is the regional north-south flattening (D2) with a south-southwest plunging extension, giving an elongated tabular form to all lenses. Several mineralized horizons are currently known which hosts lenses that range in size from 20,000 tonnes up to over 60 million tonnes.

[[%~%]]
## 1.6 Deposit Types

Sulphide lenses in the DBL mining camp are interpretated as gold-rich volcanic massive sulphidetype ("VMS") deposit. The synvolcanic mineralization on the Property occurs as two main styles: as gold-rich polymetallic massive sulphide lenses in the case of the LaRonde deposit (LaRonde Penna, Bousquet \#2-Dumagamami); and as gold-rich sulphide veins, breccia, stockworks and dissemination ore zones in the case of the LZ5 deposit (former Bousquet \#1). Sulphide veins and stockworks can be hosted in mafic to felsic host rocks. Both mineralization styles occur as single lenticular bodies.

[[%~%]]
## 1.7 Exploration And Drilling

Exploration programs conducted by Agnico Eagle at the LaRonde Complex since the late 2000s have focused mainly on underground and surface core drilling.
Since the first gold production on the LaRonde property in 1988, Agnico Eagle drilling programs have focused on areas in close proximity to mining operations (i.e., LaRonde Shaft \#1, LaRonde Shaft \#2, Penna Shaft, LaRonde Shaft \#4 and LZ5) and on adjacent properties.
From 2010 to the end of 2022, 3,049 holes (or wedge holes) were drilled for a total of 496,328 m by the LaRonde Division, and the average core recovery rates exceeded $99 \%$.

All drilling campaigns by Agnico Eagle at the LaRonde Complex during the past 22 years have been logged in Datamine's DHLogger logging software. All the databases for the Property include the collar information, downhole survey data, assay results and geological description (lithology, alteration, structure, mineralization, mineralogy, texture, vein and Rock Quality Designation data).

[[%~%]]
## 1.8 Sample Analyses

From 2014 to the present, the delineation diamond drill core samples and over $80 \%$ of the definition drill core samples have been assayed at Agnico Eagle's LaRonde Laboratory located on the Property. Since 1999, 75\% of the exploration and conversion diamond drill core samples shipped from the LaRonde Complex have been sent to external independent laboratories, and 99\% of these samples are assayed at ALS Global Group's Val-d'Or Geochemistry facilities and at Bourlamaque Assay Laboratories Limited, both located in Val-d'Or, Quebec.Samples from the LaRonde Mine are analyzed for gold, silver, copper, zinc, lead and specific gravity, while samples from the LZ5 Mine are generally only analyzed for gold. However, when required at LZ5 Mine, silver, copper, zinc, lead and SG are also analyzed.

[[%~%]]
## 1.9 Mineral Processing And Metallurgical Testing

The LaRonde processing plant (formerly named Dumagami) was commissioned in 1988 at a nominal capacity of 2,000 tpd. Initially, the plant consisted of crushing, grinding, gravity, cyanidation and carbon in pulp ("CIP") precious metals recovery circuits followed by an adsorption, desorption and recovery ("ADR") circuit. Successive expansions took place in the early 2000s in order to introduce flotation circuits that allowed for the recovery of base metals such as copper, zinc and lead. In addition, the CIP circuit was replaced by a Merrill-Crowe circuit to compensate for the increase in the silver to gold ratio values varying from 10 to 20 and thus allowing for the optimal recovery of the precious metals.
A first expansion to 3,600 tpd occurred in 2000, followed by an expansion to 5,000 tpd in 2001 and finally to 7,000 tpd in 2002.
In 2008, the processing of bulk pyrite \& gold flotation concentrate from the Company's Goldex Mine began. This flotation concentrate is transported from Goldex to LaRonde by tanker truck and is pumped directly into the cyanidation circuit of the LaRonde processing plant for recovery of gold.

The LZ5 processing plant (formerly named Lapa) was initially used to process ore from the Company's Lapa Mine in the region. This plant consisted of crushing, grinding, gravity, cyanidation and CIP gold recovery circuit followed by an ADR circuit. Start-up occurred in early 2008 with Lapa ore at a milling rate of 1,500 tpd. Nominal capacity was increased to 1,750 tpd following years of optimization. The Lapa Mine ceased operations in 2018, which allowed for the processing of ore from the LZ5 Mine at the Lapa/LZ5 processing plant since 2019. Nominal capacity for processing LZ5 ore has been optimized to 2,000 tpd.
The LaRonde and LZ5 processing plants were collectively renamed the "LaRonde Complex" processing plant in 2019 with the start of the processing of LZ5 ore. This name change reflected the various new synergies of shared services such as maintenance, a centralized control room, and a regional assay laboratory that have allowed for further optimization of operating costs. As a result, nominal capacities of the two processing plants are now regrouped into a global complex capacity of 8,200 tpd, allowing ore from zones at either of the LaRonde and LZ5 mines to be treated in one of the two processing plants according to the particularities of the ore treated.
Metallurgical testwork has been carried out on the LaRonde and LZ5 orebodies that will be mined during approximately the next 10 years, with the selection of samples for LaRonde and LZ5 ore carried out jointly by the Geology and Metallurgy teams of the LaRonde Complex. The Technical Report is based on the hypothesis that the metallurgical properties of the entire LaRonde, LZ5 and Goldex deposits are comparable to those of the historical production.
When a new zone was discovered, a metallurgical lot was built to be tested by the Metallurgy team. Current LOM for the LaRonde deposit anticipates a gold recovery in the range of 90-97\% with an average of $95 \%$, silver recovery averaging $88 \%$, copper recovery averaging $83 \%$ and zinc recovery averaging $87 \%$.
Goldex gold-pyrite concentrate ("TCGO") is added to the LaRonde leaching circuit to recover the gold, thereby allowing the Goldex mill to avoid using a cyanide circuit. Teams from Goldex completed their own testwork on new ore zones at Goldex to validate the feasibility through the entire process.LZ5 ore entering the LaRonde mill is included in the mill model performance. LZ5 and LaRonde ores have the same metal performance, and the payable metal distribution is based on the material feeding the mill (tonnes and grade). Metallurgical lots of LZ5 are tested with LaRonde metallurgical lots to validate the synergy between the two sets of ores.
Current LOM anticipates LZ5 gold recovery in the range of $88 \%$ to $96 \%$ and averaging $94 \%$.
Additional testwork was completed on cyanide destruction of tailing with the $\mathrm{INCO} \mathrm{SO}_{2} / \mathrm{O}_{2}$ process to validate the impacts of LZ5 ore on residence time and reagent dosage. The tests were done on three sets of ores: LaRonde, LZ5 and a mix of LaRonde and LZ5.
In 2018, trade-off studies were completed to determine the future of tailing deposition including a comparison between traditional deposition by slurry, spigot, paste and dry stack. Dry stack was selected as the best method for future tailing deposition at the LaRonde Complex. Construction of the dry stack mill was completed in 2022 with start-up in October 2022.

[[%~%]]
## 1.10 Mineral Resource Estimate

The 2022 Mineral Resource Estimate (the "2022 MRE") for the Property consists of 9 block models, all for underground mining.
The 2022 MRE was prepared by David Pitre, P. Eng., P.Geo., an employee of Agnico Eagle Mines Ltd, using all available information. These estimates rely on information acquired during Agnico Eagle's drilling programs and validated historical data. It also relies on cumulative data from previous annual production, milling, reconciliation and MRMR reports.
The effective date of the 2022 MRE is December 31, 2022.
A total of 43 mineralized zones were created and/or updated for all the deposits.
The QP responsible for this section of the Technical Report has classified the 2022 MRE as measured, indicated, and inferred mineral resources based on geological and grade continuity, data density, search ellipse criteria, drill hole density, and interpolation parameters. The QP responsible for this section of the Technical Report is of the opinion that the requirement of reasonable prospects for eventual economic extraction has been met by having a cut-off grade that uses reasonable inputs combined with constraining optimized mining shapes for the underground scenario. The mineral resource cut-off grade (gold or NSR basis) is defined and fixed at $80 \%$ of the mineral reserves cut-off grade. The 2022 MRE statement is summarized in Table 1.1 for gold and is detailed by zone in Table 1.2 and Table 1.3 along with the base metals content.Table 1.1 - Mineral Resource Estimate at LaRonde Complex, exclusive of Mineral Reserves, as at December 31, 2022

| Deposit | Category | Tonnage <br> $\mathbf{( 0 0 0} \mathbf{~ t )}$ | Gold grade <br> $\mathbf{( g / t )}$ | Gold <br> $\mathbf{( 0 0 0} \mathbf{~ o z . )}$ |
| :--: | :--: | :--: | :--: | :--: |
| LaRonde | Measured | - | - | - |
|  | Indicated | 5,959 | 2.96 | 566 |
|  | $\mathrm{M}+\mathrm{I}$ | 5,959 | 2.96 | 566 |
|  | Inferred | 2,942 | 4.91 | 464 |
| LZ5 | Measured | - | - | - |
|  | Indicated | 9,774 | 2.08 | 652 |
|  | $\mathrm{M}+\mathrm{I}$ | 9,774 | 2.08 | 652 |
|  | Inferred | 12,376 | 3.13 | 1,244 |
| LaRonde Complex Total | Measured | - | - | - |
|  | Indicated | 15,733 | 2.41 | 1,219 |
|  | $\mathrm{M}+\mathrm{I}$ | 15,733 | 2.41 | 1,219 |
|  | Inferred | 15,317 | 3.47 | 1,708 |

Mineral Resource Estimate notes:

1. The Qualified Person, as defined by NI 43-101, for the Mineral Resource Estimate, is David Pitre, P. Eng., P.Geo. The effective date of the 2022 MRE is December 31, 2022.
2. Mineral Resources are reported exclusive of Mineral Reserves. Mineral Resources are not Mineral Reserves and do not have demonstrated economic viability.
3. The Mineral Resource estimate follows CIM 2014 Definition Standards.
4. The cut-off grades were calculated using a gold price of US\$1,300/oz; a silver price of US\$18/oz; a copper price of US\$3.00/lb: a zinc price of US\$1.00/lb; an exchange rate of C\$1.30 per US\$; a mining cost varying from C\$40.62/t to C\$132.07/t (underground mining); a processing cost from of C\$25.88/t to C\$47.42/t; and a G\&A cost from C\$3.84/t to C\$38.38/t. The Mineral Resource cut-off grade (gold or NSR basis) is defined and fixed at $80 \%$ of the Mineral Reserve cut-off grade.
5. The assays were capped prior to compositing at 1.5 m .
6. The Mineral Resources were estimated using Datamine Studio RM v.1.9.36 using hard boundaries where the zone continuity is demonstrated on composited assays. The ID2 method was used to interpolate a block model. The final constraining surfaces and volumes were constructed with Datamine, or Deswik v.2022.2.623 (SO 4.1.3566) software.
7. Results are presented in-situ and exclusive of Mineral Reserves. 1.0 troy ounce $=$ metric tons $x$ grade $/ 31.1035$. Calculations used metric units (metres, tonnes, grams per tonne). The number of tonnes was rounded to the nearest thousand. Any discrepancies in the totals are due to rounding effects.
8. The QP is not aware of any known environmental, permitting, legal, title-related, taxation, socio-political, marketing or other relevant issues that could materially affect the Mineral Resource Estimate.
9. All mineral resources are reported within optimized mining shapes (MSO) and include internal dilution. Indicated resources include external dilution. Inferred resources exclude external dilution.
10. Tonnage and ounces columns are rounded to nearest thousand.Table 1.2 - Mineral Resource Estimate for LaRonde deposit, exclusive of Mineral Reserves, as at December 31, 2022

| Zone by category by mining method | Tonnage <br> $(\mathbf{t})$ | Gold grade (g/t) | Silver grade (g/t) | Copper grade (\%) | Zinc grade (\%) | Gold (oz.) | Silver (oz.) | Copper (kg) | Zinc (kg) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Indicated Mineral Resource (Underground) |  |  |  |  |  |  |  |  |  |
| LP1 - Zone 7 | 88,965 | 1.45 | 9.95 | 0.14 | 0.46 | 4,141 | 28,453 | 122,440 | 406,824 |
| LaRonde Zone 20 North | 2,145,075 | 4.28 | 17.86 | 0.17 | 1.27 | 295,216 | 1,232,043 | 3,612,871 | 27,339,359 |
| LP1 - Zone 4D | 908,421 | 1.75 | 3.39 | 0.27 | 0.22 | 51,200 | 98,949 | 2,479,611 | 1,961,334 |
| LP1 - Fringe HW and FW | 2,214,728 | 2.38 | - | - | - | 169,386 | - | - | - |
| LP1 - Massive | 601,609 | 2.40 | 4.46 | 0.05 | 0.03 | 46,455 | 86,227 | 281,208 | 158,363 |
| Total Indicated Mineral Resources | 5,958,798 | 2.96 | 7.55 | 0.11 | 0.50 | 566,399 | 1,445,672 | 6,496,131 | 29,865,881 |
| Inferred Mineral Resource (Underground) |  |  |  |  |  |  |  |  |  |
| LaRonde Zone 6 | 194,258 | 3.27 | 27.15 | 0.43 | 1.68 | 20,437 | 169,569 | 841,565 | 3,264,197 |
| LaRonde 3 - Zone 20 North | 1,536,961 | 7.31 | 34.56 | 0.36 | 1.48 | 361,050 | 1,707,869 | 5,604,070 | 22,774,215 |
| LP1 - Zone 4D | 1,194,108 | 2.12 | 3.23 | 0.30 | 0.23 | 81,261 | 124,035 | 3,607,731 | 2,687,143 |
| LP1 - Fringe HW and FW | 16,290 | 2.34 | - | - | - | 1,223 | - | - | - |
| Total Inferred Mineral Resources | 2,941,617 | 4.91 | 21.16 | 0.34 | 0.98 | 463,971 | 2,001,472 | 10,053,366 | 28,725,554 |Table 1.3 - Mineral Resource Estimate for LZ5 deposit, exclusive of Mineral Reserves, as at December 31, 2022

| Zone by category by mining method | Tonnage <br> (t) | Gold grade (g/t) | Gold (oz.) |
| :--: | :--: | :--: | :--: |
| Indicated Mineral Resource (Underground) |  |  |  |
| Zone 5 | 2,326,107 | 1.56 | 116,372 |
| Zone 51 | 631,933 | 2.32 | 47,043 |
| Zone 4 and Zone 41 | 1,401,985 | 2.41 | 108,470 |
| Zone 1 | 1,487,122 | 1.88 | 89,846 |
| Zone 2 | 1,386,427 | 1.64 | 73,231 |
| Zone 3 HW | 1,941,916 | 2.47 | 154,075 |
| Zone 3 FW | 349,314 | 2.58 | 29,012 |
| Zone 3-1 FW | 35,834 | 6.44 | 7,419 |
| Zone 3-1 HW | 213,661 | 3.91 | 26,889 |
| Total Indicated Mineral Resources | 9,774,299 | 2.08 | 652,357 |
| Inferred Mineral Resource (Underground) |  |  |  |
| Zone 5 | 6,420,700 | 2.24 | 463,346 |
| Zone 4 and Zone 41 | 1,616,717 | 2.99 | 155,198 |
| Zone 1 | 81,950 | 3.17 | 8,360 |
| Zone 3 HW | 590,215 | 2.83 | 53,736 |
| Zone 3 FW | 1,498,932 | 4.14 | 199,488 |
| Zone 3-4 South | 1,419,193 | 5.11 | 233,222 |
| Zone 3-4 North | 389,881 | 6.39 | 80,079 |
| Zone 3-1 FW | 33,934 | 3.68 | 4,019 |
| Zone 3-1 HW | 324,088 | 4.49 | 46,792 |
| Total Inferred Mineral Resources | 12,375,611 | 3.13 | 1,244,239 |
|  |  |  |  |

[[%~%]]
## 1.11 Mineral Reserve Estimate

The Mineral Reserve estimate for the Property includes underground operations (LaRonde and LZ5) as well as silo and stockpiled mineral reserves. Mineral Resources are converted to Mineral Reserves by applying mining cut-off grades, mining dilution, and mining recovery factors. Any optimized mining shapes (MSO process) above cut-off grade in the resource model that are classified as Measured and Indicated Mineral Resources are reported as Proven and Probable Mineral Reserves, with the exception of isolated blocks.

The Life of Mine ("LOM") internal documents produced in 2022 and updated in terms of cost/tonne in the "Budget 2023" process were the basis for production cost and cut-off grade determination. Cost parameters are based on estimates from actual and projected OPEX costs of the LaRonde Complex. Mill recovery parameters are based on the past and actual production, milling and reconciliation reports, or on the results of metallurgical testwork for future areas of mining.

Table 1.4 shows the economic assumptions parameters for metal prices and exchange rate for the end of 2022.

Table 1.4 - Economic assumption parameters used in 2022 MRMR

| Parameter | Unit | Assumed <br> Value |
| :-- | :--: | :--: |
| Gold price | US\$/oz. | 1,300 |
| Exchange rate | C\$ per US\$ | 1.30 |
| Gold price | C\$/oz. | 1,690 |
| Silver price | US\$/oz. | 18.00 |
| Copper price | US\$/lb. | 3.00 |
| Zinc price | US\$/lb. | 1.00 |
| Lead price | US\$/lb. | 0.90 |

Operating costs used to calculate a break-even cut-off grade at the LaRonde Complex are highly variable and change according to area of mining, depth, size of stope, metallic content (gold only or polymetallic) and mill destination (LaRonde mill or LZ5 mill) for ore from each deposit.

For the LaRonde deposit, average mining costs for Penna Shaft area (mainly 20 North Zone, between $2,450 \mathrm{~m}$ and $3,320 \mathrm{~m}$ depth) were estimated at C\$128.66 per tonne mined while processing costs used were estimated at C\$47.26 per tonne milled based on a milling rate of 2,900 tpd. The general and administrative costs were estimated at C\$38.38 per tonne milled for total operating costs of C\$214.30 per tonne.

Average mining costs for LaRonde Shaft \#1 area (LP1 Massive Zone - 11-3 area) were estimated at C\$49.29 per tonne mined while processing costs used were estimated at C\$47.42 per tonne milled based on a future milling rate of 1,000 tpd. The general and administrative costs were estimated at C\$3.84 per tonne milled for total operating costs of C\$100.55 per tonne.Based on these economic parameters, the variable break-even cut-off NSR for the LaRonde deposit varies from C\$198/t to C\$219/t NSR for Penna Shaft area to C\$100.55/t NSR for LaRonde Shaft \#1 area (LP-1 area / 11-3 area).

The ore outlines include a minimum 1.5 m (up to 3 m ) dilution envelope around economic ore blocks. An additional backfill dilution is estimated at $2.0 \%$ on average. Mining recovery is typically fixed at $92 \%$ and following reconciliation recommendations.

For the LZ5 deposit, average mining costs (above 750 m depth limit) were estimated at C\$49.12 per tonne mined while processing costs used were estimated at C\$25.88 per tonne milled based on a milling rate of 3,400 tpd. The general and administrative costs are estimated at C\$4.97 per tonne milled for total operating costs of C\$79.96 per tonne.

Based on these economic parameters, the variable break-even cut-off grade for the LZ5 averages $1.62 \mathrm{~g} / \mathrm{t}$ gold using a gold price of $\mathrm{C} \$ 1,690$ per oz. of gold.

The ore outlines include a minimum 1.5 m (up to 3 m ) dilution envelope around economic ore blocks. An additional backfill dilution is estimated at $2.0 \%$ on average. Mining recovery is typically fixed at $92 \%$ and following reconciliation recommendations.

The total Proven and Probable Mineral Reserves for the LaRonde Complex as at December 31, 2022, are estimated at 22.7 million tonnes at $4.42 \mathrm{~g} / \mathrm{t}$ gold for 3.2 million ounces of gold. The total Mineral Reserves also included 8.1 million ounces of silver, 34,000 tonnes of copper and 128,000 tonnes of zinc. Approximately 66\% of the mineral reserve tonnage is in the Probable category. The 2022 Mineral Reserve estimate for gold is summarized in Table 1.5 and detailed by zone in Table 1.6 and Table 1.7.

There is good reconciliation between Mineral Reserves and actual production results, and the records maintained by LaRonde Division of Agnico Eagle allow the changes in reconciliation to be studied over time. Based on the reconciliation results, the Mineral Reserve estimate is reliable and can be used for mine planning in the short, medium and long terms.Table 1.5 - Gold Mineral Reserve estimate at LaRonde Complex, as at December 31, 2022

| Deposit | Category | Tonnage <br> (000 t) | Gold <br> grade <br> (g/t) | Gold <br> (000 oz.) |
| :-- | :-- | --: | --: | --: |
| LaRonde | Proven | 2,809 | 5.23 | 473 |
|  | Probable | 9,497 | 6.69 | 2,042 |
|  | Proven and Probable | 12,306 | 6.36 | 2,515 |
| LZ5 | Proven | 4,904 | 2.08 | 327 |
|  | Probable | 5,490 | 2.17 | 383 |
|  | Proven and Probable | 10,394 | 2.12 | 710 |
| LaRonde Complex Total | Proven | $\mathbf{7 , 7 1 3}$ | $\mathbf{3 . 2 3}$ | $\mathbf{8 0 0}$ |
|  | Probable | $\mathbf{1 4 , 9 8 7}$ | $\mathbf{5 . 0 3}$ | $\mathbf{2 , 4 2 5}$ |
|  | Proven and Probable | $\mathbf{2 2 , 6 9 9}$ | $\mathbf{4 . 4 2}$ | $\mathbf{3 , 2 2 5}$ |

Notes to accompany the Mineral Reserve estimate:

1. Mineral Reserves have been estimated by David Pitre, P.Eng., P.Geo, an employee of Agnico Eagle Mines Ltd., LaRonde Division, and a "Qualified Person" as defined by NI 43-101. The Mineral Reserve estimate conforms to CIM 2014 Standards.
2. Mineral Reserves are reported by deposit at various calculated cut-off grades, based on NSR for polymetallic lenses or based on gold grades for gold-rich lenses. The cut-off grades and NSR values are based on metal price assumptions of US\$1,300/oz for gold, US\$18/oz for silver, US\$3.00/lb for copper, US\$1.00/lb for zinc, actual realized gold and base metals processing recovery (Table 15.1), and operating cost assumptions based on 2023 LaRonde Complex LOM mining plan and Budget.
3. Tonnage and ounces columns are rounded to nearest thousand.Table 1.6 - Mineral Reserve estimate for LaRonde Deposit, as at December 31, 2022

| Zone by category by mining method | Tonnage <br> (t) | Gold <br> grade <br> (g/t) | Silver grade (g/t) | Copper grade (\%) | Zinc grade (\%) | Gold (oz.) | Silver (oz.) | Copper (kg) | Zinc (kg) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Proven Mineral Reserve (Underground) |  |  |  |  |  |  |  |  |  |
| LaRonde - Zone 20 North | 2,737,667 | 5.26 | 16.55 | 0.22 | 0.76 | 462,817 | 1,456,316 | 6,099,426 | 20,931,078 |
| LP1 - Massive Zone | 20,010 | 2.22 | 5.54 | 0.08 | 0.07 | 1,428 | 3,563 | 16,580 | 14,369 |
| Silos and stockpiles | 51,274 | 5.08 | 15.33 | 0.24 | 0.88 | 8,368 | 25,274 | 124,820 | 452,432 |
| Total Proven Mineral Reserves | 2,808,952 | 5.23 | 16.45 | 0.22 | 0.76 | 472,612 | 1,485,153 | 6,240,826 | 21,397,879 |
| Probable Mineral Reserve (Underground) |  |  |  |  |  |  |  |  |  |
| LaRonde - Zone 20 North | 8,140,506 | 7.26 | 23.92 | 0.32 | 1.29 | 1,900,176 | 6,259,195 | 26,336,368 | 105,231,737 |
| LP1 - Massive Zone | 1,356,215 | 3.26 | 7.21 | 0.08 | 0.06 | 142,265 | 314,260 | 1,085,125 | 865,323 |
| Total Probable Mineral Reserves | 9,496,721 | 6.69 | 21.53 | 0.29 | 1.12 | 2,042,441 | 6,573,454 | 27,421,493 | 106,097,060 |
| Total Proven and Probable Mineral Reserves | 12,305,673 | 6.36 | 20.37 | 0.27 | 1.04 | 2,515,053 | 8,058,607 | 33,662,318 | 127,494,939 |Table 1.7 - Mineral Reserve estimate for LZ5 Deposit, as at December 31, 2022

| Zone by category by mining method | Tonnage <br> (t) | Gold grade (g/t) | Gold (oz.) |
| :--: | :--: | :--: | :--: |
| Proven Mineral Reserve (Underground) |  |  |  |
| Zone 4 and Zone 41 (Development) | 34,466 | 1.99 | 2,210 |
| Zone 5 | 3,910,831 | 2.02 | 253,450 |
| Zone 1 | 219,287 | 2.10 | 14,803 |
| Zone 2 | 475,498 | 2.32 | 35,406 |
| Zone 3 HW | 173,020 | 2.87 | 15,946 |
| Silos and stockpiles | 90,544 | 1.92 | 5,596 |
| Total Proven Mineral Reserves | 4,903,645 | 2.08 | 327,411 |
| Probable Mineral Reserve (Underground) |  |  |  |
| Zone 4 and Zone 41 (Development) | 65,709 | 1.82 | 3,842 |
| Zone 5 | 5,141,572 | 2.15 | 355,742 |
| Zone 2 (Development) | 43,464 | 2.21 | 3,089 |
| Zone 3 HW | 182,686 | 2.57 | 15,106 |
| Zone 3 FW | 56,507 | 2.70 | 4,896 |
| Total Probable Mineral Reserves | 5,489,937 | 2.17 | 382,675 |
| Total Proven \& Probable Mineral Reserves | 10,393,582 | 2.12 | 710,086 |

The sensitivity of the Proven and Probable Mineral Reserves to the gold price has been estimated by running stope optimizer algorithm (MSO) at different economic assumptions, based on gold price variation ( $\pm 10 \%$ or $\pm$ US\$130/oz.). The results of the sensitivity analysis are in Table 1.8.

Table 1.8 - Mineral Reserve sensitivity for the LaRonde Complex

| Gold <br> price <br> (US\$) | Gold <br> grade <br> $(\mathrm{g} / \mathrm{t})$ | Tonnage <br> (t) | Gold <br> (oz.) | Gold Ounces <br> difference <br> vs. \$1,300 <br> (oz.) | Gold Ounces <br> difference <br> vs. \$1,300 <br> $(\%)$ |
| :--: | :--: | :--: | :--: | :--: | :--: |
| 1,170 | 4.80 | 20,009,415 | 3,088,121 | $(191,188)$ | $-5.9 \%$ |
| 1,300 | 4.42 | 22,699,255 | 3,225,139 | - | $0.0 \%$ |
| 1,430 | 4.20 | 25,248,722 | 3,406,605 | 135,265 | $4.2 \%$ |

[[%~%]]
## 1.12 Mining Methods, Production Rates And Expected Life Of Mine

Variations of the longhole open stoping mining method are used at the LaRonde Complex.
Longitudinal and transverse longhole stoping methods are used above Level 215 at the LaRonde Mine. For lower levels at the LaRonde Mine, the transverse open stoping method is almost exclusively used to address the deep and high stress conditions. Overhand and underhand miningsequences, as well primary-secondary or pillarless sequences, are implemented in different abutments of the mine. The mining sequence is a key parameter to progressively push stress away from the orebody to reduce the seismic risk.

At the LZ5 Mine, the two mining methods used are variations of longhole open stope mining. Transverse longhole stoping is used at LZ5 in sectors with poorer ground quality. The longitudinal retreat method is used in sectors where there is better ground quality, or the width of the orebody cannot justify transverse mining.

According to the 2023 LOM, production from the LaRonde Mine is scheduled between 2023 and 2036 whereas production from the LZ5 Mine is scheduled between 2023 to 2032.

At the LaRonde Mine, a total of 12.8 million tonnes of ore are to be hoisted via the Penna Shaft during this period. From 2023 to 2027, approximately 3,900 tpd of ore will be extracted from the LaRonde Mine, and afterwards these mineral reserves will be extracted at a declining rate to almost full depletion in 2036.

At the LZ5 Mine, over the LOM approximately 10.4 million tonnes will be mined at a rate of 3,200 to $3,800 \mathrm{tpd}$. At peak production the mine will produce approximately 90,000 ounces of gold per year.

[[%~%]]
### 1.12.1 Requirement For Development

In the LOM 2023 for the LaRonde Mine, a total of 70.4 km will be required for development in the operation from 2023 to 2036, of which 11.7 km of development is planned in 2023. The annual amount of development until 2036 will be reduced progressively until the end of the operation.
In the LOM 2023 for the LZ5 Mine, a total of 35.5 km of horizontal development will be needed to extract the mineral reserves at LZ5. Development will be decreased substantially after 2027 once the major mine infrastructure has been established.

[[%~%]]
### 1.12.2 Backfill

At the LaRonde Mine, the surface paste backfill plant has been designed to produce 200 tonnes of pastefill per hour. Backfill for LZ5 is provided from a dedicated paste fill plant on surface that has a capacity of 140 tonnes of fill per hour, and the tailings for the backfilling are provided from the LaRonde mill.

[[%~%]]
### 1.12.3 Mining Fleet And Machinery

At the LaRonde Mine, the waste/ore material is mucked out with $8 \mathrm{yd}^{3}$ or $11 \mathrm{yd}^{3}$ scoops, dumped into 40-tonne or 50 -tonne trucks and then transported up to the material handling system.
The LZ5 Mine is accessed via a ramp with production and development being achieved with rubber-tired underground mining equipment. As there is no shaft, all ore and waste from the LZ5 Mine is hauled to surface using trucks. The mine primarily uses 50 -tonne trucks and $11-\mathrm{yd}^{3}$ scoops for production purposes.

[[%~%]]
### 1.12.4 Geotechnical Parameters

With the depth of the LaRonde Mine extending below 3,000 m, the in-situ stress contributes to influence the ground conditions surrounding the excavations.Seismicity is a main aspect of the operation and it requires a team of rock mechanics experts to manage the seismic risk. Site-specific expertise in mitigating seismic risk has been acquired by the Company over several years of operations at LaRonde as the mine has gradually been extended to present-day depths below 3 km from surface. The objective remains to minimize the seismic risk by introducing mitigation measures to keep a safe work environment while maintaining reasonable production rates.
Seismicity is usually associated with production blasting. A non-entry protocol is designated for each stope following the history of the previous blasts in the vicinity. The protocol could close the level partially or in entirety and the impact could extend over many levels. This strategy avoids having personnel close to any major seismic response following a blast.
Different ground support strategies have been developed in response to different anticipated ground conditions. Standard ground support elements such as rebar in the roof and friction bolts in the walls are used in areas where seismicity is not present. In the case of seismicity, dynamic ground support elements are used to prevent or minimize damage from seismic events.
To minimize exposure of the mining personnel during large seismic events, remote operation from surface is commonly used in the area where the Engineering Department anticipates a higher stress level following a production blast.
LZ5 uses ground control monitoring in areas with large spans and lower quality rock mass. Ground control monitoring is achieved in two ways. Instrumented cable bolts are used in the backs to monitor load and elongation. A Maptek 3D scanner is used to monitor convergence of drifts in areas of lower rock quality. This monitoring allows the mine personnel to react proactively to changing ground conditions.

[[%~%]]
### 1.12.5 Mine Ventilation

The LaRonde Mine is ventilated a rate of 1,500,000 cubic feet per minute ("cfm") with a network of 16 ' and 22 ' diameter raises for the intake or exhaust in a push-pull system. The system is composed at surface of two fans at the intake ( 1,750 horsepower or "hp" each) and two fans at the exhaust (3,500 hp each). Underground, at the exhaust side, a booster fan ( $6,000 \mathrm{hp}$ ) is located on Level 194 and two additional fans are being installed on Level 275 (2,500 hp and 4,250 hp) to help the main fans as the mine continues at depth. A cooling plant is used to refresh the intake air and allow good working conditions at depth.
The LZ5 Mine is ventilated at a rate of $340,000 \mathrm{cfm}$ using a pull system that uses the ramp as an intake and a 12-ft raise as the exhaust. The ventilation is driven by 75 hp exhaust fans on multiple levels that push air directly into the exhaust. To keep the mine temperature above $8^{\circ}$ Celsius at all times, an intake system equipped with 44 Mbtu natural gas burners is used.

[[%~%]]
### 1.12.6 Dewatering

A portion of the infiltration water at the LaRonde Mine is collected by a pumping station for the Dumagami mine, which allows for the LaRonde Mine to not be contaminated with acidic water. The rest of the water is derived from operations (drilling, pastefill, dust suppression, etc.).
The LZ5 Mine was developed adjacent to the former Bousquet No. 1 mine, which was flooded after it closed. In order to safely operate the LZ5 Mine, the former Bousquet No. 1 mine workings must be dewatered to a level 30 m below current mining at the LZ5 Mine. Dewatering is achieved with the use of boreholes, submersible well pumps and pumping stations. All water is treated at surface before being reused or discharged.

[[%~%]]
## 1.13 Recovery Methods

The processing plant at the LaRonde Complex is comprised of two mills: LaRonde and LZ5. The LaRonde mill has a capacity of 7,200 tpd on a yearly basis, and processes ore containing precious metals (gold and silver) recovered by a carbon in pulp ("CIP") process and ore containing base metals (copper, zinc and lead sulphides) recovered by a flotation process. The LZ5 mill has a capacity of 2,000 tpd and processes gold ore using gravity and carbon in leach ("CIL") processes.

The LaRonde mill was started in 1988 and has been modified many times to increase the tonnage and be adaptive any changes in the ore characteristics.

A new mill was built in 2007 to process the Lapa ore on the LaRonde site. The mill was situated beside the existing LaRonde mill to allow synergy between the two operations. The LZ5 mill processed Lapa ore from 2008 to 2017, and LZ5 ore from 2018 to the present.

The synergies between the LaRonde and LZ5 mills have been mainly related to the workforce, chemicals, and all environmental facilities including tailings and water treatment.

[[%~%]]
## 1.14 Infrastructure

The LaRonde Complex is a site that spans over 6 km from west to east. The site can be divided into five major sectors: the LaRonde Mine, the LZ5 Mine, the mills, the regional offices and the tailings management area. The site is serviced by a Hydro-Québec 120 kV line and the regional Energir natural gas line.

The LZ5 and LaRonde mine sites are situated on opposite ends of the west-to-east property. They have independent mining infrastructure but are operated by the LaRonde Complex team.

The LaRonde Mine was originally developed utilizing a 1,207-metre shaft (Shaft \#1) and an underground ramp access system. The ramp access system is available down to Level 25 of Shaft \#1 and continues down to Level 320 at the Penna Shaft (Shaft \#3). The mineral reserves accessible from Shaft \#1 were depleted in September 2000 and Shaft \#1 is no longer in use. A second production shaft (Shaft \#2), located approximately 1.2 km to the east of Shaft \#1, was completed in 1994 to a depth of 525 m and was used to mine zones 6 and 7 . Both ore zones were depleted in March 2000 and the workings were allowed to be flooded up to Level 6 (approximately 280 m depth). The Penna Shaft, located approximately 800 m to the east of Shaft \#1, was completed down to a depth of 2,250 m in March 2000. The Penna Shaft is used to mine zones 20 North, 20 South, 21, 6 and 7.

In 2006, the Company initiated construction to extend the infrastructure at the LaRonde Mine to access the ore below Level 245. Hoisting from this deeper part of the LaRonde Mine began in the fourth quarter of 2011 and commercial production was achieved in November 2011. Access to the deeper part of the LaRonde Mine is provided through an 823-metre internal shaft (Shaft \#4, completed in November 2009) starting from Level 203, for a total depth of 2,858 m from surface. A ramp is used to access the lower part of the orebody down to $3,200 \mathrm{~m}$ in depth. The internal winze system is used to hoist ore from depth to facilities on Level 215, approximately 2,150 m below surface, where it is transferred to the Penna Shaft hoist.

A cooling plant on Level 262 began operating in December 2013. In 2021, a new cooling plant on Level 308 (East mine) was put into operation to reach Level 332 (East mine) and provide it with adequate temperature. To reach Level 335 (West mine), a new cooling system is planned on Level 308W and is expected to be operational in 2024.The Company's regional Centre of Services and Development ("CSD") contains the dry and the offices required to run the LZ5 Mine. The rest of the LZ5 Mine infrastructure is located around the former LZ5 open pit (mined out by the previous owner), and includes the garage, electrical substation, backfill plant, ore and waste stockpiles, the crusher, ventilation intake and exhaust, and numerous other smaller infrastructure.

The milling facilities for the LaRonde Complex are located on site near Route 395. The infrastructure in this area includes the LaRonde and LZ5 mills, the ore stockpile, assay laboratory, surface mobile shop, office building, warehouse and paste backfill plant.

The water treatment infrastructure for the LaRonde Complex is located near the main tailings pond, and it includes the peroxy-silicate plant and the biological plant (final water treatment plant). The water pump station that recirculates water to the mill is located in the same area.

[[%~%]]
## 1.15 Market Studies And Contracts

The LaRonde Complex currently extracts and produces marketable gold, silver, copper and zinc that are shipped to smelters and refineries in the form of doré, copper concentrate and zinc concentrate.

The negotiated contracts terms for the above transportation, smelting and refining activities are within market parameters.

Agnico Eagle has signed contracts that are directly associated with operations at the LaRonde Complex for various consumable supplies or services provided. The duration (period of validity) of the contract is specific to each one and may vary, and the process of awarding contracts is performed by an internal committee.

[[%~%]]
## 1.16 Environmental Studies, Permitting, And Social And Community Impact

The LaRonde Complex has a history of mining and development spanning more than 30 years. All environmental studies performed at the LaRonde Complex were positive and demonstrated limited impacts on the environment due to the mining operation.

Mining and mineral processing operations and exploration activities at the LaRonde Complex are subject to extensive federal, provincial and local laws and regulations that govern waste disposal, hazardous material management, environmental protection, mine safety and other matters.

All identified environmental impacts and risks arising from LaRonde Complex activities are monitored and mitigated by the Company.

Tailings management practices at the LaRonde Complex incorporate evolving international best practices for design and management, as endorsed by the Canadian Dam Association and the Mining Association of Canada. Beginning in 1988, tailings deposition has been in slurry - a process that continued through 2022. In 2023, filtered tailings will be deposited within Extension A4 in order to reduce the environmental footprint. It is currently planned that the filtered tailings deposition in Extension A4 and in the main tailings pond will cover the needs of the complex through 2036, which is the current LOM.

For water management, a new water cell (Cell 5) is currently under construction at a location east of Extension A4, which will allow for the management of water for the transition to filtered tailings deposition. In October 2021, the first phase (North section) was completed and put in operation.The LaRonde Mine's tailings are primarily used to feed the two paste fill plants at the LaRonde Mine and the LZ5 Mine. The remaining LaRonde Mine tailings with 100\% of the LZ5 Mine tailings are sent to the TSF.

There are numerous vibrating wire piezometers, inclinometers, monitoring wells, and survey monuments installed at the tailing ponds and its related infrastructure (dikes, cofferdams, etc.). These instruments monitor porewater pressure, lateral deflections and settlement.

Stability analyses of the mine waste management infrastructure are completed by the Design Engineer and verified by the Engineer of Record when necessary. Stability is analyzed in the context of current standards and practices. Over the life of the infrastructure, this required retrofit and operational changes. A review process is integrated, which involves external experts through the organization of Independent Review Boards.

After water is pumped to the tailings pond, the water is directed to Polishing Pond \#1 before being sent to a water treatment plant for destruction of cyanide complexes and metal precipitation and then, pass into a water treatment plant using a biological process to eliminate toxicity via the degradation of residual ammonia and thiocyanate.

[[%~%]]
### 1.16.1 Permitting And Authorizations

To date, all permits and authorizations are issued for current activities on the Property. The permits and authorizations for the foreseen activities are in preparation or are issued depending on the activities. No activity is started on the Property without the prior obtention of all required permits and authorizations. A mining lease demand is currently in progress to the Government of Quebec's Ministry of Energy and Natural Resources ("MERN") for the economic portion of the LZ5 deposit located on Ellison Property included in the actual MRMR statement. Agnico Eagle's environmental monitoring program at the LaRonde Complex ensures that all activities on the Property comply with its permits and the applicable laws and regulations for the mining industry in Quebec.

[[%~%]]
### 1.16.2 Community Relations

Respect for the communities in which Agnico Eagle operates is a core value of the Company's sustainability policy. The Company have always strived to work collaboratively with its neighbours to identify ways to improve practices and foster harmonious and sustainable relationships.

As part of Agnico Eagle's community engagement, information and consultation process, the Company has voluntarily worked with citizens to develop a "Good Neighbour Framework" that is consistent with the Company's values of trust, family, respect, responsibility and equality.

The Good Neighbour Framework is a tool developed jointly with concerned stakeholders and it aims to reach an agreement on the essential conditions for good neighbourliness, measures and actions to be deployed to prevent, manage and mitigate the impacts of activities at the LaRonde Complex.

To support community development, it is the objective of the LaRonde Complex to invest in the communities, to contribute to the maintenance of property values in the surrounding communities and to encourage its employees to move closer to the site.

The LaRonde Complex initiated a collaborative process with the First Nation community of Abitibiwinni in the autumn of 2020, and the process is ongoing.

[[%~%]]
### 1.16.3 Closure Plan

The LaRonde Reclamation Plan was prepared and initially submitted to MERN in May 1996. The last update of this Reclamation Plan was deposited in February 2021 and accepted by MERN on June 21, 2022, with total estimated costs of $\$ 197.8$ million. Currently, $\$ 140.8$ million is already submitted in financial guarantees and the financial guarantee payment schedule was established by MERN for 2023 and 2024 (100\%).

A second Reclamation Plan for the Bousquet Area (LZ5 Mine) is independent and not included in the scope of LaRonde Mine's Reclamation Plan. This is due to the area being almost restored prior to the construction and development of the LZ5 Mine.

The detailed closure costs for the LaRonde Mine and the Bousquet area (LZ5 Mine) are presented in Table 1.9 and Table 1.10, respectively.

The following objectives were defined for the 2021 Reclamation Plan:

- To develop a remediation plan based on techniques that are environmentally adapted to the required closure
- To ensure that during work and after its completion, public-health and safety risks are minimized

The major elements included in the 2021 Reclamation Plan are:

- As the tailings and waste rock are acid generating, a membrane of linear low-density polyethylene ("LLDPE") will be used with the associated granular cover to protect its integrity. The choice of this technology is based on the limited availability of till in the area and the efficiency of membrane to prevent acid rock drainage.
- All infrastructures added in the filtered tailings management project were added in the last revision (filtration plant, Cell 5, filtered tailings storage, etc.).
- Updated costs for mill's clean-up and dismantling.
- Further updates are included relating to unit cost (revegetation, sand, till, waste rock excavation, etc.)

The effluent and tailings site control structures will be operated until the Government of Québec's Ministry of the Environment, the Fight Against Climate Change, Wildlife and Parks ("MELCCFP") determines that the required criteria have been met. These structures will then be dismantled. The work integrity follow-up program will include inspection of the stability of structures remaining after the site remediation process. The effluent processing plant will also be inspected on a regular basis to ensure its good operating condition.

The environmental monitoring will continue for at least 10 years after mining operations have ceased, or until the results of five consecutive years comply with the conditions of Directive 019 during mine closure.Table 1.9 - Closure costs for LaRonde Mine area

| Component | Cost (C\$M) |
| :-- | --: |
| Engineering and study | 2.6 |
| Tailings storage facility and waste rock pile | 82.6 |
| Water management facilities | 11.0 |
| Contaminated soil and revegetation | 18.0 |
| Clean-up and dismantling of complex | 24.0 |
| Environmental monitoring and inspections | 6.8 |
| Sub-total | $\mathbf{1 4 5}$ |
| Indirect costs | 27 |
| Contingency | 25.8 |
| Total | $\mathbf{1 9 7 . 8}$ |

Table 1.10 - Closure costs for Bousquet area (LZ5 Mine)

| Component | Cost (\$M) |
| :-- | --: |
| Pit, stockpiles and raises rehabilitation | 0.5 |
| Water treatment | 0.3 |
| Contaminated soil and revegetation | 0.7 |
| Clean-up and dismantling of infrastructure | 0.8 |
| Environmental monitoring and inspections | 0.6 |
| Sub total | $\mathbf{2 . 9}$ |
| Indirect costs | 0.4 |
| Contingency | 0.7 |
| Total | $\mathbf{4 . 0}$ |

[[%~%]]
## 1.17 Capital And Operating Costs, And Economic Analysis

The Company estimates that the LaRonde Complex will require C\$1,007 million of CAPEX over the life of the mining complex. The majority of this CAPEX is required for the development of the LZ5, 11-3 and LaRonde + LaRonde 3 projects. Other major CAPEX investments at the site include mobile equipment as well as mill upkeep and upgrades.The operating costs for the LaRonde Complex as estimated in the 2023 LOM are an amalgamation of the operating cost estimates for the LaRonde and LZ5 mines. The average cost per tonne for the site over the LOM is C\$147.00 per tonne with an average individual OPEX at the LaRonde Mine and the LZ5 Mine over the LOM of C\$176.60 per tonne and C\$85.00 per tonne, respectively.

The Company has performed an economic analysis for the existing LaRonde Mine and LZ5 Mine at the LaRonde Complex using a gold price of C\$1,938 per ounce, at the forecasted production rates, metal recoveries, and capital and operating cost estimated in the Technical Report. The Company confirms that the outcome is a positive cash flow that supports the mineral reserve estimate. Due to the nature of the mining business, these conditions can change significantly over relatively short periods of time. Consequently, actual results may be significantly more or less favourable.

[[%~%]]
## 1.18 Interpretations And Conclusions

The LaRonde Complex Property in the historic mining camp of Doyon-Bousquet-LaRonde, Québec, has produced over 78.2 million tonnes of ore grading $4.63 \mathrm{~g} / \mathrm{t}$ gold for a total of 10.8 million ounces of gold. The Property hosts the operating LaRonde and LZ5 underground mines, which LaRonde Complex forecasts will produce around 300,000 ounces of gold annually for the next seven years. The commercial production at LaRonde Shaft \#1 began in 1988. Since then, LaRonde's commercial production never stopped but fluctuated through a long history of successful exploration programs and acquisitions. Over 1,400,000 metres of drilling has been completed by Agnico Eagle to date to expand known mineralized zones and discover new zones.

The Mineral Resources and Mineral Reserves for the Property are suitable for public reporting. Measured and Indicated Mineral Resources are exclusive of Proven and Probable Mineral Reserves and do not have demonstrated economic viability. The Mineral Resources and Mineral Reserves are compliant with NI 43-101 requirements and CIM 2014 Definition Standards.

The 2022 MRE is considered to be reliable and thorough, and based on quality data and reasonable hypotheses and parameters. The 2022 MRE further demonstrated the geological and grade continuities for several deposits on the LaRonde Complex Property and updated the mineral resource and mineral reserve estimates using data up to December 31, 2022.

The LaRonde Complex Property is estimated to contain (exclusive to the mineral reserves) total Measured and Indicated Mineral Resources of 15.7 million tonnes grading $2.41 \mathrm{~g} / \mathrm{t}$ gold for a total of 1.22 million ounces of gold and Inferred Mineral Resources of 15.3 million tonnes grading 3.47 $\mathrm{g} / \mathrm{t}$ gold for a total of 1.71 million ounces of gold.

The total Proven and Probable Mineral Reserves at the LaRonde Complex are estimated at 22.7 million tonnes at $4.42 \mathrm{~g} / \mathrm{t}$ gold for 3.2 million ounces of gold. Most of the Mineral Reserve tonnage $(66 \%)$ is in the Probable category.

The Mineral Resources and Mineral Reserves estimates for the LaRonde Complex Property are effective as at December 31, 2022.

The Life of Mine plans and Mineral Reserves estimate for the LaRonde Complex were developed from the geological block model prepared by Agnico Eagle's LaRonde Division. As at the date of this Technical Report, the QPs have not identified any legal, political, or environmental risks that would materially affect potential development of the mineral reserves.According to the 2023 LOM, production from the LaRonde Mine is scheduled between 2023 to 2036. Approximately 3,900 tonnes per day are to be extracted from 2023 to 2027, before the rate progressively declines until depletion is completed in 2036.

According to the 2023 LOM, production from the LZ5 Mine is planned from 2023 to 2032. Approximately 3,200 to 3,800 tonnes per day will be extracted. Starting in 2028 production will occur at a progressively declining rate until depletion in 2032.

The results within this Technical Report are subject to variations in operational conditions including, but not limited to, the following:

- Assumptions related to commodity and foreign exchange.
- Unanticipated inflation of capital or operating costs.
- Significant changes in equipment productivities.
- Geological continuity of the mineralized structures.
- Geotechnical assumptions in underground infrastructures design.
- Seismic activity due to deep mining operation.
- Ore dilution or loss.
- Throughput and recovery rate assumptions.
- Changes in regulatory requirements that may affect the operation or future closure plans.
- Changes in closure plan costs.
- Change in workforce availability.

In the opinion of the QPs, there are no reasonably foreseen inputs from risks and uncertainties identified in the Technical Report that could affect the LaRonde Complex's continued economic viability.

LaRonde Division of Agnico Eagle has performed an economic analysis using a gold price of C\$1,938 per oz. Minable stope shapes and COG were generated using a gold price of C\$1,690 per oz. at the forecasted production rates, metal recoveries, and capital and operating costs estimated in this Technical Report. The QPs responsible for the economic analysis in this Technical Report confirm that the outcome is a positive cash flow for the LaRonde Complex.

Environmental monitoring programs at the LaRonde's Mining Complex cover all aspects of the identified environmental impacts. These programs have been rigorously implemented and their results comply with all governmental and community requirements.

[[%~%]]
## 1.19 Recommendations

As the LaRonde Complex is an operating mining complex, with no planned expansions, the QPs have no meaningful recommendations to make.

[[@~@]]
# 2 Introduction

The LaRonde Division of Agnico Eagle Mines Limited prepared this technical report (the "Technical Report") to present and support the results of the Year-End 2022 Mineral Resource and Mineral Reserve estimate (the "2022 MRMR") and to summarize the current underground mining operation of the LaRonde Complex that includes the LaRonde Mine and the LZ5 Mine.

Agnico Eagle is a senior Canadian gold mining company that operates mines in Canada, Australia, Finland and Mexico. It also conducts exploration activities in each of those countries, as well as the United States, Sweden and Colombia. Agnico Eagle's head office and registered office is at 145 King Street East, Suite 400, Toronto, Ontario, Canada, M5C 2Y7. Agnico Eagle shares trade on the Toronto Stock Exchange and the New York Stock Exchange under the symbol AEM. Agnico Eagle is a "producing issuer" according to the rules and definitions provided by the Canadian Securities Administrators and a long-time "reporting issuer" under the definitions of National Instrument 43-101 ("NI 43-101").

The Technical Report was prepared in compliance with the standards set out in the Canadian Securities Administrators' NI 43-101, Companion Policy 43-101 CP and Form 43-101F1.

The 2022 MRMR reported herein as at December 31, 2022 was prepared in conformity with generally accepted standards set out in the Canadian Institute of Mining, Metallurgy and Petroleum ("CIM") Mineral Resource and Mineral Reserves Estimation Best Practices Guidelines (November 2019) and were classified according to CIM Definition Standards for Mineral Resources and Mineral Reserves ("CIM 2014 Definition Standards").
The Technical Report includes information concerning geology, assaying, quality control, estimation methods, mining operations, recoverability, markets, contracts, environmental considerations, taxes, capital and operating cost estimates, economic analysis, pay back and mine life.

[[%~%]]
## 2.1 Terms Of Reference And Sources Of Information

The Technical Report presents inventory information including the ongoing mining operation up to December 31, 2022, and diamond drilling results up to October 31, 2022. The 2022 MRMR estimate for the LaRonde Complex was released to the public in a news release dated February 16, 2023.
The documentation listed in Section 3 and Section 27 was used to support the Technical Report. Excerpts or summaries from documents authored by other consultants are indicated in the text. The assessment by the Qualified Persons ("QPs") of the LaRonde Complex was based on published and unpublished material, and the data and opinions of other professionals.
The QPs also consulted other sources of information, mainly the Government of Québec's online claim management and assessment work databases (GESTIM and SIGEOM, respectively), the LaRonde Complex's and other technical reports, annual information forms, MD\&A reports and news releases published online on SEDAR at www.sedar.com.
The QPs reviewed and appraised the information used to prepare this Technical Report, including the conclusions and recommendations, and believe that such information is valid and appropriate considering the status of the LaRonde Complex, and the purpose for which this Technical Report has been prepared. The QPs have thoroughly researched and documented the interpretations and conclusions made in this Technical Report.
The outlines of the mineral reserve and mineral resource stopes are displayed by zone on separate Deswik format longitudinal sections and are summarized on a composite longitudinalplan. The estimate is compiled in a database report format and a series of Excel format reports which are all summarized by category in the final tabulation.

For the preparation of the Technical Report, which includes an updated Mineral Resource and Mineral Reserve estimate, the QPs responsible for the report have relied on previous Mineral Resource and Mineral Reserve estimates from 2015 and earlier; on the LaRonde II Project 2006 Feasibility Study (Girard, et al. 2006); on previous Mineral Resource and Mineral Reserve estimates from 2021 and earlier; and on the LZ5 Project Prefeasibility Study (Turcotte, et al. 2017). The QPs responsible for the Technical Report have also relied on new data collected during 2022, including diamond drilling results and production, mill and reconciliation reports.

[[%~%]]
## 2.2 Report Responsibility, Qualified Persons And Site Visits

The 2022 MRMR estimate and the information presented in the Technical Report are the responsibility of the Geology Department at the LaRonde Complex of Agnico Eagle Mines Limited. The Technical Report has been prepared under the direction of David Pitre, P. Eng. And Geo., Senior Resource Geologist at the LaRonde Complex, with the collaboration of other LaRonde Complex professionals responsible as Qualified Persons as defined by NI 43-101, in conformity with generally accepted guidelines of the CIM for "Exploration Best Practices" and "Estimation of Mineral Resources and Mineral Reserves Best Practices".

The QPs responsible for the Technical Report are Agnico Eagle employees who are based and work full-time at the LaRonde Complex, obviating the need for site visits by the QPs. Each QP retains the responsibility for their contribution as indicated in Table 2.1. The QPs' qualifications and period of work at the LaRonde Complex are summarized in the certificates at the beginning of the Technical Report.

Table 2.1 - Report responsibilities of each Qualified Person

| Qualified Person (QP) | Position at <br> LaRonde Complex | Responsible for Item/Section |
| :-- | :-- | :-- |
| David Pitre, P.Eng., P.Geo. | Senior Resource Geologist | $4,5,6,7,8,9,10,11,12,14,15,23$ |
| Vincent Dagenais, P.Eng. | Engineering Superintendent | $16,18,19,21$ and 22 |
| Devin Wilson, P.Eng. | LZ5 Technical Services <br> Superintendent | $16,18,19,21$ and 22 |
| Claude Bolduc, P.Eng. | General Mills \& Surface <br> Superintendent | 13,17 and 18 |
| Yanick Létourneau, P.Eng. | Environment Superintendent | 20 |
| All QPs |  | Related disclosure in 1 to 3 and 24 to 27 |

[[%~%]]
## 2.3 Abbreviations, Acronyms, Currency And Units Of Measurements

The abbreviations, acronyms and units used in this report are provided in Table 2.2 and Table 2.3. All currency amounts are stated in Canadian Dollars ("\$", "C\$" or "CAD") or US dollars ("US\$" or "USD"). Quantities are stated in metric units, as per standard Canadian and international practice, including metric tons (tonnes, $t$ ) and kilograms ( kg ) for weight, kilometres ( km ) or metres ( m ) for distance, hectares (ha) for area, percentage (\%) for copper, zinc and lead grades, and gram per metric ton ( $\mathrm{g} / \mathrm{t}$ ) for precious metal grades. Wherever applicable, imperial units have been converted to the International System of Units (SI units) for consistency (Table 2.4).

Table 2.2 - List of abbreviations and acronyms

| Abbreviation or acronym | Term | Abbreviation or acronym | Term |
| :--: | :--: | :--: | :--: |
| 3D | Three-dimensional | MA | Survey monument |
| AA or AAS | Atomic absorption spectroscopy | Mag, MAG | Magnetometer, magnetometric |
| ADR | Adsorption, desorption and recovery (circuit) | MELCCFP | Government of Québec's Ministry of the Environment, the Fight Against Climate Change, Wildlife and Parks |
| Ag | Silver | MERN | Government of Québec's Ministry of Energy and Natural Resources |
| Agnico Eagle, AEM | Agnico Eagle Mines Limited | mesh | US mesh |
| Au | Gold | MP-AES | Microwave plasma atomic emission spectroscopy |
| BM | Block Models | MRC | Regional county municipality |
| BQ | Size of diamond drill core ( 36.5 mm ) | MRE | Mineral Resource Estimate |
| CAD, C\$ | Canadian dollar | MRMR | Mineral resource and mineral reserve |
| CAPEX | Capital expenditure | MSO | Mineable shape optimizer |
| CIL | Carbon in leach | N | North |
| CIM | Canadian Institute of Mining, Metallurgy and Petroleum | NI 43-101 | National Instrument 43-101 |
| CIP | Carbon in pulp | NPI | Net profits interest |
| CMS | Cavity Monitoring System | NQ | Size of diamond drill core ( 47.6 mm ) |
| COG | Cut-off grade | NSR | Net smelter return |
| CRM | Certified reference material | NTS | National Topographic System |
| CSD | Centre of Services and Development | OGQ | Québec Order of Geologists |
| CV | Coefficient of variation | OIQ | Québec Order of Engineers |
| DBL | Doyon-Bousquet-LaRonde (mining camp) | OK | Ordinary kriging |
| DDH | Diamond drill hole | OPEX | Operational expenditure |
| E | East | P80 | 80\% passing - Product |
| ELOS | Equivalent linear overbreak slough | P\&P | Proven and Probable |
| EM | Electromagnetics | P.Eng. | Professional engineer || Abbreviation <br> or acronym | Term | Abbreviation <br> or acronym | Term |
| :-- | :-- | :-- | :-- |
| FA | Fire assay | P.Geo. | Professional geologist |
| FAAA | Fire assay and atomic absorption <br> spectrometry (method) | PRRI | Industrial Waste Reduction Program <br> by the MELCCFP (Programme de <br> réduction des rejets industriels) |
| FAGV | Fire assay-gravimetric | PTP-MAL | Proficiency Testing Program for <br> Mineral Analysis Laboratories |
| FW | Footwall | PZ | Monitoring well |
| G\&A | General and administrative | QA/QC | Quality assurance / quality control |
| GAAP | Generally Accepted Accounting <br> Principles | QP | Qualified Person |
| GESTIM | Government of Québec's Public <br> Register of Real and Immovable <br> Mining Rights | RQD | Rock Quality Designation |
| GPS | Global Positioning System | S | South |
| HLEM | Horizontal loop electromagnetic | SAG | Semi-autogenous grinding |
| HW | Hanging wall | SD | Standard deviation |
| ICP | Inductively coupled plasma | SG | Specific gravity |
| ICP-MS | Inductively coupled plasma mass <br> spectrometry | SPEDE | Quebec carbon exchange program <br> (Système de plafonnement et <br> d'échange des droits d'émission de <br> gaz à effet de serre) |
| ID2 | Inverse distance squared | TCGO | Goldex pyrite/gold concentrate |
| IEC | International Electrotechnical <br> Commission | TSF | Tailings storage facility |
| IFRS | International Financial Accounting <br> Standards | UG, U/G | Underground |
| Inc. | Incorporated | URF | Unconsolidated waste rock fill |
| INC | Inclinometer | US | United States of America |
| IP | Induced polarization (survey) | USBM | United States Bureau of Mines |
| ISO | International Organization for <br> Standardization | UTM | Universal Transverse Mercator <br> (coordinate system) |
| LIMS | Laboratory Information and <br> Management System | VLF | Very low frequency |
| LLDPE | Linear low-density polyethylene | VMS | Volcanogenic massive sulphide |
| LOM | Life of mine | VWP | Vibrating wire piezometer |
| Ltd. | Limited | W | West |
| M\&I | Measured and Indicated | WTP, FWTP | Water treatment plant |Table 2.3 - List of symbols and units of measurements

| Symbol | Unit | Symbol | Unit |
| :--: | :--: | :--: | :--: |
| \$, C\$, CAD | Canadian dollar | m | Metre |
| $\$ / t$ | Dollars per tonne | M | Million, mega |
| \% | Percent | $\mathrm{m}^{2}$ | Square metre |
| " | Angular degree | $\mathrm{m}^{3}$ | Cubic metre |
| ${ }^{\circ} \mathrm{C}$ | Degree Celsius | masl | Metres above mean sea level |
| $\mu \mathrm{m}$ | Micron (micrometre) | $\mathrm{mg} / \mathrm{L}$ | Milligram per litre |
| $\begin{aligned} & \text { CAD/USD, } \\ & \text { C\$/US\$ } \end{aligned}$ | Canadian-American dollar exchange rate | mm | Millimetre |
| cfm | Cubic feet per minute | Moz | Million (troy) ounces |
| cm | Centimetre | Mt | Million tonnes |
| dba | Decibel unit relative to reference level A | MW | Megawatt |
| ft or ' | Foot (12 inches) | oz | Troy ounce |
| $\mathrm{ft}^{3}$ | Cubic feet | oz/t | Troy ounce per short ton (2,000 lbs) |
| g | Gram | pH | Potential of hydrogen |
| g/L | Gram per litre | ppm | Parts per million |
| $\mathrm{g} / \mathrm{t}$ | Gram per tonne | t | Metric tonne ( $1,000 \mathrm{~kg}$ ) |
| h, hr | Hour (60 minutes) | ton | Imperial short ton (2,000 lbs) |
| Hp, hp | Horsepower | $\mathrm{t} / \mathrm{h}, \mathrm{tph}$ | Tonnes per hour |
| Hz | Hertz | $\mathrm{t} / \mathrm{m}^{3}$ | Tonnes per cubic metre |
| kg | Kilogram | tpy, t/y | Tonnes per year (annum) |
| $\mathrm{kg} / \mathrm{t}$ | Kilogram per tonne | tpd | Tonnes per day |
| km | Kilometre | tpcd \& tpod | Tonnes per calendar/operating day |
| kV, KV | Kilovolt | US\$ or USD | United States dollar |
| kW | Kilowatt | USD/CAD | US\$ to C\$ dollar exchange rate |
| L | Litre | V | Volt |

Table 2.4 - Conversion factors for measurements

| Metric unit | Multiplied by | Imperial unit |
| :--: | :--: | :-- |
| 1 m | 3.2808 | foot |
| 1 kg | 2.2046 | lbs |
| 1 g | 31.1035 | ounce (troy) |
| $1 \mathrm{~g} / \mathrm{t}$ | 34.2857 | ounce (troy) / t (short) |
| 1 t | 1.1023 | ton (short) |

[[@~@]]
# 3 Reliance On Other Experts

The Technical Report was compiled through the efforts of Agnico Eagle staff under the supervision of Qualified Persons, as described in Section 2.2. These QPs have relied upon, and believe they have a reasonable basis to rely upon, the internal experts who have contributed to the legal, political, royalty, taxation, environmental and land tenure information stated in the Technical Report. The QPs responsible for the Technical Report have reviewed the information provided by the internal experts and based on the QPs' review of this information, believe it to be reasonable and reliable.

The information, conclusions, opinions and estimates contained in the Technical Report are based on the following parameters:

- Information available to LaRonde Complex at the time of preparation of the Technical Report
- Assumptions, conditions and qualifications as set forth in the Technical Report

The status of the mining titles (claims and mining leases) is managed by the Exploration Division, under the responsibility of the Company's mining titles manager for Quebec. The QPs have not performed an independent verification of the land title and tenure information, as summarized in Section 4 of the Technical Report, nor have they verified the legality of any underlying agreement(s) that may exist concerning the permits or other agreement(s) between third parties, as summarized in Section 4 of the Technical Report.
For this topic, the QPs have relied on information provided by the legal department of the LaRonde Complex and have reviewed claim holdings using the Government of Québec's online Public Register of Real and Immovable Mining Rights ("GESTIM").
The QPs have relied on various departments at the LaRonde Complex and the Company's Head Office for guidance on applicable market studies, contracts, taxes, royalties and other government levies or interests, applicable to revenue or income from the LaRonde Complex.
Except for the purposes legislated under applicable securities laws, any use of this Technical Report by any third party is at that party's sole risk.

[[@~@]]
# 4 Property Description And Location

The LaRonde Complex property (the "Property") consists of the LaRonde Mine and LZ5 Mine mining operations, and the contiguous LaRonde, Bousquet, Ellison, El Coco and Terrex properties.

[[%~%]]
## 4.1 Location

The Property is situated approximately halfway between the City of Rouyn-Noranda and the City of Val-d'Or in the Province of Québec, Canada, in the municipalities of Preissac and RouynNoranda (Cadillac District) (Figure 4.1). The approximate centre of the Property is at Latitude $48^{\circ} 15^{\prime} \mathrm{N}$ and Longitude $78^{\circ} 16^{\prime} \mathrm{W}$ and the approximate UTM coordinates are 690850 m E, 5347 485m N, NAD 83, Zone 17.

[[%~%]]
## 4.2 Mining Title Status

The Property consists of a contiguous block comprising five mining leases and 63 mining claims for a total of 3,324.86 ha (Figure 4.2). Expiration dates for the mining leases on the Property range from August 21, 2023, to July 1, 2034, and each mining lease is automatically renewable upon payment of a small fee for three further 10-year terms after the initial 20-year term. A list of claims and mining leases is provided in Table 4.1. All claims and mining leases are held 100\% by Agnico Eagle Mines Limited.
In recent years, previous mining titles (claims) described in different reports have been converted into map-designated cells by GESTIM and the original property boundaries no longer exactly match the resulting cell boundaries. The changes in property boundaries are minor and considered negligible.
The status of the mining titles (claims and mining leases) was supplied and is managed by the Exploration Division of Agnico Eagle as a responsibility of the Mining Titles Manager. The status of the mining titles on the Property was also verified using the Government of Québec's online claim management system via the GESTIM website. All mining titles of the Property on GESTIM are registered to Agnico Eagle Mines Limited.
Each of the properties constituting the current Property are described below.

[[%~%]]
### 4.2.1 Laronde Property

The LaRonde property consists of 19 contiguous mining claims and one provincial mining lease (BM-796) and covers 1,441 ha in total. The mining lease BM-796 covering 491.9 ha was issued in October 1988 and was initially valid for a 20-year period. BM-796 was originally registered under the name of Dumagami Mines Ltd., which was amalgamated with Agnico Eagle Mines Limited in 1989. The mining lease on the LaRonde property was renewed in 2018 for further 10-year terms upon payment of a small fee.

[[%~%]]
### 4.2.2 Bousquet Property

The Bousquet property is located immediately west of the LaRonde property and consists of two mining leases covering 80.0 ha and 17 claims covering 646.9 ha registered under the name of Agnico Eagle Mines Limited. The mining leases BM-689 and BM-698 were originally granted to Lac Minerals Ltée. from the Québec Ministry of Natural Resources and Wildlife on June 4, 1980.![img-1.jpeg](img-1.jpeg)

Figure 4.1 - Location and property boundaries of LaRonde Complex, Province of Quebec, as at December 31, 2022In 1994 the Bousquet property along with the mining leases BM-689 and BM-698 were acquired by Barrick Gold Corporation. The Bousquet property including the two mining leases were acquired 100\% by Agnico Eagle from Barrick Gold in September 2003. The property remains subject to a 2\% net smelter return royalty interest in favour of Royal Gold Inc.

[[%~%]]
### 4.2.3 Ellison Property

The Ellison property is located immediately west of the Bousquet property and consists of six claims covering 176.5 ha. The Ellison property was acquired 100\% by Agnico Eagle from Yorbeau Resources Inc. in 2002. A remaining net smelter return royalty on the Ellison property held by Yorbeau Resources Inc. was acquired by Agnico Eagle in 2017, resulting in the Ellison property no longer being subject to a royalty.

[[%~%]]
### 4.2.4 El Coco Property

The El Coco property covers 369.6 ha in total and consists of nine contiguous mining claims and one provincial mining lease. The mining lease BM-854, which totals 59.68 ha and covers Lot 62 in Cadillac Township (Val-d'Or Mining District), was granted to Agnico Eagle Mines in June 2001 for a 20-year period by the Ministry of Natural Resources and Wildlife in Quebec.
The mining lease on the El Coco property expires in 2031.
Agnico Eagle acquired the El Coco property from Barrick Gold Corporation in June 1999 and two remaining royalties on the property held by Barrick Gold Corporation were acquired by Agnico Eagle in 2014. The El Coco property is no longer subject to any royalty.

[[%~%]]
### 4.2.5 Terrex Property

The Terrex property is located immediately south of the LaRonde property and consists of mining lease BM-1027 and 12 contiguous mining claims that cover 610.9 ha in total.
The main orebody of the LaRonde Mine shows a down plunge continuity onto the Terrex property at depth. An application for a new mining lease on the Terrex property was submitted by Agnico Eagle in October 2012 and the mining lease BM-1027 was received on July 2, 2014. The mining lease BM-1027 covers 80.184 ha and is valid for a 20-year period.
The Terrex property is subject to a 5\% net profits royalty to Delfer Gold Mines Inc. The Company started development and production on the Terrex property in 2021.

[[%~%]]
### 4.2.6 Additional Surface Rights

The Company has three surface rights leases that cover approximately 453.497 ha in total relating to the water pipeline right of way from Preissac Lake and the eastern extension of the LaRonde Tailings Pond \#7 on the El Coco property (Table 4.2). The surface rights leases are renewable annually. In the Province of Quebec, the holder of a mining lease is generally also granted the surface rights. At LaRonde, the Quebec Ministry of Transport retains surface rights over a small portion of the BM-796 mining lease that underlies a portion of Regional Highway 395 that totals 8.16 ha in Block 33 of Bousquet Township. The mining leases are legally surveyed. The boundary of the surface rights leases and the area of the tailing ponds on BM-796 are approximate.![img-2.jpeg](img-2.jpeg)

Figure 4.2 - Map of active mining titles within the LaRonde Complex Property in 2022, showing mining lease and claim numbersTable 4.1 - Claims and mining leases at LaRonde Complex

| Mining titles type | Title number | Project number | Property name | Expiration date | Area (ha) | Owner | AEM mining rights | Agreements and encumbrances |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| BM | 796 | 021 | LaRonde | 2028-10-31 | 491.89 | Agnico Eagle Mines Ltd. | 100\% | No royalty |
| CDC | 2429562 | 021 | LaRonde | 2024-05-15 | 57.33 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429563 | 021 | LaRonde | 2024-05-15 | 57.33 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429573 | 021 | LaRonde | 2024-05-15 | 57.34 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429574 | 021 | LaRonde | 2024-05-15 | 57.34 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429575 | 021 | LaRonde | 2024-05-15 | 57.34 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429576 | 021 | LaRonde | 2024-05-15 | 57.34 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429577 | 021 | LaRonde | 2024-05-15 | 57.34 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429578 | 021 | LaRonde | 2024-05-15 | 57.34 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429579 | 021 | LaRonde | 2024-05-15 | 57.34 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429581 | 021 | LaRonde | 2024-05-15 | 57.33 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429582 | 021 | LaRonde | 2024-05-15 | 57.33 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429583 | 021 | LaRonde | 2024-05-15 | 57.33 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429584 | 021 | LaRonde | 2024-05-15 | 57.33 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429585 | 021 | LaRonde | 2024-05-15 | 57.33 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429586 | 021 | LaRonde | 2024-05-15 | 57.33 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429587 | 021 | LaRonde | 2024-05-15 | 57.33 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429622 | 021 | LaRonde | 2024-05-15 | 6.59 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429623 | 021 | LaRonde | 2024-05-15 | 13.34 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429672 | 021 | LaRonde | 2023-09-20 | 11.79 | Agnico Eagle Mines Ltd. | 100\% |  |
| BM | 689 | 126 | Bousquet | 2025-06-03 | 35.9 | Agnico Eagle Mines Ltd. | 100\% | Titles are subject to a 2\% NSR royalty payable to Royal Gold Inc. |
| BM | 698 | 126 | Bousquet | 2025-06-03 | 44.12 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579138 | 126 | Bousquet | 2023-08-21 | 57.34 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579139 | 126 | Bousquet | 2023-08-21 | 57.34 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579140 | 126 | Bousquet | 2023-08-21 | 57.34 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579141 | 126 | Bousquet | 2023-08-21 | 57.34 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579142 | 126 | Bousquet | 2023-08-21 | 57.33 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579153 | 126 | Bousquet | 2023-08-21 | 52.27 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579157 | 126 | Bousquet | 2023-08-21 | 52.19 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579158 | 126 | Bousquet | 2023-08-21 | 32.96 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579162 | 126 | Bousquet | 2023-08-21 | 32.05 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579163 | 126 | Bousquet | 2023-08-21 | 38.17 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579164 | 126 | Bousquet | 2023-08-21 | 47.48 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579165 | 126 | Bousquet | 2023-08-21 | 4.1 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579166 | 126 | Bousquet | 2023-08-21 | 0.93 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579168 | 126 | Bousquet | 2023-08-21 | 12.89 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579169 | 126 | Bousquet | 2023-08-21 | 48.75 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579170 | 126 | Bousquet | 2023-08-21 | 33.66 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579171 | 126 | Bousquet | 2023-08-21 | 4.77 | Agnico Eagle Mines Ltd. | 100\% |  |
| BM | 1027 | 125 | Terrex | 2034-07-01 | 80.18 | Agnico Eagle Mines Ltd. | 100\% | Titles are subject to a 5\% NPI royalty payable to Delfer Gold Mines Inc. |
| CDC | 2579133 | 125 | Terrex | 2023-08-21 | 57.36 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579144 | 125 | Terrex | 2023-08-21 | 57.37 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579145 | 125 | Terrex | 2023-08-21 | 57.37 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579146 | 125 | Terrex | 2023-08-21 | 57.37 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579147 | 125 | Terrex | 2023-08-21 | 46.66 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579148 | 125 | Terrex | 2023-08-21 | 16.41 | Agnico Eagle Mines Ltd. | 100\% |  || Mining <br> titles <br> type | Title <br> number | Project <br> number | Property <br> name | Expiration <br> date | Area <br> (ha) | Owner | AEM <br> mining <br> rights | Agreements and <br> encumbrances |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| CDC | 2579149 | 125 | Terrex | 2023-08-21 | 22.99 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579150 | 125 | Terrex | 2023-08-21 | 42.44 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579151 | 125 | Terrex | 2023-08-21 | 6.71 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579154 | 125 | Terrex | 2023-08-21 | 56.1 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579155 | 125 | Terrex | 2023-08-21 | 54.96 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579156 | 125 | Terrex | 2023-08-21 | 55 | Agnico Eagle Mines Ltd. | 100\% |  |
| BM | 854 | 106 | El Coco | 2031-06-04 | 59.68 | Agnico Eagle Mines Ltd. | 100\% | No royalty <br> (Previous royalty <br> acquired by AEM <br> from Barrick Gold <br> Corp. in 2014) |
| CDC | 2429564 | 106 | El Coco | 2024-05-15 | 57.35 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429565 | 106 | El Coco | 2024-05-15 | 57.35 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429605 | 106 | El Coco | 2024-05-15 | 0.91 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429606 | 106 | El Coco | 2024-05-15 | 0.65 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429607 | 106 | El Coco | 2024-05-15 | 57.33 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429660 | 106 | El Coco | 2024-05-15 | 1.87 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429661 | 106 | El Coco | 2024-05-15 | 46.35 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429662 | 106 | El Coco | 2024-05-15 | 50.71 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2429663 | 106 | El Coco | 2024-05-15 | 37.36 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2423252 | 121 | Ellison | 2024-04-17 | 9.76 | Agnico Eagle Mines Ltd. | 100\% | No royalty <br> (Previous royalty <br> acquired by AEM <br> from Yorbeau <br> Resources Inc. <br> in 2017) |
| CDC | 2579152 | 121 | Ellison | 2023-08-21 | 56.03 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579159 | 121 | Ellison | 2023-08-21 | 51.16 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579160 | 121 | Ellison | 2023-08-21 | 8.96 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579161 | 121 | Ellison | 2023-08-21 | 50.35 | Agnico Eagle Mines Ltd. | 100\% |  |
| CDC | 2579167 | 121 | Ellison | 2023-08-21 | 0.23 | Agnico Eagle Mines Ltd. | 100\% |  |

Table 4.2 - Public surface rights at LaRonde Complex

| Project | Document \# | Description | Area (ha) |
| :-- | --: | :-- | --: |
| 21 - LaRonde | 305629 | Public surface rights - Extension of tailings pond | 12.457 |
| 21 - LaRonde | 807400 | Public surface rights - Water line for LaRonde Mine | 2.1 |
| 106 - El Coco | 816693 | Public surface rights - Block 101 - New lease in 2019 | 438.94 |

[[%~%]]
## 4.3 Agreements And Encumbrances

The mining titles constituting the current LaRonde Complex Property were acquired by Agnico Eagle first in stages during the 1980s and then in 2003 for the Bousquet property from Barrick Gold Corporation. Many of the mining titles for the Property are not subject to any encumbrances.
The Bousquet property mining titles are subject to a 2\% net smelter return ("NSR") royalty payable to Royal Gold Inc. and the Terrex property mining titles are subject to a 5\% net profits interest ("NPI") royalty payable to Delfer Gold Mines Inc.

[[%~%]]
## 4.4 Mining-Incompatible Territory

At the time of the filing of the Technical Report, no part of the Property is considered "miningincompatible territory" as described under Section 304.1.1 of the provincial Mining Act.

[[%~%]]
## 4.5 Permitting And Authorization

Agnico Eagle Mines has obtained all currently required permits to continue carrying out the mining operations on the Property. The LaRonde Complex is governed by several certificates of authorization issued by the Ministry of Sustainable Development, Environment, and the Fight Against Climate Change (MDDELCC). Refer to Section 20 of this Technical Report for a detailed description of the current permitting status.
To permit the future extension of LZ5 Mine operations at depth, an application for a new mining lease on the Ellison property is expected to be submitted by Agnico Eagle in 2023.

[[%~%]]
## 4.6 Environmental Liabilities

The primary environmental considerations and potential liabilities for the LaRonde Complex are related to the operations of the water treatment plants ("WTP" and "FWTP"), the tailings storage facility ("TSF") and waste management. Agnico Eagle prioritizes the management of tailings at all its operations and is in the process of aligning the Company's tailings management system including the system utilized at LaRonde Complex with best practices proposed by the Mining Association of Canada guidelines.
Additional details on tailings infrastructure and management at the LaRonde Complex are provided in Sections 18 and 20 of the Technical Report.
The QP responsible for this section of the Technical Report is not aware of any other significant factors and risks that may affect access, title, or the right or ability to perform mining and exploration work on the property.

[[@~@]]
# 5 Accessibility, Local Resources, Climate, Physiography And Infrastructure

[[%~%]]
## 5.1 Accessibility

The Property is located in the Abitibi-Témiscamingue administrative region in the northwestern area of the Province of Québec, Canada. The Property can be accessed from the city of Val-d'Or in the east and from the city of Rouyn-Noranda in the west, each of which are located approximately 60 km from the LaRonde Complex via Quebec provincial Highway 117. The LaRonde Complex is situated approximately 2 km north of Highway 117 on Quebec regional Highway 395, which passes through the middle of the Property. The vehicle circulation on the Property is on private, Agnico-owned paved and gravel roads. The physical address for LaRonde Complex is 10 200, Route de Preissac, Rouyn-Noranda, Québec, Canada.
Val-d'Or and Rouyn-Noranda have airports that can accommodate jet aircraft. Freight can be sent by rail to the Canadian National Railway station at the town/district of Cadillac, located 10 km from the Property.

[[%~%]]
## 5.2 Local Resources And Infrastructure

The Abitibi region of northwestern Quebec is known as a mining region and it has sufficient experienced mining personnel to staff the Company's operations in the Abitibi region. The Property is well serviced due to its close proximity to Val-d'Or and Rouyn-Noranda. These cities have a large pool of trained and experienced personnel for mining and construction as well as operations. This region also hosts numerous suppliers and fabricators for the mining industry.
All of the power requirements for the LaRonde Complex are supplied by Hydro-Québec through connections to its main power transmission grid. Water used in the LaRonde Mine's operations is sourced from Lac Preissac/Chassignolle and is transported by pipeline over a distance of approximately 4 km . Water for the LZ5 Mine operations is sourced from the Bousquet River and transported by pipeline over approximately 1.2 km .

[[%~%]]
## 5.3 Climate And Vegetation

The Abitibi region has a continental climate with an average annual precipitation of 927 mm . This includes 640 mm of rainfall (maximum monthly rainfall is 103 mm in September) and 3,180 mm of snowfall (maximum monthly snowfall is 650 mm in December). The snow stays on the ground from mid-November until the ice leaves the lakes in early to mid-May. Winters are cold with temperatures averaging $-15^{\circ} \mathrm{C}$ in January and February. The ground is frost-free from May to October. Summers are warm and relatively dry with a mean temperature of $22^{\circ} \mathrm{C}$. Under normal circumstances, mining operations are conducted year-round without interruption due to weather conditions.
A boreal-type forest covers much of the undeveloped portions of the Property, consisting mainly of black spruce and poplar with minor birch, tamarack and balsam fir.

[[%~%]]
## 5.4 Physiography And Topography

The Property is located in the Abitibi lowlands and is relatively flat, consisting of plains with a few small hills and maximum relief of approximately 40 m . The topography gently slopes down from north to south, and the average elevation is 337 m above sea level.In the eastern part of the Property, the surface water drains southeast into Dormenan Creek, which follows the southern boundary of the Property and is a tributary to Noir Creek, located 2 km to the east. Noir Creek flows northward into Lake Preissac, about 4 km north of the Property.
In the western part of the Property, the surface water drains southwest into Yorbeau Creek, which follows the southern boundary of the Property and then turns northward along the western boundary of the Property and becomes a tributary to the Bousquet River, located 1 km to the north. The Bousquet River flows northward into Chassignolle Lake, about 3 km to the north of the Bousquet property.

[[%~%]]
## 5.5 On-Site Infrastructure

There is significant infrastructure available at the LaRonde Complex. Surface mining, milling and tailings infrastructure cover roughly 60\% of the LaRonde Complex leases (Figure 5.1 and Figure 5.2).

Since 2017, additional facilities have been constructed at the LZ5 Mine site including a paste plant, small tank farm, mobile equipment garage and an electrical substation. The LZ5 Mine tailings are directed from the LZ5 mill plant to the LaRonde tailings storage facility, and water is treated at the LaRonde water treatment plant before discharge.
Additional details on mining, milling, tailings infrastructure and tailings management at the LaRonde Complex are provided in Sections 18 and 20 of the Technical Report.![img-3.jpeg](img-3.jpeg)

Figure 5.1 - Surface plan map of LaRonde Complex as at December 31, 2022![img-4.jpeg](img-4.jpeg)

Source: AEM, December 2021
Figure 5.2 - Infrastructure and landscape: A) Penna Shaft headframe and main office; B) Tailings storage facility; C) Mineral processing plant including LaRonde mill and LZ5 mill; D) LZ5 open pit \& portal, paste plant and mobile equipment garage

[[@~@]]
# 6 History

The Property's mining history extends more than 80 years from the late 1930s to the present day. Its history reflects the evolution of the Doyon-Bousquet-LaRonde mining camp and the wider Cadillac mining district, from initial gold discoveries to a more mature mining camp with ongoing production and expansion.
The current limits of the Property cover and overlap many historical mining and exploration properties. The boundaries and names of these properties have changed over time following ownership and/or option changes, abandoned and/or added claims, and status changes from exploration claim to mining lease.

The Property is the product of several consolidation phases. Table 6.1 summarizes the main companies that have been active on the Property and the production phases. Various other prospectors and junior exploration companies of minor historical significance have also been involved in the Property and are not detailed in the Technical Report.
The Property hosts five historical underground mines (Figure 6.1): Bousquet No. 1 (now related to current LaRonde Zone 5 operation), Bousquet No. 2, Dumagami / LaRonde Shaft \#1, LaRonde Shaft \#2 and the Penna Shaft which is still in production. In modern times, gold production on the Property has been continuous since 1978. During the same period, a series of small open pit operations have also been mined by owners.
As at December 31, 2022, total gold production from the Property is 10.8 million ounces of gold from 78.2 million tonnes grading an average of $4.63 \mathrm{~g} / \mathrm{t}$ gold (Table 6.2).
From 1974 to 2002, the Bousquet property ownership changed from Long Lac Exploration Ltd. to Lac Minerals Ltd. and then to Barrick Gold. Ownership then passed to Agnico Eagle Mines Ltd. in 2003. Agnico Eagle had already acquired the Ellison property from Yorbeau Resources Inc. in 2002.

Since 2003, Agnico Eagle Mines Ltd. has held a 100\% ownership in all the properties at the LaRonde Complex. The evolution of the LaRonde Complex into a multi-mine facility began with the approval by the Company's Board of Directors of the LaRonde Zone 5 ("LZ5") Project in 2016 and followed by commercial production at LZ5 in 2018.
The historical production data reported in this section of the Technical Report were obtained from Agnico Eagle's historical reports and a compilation of Bousquet's historical reports.Table 6.1 - Activity at LaRonde Complex since 1924, showing exploration and production periods, and property acquisitions / consolidations
![img-5.jpeg](img-5.jpeg)![img-6.jpeg](img-6.jpeg)

Figure 6.1 - Schematic composite longitudinal view (looking north) of underground mining infrastructure, historical production areas and locations of mineral resources and mineral reserves at LaRonde Complex at year-end 2022Table 6.2 - Summary of historical gold, silver and base metals production at LaRonde Complex (1978-2022)

| Historical group of properties | Owners and/or property area | Years | Tonnage milled (000 t) | Gold grade (g/t) | Gold (in situ) (000 oz.) | Production paid net from smelter |  |  |  |  | Metallurgical recovery for gold (\%) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  |  |  |  |  |  | Gold (000 oz.) | Silver (000 oz.) | Copper (000 lbs.) | Zinc (000 lbs.) | Lead (000 lbs.) (2008-13) |  |
| LaRonde* | Agnico Eagle | $\begin{gathered} 1988- \\ 2022 \end{gathered}$ | 58,026 | 4.08 | 7,698 | 7,119 | 62,050 | 330,873 | 1,909,302 | 14,113 | 92.5 |
| Bousquet | Bousquet Complex (Long Lac / Lac Minerals / Barrick Gold) | $\begin{gathered} 1978- \\ 2002 \end{gathered}$ | 15,591 | 7.21 | 3,612 | 3,399 | n/a | 100,887 | n/a | n/a | 94.1 |
|  | Agnico Eagle | 2003-07 | 211 | 4.57 | 31 | 28 | 27 | 175 | 81 | n/a | 91.3 |
|  | LZ5 - Agnico Eagle | 2017-22 | 4,340 | 2.15 | 300 | 283 | n/a | n/a | n/a | n/a | 94.6 |
| LaRonde Complex Total | Agnico Eagle / Long Lac / Lac Minerals / Barrick Gold | $\begin{gathered} 1978- \\ 2022 \end{gathered}$ | 78,168 | 4.63 | 11,641 | 10,830 | 62,078 | 431,935 | 1,909,383 | 14,113 | 93.0 |

*Includes production from LaRonde, El Coco and Terrex properties.

[[%~%]]
## 6.1 Exploration And Mine Development At Laronde Property

The Property has been the subject of multiple exploration programs including prospecting, geological mapping, geophysical surveys, geochemical surveys, and drilling (surface and underground, from exploration to mineral resource definition). It has also been the subject of several studies on various topics and at various scales, from local mineral resource and mineral reserve estimates and engineering studies to regional geological surveys, syntheses, and academic research.

[[%~%]]
### 6.1.1 Historic Exploration And Discovery

Marquis, Huber and Brown et al. (1992) presented a comprehensive description of the exploration and development work completed on the LaRonde property prior to 1989 (Table 6.3). The work was also summarized by Trudel et al. (1992).
In 1937, Scott Chibougamau Mines Ltd. completed $70 \mathrm{~m}^{2}$ of outcrop stripping and trenching. This work uncovered several quartz-tourmaline-pyrite-pyrrhotite veins with traces of chalcopyrite and sericite and revealed the presence of massive sulphides (pyrite) on the property. This showing was found in the vicinity of the original LaRonde no. 1 open pit (or East) zone.
In 1961, Rio Tinto Canadian Exploration Ltd. and O'Brien Gold Mines Ltd. conducted a reconnaissance electromagnetic survey in the area and investigated seven conductors.
In 1963, Dumagami Mines Ltd. staked 46 claims (696.1 ha) covering the Scott Chibougamau Mines gold-silver-copper showing centered on the current LaRonde property. In 1963 and 1964, Dumagami Mines Ltd. completed geological, magnetic and electromagnetic surveys and 51 diamond drill holes $(10,274 \mathrm{~m})$. Most of the holes tested the area around the main showing (East zone) with the rest scattered along the axis of the mineralized zone.
In 1965, Dumagami Mines published a mineral resource estimate. The report's conclusion was that the grades were too low to justify an economic operation and work was suspended on the property.
In 1974, Mentor Exploration and Development Company Ltd. (part of the Agnico Eagle Group of companies) joined Noranda Mines and Iso Mines, which had been the principal shareholders of Dumagami Mines since 1961.
In 1975, Dumagami Mines completed 19 diamond drill holes $(1,364 \mathrm{~m})$ to evaluate the open pit potential of the mineral reserves to a depth of 61 m . Some overburden stripping over the main zone of mineralization (East zone) and metallurgical tests were also completed. In 1976, a decline in the price of gold led to a cancellation of plans to bring the main zone into production.
In 1979, Agnico Eagle Mines Ltd. became a shareholder of Dumagami Mines Ltd. (joining Noranda Mines Ltd. and Mentor Exploration and Development Company Ltd.) and became the operator of the exploration program on the Dumagami property (later renamed the LaRonde property).
In 1980, detailed geological mapping, litho-geochemical sampling and additional overburden stripping were completed over the main zone of mineralization and elsewhere on the property, and 20 diamond drill holes were completed $(3,537 \mathrm{~m})$.
Between 1983 and 1985, Dumagami Mines carried out an underground and surface exploration program on the main zone of mineralization with work that included: sinking a three-compartment shaft to a depth of 435 m ; completing underground development totalling $3,347 \mathrm{~m}$ on five levels; underground definition and exploration drilling totalling $18,985 \mathrm{~m}$; and a surface diamond drilling program totalling $7,349 \mathrm{~m}$.Table 6.3 - Historical exploration and mining at LaRonde property (1937-2022)

| Year | Company | References | Work program, exploration and results |
| :--: | :--: | :--: | :--: |
| 1937 | Scott Chibougamau Mines Ltd. |  | Surface work, outcrop stripping and trenching on near-surface massive sulphides (pyrite-chalcopyrite) |
| 1961 | Rio Tinto Canadian Exploration Ltd., O'Brien Gold Mines Ltd. |  | Electromagnetic surveying discovers 7 conductors |
| 1963-65 | Dumagami Mines Ltd. |  | Staking (46 claims, 696.1 ha). Geological, magnetic and electromagnetic surveys. 51 drill holes $(10,274 \mathrm{~m})$. First mineral resource estimate (uneconomic). |
| 1975-76 | Dumagami Mines Ltd. |  | 19 drill holes (1,364 m), metallurgical testing |
| 1980 | Dumagami Mines Ltd. | GM-37331 | 20 drill holes $(3,537 \mathrm{~m})$. <br> Stripping, geological mapping and sampling. |
| 1981 | Dumagami Mines Ltd. | GM-38404 | Geochemical assaying |
| 1983-85 | Dumagami Mines Ltd. |  | Underground and surface exploration program. <br> Shaft at 435 m depth. <br> Drilling of 26,334 m. |
| 1986 | Dumagami Mines Ltd. |  | Revised mineral resource estimate (uneconomic). Discovery of new gold-rich zone (West Zone) at vertical depth of 854 m . Drilling of $3,894 \mathrm{~m}$ and underground development of 820 m . |
| 1987 | Dumagami Mines Ltd. | Anderson <br> (1987) | Positive feasibility study. <br> Deepening of Shaft \#1 to 975 m . <br> Building concentrator at 1,360 tpd. |
| $\begin{aligned} & 1988- \\ & 2000 \end{aligned}$ | Dumagami Mines Ltd. / Agnico Eagle Mines Ltd. |  | Commercial production at Shaft \#1 |
| 1989 | Agnico Eagle Mines Ltd. |  | Agnico Eagle acquires 100\% of outstanding shares of Dumagami Mines Ltd. |
| $\begin{aligned} & 1990- \\ & 2022 \end{aligned}$ | Agnico Eagle Mines Ltd. |  | Continuous U/G exploration drilling program and production. Exploration drift on levels 86, 215, 290 and 292. |
| 1992-93 | Agnico Eagle Mines Ltd. |  | Discovery of Zone 6, Zone 7 (Shaft \#2). <br> Discovery of Zone 20 North, Zone 20 South and Zone 7 (Penna Shaft). |
| $\begin{aligned} & 1995- \\ & 2000 \end{aligned}$ | Agnico Eagle Mines Ltd. |  | Commercial production at Shaft \#2 |
| 2006 | Agnico Eagle Mines Ltd. | Girard et al. (2006) | Approval of LaRonde II Project to 3.1 km depth. <br> Sinking Shaft \#4 to 2.8 km depth. |
| 2015-22 | Agnico Eagle Mines Ltd. |  | LaRonde 3 exploration drilling program (3.1 to 3.8 km depth) |
| 1999- <br> present | Agnico Eagle Mines Ltd. |  | Commercial production at Penna Shaft |In January 1986, Dumagami Mines published a revised mineral resource estimate (to a depth of 221 m ) for the no. 3 and no. 5 lenses (East zone). Although the deposit was determined to be uneconomic, approval was given to pursue a limited surface drill program to the west of the main zones of mineralization and a single underground drill hole. In early 1986, a new and relatively gold-rich zone of mineralization (West zone) was discovered at depth and to the west of the previous mineralization, with the discovery hole $86-3$ intersecting $7.76 \mathrm{~g} / \mathrm{t}$ gold over 9.1 m at a vertical depth of 854 m . A further 820 m of underground development on two levels and $3,894 \mathrm{~m}$ of diamond drilling were completed.
In 1987, Dumagami Mines completed a positive feasibility study (Anderson 1987) that recommended building a concentrator capable of treating 1,360 tpd. Shaft \#1 was deepened to 975 m .

Agnico Eagle acquired 100\% of the outstanding shares of Dumagami Mines Limited on December 19, 1989, and on December 29, 1992, Dumagami transferred all its property and assets, including the LaRonde mine, to Agnico Eagle Mines Ltd. and subsequently dissolved.

[[%~%]]
### 6.1.2 Mine Development And Exploration

Commercial production at LaRonde began in October 1988. In 1989, the production rate was increased to $1,810 \mathrm{tpd}$.

In 1990, a surface and underground exploration program was initiated over the eastern portion of the LaRonde property. The surface diamond drilling program led to the discovery of Zone 4 (Open Pit no. 2) in 1991 and Zone 6 and Zone 7 in 1992.

The underground exploration program initiated in 1990 consisted of exploration drilling of the favourable horizon from a main exploration drift on Level 20 ( 860 m below surface) that extended to the eastern boundary of the LaRonde property. A small lens corresponding to Zone 7 (block 72) was discovered in 1991 while zones 20 North Gold (formerly Zone 19), 20 North Zinc, 20 South and Zone 6 (at depth) were found in 1992 and 1993.
In 1993, Zone 4 was test-mined via a small open pit. Open Pit no. 2 was mined-out by 1999 and milling of the stockpiled ore was completed in 2000.
In 1994, Shaft \#1 was deepened to 1,205 m and Shaft \#2 was completed to a depth of 525 metres. Mining began at Shaft \#2 in 1995.
In 1994, the Company initiated the Penna Shaft underground exploration and development program and a mill expansion program.
In 2000, a transition took place in production from Shaft \#1 and Shaft \#2 towards the newly commissioned Penna Shaft. Underground production from Shaft \#2 ceased in April 2000 and underground production from Shaft \#1 zones stopped in October 2000. The Penna Shaft was completed to a depth of $2,250 \mathrm{~m}$, the shaft changeover was completed and the $4,500 \mathrm{tpd}$ production hoist and ore handling facilities were commissioned. The LaRonde mill capacity was increased to $4,500 \mathrm{tpd}$.
In 2001, surface exploration on the El Coco property led to the discovery of Zone 22, located 1.5 km east of the Penna Shaft at 300 m below surface. The exploration drift on Level 86 ( 860 m depth) was extended to the east across the El Coco property.
In October 2002, the hoisting and ore handling facilities were expanded to 6,300 tpd at the Penna Shaft, and the LaRonde mill capacity was increased to 6,300 tpd.
Since 2002, underground exploration work has been completed on Level 215 (2,150 m depth) from an exploration drift approximately 400 m to the north of the favourable rock sequence thathosts the massive sulphides lenses on the LaRonde property. The LaRonde II exploration campaign is following the deep extension of the Penna Shaft lenses to a depth of 3,300 m.
In 2005, the Company completed an optimized feasibility study of LaRonde II (or LaRonde Extension). This feasibility study was independently reviewed and development of LaRonde II was approved by the Company's Board of Directors in May 2006.
In 2009, as part of the LaRonde Mine extension, the Company completed construction of an 823-m internal shaft (Shaft \#4) from Level 206 to access the ore below Level 245, approximately $2,858 \mathrm{~m}$ below surface.
In November 2011, the first ore was hoisted from Shaft \#4.
Between 2015 and 2017, an underground exploration drift was completed on Level 290 in the western part of the mine at 2,900 m depth. Since 2015, the LaRonde 3 exploration campaign is following the deep extension of the Penna Shaft lenses to a depth of 3,700 m in both the West Mine area and East Mine area of Zone 20 North and Zone 6.
In late 2020, Agnico Eagle resumed underground development and exploration to the west of Zone 20 North with exploration drifts extended westward on Level 290 and Level 215.
In 2022, the development of the exploration drift on Level 215 continued towards the west, and further westward extension of the drift is planned in 2023.

[[%~%]]
### 6.1.3 Production At Laronde Property

The annual and cumulative payable metal production at the LaRonde Mine, and the division's production history by shaft are shown in Table 6.4 and Table 6.5, respectively. At LaRonde's Penna Shaft, the rate of ore extraction decreased during recent years mainly due to the increasing mining depth and resulting mining constraints.
The ore that is extracted on the Property is milled at both the LaRonde mill and the LZ5 mill, which are adjacent. The LZ5 mill was previously named the Lapa mill as from 2009 to June 2018 it milled ore from the Company's nearby Lapa Mine. With the closure of Lapa, the mill became available to process ore from the LZ5 Mine.
In June 2016, the LaRonde Mine reached the milestone of 5 million ounces of accountable gold production.
With the increase of tonnage that could be mined at LZ5, it became necessary to optimize both mills. The resulting optimization of the LaRonde Complex's milling capacity in 2019 has allowed the Company to process ore from the LZ5 Mine in both available mills (LaRonde and LZ5).
In 2018 and 2019, nearly 95\% of the ore processed from the LaRonde Mine was extracted from the deeper portion of the mine below Level 245. In 2023, 100\% of the ore processed will be from this deeper part of the mine.Table 6.4 - LaRonde Mine milled annual production to December 31, 2022

| Year | Ore milled (t) | Gold grade (g/t) | Production paid net from smelter |  |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  |  |  | Gold (oz.) | Silver (oz.) | Copper (lbs.) | Zinc (lbs.) | Lead (lbs.) |
| 1988 | 280,712 | 3.4 | 25,792 | 39,868 | 412,270 | - | - |
| 1989 | 629,434 | 4.8 | 84,974 | 127,339 | 1,394,567 | - | - |
| 1990 | 679,830 | 4.8 | 98,326 | 167,886 | 2,023,417 | - | - |
| 1991 | 591,844 | 6.9 | 115,831 | 164,572 | 3,869,050 | - | - |
| 1992 | 545,274 | 8.2 | 134,474 | 266,412 | 7,267,126 | - | - |
| 1993 | 579,264 | 8.9 | 152,355 | 270,671 | 9,207,872 | - | - |
| 1994 | 562,657 | 8.6 | 144,584 | 268,004 | 10,267,443 | - | - |
| 1995 | 660,495 | 8.6 | 167,209 | 330,532 | 12,183,871 | - | - |
| 1996 | 661,673 | 8.2 | 159,558 | 295,674 | 10,489,087 | - | - |
| 1997 | 712,648 | 7.2 | 154,515 | 279,938 | 8,844,441 | - | - |
| 1998 | 704,641 | 7.2 | 150,443 | 269,985 | 6,151,063 | 1,231,446 | - |
| 1999 | 724,306 | 4.1 | 90,035 | 277,327 | 3,282,471 | 9,778,278 | - |
| 2000 | 1,284,494 | 4.8 | 173,852 | 1,128,234 | 4,943,421 | 50,680,921 | - |
| 2001 | 1,637,710 | 5.1 | 234,860 | 2,524,146 | 4,096,247 | 126,275,217 | - |
| 2002 | 1,780,939 | 4.8 | 260,183 | 3,093,543 | 8,927,100 | 108,059,888 | - |
| 2003 | 2,221,358 | 3.8 | 236,653 | 3,953,403 | 20,131,125 | 100,337,485 | - |
| 2004 | 2,700,650 | 3.4 | 271,567 | 5,698,517 | 22,815,827 | 167,282,658 | - |
| 2005 | 2,671,811 | 3.1 | 241,807 | 4,830,980 | 16,265,155 | 168,750,179 | - |
| 2006 | 2,673,080 | 3.1 | 245,826 | 4,955,164 | 16,068,481 | 181,181,100 | - |
| 2007 | 2,673,463 | 3.0 | 231,288 | 5,669,066 | 18,146,833 | 185,847,940 | - |
| 2008 | 2,638,691 | 2.8 | 216,209 | 4,068,656 | 15,260,814 | 144,963,010 | 1,221,106 |
| 2009 | 2,545,830 | 2.8 | 203,392 | 3,919,055 | 14,707,592 | 123,867,193 | 456,264 |
| 2010 | 2,592,292 | 2.2 | 162,806 | 3,577,652 | 9,311,437 | 137,883,863 | 4,309,155 |
| 2011 | 2,406,342 | 1.8 | 124,173 | 3,169,496 | 7,090,964 | 121,020,040 | 5,162,027 |
| 2012 | 2,358,499 | 2.4 | 160,855 | 2,243,674 | 9,096,378 | 85,179,351 | 2,333,745 |
| 2013 | 2,319,132 | 2.6 | 181,781 | 2,102,116 | 10,658,778 | 43,681,658 | 639,363 |
| 2014 | 2,085,346 | 3.2 | 204,652 | 1,274,339 | 11,015,570 | 23,181,179 | $-8,289$ |
| 2015 | 2,241,424 | 3.9 | 267,921 | 915,720 | 10,894,055 | 7,718,607 | - |
| 2016 | 2,240,144 | 4.4 | 305,787 | 987,918 | 9,735,359 | 10,333,842 | - |
| 2017 | 2,246,114 | 5.1 | 348,870 | 1,254,094 | 9,922,420 | 14,351,719 | - |
| 2018 | 2,108,070 | 5.3 | 343,686 | 1,040,045 | 9,243,330 | 17,337,709 | - |
| 2019 | 2,057,187 | 5.5 | 343,154 | 882,935 | 7,489,533 | 29,016,482 | - |
| 2020 | 1,706,447 | 5.5 | 288,239 | 672,475 | 6,765,543 | 13,799,032 | - |
| 2021 | 1,837,310 | 5.5 | 308,946 | 723,961 | 6,513,534 | 19,482,019 | - |
| 2022 | 1,669,900 | 5.6 | 284,780 | 608,825 | 6,396,472 | 18,066,670 | - |
| Total | 58,029,011 | 4.13 | 7,119,384 | 62,052,222 | 330,888,646 | 1,909,307,486 | 14,113,371 |Table 6.5 - LaRonde Mine cumulative production by shaft to December 31, 2022

| Production source | Ore mined <br> $(\mathbf{t})$ | Gold <br> grade <br> $(\mathbf{g} / \mathbf{t})$ | Silver <br> grade <br> $(\mathbf{g} / \mathbf{t})$ | Copper <br> grade <br> $(\%)$ | Zinc <br> grade <br> $(\%)$ | Lead* <br> grade <br> $(\%)$ |
| :-- | --: | --: | --: | --: | --: | --: |
| Penna Shaft | $48,319,018$ | 3.66 | 50.43 | 0.31 | 2.44 | 0.30 |
| Open Pit \#2 | 173,256 | 2.41 | 4.91 | 0.24 | 0.33 | - |
| Shaft \#1 | $6,539,500$ | 6.82 | - | - | - | - |
| Shaft \#2 | 959,516 | 7.34 | 40.67 | 0.73 | 2.54 | - |
| Total LaRonde Mine | $\mathbf{5 5 , 9 9 1 , 2 9 0}$ | $\mathbf{4 . 0 9}$ | $\mathbf{4 4 . 2 3}$ | $\mathbf{0 . 2 8}$ | $\mathbf{2 . 1 5}$ | $\mathbf{0 . 2 6}$ |

*Lead has been produced since 2008; grade is for 2008-2013 production.

[[%~%]]
## 6.2 Exploration And Mine Development At The Bousquet Property

[[%~%]]
### 6.2.1 Historic Exploration And Discovery

Tourigny et al. (1992) presented a comprehensive description of the exploration and development work completed at Bousquet No. 1 prior to 1989.

A compilation of historical activity prior to Agnico Eagle acquiring the Bousquet property in 2003 is shown in Table 6.6.

Gold was first discovered on the Bousquet property in 1937 by Thompson Bousquet Gold Mines Ltd. During the spring of 1938, surface work and diamond drilling identified a large low-grade pyritic band 400 m long over a thickness of 20 m named the Main Zone (Valliant, Mongeau and Doucet 1982), which corresponds to the current Zone 5.

The Main Zone was drilled by Teck Hughes Gold Mines and Siscoe Gold Mines in 1939 and 1944, respectively, confirming an estimation of 2.2 million tonnes grading $2.26 \mathrm{~g} / \mathrm{t}$ gold from surface to a depth of 122 metres. No major exploration work was completed at the Bousquet property from 1945 to 1973.

In 1974, Long Lac Mineral Exploration Ltd. signed an agreement with Malartic Gold Fields to develop the Thompson Bousquet property. The first exploration work included taking a 15,000tonne bulk sample of the Main Zone via a $180-\mathrm{m}$ long exploration ramp. This exploration phase also included geophysical surveys, surface trenching and diamond drilling. During this period, diamond drill holes first intersected the gold-rich Zone 3 located south of the Main Zone and in proximity to claims held by Bijou Gold Mines.
Long Lac Mineral Exploration signed an agreement with Bijou Gold Mines to continue exploration towards the south. During 1976 and 1977, a drilling campaign of 117 diamond holes (19,721 m) was performed to test the extension of the Zone 3 discovery. A 12,000-tonne bulk sample from Zone 3 was completed in 1978.Table 6.6 - Historical exploration and mining at Bousquet property (1937-2002)

| Year | Company | Work programs, exploration and results |
| :--: | :--: | :--: |
| $1937-38$ | Thompson Bousquet Gold Mines Ltd. | Surface work and diamond drilling led to first discovery of gold on property in low-grade pyritic band 400 m long by 20 m thick named "Main Zone" (now "Zone 5") - 29 DDH. |
| 1939 | Teck Hughes Gold Mines | Diamond drilling of Main Zone |
| 1944 | Siscoe Gold Mines | Diamond drilling. Early historical mineral reserves for Main Zone estimated at 2.18 million tons (unspecified type of tonnes) grading $2.26 \mathrm{~g} / \mathrm{t}$ gold, from surface to a depth of 122 m (Tourigny, et al. 1992). |
| $1974-78$ | Long Lac Mineral Exploration Ltd. | Restarted exploration by taking 15,000-tonne bulk sample of Main Zone from 180-m-long exploration ramp. Discovered gold-rich Zone 3 orebody south of Zone 5. |
| $1978-2002$ | Lac Minerals/ Barrick Gold Corporation | 1978 -1996: Bousquet Shaft \#1 in operation, mining 7.4 Mt at $5.7 \mathrm{~g} / \mathrm{t}$ gold, producing $1,270,000 \mathrm{oz}$. of gold (including open pit of Zone 5). |
|  |  | 1990-2002: Bousquet Shaft \#2 in operation, mining 8.2 Mt at $8.6 \mathrm{~g} / \mathrm{t}$ gold, producing $2,140,000 \mathrm{oz}$. of gold. |

[[%~%]]
### 6.2.2 Mine Development And Exploration Prior To Agnico Eagle (1977-2002)

The sinking of Bousquet Shaft \#1 started in 1977, initially to a depth of 375 m in 1979 and later to a final depth of 640 m . Exploration work continued during the production phase, mainly with diamond drilling that targeted potential extensions of lenses of all zones at depth.
Production at the Bousquet No. 1 mine started in 1978 and ended in 1996 with the closure of the mine by Barrick Gold. The production was mainly from underground, focused on the high-grade Zone 3 area (Zones 1, 3 FW and 3HW). Production is summarized in Table 6.7.
However, the lower grade Zone 5 was also mined by open pit in the late 1980s, yielding 1.7 million tonnes of ore grading $2.2 \mathrm{~g} / \mathrm{t}$ gold. During 1995-96, Zone 5 was mined using selective underground mining methods, producing approximately 100,000 tonnes of ore. Underground production from Zone 3 and Zone 5 were hoisted together and are reported together in historical reports.
Surface exploration activity declined during the 1979-85 period as mine development proceeded at the Bousquet No. 1 mine.
However, in early 1986, Dumagami Mines discovered a high-grade zone to the east of the Bousquet No. 1 mine. The discovery was close to the eastern limits of the Bousquet property of Lac Minerals and initiated the major exploration drilling campaign of 1986. In mid-1986, the discovery of Zone D (a gold- and copper-rich massive sulphide lens) occurred on the future site of the Bousquet No. 2 mine, which was the geological extension of the high-grade Dumagami zone. The Dumagami-Bousquet 2 deposit became a significant single major deposit that was mined by two different companies.Exploration and construction of Bousquet Shaft \#2 and related infrastructure on the Bousquet property, 2 km east and along strike from the Bousquet No. 1 mine, led to the start of commercial production at the Bousquet No. 2 mine in 1990 (Table 6.8).
In 1994, Barrick Gold Corporation acquired Lac Minerals Ltd. and became the owner and operator of the Bousquet Complex. No mill was available on the Bousquet property, and ore was transported by truck to existing mills in Malartic area - the East Mine's mill for Bousquet No. 2 ore and the Camflo mill for Bousquet No. 1 ore.
Barrick completed the closure of the Bousquet No. 2 mine in 2002.

[[%~%]]
### 6.2.3 Mine Development And Exploration By Agnico Eagle (2003 To Present)

The Bousquet property, along with various equipment and other mining properties, was acquired in September 2003 by Agnico Eagle from Barrick Gold Corporation for $\$ 3.9$ million in cash, $\$ 1.5$ million in Agnico Eagle common shares and the assumption of specific reclamation and other obligations related to the Bousquet property.

## 2004-2007

From 2004 to 2007, Agnico Eagle recovered 108,407 tonnes of ore grading $2.33 \mathrm{~g} / \mathrm{t}$ gold from Zone 4 in a small open pit. Two small portions of Zone 3-1 and Zone 3-3 at Bousquet No. 2 were mined underground by the Company from 2006 to 2007, recovering 99,342 tonnes of ore grading $7.02 \mathrm{~g} / \mathrm{t}$ gold. There has been no mining at Bousquet No. 2 since 2007.

## 2010-present

In 2010, the company conducted an early stage diamond drilling program consisting of drill hole twinning and resampling of historic holes to evaluate the production potential of an open pit at Bousquet Zone 5. This work led to an initial inferred mineral resource estimate for Zone 5 of 18.8 million tonnes at $1.87 \mathrm{~g} / \mathrm{t}$ gold. Exploration expenditures were $\$ 0.2$ million, including the cost of drilling 7 holes $(2,082 \mathrm{~m})$. A preliminary economic assessment in October 2010 confirmed the potential to viably mine Bousquet Zone 5.
A diamond drilling program on Zone 5 was started in 2010 and was completed in 2011, leading to a new mineral resource estimate for Zone 5 and an internal feasibility study. The results were a positive scenario for resuming production from the Zone 5 open pit, and the estimation of initial probable mineral reserves in Zone 5. Exploration expenditures on the Bousquet property in 2011 were $\$ 2.40$ million including the cost of drilling 70 holes $(18,616 \mathrm{~m})$.
In 2017, Agnico Eagle completed a positive internal prefeasibility study (Turcotte, et al. 2017) that recommended bringing the LZ5 Project into production using underground mining methods.
The LZ5 Mine construction was approved by Agnico Eagle's Board of Directors in February 2017 and commercial production started on June 1, 2018 - representing a second life for Zone 5, 80 years after its initial discovery.
The commercial production of LZ5 Mine was planned to match the end of commercial production of the Company's Lapa mine in the region at the end of May 2018. As result of the strategy, the Lapa Mill (now LZ5 Mill) had continuous feed throughout the transition in mill feed from Lapa to LZ5.
With the development of new underground infrastructure at LZ5 Mine since 2018, the Company began a broad economic revaluation of all zones at the Bousquet property, including unmined areas of Bousquet No. 1 and Bousquet No. 2, and other residual mineral resources (included in current MRMR estimate).Table 6.7 - Bousquet No. 1 Mine milled production summary to December 31, 2022

| Year | Owner / Operator | Ore milled (t) | Gold grade (g/t) | Gold mined in situ (oz.) | Gold production paid net from smelter (oz.) |
| :--: | :--: | :--: | :--: | :--: | :--: |
| 1978 | Long Lac Exploration Ltd. | 8,850 | 9.7 | 2,751 | 2,493 |
| 1979 | Long Lac Exploration Ltd. | 109,324 | 8.3 | 29,204 | 27,790 |
| 1980 | Long Lac Exploration Ltd. | 258,339 | 7.2 | 59,960 | 57,054 |
| 1981 | Long Lac Exploration Ltd. | 383,610 | 6.5 | 80,403 | 76,945 |
| 1982 | Long Lac Exploration Ltd. / Lac Minerals Ltd. | 393,176 | 5.9 | 74,445 | 70,500 |
| 1983 | Lac Minerals Ltd. | 466,505 | 6.8 | 101,376 | 95,068 |
| 1984 | Lac Minerals Ltd. | 534,429 | 6.2 | 107,031 | 99,425 |
| 1985 | Lac Minerals Ltd. | 637,111 | 5.2 | 106,705 | 99,057 |
| 1986 | Lac Minerals Ltd. | 496,121 | 4.5 | 71,609 | 65,745 |
| 1987 | Lac Minerals Ltd. | 531,943 | 5.5 | 94,392 | 86,548 |
| 1988 | Lac Minerals Ltd. | 624,508 | 5.2 | 103,992 | 95,101 |
| 1989 | Lac Minerals Ltd. | 934,504 | 4 | 121,065 | 110,364 |
| 1990 | Lac Minerals Ltd. | 528,536 | 5.3 | 90,729 | 83,224 |
| 1991 | Lac Minerals Ltd. | 338,045 | 6.3 | 68,462 | 63,036 |
| 1992 | Lac Minerals Ltd. | 329,405 | 6.5 | 68,300 | 62,194 |
| 1993 | Lac Minerals Ltd. | 238,787 | 7.4 | 56,496 | 52,989 |
| 1994 | Lac Minerals Ltd. / Barrick Gold Corp. | 219,512 | 5.8 | 41,140 | 39,376 |
| 1995 | Barrick Gold Corp. | 247,870 | 6 | 47,968 | 45,812 |
| 1996 | Barrick Gold Corp. | 167,363 | 7.1 | 38,414 | 36,790 |
| 1997-2002 | Barrick Gold Corp. | No production. Closure of Bousquet \#1 |  |  |  |
| 2003-2016 | Agnico Eagle Mines Ltd. | No production |  |  |  |
| 2017 | Agnico Eagle Mines Ltd. | 7,753 | 2.2 | 557 | 529 |
| 2018 | Agnico Eagle Mines Ltd. | 224,643 | 2.8 | 19,957 | 18,620 |
| 2019 | Agnico Eagle Mines Ltd. | 869,569 | 2.3 | 63,455 | 60,172 |
| 2020 | Agnico Eagle Mines Ltd. | 967,990 | 2.1 | 65,203 | 61,674 |
| 2021 | Agnico Eagle Mines Ltd. | 1,124,014 | 2.1 | 74,927 | 70,788 |
| 2022 | Agnico Eagle Mines Ltd. | 1,145,788 | 2.0 | 75,390 | 71,557 |
| Sub-total before Agnico Eagle acquisition in 2003 | Long Lac Exploration Ltd. / Lac Minerals Ltd. / Barrick Gold Corp. | 7,447,938 | 5.70 | 1,364,442 | 1,269,511 |
| Sub-total after Agnico Eagle acquisition in 2003 | Agnico Eagle Mines Ltd. | 4,339,757 | 2.15 | 299,489 | 283,339 |
| Total |  | 11,787,695 | 4.39 | 1,663,931 | 1,552,850 |Table 6.8 - Bousquet No. 2 Mine milled production summary to December 31, 2022

| Year | Owner / Operator | Ore milled (t) | Gold grade (g/t) | Gold mined in situ (oz.) | Production paid net from smelter |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  |  |  |  |  | Gold (oz.) | Silver (oz.) | Copper (lbs.) | Zinc (lbs.) |
| 1990 | Lac Minerals Ltd. | 164,759 | 13.8 | 72,879 | 68,992 | - | 5,209,496 | - |
| 1991 | Lac Minerals Ltd. | 389,670 | 15.0 | 187,396 | 181,135 | - | 11,365,516 | - |
| 1992 | Lac Minerals Ltd. | 494,897 | 9.9 | 157,182 | 149,169 | - | 8,870,729 | - |
| 1993 | Lac Minerals Ltd. | 617,676 | 8.6 | 170,961 | 162,003 | - | 7,914,590 | - |
| 1994 | Lac Minerals Ltd. / Barrick Gold Corp. | 646,517 | 9.6 | 199,519 | 191,534 | - | 8,774,681 | - |
| 1995 | Barrick Gold Corp. | 623,395 | 9.2 | 184,167 | 174,579 | - | 9,457,381 | - |
| 1996 | Barrick Gold Corp. | 642,689 | 9.8 | 202,676 | 194,564 | - | 10,961,016 | - |
| 1997 | Barrick Gold Corp. | 604,749 | 9.1 | 176,520 | 169,751 | - | 8,050,692 | - |
| 1998 | Barrick Gold Corp. | 648,101 | 8.8 | 183,340 | 175,621 | - | 9,005,586 | - |
| 1999 | Barrick Gold Corp. | 786,786 | 8.5 | 214,985 | 203,800 | - | 8,882,857 | - |
| 2000 | Barrick Gold Corp. | 883,522 | 6.3 | 178,081 | 165,184 | - | 6,353,023 | - |
| 2001 | Barrick Gold Corp. | 877,369 | 5.9 | 166,405 | 152,412 | - | 3,497,890 | - |
| 2002 | Barrick Gold Corp. | 762,987 | 6.3 | 153,296 | 140,812 | - | 2,543,411 | - |
| 2003 | Agnico Eagle Mines Ltd. | No production. Agnico Eagle acquisition in 2003 |  |  |  |  |  |  |
| 2004 | Agnico Eagle Mines Ltd. | 57,413 | 2.7 | 4,960 | 4,541 | - | - | - |
| 2005 | Agnico Eagle Mines Ltd. | 33,192 | 2.2 | 2,381 | 2,156 | - | - | - |
| 2006 | Agnico Eagle Mines Ltd. | 39,515 | 7.1 | 9,003 | 8,173 | 12,281 | 67,005 | 30,492 |
| 2007 | Agnico Eagle Mines Ltd. | 77,629 | 5.7 | 14,173 | 12,960 | 13,364 | 92,482 | 44,741 |
| 2008-21 | Agnico Eagle Mines Ltd. | No production. Care and maintenance |  |  |  |  |  |  |
| 2022 | Agnico Eagle Mines Ltd. | 3,034 | 3.1 | 306 | 288 | 1,769 | 15,337 | 5,852 |
| Pre 2003: <br> Sub-total before Agnico Eagle acquisition | Lac Minerals Ltd. / Barrick Gold Corp. | 8,143,117 | 8.58 | 2,247,407 | 2,129,556 | - | 100,886,868 | - |
| Post 2003: <br> Sub-total after Agnico Eagle acquisition | Agnico Eagle Mines Ltd. | 210,783 | 4.57 | 30,822 | 28,119 | 27,413 | 174,824 | 81,085 |
| Total |  | 8,353,900 | 8.49 | 2,278,229 | 2,157,675 | 27,413 | 101,061,692 | 81,085 |Table 6.9 - Total Bousquet property milled production summary to December 31, 2022

| Owner / Operator | Ore milled (t) | Gold grade (g/t) | Gold in situ (oz.) | Production paid net from smelter |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  |  |  |  | Gold (oz.) | Silver (oz.) | Copper (lbs.) | Zinc (lbs.) |
| Long Lac Exploration Ltd. / Lac Minerals Ltd. / Barrick Gold Corp. | 15,591,055 | 7.21 | 3,611,849 | 3,399,067 | - | 100,886,868 | - |
| Agnico Eagle Mines Ltd. | 4,550,540 | 2.45 | 330,311 | 311,458 | 27,413 | 174,824 | 81,085 |
| Total | 20,141,595 | 6.09 | 3,942,160 | 3,710,525 | 27,413 | 101,061,692 | 81,085 |

[[%~%]]
### 6.2.4 Production At Bousquet Property

In Table 6.7, Table 6.8 and Table 6.9 are summaries of the cumulative payable metal production at Bousquet No. 1 and Bousquet No. 2 mines by previous owners and Agnico Eagle.

[[%~%]]
### 6.2.5 Exploration And Mine Development At The El Coco And Terrex Properties

The El Coco and Terrex properties are contiguous to the LaRonde property to the south and to the east. Agnico Eagle has a mining lease on each of these two properties (BM-854 and BM-1027) that together cover the extensions at depth of the main lenses of the Penna Shaft.

[[%~%]]
### 6.2.6 Historical Exploration And Discovery

Laplante (2002) presented a comprehensive list of exploration work completed on the El Coco property prior and after the acquisition of the property by Agnico Eagle in 1999, while De Chavigny (2007) presented a comprehensive list of the exploration work completed on the Terrex property prior and after the acquisition of the property by Agnico Eagle in 2002. Those works are summarized in Table 6.10 and Table 6.11.

Table 6.10 - Summary of exploration programs at El Coco property (1963-2012)

| Year | Company | Reference | Exploration program and results |
| :--: | :--: | :--: | :--: |
| 1963 | New Alger Mines Ltd. | GM-13440 <br> GM-14495 | Mapping campaign discovered several quartz veins in shear zones. Ground EM and 4 drill holes ( 428 m ). |
| 1968 | El Coco Exploration Ltd. | GM-24459 | El Coco Exploration Ltd acquired 65 claims covering El Coco and Dormenan properties. Line cutting and EM. |
| 1969 | El Coco Exploration Ltd. | GM-24460 | 8 holes $(1,168 \mathrm{~m})$. Best result of $6.6 \mathrm{~g} / \mathrm{t}$ gold over 3 m in EL69-02. |
| 1971 | MRNQ | DP 763 | Regional airborne survey (EM-input) by MRNQ with anomalies along Blake River-Cadillac contact. |
| 1973 | D.B. Resources Corp. | GM-29312 | Ground mag-EM surveys |
| 1974 | D.B. Resources Corp. | GM-30115 | 1 hole DB74-01 drilled to verify EL69-01 |
| 1975 | D.B. Resources Corp. | GM-31105 | 1 hole, no significant mineralization reported || Year | Company | Reference | Exploration program and results |
| :--: | :--: | :--: | :--: |
| 1976 | Long Lac Mineral Exploration Ltd. | GM-32677 | Mapping and ground EM |
| 1977 | Long Lac Mineral Exploration Ltd. | - | 5 holes ( 553 m ) |
| 1984 | Lac Minerals Ltd. | GM-41213 | IP survey over western and eastern parts of property |
| 1985 | Lac Minerals Ltd. / <br> Cambior Joint Venture | GM-43358 | Joint venture (50/50) by Lac Minerals and Cambior (through Ressources Aiguebelle acquisition) incl. 3 year operator alternation. Line cutting, 1,951 m of drilling. |
| 1987 | Lac Minerals Ltd. / <br> Cambior Joint Venture | GM-45869 <br> GM-47494 | Geological compilation by Lac Minerals Ltd. <br> PP survey and 1,268 m of drilling. |
| 1988 | Lac Minerals Ltd. / <br> Cambior Joint Venture | GM-49270 <br> GM-49282 <br> GM-49352 | Lac Minerals: detailed mapping north of Dormenan Creek. Airborne and ground mag-VLF surveys. 4 holes (1,340 m). Hole EL88-04 intersected a narrow semi massive horizon yielding $1.5 \mathrm{~g} / \mathrm{t}$ gold, $0.3 \%$ copper, $0.7 \%$ zinc over 0.8 m . |
| 1991 | Lac Minerals Ltd. / <br> Cambior Joint Venture | Internal report | Cambior: 2 holes (1,100 m). Pulse-EM surveys in holes D85-02, D85-03, EL88-04, D91-01 and D91-02. A Mise a la Masse survey in holes EL88- 04, D91-01 and D91-02. |
| 1992-93 | Lac Minerals Ltd. / <br> Cambior Joint Venture | GM-52027 | Cambior: 2,048 m of drilling, down-hole EM surveys, surface mapping \& sampling, geophysical data compilation. |
| 1993-94 | Lac Minerals Ltd. / <br> Cambior Joint Venture | Lac Minerals internal report | Lac Minerals: 8 holes (9,191 m). Drilling targeted extensions of the LaRonde orebody, extensions of Main Zone on El Coco and untested stratigraphy to east. |
| 1995 | Lac Minerals-Barrick Gold Corp. / Cambior Joint Venture | Barrick Gold internal report | Barrick Gold: 2 holes $(2,872 \mathrm{~m})$ testing for lateral and downdip extensions of Zones 20 North and 20 South (LaRonde Mine). Surface mapping. |
| 1998 | Barrick Gold Corp. / <br> Cambior Joint Venture | - | 801 m of drilling |
| 1999 | Agnico Eagle Mines Ltd. | (Dionne and Boyd 1999) | El Coco property acquisition by Agnico Eagle |
| 1999 | Agnico Eagle Mines Ltd. | (Lombardi 2000) | 1,893 m of drilling, 3D Multiple Total Field (MTF) geoelectrical survey on El Coco and Sphynx properties. |
| 2000 | Agnico Eagle Mines Ltd. | (Lombardi 2000) <br> GM58801 | 2,623 m of drilling |
| 2001 | Agnico Eagle Mines Ltd. | (Gagnon 2000) | Mining lease on El Coco (BM-854) |
| 2000 | Agnico Eagle Mines Ltd. | Internal report | Production started on Zone 20 South on El Coco property |
| 2001 | Agnico Eagle Mines Ltd. | - | Exploration drift on level 86 starting at LaRonde Shaft \#1 entering on El Coco property at depth. |
| 2001-02 | Agnico Eagle Mines Ltd. | (Lombardi 2001), (Vermette 2002), (Laplante 2002) GM-59818 | AEM Exploration Div., 23 surface holes (13,442 m) targeting mainly Zone 22. Down-hole pulp EM surveys. |
| 2001-12 | Agnico Eagle Mines Ltd. | - | Underground exploration drilling from exploration drift of Level 86. 48 holes $(36,340 \mathrm{~m})$ of drilling. |Table 6.11 - Summary of exploration programs on Terrex property (1924-2022)

| Year | Companies | Reference | Exploration program and results |
| :--: | :--: | :--: | :--: |
| 1924 | Graham and Abrams, Dome Mine Ltd. |  | Claim staking and surface exploration |
| 1926 | Graham-Bousquet | GM-07424 | 4 drill holes ( 308 m ). Gold discovered in quartz veins. |
| 1928-29 | Graham-Bousquet | GM-06990 (A TO C) | Exploration shaft sinking ( 160.6 m ). Underground horizontal development ( 439 m ), 11 drill holes ( $U / G$ and surface) for $1,212 \mathrm{~m}$. |
| 1936-37 | Bouscadillac Gold Mines Ltd. |  | U/G horizontal development ( 627 m ). <br> 17 drill holes (U/G and surface) for $1,539 \mathrm{~m}$. |
| 1946 | Bouscadillac Gold Mines Ltd. |  | Magnetic survey |
| $1958-66$ | Graham-Bousquet Gold Mines \& Bouscadillac Gold Mines Ltd. <br> - Cadamet Mines Ltd. <br> - Terrex Mining Co. Ltd. |  | Change of owners / operators |
| 1974-75 | Fervat Mines Ltd. \& Darius Gold Mines |  | New owners. Merger of Terrex and Brown Bousquet properties. Magnetic and EM surveys, dewatering and resampling of 1929 shaft. |
| 1977 | Gold Fields Mining Corp. \& Darius Gold Mines |  | EM surveys (ABEM HLEM). 1 drill hole ( 152 m ), with no significant values. Surface mapping. |
| $1980-90$ | Darius Gold Mines Inc. <br> - St-Joseph Exploration Ltd. <br> - Sulpetro Minerals Ltd. <br> - Ressource Novamin Inc. <br> - Breakwater Resources Ltd. \& Bond Gold Canada Inc. |  | Change of owners / operators of Darius Joint Venture. |
| 1984 | Sulpetro Minerals Ltd. | GM-42643, GM-42645, GM-42365 | 7 trenches and mapping. |
| 1985 | Sulpetro Minerals Ltd. | GM-42202 | Magnetometric, gradiometric and EM (Max-Min and TBF) surveys. |
| 1986 | Ressource Novamin Inc. | GM-45127 | HLEM-type electromagnetic survey |
| 1987 | Ressource Novamin Inc. | GM-45845 | 4 drill holes ( 640 m ). Low gold grade. |
| 1990 | Breakwater Resources Ltd. | GM-50106 | Regional compilation and stripping |
| 2002 | Agnico Eagle Mines Ltd. |  | Property acquisition by Agnico Eagle |
| 2003-04 | Agnico Eagle Mines Ltd. |  | Regional compilation and drilling of 6 surface holes for $1,926 \mathrm{~m}$. |
| 2004-22 | Agnico Eagle Mines Ltd. | LaRonde annual MRMR reports (2014-22) | Exploration and conversion drilling from LaRonde property. Extension of the economic Zone 20 North below 2,900 m depth on Terrex property. First mineral reserve estimate declared in 2005: 335,000 t at $6.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$. |
| 2020-22 | Agnico Eagle Mines Ltd. | LaRonde internal reconciliation reports | Production of ore from Terrex property, Zone 20 North at depth $(-2,930 \mathrm{~m})$ started in 2020. |Most exploration on the LaRonde property from 1993 to the present has been a continuous exploration drilling program from underground infrastructure. The exploration drift on Level 20 of LaRonde Shaft \#1 (Level 86 of Penna Shaft) was a major exploration site for the discovery and development of mineral resources and mineral reserves accessible from the Penna Shaft. Exploration holes have shown the continuity of the Zone 20 South from the LaRonde property towards the El Coco property.
The exploration drift on Level 20 was connected to Level 86 at the Penna Shaft at 860 m depth. Exploration on Level 86 was extended over approximately 1 km , towards the east and past the LaRonde-El Coco property limit. In 2006, a Titan-24 geophysical survey conducted over an area east of the main LaRonde deposit by Quantec detected the (known) Zone 22 lens and a significant anomaly within untested ground east of the easternmost drill bay of Level 86. In 2007, two drill rigs completed 10 holes $(7,917 \mathrm{~m})$ with no significant results for Zone 22 on the El Coco property.

[[%~%]]
### 6.2.7 Production

In June 2001, Agnico Eagle receive the mining lease (BM-854) covering the extension of Zone 20 South on the El Coco property. Production from the El Coco property was limited to 1999 to 2004, until the depletion of the mineral reserves. A total of 1,329,323 tonnes were extracted from the El Coco property with a grade of $9.42 \mathrm{~g} / \mathrm{t}$ gold, $76.92 \mathrm{~g} / \mathrm{t}$ silver, $0.28 \%$ copper and $4.06 \%$ zinc, mostly from Zone 20 South.
In July 2014, Agnico Eagle received the mining lease (BM-1027) covering the extension of the Zone 20 North at depth on the Terrex property. Production on the Terrex property started slowly in 2020 on Level 293 at 2,930 m depth.

[[%~%]]
## 6.3 Exploration And Mine Development At The Ellison Property

In August 2002, Agnico Eagle purchased the Ellison property from Yorbeau Resources Inc., which retained a NSR royalty that varied from $1.5 \%$ to $2.5 \%$. In 2017, Agnico Eagle also bought the Ellison royalty from Yorbeau Resources Inc.

[[%~%]]
### 6.3.1 Historic Exploration And Discovery

Mercier-Langevin (2006) presented a comprehensive list of the exploration work completed on the Ellison property prior to and after the acquisition of the property by Agnico Eagle in 2002. Table 6.12 is a compilation of these exploration programs.

Exploration on the Ellison property began in 1936, and between 1936 and 1944 at least two drilling campaigns were carried out. The results of these campaigns are unknown to the Company. In 1972 Hewbett Mines Ltd. conducted a magnetic and electromagnetic survey of the property between the two known gold-bearing zones of the then-Thompson Bousquet Gold Mines property to the east and the Westwood Cadillac property to the west. However, no significant magnetic anomalies were encountered in the surveys.

Long Lac Exploration Ltd. carried out several exploration programs on the property between 1975 and 1977 that consisted of soil and rock sampling, magnetic and electromagnetic surveys and drilling. Gold was first discovered on the property by Long Lac Exploration in 1975 during a 6-hole drill campaign.

Between 1979 and 1984 several drilling campaigns and geophysical surveys were conducted by Lynx Canada Exploration Ltd., Dejour Mines Ltd. and Yorbeau Resources Inc. A mineral resource estimate (non NI-43-101 compliant) was completed in 1984 by independent consultants forYorbeau Resources. The historical mineral resource estimates for Zone A and Zone C were 1 million tons grading $6.86 \mathrm{~g} / \mathrm{t}$ gold and 1.5 million tons grading $10.29 \mathrm{~g} / \mathrm{t}$ gold, respectively.

Table 6.12 - Summary of exploration programs at Ellison property (1936-2022)

| Year | Company | Reference | Exploration program |
| :--: | :--: | :--: | :--: |
| 1936 | Jack Brawley and Associates |  | Staking |
| 1937-38 | Teck-Hughes Gold Mines |  | 2 drill holes |
| 1944 | Siscoe Mines Ltd. |  | 2 drill holes |
| 1972 | Hewbett Mines Ltd. | GM 27914 | Magnetic and electromagnetic surveys |
| 1975 | Long Lac Exploration Ltd. | GM 33393 <br> GM 32661 <br> GM 32011 | 6 drill holes, Magnetic and electromagnetic surveys |
| 1976 | Long Lac Exploration Ltd. | GM 32789 | 54 drill holes |
| 1977 | Long Lac Exploration Ltd. | GM 32996 | 33 drill holes |
| 1979 | Lynx Canada Exploration Ltd. |  | Property acquisition |
| 1980 | Lynx Canada Exploration Ltd., <br> Dejour Mines Ltd |  | 31 drill holes ( $3,800 \mathrm{~m}$ ), magnetic and IP surveys, and geochemical analysis |
| 1981 | Lynx Canada Exploration Ltd., <br> Dejour Mines Ltd. |  | 35 drill holes $(7,181 \mathrm{~m})$ |
| 1983 | Yorbeau Resources Inc., Lynx Canada Exploration Ltd. |  | 2 drill holes $(1,214 \mathrm{~m})$, magnetic and IP surveys, and deep pulse EM surveys |
| 1984 | Yorbeau Resources Inc., Lynx Canada Exploration Ltd. |  | 34 drill holes $(16,377 \mathrm{~m}$ ), geophysical surveys and soil geochemical surveys |
| 1985 | Yorbeau Resources Inc. |  | Underground exploration cited but not confirmed, and mineral resource estimates |
| 2002 | Agnico Eagle Mines Ltd. |  | Property acquisition by Agnico Eagle |
| 2004 | Agnico Eagle Mines Ltd. |  | 2 drill holes $(1,341 \mathrm{~m})$ |
| 2005 | Agnico Eagle Mines Ltd. |  | 1 drill hole ( 361 m ) |
| 2006 | Agnico Eagle Mines Ltd. | GM 62983 | 20 drill holes $(3,238 \mathrm{~m})$ |
| 2012 | Agnico Eagle Mines Ltd. |  | 9 drill holes $(2,623 \mathrm{~m})$ |
| 2021 | Agnico Eagle Mines Ltd. |  | 9 drill holes $(5,942 \mathrm{~m})$, <br> Zone 5 conversion drilling program |
| 2022 | Agnico Eagle Mines Ltd. |  | 34 drill holes $(20,344 \mathrm{~m})$ in Zone 4, Zone 41 and Zone 5 in exploration and conversion drilling program |

After the acquisition of the Ellison property in 2002, drilling campaigns were conducted by Agnico Eagle's Exploration Division in 2004, 2005 and 2006. The two most recent drilling campaigns in 2012 and 2021-22 were conducted by LaRonde Mine personnel. The purpose of the drilling campaign of 2021 was to convert Zone 5 from the mineral resource category into the mineral reserve category to support a mining lease application to the Quebec government (MRNQ) planned in 2023. The drilling campaign of 2022 focused on conversion on resources of Zone 4 and Zone 41.

[[@~@]]
# 7 Geological Setting And Mineralization

The information presented in this section is based on data and interpretations from numerous research papers and theses available for the Doyon-Bousquet-LaRonde ("DBL") mining camp: Valliant, Mongeau and Doucet (1982), Hodgson and Hamilton (1989); Card (1990); Chown et al. (1992); Poulsen, Card and Franklin (1992); Tourigny et al. (1992); Trudel et al. (1992); Teasdale, Brown and Tourigny (1996); Mueller et al. (1996); Moorhead et al. (2000); Lafrance, Moorhead and Davis (2002) and (2003); Dubé, Mercier-Langevin and Hannington, et al. (2003); Dubé, Mercier-Langevin and Hannington, et al. (2004); (Dubé, Mercier-Langevin and Hannington, et al. 2007); Dubé, Mercier-Langevin and Kjarsgaard, et al. (2014); Mercier-Langevin (2005), MercierLangevin, Dubé et al. (2007a); Mercier-Langevin, Dubé et al. (2007b); Yergeau (2015); and BoilyAuclair (2022). The information presented in this section is also based on data summarized from previous technical reports by Girard et al. (2006) and Pitre et al. (March 2012).

[[%~%]]
## 7.1 Regional Geology

The Property forms part of the DBL mining camp (Mercier-Langevin, Dubé and Blanchet, et al. 2017) in the southeastern portion of the Abitibi Subprovince, which is a typical granite-greenstone terrane (Figure 7.1). The Archean-age (2.7 Ga) Abitibi Subprovince is located in the southeastern part of the Superior Province of the Canadian Shield. The Abitibi belt is one of the world's largest known greenstone belts covering $85,000 \mathrm{~km}^{2}$ of surface area (Card 1990) and one of the richest mining areas (Hodgson and Hamilton 1989) (Poulsen, Card and Franklin 1992). The Abitibi Subprovince extends approximately 700 km from the Kapuskasing Structural Zone in northeastern Ontario eastward to the Grenville Front (geological province) in northwestern Quebec. The Abitibi Subprovince is bound to the north by the gneiss and plutonic terrane of the Opatica Subprovince, while to the south it is bound by metasedimentary rocks and plutons of the Pontiac Subprovince.
The Abitibi Subprovince is divided into a "Northern Volcanic Zone" and a younger "Southern Volcanic Zone" (Chown, et al. 1992) (Mueller, et al. 1996). The DBL mining camp is located within the Southern Volcanic Zone. The Porcupine-Destor Deformation Zone is interpreted to be the limit dividing the Northern Volcanic Zone from the Southern Volcanic Zone. The east-west trending Larder Lake - Cadillac Deformation Zone is a major fault corridor and marks the contact between the Abitibi and the Pontiac subprovinces.

The regional stratigraphy of the southeastern Abitibi area is divided into groups of alternating volcanic and sedimentary rocks that are generally oriented east-west and separated by fault zones. The main lithostratigraphic divisions in this region are, from north to south: the ultramafic and mafic rocks of the Malartic Group; the sedimentary rocks of the Kewagama Group; the basaltdominated Blake River Group; the turbidite sequence of the Cadillac Group; the ultramafic and mafic rocks of the Piché Group; all of the Abitibi Subprovince; and the sedimentary rocks of the Pontiac Group of the Pontiac Subprovince.![img-7.jpeg](img-7.jpeg)

Figure 7.1 - Regional geology of Doyon-Bousquet-LaRonde mining camp (from MercierLangevin et al., 2017)

[[%~%]]
## 7.2 Local And Property Geology

The geology that underlies the LaRonde Complex consists of three east-west-trending (N85-95 ${ }^{\circ}$ ), steeply south-dipping $\left(80^{\circ} \pm 10^{\circ}\right)$ and generally southward-facing homoclinal regional lithological units (geological groups). The units are, from north to south: the Kewagama Group consisting of thick bands of interbedded wacke; the Blake River Group, which is the volcanic assemblage that hosts all the known economic mineralization in the DBL mining camp; and the Cadillac Group consisting of thick bands of wacke interbedded with pelitic schists and minor iron formation (Figure 7.1). The stratigraphy is parallel to the main regional foliation. The Larder Lake - Cadillac Deformation Zone is located approximately 2 km south of the Property.
The portion of the Blake River Group that is observed on the Property is close to 1,300 m wide and comprised of volcanic rocks (Lafrance, Moorhead and Davis 2002). The regional sequence shows a basaltic flow basement overlain by andesitic to rhyolitic flows and fragmental rocks associated with local volcanic centres. Two formations present on the Property can be identified regionally (Figure 7.1). These are, from north to south: Hébécourt Formation (formerly called the Northern Tholeiitic Basalt member); and the Bousquet Formation, which has been divided into two members: the Lower Member (formerly named the Lower Transitional member) and the UpperMember (formerly named the Upper Felsic member) (Moorhead, et al. 2000) (Lafrance, Moorhead and Davis 2002) and (Dubé, Mercier-Langevin, et al. 2004).
The Hébécourt Formation consists locally of a $750-\mathrm{m}$ thick homoclinal sequence of relatively undeformed, southward facing, tholeiitic, massive to pillow basalt flows. Some of the flows are glomeroporphyritic and can be traced laterally for several kilometres. Although this unit hosts portions of the former Mouska and Mic-Mac gold mines, no significant mineralization or alteration is known to occur within this unit on the Property. However, the Bousquet No. 1 mine's Zone 6 (uneconomic) is located near the top of the Hébécourt Formation. Rocks of the Hébécourt Formation could be interpretated as an Archean oceanic crust formed on a back-arc basin ridge.
In the DBL mining camp, the Hébécourt Formation, which represents the base of the Blake River Group, is overlain by the Bousquet Formation. Towards the southern contact with the Bousquet Formation, the Hébécourt Formation is interbedded with quartz-porphyritic rhyolite sill and dike units that are up to 150 m thick. These sill and dike units consist of several metres-thick, finegrained felsic layers of tholeiitic to transitional affinity, which is characterized by 3-15\% mm-sized blue-grey quartz phenocrysts and equally abundant albite phenocrysts. No gold mineralization is known to occur in these sill and dike units on the Property.
The Bousquet Formation is further subdivided into Lower Member and Upper Member. Lafrance et al. (2003) describe the units of the Lower Member to be laterally extensive, whereas the felsic units of the Upper Member are laterally restricted and form coalesced flows.
The Lower Member of the Bousquet Formation is comprised of rocks that are of mafic to intermediate composition with a tholeiitic to transitional affinity, including basalt-andesite flows, and with abundant vesicles and amygdales. On the Property the Lower Member has a thickness of between 200 to 350 metres. Minor horizons of intermediate to felsic tuff may be observed. The contact between the Bousquet Formation Lower Member and the Bousquet Formation Upper Member is not always recognizable but locally it is generally strongly sheared and faulted over several metres.
The Bousquet Formation Upper Member hosts all the significant gold, silver and base metal mineralization on the Property. Previously gold occurrences of the Ellison lenses (A, B and C) and Zones 3FW, Zone 4 and Zone 5 of Bousquet No. 1 mine were thought to occur in the Bousquet Formation Lower Member, however recent research by Boily-Auclair et al. (2020) classifies the host rocks as forming part of the Bousquet Formation Upper Member. This member varies in thickness from 150 m in the vicinity of LaRonde Shaft \#1 to over 550 m thick at the Penna Shaft (Dubé, Mercier-Langevin, et al. 2003), and comprises units of an intermediate to felsic composition with a transitional to calc-alkaline affinity (Figure 7.2).
This stratigraphic interval is characterized by the dominance of quartz and feldspar porphyritic rhyodacite to rhyolitic flows, breccia and lapilli block tuff over fine-grained felsic tuff. Andesitic to dacitic flows and tuffs are common in the northern part of the unit, while blue and grey quartz porphyritic rhyolite tuffs and lapilli block tuff horizons occur in the southern portion of the unit. Minor andesite flow horizons and possible sills have also been observed.
On the Property, the contact between the Bousquet Formation Upper Member and the metaturbidites of the Cadillac Sedimentary Group can be defined by a metre-wide semi-massive to massive band of pyrrhotite, which possibly represents a hiatus between the Blake River Group volcanic episode and the beginning of the Archean submarine sedimentation of the Cadillac Group, or it may be sheared across several metres with local fault gouge.![img-8.jpeg](img-8.jpeg)

Figure 7.2 - Detailed surface geology of LaRonde Mine property at LaRonde Complex (from Mercier-Langevin, 2005)

[[%~%]]
## 7.3 Mineralization

Mineralization at the LaRonde Complex is hosted within the Archean volcanic and intrusive rocks of the Bousquet Formation (2,699 to 2,696 Ma) which is one of the youngest assemblages of the Blake River Group (2,703 to 2,694 Ma). Approximately 50 km to the west, the Blake River Group also hosts several world-class deposits in the Rouyn-Noranda mining camp including the Horne and Quémont deposits.
The synvolcanic mineralization occurs as two main styles: gold-rich polymetallic massive sulphide lenses (LaRonde Penna and Bousquet 2-Dumagami); and gold-rich sulphide veins, breccia, stockworks and dissemination ore zones (Bousquet 1 - LZ5). Sulphide veins and stockworks can be hosted in mafic to felsic host rocks. Both mineralization styles occur as single lenticular bodies.
The LaRonde Complex mineralization consists of an assemblage of disseminated to massive sulphide lenses that are stacked within the Upper Member of the Bousquet Formation. These lenses are typically polymetallic with a pyrite $\pm$ sphalerite-chalcopyrite-galena-pyrrhotite-gold assemblage. The lenses are stratiform, showing the same east-west dipping south attitude as the host rocks. The principal deformation affecting ore lenses is the strong regional north-south flattening (D2) with a south-southwest plunging stretching, giving an elongated tabular form to all lenses (Figure 7.3). All lenses show a similar subvertical dip of $80^{\circ}\left( \pm 10^{\circ}\right)$ to the south. The widthsof the lenses vary from less than 1 m up to 40 m , while their continuous lengths vary from less than 100 m up to 3 km in the case of the unique Zone 20 North.
![img-9.jpeg](img-9.jpeg)

Figure 7.3 - Isometric view of mineralized lenses at LaRonde Complex, looking northwest
The structural deformation of orebodies has locally affected the mineralization. Shears, fractures and quartz veins show evidence of gold remobilization along with tellurides, chalcopyrite and other sulphide assemblages.
In the vicinity of the Penna Shaft, four mineralized horizons are known and they host lenses that range in size from 20,000 tonnes to more than 60 million tonnes.

[[%~%]]
### 7.3.1 Mineralized Zones At Laronde Zone 5 (Former Bousquet Shaft \#1) 

The gold-bearing zones at LZ5 are lenses or stringers of disseminated through semi-massive, locally massive aggregates of fine to coarse pyrite with traces of pyrrhotite and chalcopyrite. Local traces of different metallic minerals such as sphalerite, galena, bornite, telluride and native gold can be observed. These zones vary in size from 150,000 tonnes up to 26 million tonnes (i.e., the geological and mineralized envelope of Zone 5). The mineralization in the vicinity of LZ5 occurs along five distinct mineralized horizons named Zones 1 to 5 (from south to north) as illustrated in Figure 7.4. Although the economically mineralized portions of these horizons are restricted to local sulphide-rich lenses, some mineralized horizons can be followed over the Bousquet property.

[[%~%]]
#### 7.3.1.1 Zone 1 And Zone 2

Zones 1 and 2 were mined underground using Bousquet Shaft \#1, and they consist of narrow, disseminated stringers to semi-massive sulphide lenses. This vein-type mineralization is composed predominantly of pyrite, with minor chalcopyrite-sphalerite and quartz in felsic host rocks. Zone 1 averages 4 m in width and can be followed over more than 300 m east-west as well as at depth. Zone 2 is considered to be a local secondary horizon of mineralization encountered between Zones 1 and 3, and has similar dimensions to Zone 1.

[[%~%]]
#### 7.3.1.2 Zone 3Fw And Zone 3Hw

The Zone 3 horizon is divided into Zone 3FW and Zone 3HW. The ore that has been extracted from gold-rich portions of Zone 3 represents $80 \%$ of the tonnes already mined at the Bousquet Shaft \#1 (Mercier-Langevin, Hannington, et al. 2011). Zone 3 mineralization has been described as similar to other zones on the Bousquet property (Valliant, Mongeau and Doucet 1982) (Tourigny, et al. 1992). The gold-bearing zone is associated with disseminated stringers through semi-massive, locally massive, aggregates of fine to coarse pyrite with traces of chalcopyrite. The mineralization is hosted by sericitized and sheared andesitic tuff units. Local traces of different metallic minerals such as sphalerite, bornite, rutile, telluride and native gold can be observed.
Immediately underlying Zone 3 is a continuous, garnet-bearing horizon associated with hydrothermal alteration below the lens, as observed elsewhere in the DBL mining camp (e.g., at the Westwood mine and in the 20 North lens at the LaRonde Mine). The mined portion of Zone 3 extends over 600 m strike length (east-west) and approximately 600 m vertically. The thickness of the high-grade (above $4 \mathrm{~g} / \mathrm{t}$ gold) portion of Zone 3 averages approximately 3 to 5 m but has reached up to 15 m where Zone 3FW and Zone 3HW were mined together.

[[%~%]]
#### 7.3.1.3 Zone 5

The Zone 5 lens consists of a 4 - to $30-\mathrm{m}$ thick horizon of disseminated to stringer sulphide mineralization containing $5 \%$ to $20 \%$ pyrite and traces of chalcopyrite with rare millimetre-wide grains of visible gold (Figure 7.5 A).
The Zone 5 horizon has a very large geological footprint; it has been estimated to have a mass of more than 26 million tonnes and can be followed over 900 m east-west strike length over the Bousquet property, and another 400 m on the Ellison property for a total strike length of $1,300 \mathrm{~m}$. Zone 5 has been traced vertically for almost $1,000 \mathrm{~m}$ and it shows a steep dip to the southwest. In an enlarged area of Zone 5, there is gold enrichment near the margins of the economic envelope. Zone 5 includes two higher grade portions named Zone 5 Footwall (5FW) and Zone 5 Hanging wall (5HW).
In the 1980s, bulk mining of Zone 5 by open pit produced 1.9 million short tons ( 1.7 million tonnes) for a production of 124,000 ounces of gold. From 1978 to 1996, underground mining of Zone 5 Footwall also occurred of almost 111,000 short tons (101,500 tonnes) with a production of approximately 8,000 ounces of gold.![img-10.jpeg](img-10.jpeg)

Figure 7.4 - Cross section of mineralized zones at LZ5 Mine (section 6850E looking west, $\pm 20 \mathrm{~m}$ )![img-11.jpeg](img-11.jpeg)

Figure 7.5 - Photographs of mineralized zones at Bousquet No. 1 and Bousquet No. 2: A) Typical Zone 5 with 12-15\%, mm-tocm thick stringers of pyrite that are sub-concordant with the stratigraphy in a massive and homogeneous basaltic-andesitic rock. Note the strong S2 foliation developed in the host rock. Development PS-12-05-118, level 12. B) Quartz-pyrite auriferous breccia with pyrite stringers, Bousquet No. 2 (stope 9-3-11). C) Pyrite-sphalerite-rich ore zone hosted by highly strained andalusite-rich rhyolite, Dumagami (level 17, stope 20). D) Massive Hangingwall Zone showing ore breccia composed of massive pyrite and flattened angular silicified wallrock clasts, section view looking West, Bousquet No. 2 (stope 9-0-19). Photography by P. Mercier-Langevin.

[[%~%]]
#### 7.3.1.4 Zone 4 And Zone 41

The Zone 4 horizon is located 4 to 10 m stratigraphically above Zone 5 and is very similar to Zone 5 in terms of mineralization and lateral extension. However, Zone 4 is narrow, averaging 2 to 4 m in thickness, and so could be considered a satellite horizon of Zone 5. During the 2010-11 drilling campaign, traces of visible gold were observed mainly in Zone 4. Less than 9,000 short tons ( 8,200 tonnes) have been extracted by underground mining from Zone 4.
Zone 41 refers to a narrow horizon similar to Zone 4, located above Zone 4. This horizon has not been described previously due to its low grade ( $\pm 1-2 \mathrm{~g} / \mathrm{t}$ gold), however, marginally economic material has been mined locally.

[[%~%]]
### 7.3.2 Mineralized Zones At Bousquet No. 2 And Laronde Shaft \#1

Various polymetallic (Au-Ag-Cu-Zn-Pb) sulphide-rich mineralized zones are present in the deposit. A summary is presented below and readers are referred to Marquis et al. (1992) and Teasdale, Brown and Tourigny (1996) for further details.
The main ore zone is east-west trending, steeply south-dipping and known as the Massive Zone at Bousquet No. 2 and as Zone 5 (or Zone A) at LaRonde Shaft \#1 (Dumagami).

[[%~%]]
#### 7.3.2.1 Massive Zone (Footwall And Hangingwall)

The Massive Zone is the main orebody of the Bousquet No. 2-Dumagami deposit (Dubé et al., 2014), and it consists of a large polymetallic (gold-copper-silver $\pm$ zinc) stringer/breccia to massive-sulphide zone (Figure 7.5 B, C and D). The lens shows a typical volcanogenic massive sulphide ("VMS") metallic zonation and is divided in a Footwall ("MF") zone and a Hangingwall ("MH") zone in the lower portion of the deposit (Figure 7.6). The top of the Massive Zone appears at surface on the Property and has been traced down to $1,600 \mathrm{~m}$ below surface on the Bousquet property with a south-southwest plunging attitude. The Massive Zone has a variable thickness of 1 to $\pm 20 \mathrm{~m}$ and the zone is up to 400 m in east-west length in its middle portion.
The lateral extension of the Massive Zone towards depth is known as the D zone at Bousquet No. 2 and corresponds to a gold-bearing, metres-wide transposed stringer zone with 15-25\% pyrite and abundant andalusite. Under Level 11-3, the Massive Zone occurs around a lithological contact between a highly sericitized-silicified dacitic unit and a low sericitized-silicified felsic tuff horizon. The mineralization in both the MF and MH zones consists of a blended facies of massive sulphide zones, pyritic breccia to stringer zones and massive pyrite veins, with locally minor chalcopyrite, bornite and sphalerite content.

[[%~%]]
#### 7.3.2.2 Other Satellite Zones At Bousquet No. 2 And Laronde Shaft \#1

Smaller satellite zones are present around the Massive Zone at Bousquet No. 2-Dumagami. These zones could represent a lateral extension of the Massive Zone, such as the Fringe Zone or a different stratigraphic level, such as Zone 4. Due to the metallic zonation, some zinc-rich areas are considered to be separate zones. All these zones share some characteristics: metrescale stringer/breccia to massive-sulphide mineralization with a variable polymetallic content (gold-copper-silver $\pm$ zinc) and located within rhyodacite-rhyolite rocks. These satellite zones have undergone the same regional deformation as the main orebody, showing the same north-south flattening within an east-west trend, and steeply dipping south.![img-12.jpeg](img-12.jpeg)

Figure 7.6 - Cross section 5810E ( $\pm 20 \mathrm{~m}$ ) of Massive Zone (Footwall and Hangingwall) at Bousquet No. 1 (LP1) from Level 131 to Level 149, looking west

[[%~%]]
### 7.3.3 Mineralized Zones At Laronde Shaft \#2 

There are no mineral resources or mineral reserves at LaRonde Shaft \#2. For a detailed description of mineralized zones at LaRonde Shaft \#2, refer to Legault (2001). The mineralized zones at LaRonde Shaft \#2 correspond to the Zone 6 and Zone 7 horizons and are considered to be the up-dip equivalent of the Zone 6 and Zone 7 horizons at the Penna Shaft. A description of the mineralization is presented further below in this section.

[[%~%]]
### 7.3.4 Mineralized Zones At The Laronde Penna Shaft

Mineralization at the LaRonde Mine in the vicinity of the Penna Shaft (Figure 6.1) occurs along three distinct stacked mineralized horizons that are known from north to south as: Zones 6 and 7; Zone 20 North (Zones!domains 19 and 20); and Zone 20 South. The main orebody at LaRonde Mine is Zone 20 North, which has been traced from 800 m below the surface to 3.7 km depth in the LaRonde and LaRonde Extension portions of the deposit (Figure 7.7).

[[%~%]]
#### 7.3.4.1 Zone 6 And Zone 7 At Penna Shaft

The horizon containing both Zone 6 and Zone 7 is located 20 to 30 m south of the Bousquet Formation's Lower Member/Upper Member contact. This horizon can be traced over 1.5 km from Bousquet No. 2-Dumagami to LaRonde Shaft \#2 at surface, and from surface to 3.5 km depth at the Penna Shaft. This horizon consists of decimetre- to metre-wide uneconomic bands in a mix of andesitic to felsic tuff units of disseminated to stringer sulphide mineralization containing 5 to 10\% pyrite. When both zones are present, Zone 6 is located 5 to 25 m south of Zone 7.
Economic mineralization is discontinuous and it pinches and swells throughout the favourable horizon, resulting in a series of localized polymetallic lenses developed along the horizon.
The principal economic portion of Zone 7 occurs between levels 158 and 221 of the LaRonde Mine ("Zone 7 at Penna Shaft lens"). In this sector, the Zone 7 lens is comprised of a massive to semi-massive sulphide zone containing up to $50 \%$ pyrite, $10-15 \%$ sphalerite and $1-3 \%$ chalcopyrite and rarely millimetre-sized grains of visible gold. A weakly pyrite-mineralized, feldspar-quartz porphyritic, rhyodacite lapilli tuff horizon occurs immediately north and south of the massive sulphides.
From west to east, the Zone 7 at Penna Shaft lens is continuous for up to 120 m and has been traced vertically from its apex at Level 158 down to 650 m depth where it pinches out at Level 224. The Zone 7 at Penna Shaft lens occurs at the identical stratigraphic position as the other Zone 7 lenses identified elsewhere on the Property.
At the Penna Shaft, two massive and disseminated sulphide lenses are interpreted to be the downdip extensions of the Zone 6 gold-copper-zinc mineralization that was mined at LaRonde Shaft \#2 (Figure 6.1). The smaller of the two lenses - block 63, at 110,000 tonnes - is a narrow, 3-metre lens of stringer and semi-massive pyrite with 1-2\% sphalerite (up to 20\% locally) and trace amounts of chalcopyrite.
In 2012, a deep hole from Level 215 intersected the Zone 6 horizon at a depth of $3,551 \mathrm{~m}$ below surface. The exploration drilling results on Zone 6 have confirmed the presence of a large subeconomic to economic polymetallic sulphide lens. Zone 6 consists mainly of a massive to semimassive mineralization with a pyrite-sphalerite $\pm$ chalcopyrite-galena assemblage, and thickness ranging from 1 to 20 metres. The extension at depth of this zone is not yet fully defined, but the tonnage is estimated to be more than 5 million tonnes. Zone 6 shows the same south-southwest plunging attitude as other lenses on the Property.

[[%~%]]
#### 7.3.4.2 Zone 20 North

Zone 20 North is the main orebody at the LaRonde Mine. It consists of a large polymetallic (gold-copper-zinc-silver-lead), disseminated to massive sulphide zone which has been traced in the central portion of the Property, 120 to 150 m north of the sedimentary Cadillac Group contact (Figure 7.7). The top of this zone is at approximately 800 m depth and the zone has been traced down to 3.7 km below surface within the LaRonde Extension portion for a vertical extension of more than 2.8 km . The zone is up to $400-500 \mathrm{~m}$ in east-west length in the upper portion of the deposit and reaches $1,000 \mathrm{~m}$ in east-west length in the LaRonde Extension portion of the deposit near Level 317 (Figure 6.1). With a south-southwest plunging attitude, the zone crosses from the LaRonde property onto the Terrex property at 2.8 km depth.
Zone 20 North shows a strong metallic zonation throughout the thickness of the lens, which explains the distinction of two separate (north-south) domains: the 20 North Gold Zone (northern gold-rich portion) and 20 North Zinc Zone (southern zinc-rich portion). Partially due to strong stretching deformation along the plunge of the deposit, the sulphide zonation is also expressed with depth, showing massive mineralization in the upper portion of the mine, while stringer to semimassive mineralization is more common in the lower portion of the mine (Figure 7.8).

## Zone 20 North Gold Zone

The Zone 20 North Gold Zone ("20 North Gold Zone") is a disseminated to massive sulphide goldcopper zone which represents the lower portion the lens. The top of this zone is at 980 m depth and has been traced to 3.7 km depth below surface within the LaRonde Extension area.
At the Penna Shaft above Level 155, the 20 North Gold Zone occurs within a weakly to moderately sheared, sericitized and silicified felsic lapilli tuff horizon. The zone occurs immediately south of a garnet-bearing rhyodacite-rhyolite tuff horizon and is 3 to 10 m thick. The mineralization consists of finely disseminated to locally semi-massive pyrite (5-30\%) and millimetre to centimetre-thick chalcopyrite (1-10\%) veinlets transposed to slightly discordant with the main fabric. Rare millimetre-sized blebs of visible gold are observed associated with the chalcopyrite or quartz veins. This sulphide-rich, lapilli tuff horizon closely follows the north contact of the 20 North Zinc massive sulphide lens. Where the massive sulphide horizon is absent, the sulphide-rich tuff band is in fault contact to the south with either altered andesite or rhyodacitic, blue quartz porphyritic lapilli-block tuff. Above Level 155, the gold grade is generally related to the presence of chalcopyrite (copper) within the 20 North Gold Zone.
Below Level 155 and towards Level 236, the sulphide-rich felsic lapilli tuff horizon continues to contain gold and copper mineralization but the overlying massive sulphide mineralization progressively contains gold and copper. Around Level 215, the massive sulphide portion of the 20 North lens is mostly copper- and gold-rich and the extreme eastern portion of the lens has significant zinc content. From Level 215 towards Level 236, the zinc concentration decreases within all mineralized phases (disseminated, semi-massive sulphide and massive sulphide) which become mainly gold-rich with variable amounts of silver and copper.
In the LaRonde Extension portion of the deposit, the 20 North Gold Zone continues to occur within the sulphide-rich lapilli tuff horizon and the overlying massive sulphide lens. Progressively with depth, the massive sulphide mineralization is replaced by a silicified pyrite (10-20\%)-chalcopyrite (tr-5\%) stringer zone with aluminosilicate porphyroblasts (mostly kyanite and andalusite) which becomes progressively more abundant. This style of mineralization can locally represent $30 \%$ of the ore zone. Finally, within the lower and western portion of LaRonde Extension, massive sulphide mineralization occurs. This massive sulphide zone is rich in gold and copper and has significant amounts of zinc and silver. Similar polymetallic gold-silver-copper-zinc type mineralization also occurs in the eastern fringe of the deposit between Level 170 and Level 215 within the LaRonde Mine.# Zone 20 North Zinc and Zone 20 North Zinc South 

The Zone 20 North Zinc Zone ("20 North Zinc Zone") — including satellite 20 North Zinc South — is a semi-massive to massive sulphide zinc-silver zone typically located above the 20 North Gold Zone. The 20 North Zinc Zone represents the upper domain (exhalative portion) of Zone 20 North. The economic segment of 20 North Zinc Zone is mostly concentrated on the LaRonde Mine property in the upper levels of the mine. Within the central region of the LaRonde Mine property, this zone lies 100-150 m north of the volcanic-sedimentary (Cadillac Group) contact (Figure 7.7). It generally consists of several massive sulphide lenses made up of 50-90\%, 1 to 3 millimetresized pyrite, 10-50\% light brown disseminated sphalerite with minor chalcopyrite and galena. Narrow (usually less than 1 m in thickness) and laterally discontinuous bands of variably graphitic to cherty argillite occur more commonly near or at the southern contact of these massive sulphide lenses in higher levels of the mine. The argillite bands are generally strongly sheared, or even faulted, and are not traceable for more than 10 m along strike and appear to be concentrated at the east-west edges of the massive sulphide lenses.

These massive sulphide lenses vary between 1 to 30 m in thickness and the largest lens has been traced for up to 600 m horizontally and over 1,500 m vertically. The 20 North Zinc massive sulphide lens overlies the sulphide rich felsic lapilli tuff of the 20 North Gold Zone as either a blue quartz porphyritic rhyolite tuff (to lapilli tuff) horizon or as an altered and mineralized fine-grain andesite volcanic flow horizon. Both lower and upper contacts are either gradational to sharp or slightly sheared.

Below Level 155, the zinc mineralization is less continuous and occurs as isolated satellite pods down to 3.4 km below surface. The satellite 20 North Zinc South Zone is comprised of narrow, zinc-rich semi-massive to massive pods, generally 3 to 5 m thick and a few hundreds of metres long, located on the eastern flank of Zone 20 North, near the top (south) of the lens.![img-13.jpeg](img-13.jpeg)

Figure 7.7 - Cross section 6800E ( $\pm 20 \mathrm{~m}$ ) of horizons of Zone 6, Zone 20 North (Domain or Zone 19N, 19, 20S) and Zone 20 South (Domain Zone 21) at the Penna Shaft from Level 245 to Level 311 (looking west)![img-14.jpeg](img-14.jpeg)

Figure 7.8 - Photographs of mineralization in Zone 20 North: A) Pink garnet porphyroblasts in a quartz-biotite-muscovite matrix in the footwall of Zone 20 North; Inset: Photomicrograph showing elongated syn- to late deformation Mn-rich garnet (plane-polarized light). B) Foliated aluminous Zone 20 North at depth in the mine showing kyanite, pyrite and chalcopyrite. C) Pyrite-chalcopyrite stockwork at the base of Zone 20 North, developed in a fragmental rhyodacite-rhyolite unit. D) Massive sulphide bands on top of Zone 20 North Zinc showing alternation of pyrite- and sphalerite-rich bands in the east wall of Stope 152-20-66. Photography by P. Mercier-Langevin.

[[%~%]]
#### 7.3.4.3 Zone 20 South

Zone 20 South consists of a 5 to 6 million tonne, gold-copper-zinc-silver-bearing sulphide lens. This lens is composed of a main lens with some satellite lenses along a sulphide-rich horizon that has been traced in the central portion of the LaRonde mining lease (and eastward across onto the El Coco property) within 20 m north of the sedimentary Cadillac Group contact (Figure 7.7) and 80 to 130 m south of Zone 20 North. The Zone 20 South horizon is oriented east to east-southeast with an $80-85^{\circ}$ south dip. As with other lenses at the Property, the economic portion of Zone 20 South has a steeply westward plunging rake. Zone 20 South shows a similar but smaller pattern of sulphide zonation than Zone 20 North, with an uppermost massive portion (possibly exhalative expression) and a lowermost disseminated to semi-massive portion (stockwork and replacement).
The lens generally occurs as pods of ore that are 50 to 250 m in length in an east-west direction, 100 to $1,500 \mathrm{~m}$ in length along plunge and 3 to 15 m thick in a north-south direction within the more extensively developed sulphide-rich horizon. The mineralized horizon is 5 to 15 m thick and consists of disseminated to massive pyrite, pyrrhotite and minor sphalerite-chalcopyrite within a sericitic siliceous (felsic) matrix to a chloritic (andesitic) matrix. The Zone 20 South sulphide horizon occurs within an altered andesite unit of 5 to 20 m in thickness or near the contact between an andesite unit and a felsic tuff unit. The alteration commonly affecting the andesite consists of strong matrix silicification with titanite micro-stringers (hematization alteration due to the titanite micro-phenocrysts concentrated along fractures). Immediately south of the zone is often found a narrow band (up to 10 m in thickness) of altered andesite. Generally wedged between the Cadillac Group sediments to the south and the andesite is a 1 to 5 m thick band of blue quartz-eye bearing rhyolite tuff or lapilli tuff followed by a thicker horizon of rhyolitic lapilli tuff unit that is 1 to 10 m in thickness.

Gold values in Zone 20 South, whether in the disseminated facies or in the massive sulphides, are always associated with the presence of base metal minerals such as chalcopyrite or sphalerite with rare millimetre-size blebs of native gold within 1-5 mm blebs or veinlets of chalcopyrite. The chalcopyrite is generally disseminated in the sulphide matrix or remobilized along north-south trending and steeply dipping crosscutting millimetre-thick discontinuous veinlets located throughout the sulphide zone.

[[@~@]]
# 8 Deposit Types

The DBL mining camp is one of Canada's largest VMS districts (Mercier-Langevin, Dubé and Blanchet, et al. 2017). The mineralization on the Property has been well documented by various researchers and is recognized as comprised of world-class, gold-rich VMS deposits formed in a submarine back-arc basin or submarine arc crust. Like other VMS-type deposits, the LaRonde Complex's lenses were formed mainly by sulphide precipitation from hydrothermal fluids on an Archean seafloor and by sulphide replacement in the footwall below the lenses. Figure 8.1 illustrates a schematic section of a typical gold-rich VMS deposit.
![img-15.jpeg](img-15.jpeg)

Figure 8.1 - Schematic illustration of the geological setting and hydrothermal alteration of a gold-rich high-sulphidation volcanogenic massive sulphide hydrothermal system (from Dubé et al., 2007)

Recent research has resulted in several technical publications on the LaRonde deposit and the DBL mining camp including Dubé, Mercier-Langevin and Hannington, et al. (2004); Dubé, MercierLangevin and Hannington, et al. (2007); Dubé, Mercier-Langevin and Kjarsgaard, et al. (2014); Mercier-Langevin (2005); Mercier-Langevin, Dubé and Hannington, et al. (2007a); MercierLangevin, Dubé and Hannington, et al. (2007b); Mercier-Langevin, Hannington, et al. (2011); Mercier-Langevin, Dubé and Blanchet, et al. (2017); Yergeau (2015); and Boily-Auclair, MercierLangevin, et al. (2020).
The geological model proposed by Dubé, Mercier-Langevin and Hannington, et al. (2007) and Yergeau (2015) for the DBL mining camp implies a series of possible kilometre-spaced synvolcanic faults expressed by the spacing between the major deposits (Figure 8.2). The stacking of lenses on different horizons represents a succession of volcanic events, intercalated by cycles of hydrothermal activity associated with reactivation of synvolcanic faults (Figure 8.3).Two deposits styles are recognized on the Property:

- Gold-rich base metal massive sulphide lenses (LaRonde Penna, Bousquet No. 2Dumagami), which represent the exhalative part of a VMS-type system above the seafloor.
- Gold-rich vein stockworks and sulphide disseminations (Bousquet No. 1-LZ5 and Ellison); which represent the sub-seafloor stockwork and replacement-style VMS-type system (feeder zone) into permeable (i.e., fragmental) facies in volcanic rocks such as breccia, volcanic tuff, pyroclastic unit, etc.
![img-16.jpeg](img-16.jpeg)

Figure 8.2 - Schematic east-west section showing simplified stratigraphy and possible pre-deformation structure of mineralized hydrothermal systems in LaRonde-Bousquet 2 gold-rich VMS complex (from Yergeau, 2015; and Dubé et al., 2014)![img-17.jpeg](img-17.jpeg)

Figure 8.3 - Simplified stratigraphic columns of DBL mining camp showing stratigraphic position of main mineralized zones [from Boily-Auclair, Mercier-Langevin, et al. (2020)]. Ore lenses are not to scale.The origin of the gold in the DBL mining camp has been debated in the past, but previous cited studies have provided clear evidence for the synvolcanic model for the source of gold, with substantial local remobilization during regional deformation.
Epizonal "intrusion-related" sulphide $\mathrm{Au} \pm \mathrm{Cu}$ veins and shear hosted sulphide-rich Au-Cu veins located in the western part of the DBL mining camp (e.g., Mouska, Doyon and Westwood mines) show evidence for the presence of a gold-rich magmatic fluid linked to synvolcanic Mooshla intrusion. These contrasting mineralization styles are considered part of an extensive Archean synvolcanic magmatic-hydrothermal system as shown in Figure 8.3 (Mercier-Langevin, Dubé and Blanchet, et al. 2017) (Boily-Auclair, Mercier-Langevin, et al. 2020).
Based on this geological model, exploration programs have targeted all favourable stratigraphic horizons in the Bousquet Formation with a focus on stacked lenses and oreshoots, leading to the successful exploration campaign in the 1990s that resulted in the discovery of Zone 6 and Zone 7 at LaRonde Shaft \#2, and Zone 20 North and Zone 20 South at the Penna Shaft.
Current exploration programs by the Company at the LaRonde Complex still use the same approach by regularly carrying out north-south drilling, which permits a cross-cutting of all favourable horizons of mineralization, particularly in the plunge of known orebodies.

[[@~@]]
# 9 Exploration

Exploration programs conducted by Agnico Eagle at the LaRonde Complex since the late 2000s have focused mainly on exploration drilling. The significant exploration results that are material to the Technical Report were obtained by both underground and surface core drilling. This work and resulting interpretations are summarized in Sections 10 and 14 of the Technical Report.

[[@~@]]
# 10 Drilling

Systematic diamond drilling has been the most prevalent and successful strategy to date for mineral exploration in the DBL Mining Camp.
Current exploration programs at the LaRonde Complex still use this approach and regularly make north-to-south drill patterns in order to cross-cut all favourable horizons of mineralization, particularly in the plunge of known orebodies. Table 10.1 summarizes all drilling on the Property by area, department and year. Figure 10.1 shows a longitudinal section view of all drill holes on the Property, including the validated diamond drill holes used in the 2022 Mineral Resource Estimate (see Section 14).
Since the first gold production on the LaRonde property in 1988, Agnico Eagle drilling programs have focused on areas in close proximity to mining operations (i.e., LaRonde Shaft \#1, LaRonde Shaft \#2, Penna Shaft, LaRonde Shaft \#4 and LZ5) and on adjacent properties, and the programs have had multiple objectives.
Exploration drilling at the LaRonde Complex has focused on finding new orebodies or demonstrating extensions of known orebodies. The purpose of conversion drilling is to convert inferred mineral resources into indicated mineral resources. Exploration and conversion drilling programs (underground and at surface) within 2 km of mining infrastructure were supervised by the exploration team of the Geology Department of the LaRonde Division. However, exploration drilling programs on the adjacent Ellison, El Coco and Terrex properties, which are more than 2 km from mining infrastructure at the LaRonde Mine, were supervised by AEM's Regional Exploration Group ("Regional Exploration") based at the Company's Val-d'Or Exploration office.
Definition and delineation drilling at the LaRonde Complex are focused on bringing mineral resources into the indicated and measured categories to assist in developing the production mining plan. All definition and delineation drilling programs on the Property are supervised by the production geologist team of the Geology Department of LaRonde Division.
Additional drilling programs for geotechnical purposes or for mine-services holes are also supervised by the Geology Department.
Agnico Eagle acquired the Bousquet Complex in 2003 and transferred the historical Bousquet drillhole database to AEM. This historical database was subsequently fully integrated into the Company's Fusion database (Bousquet Business Unit). The stored, historical drill cores from the Bousquet Complex were also added to Agnico Eagle's drill core inventory.Table 10.1 - Summary of drilling at LaRonde Complex to December 31, 2022

| Department / Business Unit | Year | Holes |  | Comment |
| :--: | :--: | :--: | :--: | :--: |
|  |  | No. of holes | Length (m) |  |
| Regional <br> Exploration (Ellison, El Coco and Terrex properties) | Pre-2003 (Historic owners) | 137 | 36,632 | Historic surface exploration drilling |
|  | 1999-2002 (El Coco - AEM) | 32 | 17,958 | Surface exploration drilling |
|  | 2004 \& 2006 (Terrex - AEM) | 8 | 2,250 | Surface exploration drilling |
|  | 2004-06 (Ellison - AEM) | 23 | 4,938 | Surface exploration drilling |
|  | 2007-22 | - |  | No drilling |
| Total Regional Exploration Drilling: |  | 200 | 61,778 |  |
| LaRonde (LaRonde deposit) | Pre-1989 (Historic owners) | 673 | 72,192 | Historic surface exploration \& conversion drilling: Shaft \#1 |
|  | Pre-2010 (AEM) | 4,998 | 826,580 | Exploration, conversion/definition \& delineation: Shaft \#1 \& \#2 and Penna Shaft |
|  | 2010 | 238 | 22,115 | Exploration, conversion/definition \& delineation: Penna Shaft and Shaft \#4 |
|  | 2011 | 163 | 12,282 |  |
|  | 2012 | 279 | 25,849 |  |
|  | 2013 | 287 | 28,098 |  |
|  | 2014 | 178 | 29,699 |  |
|  | 2015 | 200 | 39,978 |  |
|  | 2016 | 218 | 47,222 |  |
|  | 2017 | 220 | 44,388 |  |
|  | 2018 | 145 | 32,069 |  |
|  | 2019 | 156 | 26,109 |  |
|  | 2020 | 172 | 35,114 |  |
|  | 2021 | 149 | 31,330 |  |
|  | 2022 | 152 | 21,922 |  |
|  | Total | 8,228 | 1,294,947 |  |
| Bousquet (LZ5 deposit) | Pre-2003 Historic Owners (Long Lac Mineral Exploration; Lac Minerals; Barrick) | 5,970 | 677,363 | Exploration, conversion/definition \& delineation: Bousquet \#1 \& Bousquet \#2 |
|  | Pre-2010 (AEM) | 117 | 68,886 | Exploration drilling (surface \& underground) |
|  | 2010 | 9 | 2,457 | Surface drilling for validation, exploration and conversion: LZ5 |
|  | 2011 | 68 | 18,241 |  |
|  | 2012 | 13 | 4,357 |  |
|  | 2013-15 | - |  | No drilling |
|  | 2016 | 9 | 2,777 | Conversion drilling LZ5 |
|  | 2017 | 41 | 2,929 | Delineation drilling LZ5 |
|  | 2018 | 30 | 1,805 | Delineation drilling LZ5 |
|  | 2019 | 69 | 3,828 | Delineation drilling LZ5 |
|  | 2020 | 59 | 3,872 | Delineation drilling LZ5 |
|  | 2021 | 52 | 12,875 | Exploration, conversion \& delineation |
|  | 2022 | 102 | 26,804 | Exploration, conversion \& delineation |
|  | Total | 6,539 | 826,194 |  |
| Total Mine Drilling: |  | 14,767 | 2,121,141 |  |
| Total drilling at LaRonde Complex | Subtotal historic owners | 6,780 | 786,187 | Various owners (see Section 6) |
|  | Pre-2010 AEM | 5,138 | 900,404 | AEM drilling (LaRonde Division \& Exploration Division) |
|  | 2010-22 AEM | 3,049 | 496,328 | AEM drilling (LaRonde Division \& Exploration Division) |
|  | Total Drilling: | 14,967 | 2,182,919 |  |![img-18.jpeg](img-18.jpeg)

Figure 10.1 - Composite longitudinal section showing all drill holes on the Property including validated diamond drill holes used in 2022 Mineral Resource Estimate

[[%~%]]
## 10.1 Drilling Contractors

All core drilling has been performed using conventional underground and surface drill rigs furnished and operated by contractors. Several drilling contractors located in the Abitibi region and listed in Table 10.2 were used to execute drilling campaigns at the LaRonde Complex since the 1980s. Since 2010, the main drilling contractors have been:

- Forage Orbit Garant Inc. (previously Forage Garant et Frères Inc.) of Val-d'Or, Que., which carried out almost all underground diamond drilling on the Property since January 2011 until the end of 2019. Forage Orbit Garant also completed surface diamond drilling in 2016.
- Machine Roger International Inc. of Val-d'Or, Que., which completed all underground diamond drilling at LZ5 Mine since February 2018 and at LaRonde Mine since January 2020.
- Forage M. Rouillier Drilling Inc. of Amos, Que., which completed all surface diamond drilling for the exploration campaigns from 2010 to 2012.
- Forage RJLL Inc. of Rouyn-Noranda, Que., which completed surface diamond drilling in 2021 and 2022 at LZ5.

Table 10.2 - Drilling contractors and drilling campaigns at LaRonde Complex (1929 to 2022)

| Business <br> Unit | Contractor | Locality | Period of activity | Site of drilling | Purpose |
| :--: | :--: | :--: | :--: | :--: | :--: |
| LaRonde | Various (Forage Garant et Frères, Forage Groleau, Forage Hosking, Forage Mercier Inc., Morrissette, Norex Drilling, Swick Mining Services Ltd. and others) | Various | $\begin{gathered} \text { Various } \\ 1929-2010 \end{gathered}$ | Underground \& Surface | Exploration, conversion, definition \& delineation |
|  | Forage Orbit Garant | Val-d'Or, Quebec | 2011-19 | Underground | Exploration, conversion, definition \& delineation |
|  | Machines Roger International | Val-d'Or, Quebec | 2020-22 | Underground | Exploration, conversion, definition \& delineation |
|  | Forage RJLL | Rouyn-Noranda, Quebec | 2021 | Surface | Geotechnical holes |
| Bousquet | Various (Bradley, Forage Dominik, Foranord Inc., Forage Garant et Frères, Forage Hosking, Forages Rouillier, Morrissette, Phillipon D.D. and others) | Various | Various 1937-2009 | Underground \& Surface | Exploration, conversion, definition \& delineation |
|  | Forages Rouillier | Amos, Quebec | 2010-12 | Surface | Exploration, conversion |
|  | Forage Orbit Garant | Val-d'Or, Quebec | 2016-17 | Underground \& Surface | Conversion, delineation |
|  | Machines Roger International | Val-d'Or, Quebec | 2018-22 | Underground | Exploration, conversion, definition \& delineation |
|  | Forage RJLL | Rouyn-Noranda, Quebec | 2021-22 | Surface | Exploration, conversion |

[[%~%]]
## 10.2 Drilling Procedures

[[%~%]]
### 10.2.1 Core Size And Core Boxes

The majority of the current diamond drilling at LaRonde Complex recovers BQ size ( 3.64 cm diameter) core for definition and delineation, and NQ size ( 4.76 cm diameter) core for exploration and conversion, using industry standard wire-line methods.

The historical holes drilled from surface, when reported, were mainly BQ core size while the historical underground drilling included BQ and AQ/AW/TT46 core sizes.

The core is stored in consecutive order (standard left to right and top to bottom sequence) in 1.5-metre long wooden trays (core boxes) that have an approximate 4.5 m (NQ) or 6 m (BQ) capacity. The drill contractor identifies the location of the core samples along the hole by placing wooden markers at 3 m spacing. The drill contractor also identifies intervals of incomplete core recovery (due to grinding or washout). Once the box is full, it is closed tightly with a matching lid using common fencing wire or fiber tape. The drill hole identification and box numbers are then recorded on the lid using a permanent ink marker.

[[%~%]]
### 10.2.2 Drill Hole Identification

Each drill hole at LaRonde Complex has a unique identification that is related to the location of the collar. Exploration and definition drill holes are numbered differently than delineation drill holes. However, the identification method changed in late 2014, according to the Company's standardizing document, "AEM Drilling nomenclature and Logging Guidelines_v1.9" (current version is 2.6).

Since October 2014, underground exploration, conversion and definition holes are identified by the mine site code and the level from which the hole started, followed by a sequential three-digit number. Mine site codes are LR for LaRonde and BZ for LZ5. For example, LR290-005 means the fifth hole drilled on Level 290 at the LaRonde Mine.

Delineation drill holes are completed during the underground development stage of each production stope at LaRonde Mine and LZ5 Mine. Each delineation hole is numbered using a simple 8 or 9 integer series that identifies its sublevel, targeted zone, stope draw point, and sequential start-up. For example, at LZ5 Mine, delineation drill hole BZ09051351 was drilled on Level 9, it tested Zone 5 (with zones 4, 41 and 5 identified by the numbers 04, 41, and 05 respectively), it was drilled in draw point no. 135, and it was the first hole to be drilled from this collar location.

Historical holes have different nomenclatures, but most commonly have a prefix such as "S" for surface drilling (or "EL" for Ellison), followed by the year of drilling ("87" for 1987), and a sequential number (e.g., S87-142).

[[%~%]]
### 10.2.3 Core Storage

With few exceptions, half of the drill core from exploration holes is stored in the LaRonde Complex core library for additional purposes (e.g., metallurgical testing, geotechnical studies and environmental studies), while the other half-core is sent for lab analysis.

Generally, for drill holes from conversion and definition drilling programs (that systematically test the target horizons on evenly spaced intervals along a given section line) only core from selected flat holes is retained.For delineation drill core, no core is retained, with whole core from within the mineralized zones being sent for lab analysis and core from the wall rocks being destroyed.
Each stored core box is identified with an aluminum tag embossed with the appropriate drill hole information including hole number, box number and the core interval stored in the box. Boxes belonging to individual drill holes are stored consecutively in core racks located on the Property. An inventory is kept for each core rack and is copied into an electronic data bank by the Geology Department.

[[%~%]]
### 10.2.4 Drill Hole Collar Surveys And Downhole Surveys

[[%~%]]
#### 10.2.4.1 Drill Hole Collar Surveys

All surface drill hole collars from the 2010-22 period were surveyed using a GPS system. Each hole collar location is spotted in the field with a GPS. The drill is aligned under the field supervision of Agnico Eagle geologists or technicians. Drills were aligned using wooden pickets for the back sights or front sights. All coordinates were surveyed in the UTM NAD83, Zone 17 grid prior to LaRonde or Bousquet grid conversion.

Since the end of 2021, surface drill hole collars have been implanted and surveyed by the surveyor technician of Surface and Environment Department of LaRonde Division with GPS Leica Viva GS-14 (CS20 controller) directly in the local mine grid. The contractor sets the diamond drill onto the collar and aligns the drill using a gyroscopic aligner (Reflex TN14 Gyrocompass). Once drill holes are completed, the final collar coordinates are re-surveyed with the GPS system. The casings are covered with a steel cap and a steel marker showing the collar identification. Whenever possible, the casings are kept unless they are in the vicinity of planned mining infrastructure in which case they are removed before construction begins. If required, the holes are plugged and cemented to prevent water from infiltrating any potential future underground workings. This information is recorded in the drill hole database.

For underground drilling at both LaRonde Mine and LZ5 Mine, the following procedure is applied for an approved drill hole:

1. The Geology Department prepares the drill hole layout on a copy of the most current 1:250 scale underground development map (provided by the Engineering Department) that covers the proposed collar location. Information such as collar coordinates (which reference LaRonde Mine or Bousquet Mine grid), drill hole azimuth and dip, hole length and special comments are noted directly on the layout. The layout is approved by sector engineers and geologists using a check list to avoid oversight that includes a borehole warning when drilling is close to drifts and underground openings.
2. Approved drill hole layouts are transmitted to the foreman of the diamond drilling contractor, the surveying team and the Mine Department. The drill hole collar is identified by the surveyors, with front and back sight references on the wall, with paint or metallic spads.
3. The contractor sets the diamond drill onto the collar and aligns the drill using a gyroscopic aligner (Reflex TN14 Gyrocompass) or, when not available, using front and back sights references.4. Once the hole is completed, the Geology Department re-issues the layout to the surveying team who return to the collar location of the hole and directly measure the final coordinates, azimuth and dip. When available, collar azimuth and dip are measured with the gyrocompass.
5. The coordinates, azimuths and dip are now sent electronically to the Geology Department by the surveying team and stored on LaRonde's server. These data are electronically imported directly in AEM's drillhole central database (Fusion) by the geology team.

[[%~%]]
#### 10.2.4.2 Downhole Surveys

Downhole orientation measurements are typically taken by an EZ-Trac magnetometer-accelerometer-temperature tool (Reflex Instrument Canada) and are performed as drilling progresses by the drilling contractors.

Downhole survey tests are generally taken at each 50 m interval in the EZ-Trac single shot mode for all drillholes. For short delineation holes, one test is taken at 15 m and a second test is taken at the end of the hole. Each test is hand-written reported on small paper and/or in the drilling daily report, then validated and recorded in LaRonde's database and finally kept in a register.

For an exploration hole, a second set of tests in EZ-Trac multi-shot mode are usually taken at each 12 m interval once the hole is completed. All multi-shot (and some single shot) measurements are transferred via a secure, cloud-based server (IMDEXHUB-IQ) connected with the measuring device (Reflex EZ-Trac). After quality control inspection, the data is uploaded to LaRonde's database.

Several downhole survey methods were performed in the past at LaRonde and Bousquet. The methods that were employed are:

- Gyroscopic surveys performed by specialized companies or drilling contractors (Sperry Sun Drilling Services or CBC Welnav)
- Deflection type Maxibor surveys by specialized companies (Reflex Instrument Canada or Boreinfo) and Lightlog surveys completed by Agnico Eagle or by a contractor (Techdel International)
- EZ-Shot tests (Reflex Instrument Canada) and single or simultaneous-double single-shot compass tests (Tropari-Pajari Instruments or Sperry Sun Drilling Services) completed by mine staff or by the drilling company
- Rotodip inclinometer tests (Techdel International) read by the drilling company
- Acid-dip tests (commonly at 100 ft or 30 m intervals)


[[%~%]]
### 10.2.5 Cementing Of Completed Drill Holes

In accordance with Quebec mining regulations, after drill holes are completed and surveyed, they are cemented either at the collar (over a 15 m length) or over the full hole length in the case of delineation drill holes in ore and filled using a grout and cement mixture. These cementing operations are completed by the drilling contractor. The list of cemented holes is kept in a handwritten registry stored in the Geology Department vault. Since 2001, hole cementation is also registered in the database of the DHLogger system and identified on the front page of every drill hole log.

[[%~%]]
## 10.3 Drilling By Agnico Eagle

From 2010 to the end of 2022, 3,049 holes (or wedge holes) were drilled for a total of $496,328 \mathrm{~m}$ by the LaRonde Division (see Table 10.1). The average core recovery rates exceeded $99 \%$.

Figure 10.2 and Figure 10.3 show the distribution of pierce points in the Zone 20 North Zone area at the LaRonde Mine and the Zone 5 area at the LZ5 Mine, respectively.

[[%~%]]
### 10.3.1 Regional Exploration Drilling

The Regional Exploration drilling program from 1999 to 2002 mainly focused on the El Coco property after its acquisition by Agnico Eagle in 1999. This program confirmed the presence of a mineralized horizon (Zone 22) located approximately 1.5 km east of the Penna Shaft and explained the presence of previously identified geophysical anomalies. Only anomalous to subeconomic values were intercepted (Laplante 2002). However, the drilling into Zone 22 confirmed the geological model of a succession of mineralized lenses along a repetition of probable synvolcanic faults at each $\pm 2 \mathrm{~km}$ interval.

The Regional Exploration infill drilling program from 2004 to 2006 mainly focused on the Ellison property and targeted its Zone A horizon. This program confirmed the presence and the continuity of narrow mineralized horizons along the Ellison property, which are now interpretated as the extension of Zone 4 and Zone 41 of the LZ5 deposit.

In 2004 and 2006, a small drilling program was initiated on the Terrex property located south of the Penna Shaft. The program targeted geophysical anomalies linked to iron formation in the Cadillac Group (De Chavigny 2007) but was unsuccessful in intersecting potentially economic mineralization.

[[%~%]]
### 10.3.2 Laronde Deposit Drilling

Exploration and definition drilling programs at the LaRonde Mine have been uninterrupted during the past 30 years. The Zone 20 North package accessible from the Penna Shaft was the main focus of exploration since production from the shaft began in 2000. The objectives of the drilling campaigns over this period have remained consistent: to extend mineralized zones, to perform infill drilling, and to follow up on new discoveries.

From 2015 to 2022, the program successfully extended Zone 20 North and Zone 6 down to more than 3.7 km depth. Zone 20 North shows a down-plunge extension of nearly 3.0 km long and a lateral east-west extension of 1.0 km at 3.2 km depth. In 2020, the drilling identified a new zone of interest, named the 20 North Zinc South Zone, that is an eastern satellite zinc-rich zone and part of the 20 North horizon between levels 314 and 341.

Since 2016, exploration has continued periodically from an exploration drift on Level 215. The deep extension of the Bousquet No.2-Dumagami deposit and Zone 3-1 have been targeted by steep exploration holes that have shown continuous mineralized horizons.

[[%~%]]
### 10.3.3 Lz5 Deposit Drilling

The Bousquet property (hosting the former Bousquet No. 1 and Bousquet No. 2 mines) have been extensively drilled since the mid-1970s, with more than 5,900 historical diamond drill holes representing nearly 677,000 m over this 45-year period (see Table 10.1 and Figure 10.3). Previousoperators (1978 to 2002) of the Bousquet Complex - successively Long Lac Mineral Exploration, Lac Minerals and Barrick Gold - completed all required drilling from exploration to the delineation stage, which is now considered historical drilling.

From 2010 to 2012, a conversion-exploration drilling program totalling approximately 20,000 m was completed around the open pit of Zone 5 to validate and confirm historical values of Zone 5. A resampling campaign was also completed in 2010 on 22 selected holes that were stored at the Bousquet No. 1 core shack to compare the old and new data sets.

Since 2016, conversion and definition/delineation drilling on the Zone 5 horizon (including zones 4, 41, 5 and 51) have been the main focus of drilling programs (see Figure 10.4). Since 2020, several holes were also drilled targeting the Zone 3 horizon (including zones 1, 2, 3FW and 3HW) to confirm its position and grade. All these new holes have confirmed interpretations based on historical drillholes, with Zone 5 now showing a down-plunge extension of nearly 1.0 km long and a lateral east-west extension of 600 metres.![img-19.jpeg](img-19.jpeg)

Figure 10.2 - Plan view and cross-section showing diamond drill holes and pierce points below 2.45 km depth in Zone 20 North at LaRonde Mine![img-20.jpeg](img-20.jpeg)

Figure 10.3 - Plan view and cross-section showing diamond drill holes and pierce points in mineralized zones at LZ5 Mine![img-21.jpeg](img-21.jpeg)

Figure 10.4 - Example of longitudinal section showing pierce points by year in Zone 5 at LZ5 Mine

[[%~%]]
## 10.4 Note On Historical Drilling By Previous Owners And Agnico Eagle

The LaRonde Complex has been extensively drilled since the mid-1970s, with almost 15,000 diamond drill holes representing nearly 2.2 million metres completed over this period. All drill holes related to pre-2000 mining operations (i.e., Bousquet No. 1, Bousquet No. 2, LaRonde Shaft \#1 and LaRonde Shaft \#2) were completed before NI 43-101 standards were first adopted in February 2001.

The majority of historical drill holes of the Bousquet No. 1 and Bousquet No. 2 mines have been fully integrated into the current drillhole database at the LaRonde Complex through different compilation works in 2010 and by Hallé (2015) and Pitre (2020b). Drillhole positions (collars and surveys) and assays have passed through a rigorous and robust validation process to check the accuracy and consistency. Surveyed collars of historical holes are reported (in Bousquet Mine grid) in all original paper logs and surveyor logbooks that are kept in a vault at Agnico Eagle's Abitibi Regional Office situated on the Bousquet property. The procedures for surveying are not reported, but validations have been made from original logs as well as correspondence with the 3D positions of underground drifts and/or existing drilling bays. The correspondence is excellent. However, structures, alterations, textures and mineralogy are not available in the database but they are not critical to the estimation.

Almost all drillhole and survey logs have been scanned as PDF files, but most of the original assay certificates prior to 2002 are no longer available. No major issues were found, and corrections were made when original data were available. Uncertain historical results are noted but excluded from the MRMR estimate. It is the opinion of the QP responsible for this section of the Technical Report that the majority of historical drilling is reliable for the purposes of this report.

[[%~%]]
## 10.5 Conclusion

The QP responsible for this section of the Technical Report is of the opinion that the logging and recording procedures at LaRonde Complex are comparable to industry standards. There are no other known drilling, sampling, or recovery factors that could materially impact the accuracy and reliability of results.

[[@~@]]
# 11 Sample Preparation, Analyses And Security

This section describes the sample preparation, analyses and security protocols for the LaRonde Complex diamond drilling programs, encompassing the mine exploration, conversion and definition drilling programs implemented by the Mine Exploration Geology team and the delineation drilling programs implemented by the Production Geology team.
From 2014 to the present, the delineation diamond drill core samples and over $80 \%$ of the definition drill core samples have been assayed at Agnico Eagle's LaRonde Laboratory located on the Property. Since 1999, 75\% of the exploration and conversion diamond drill core samples shipped from the LaRonde Complex have been sent to external independent laboratories, and 99\% of these samples are assayed at ALS Global Group's ("ALS") Val-d'Or Geochemistry facilities and at Bourlamaque Assay Laboratories Limited ("Bourlamaque Laboratories"), both located in Val-d'Or, Quebec.

All standards of practice for core-logging and sampling at the LaRonde Complex have been established by Agnico Eagle, and the procedures for core sampling, analyses and security detailed in the Technical Report relate only to drilling campaigns conducted by Agnico Eagle. The historical procedures for sample preparation, analyses and security prior to the Company's ownership of the Property are not outlined in this report.

[[%~%]]
## 11.1 Core Handling, Sample Preparation And Security

The drill core is placed into $1.5-\mathrm{m}$-long wooden core boxes at the drill site. A wooden block with the drill hole and box numbers is inserted at the start of each new box. At the end of each drill run, a wooden block is inserted with the depth of the hole written on it. When the core box is full, it is covered with another core box and the box and lid are secured by steel wire. The drill hole and box numbers are written on the cover.
Approximately once per day the accumulated core boxes are sent by ground transportation a distance of less than 4 km to the core receiving area adjacent to the LaRonde Mine core shack. At the core shack, the boxes are opened and inspected. Core meterage is measured to ensure accuracy and then the core is stored in steel racks until it is logged by a geologist. Corrections are made if discrepancies are found.
During logging, the geologist provides a detailed description of the drill core. The geologist then marks the start and end of the sample directly onto the core with a coloured wax crayon while the core is still intact in the core box. Following existing Quality Assurance and Quality Control ("QA/QC") protocols, the geologist inserts the corresponding sample tags at the correct sample interval (the "to" distance of the sample) as well as the QA/QC identification tags. The sample tags are comprised of waterproof paper and indelible ink and are divided into two identical tags. One of the labels is placed in the sample bag and the other is stapled to the core box and kept as a reference. Each sample is assigned a unique number. The wet core is photographed prior to sampling, with logging marks and sample tags in place.
Continuous core samples are taken in visually mineralized zones in sample lengths varying from 0.5 to 1.5 m , with a standard length of 1.5 m . Samples are measured to the nearest 10 cm . Effort is made to restrict individual samples to a single rock type and to not sample across major rocktype boundaries. Typically, mineralized samples must be properly bordered by 3.0 m (true width) of waste.

The drill core samples for the delineation and definition drill holes are generally whole core samples. Drill core for these drill holes is generally BQ size. However, where the ground conditions are of poor quality, NQ-size drill core may be used. The entire sample is collected consecutivelydown the interval (along with the sample tag) and placed in a sample bag. Several samples in sequential order are placed together in a rice sack which is then securely closed with a cable tie.

For the exploration and conversion drill core samples, the core is split using a diamond cutting saw. Depending on the sector of drilling and the ground conditions, both NQ- and BQ-size drill core may be used. Core is halved according to the sample limits and sample tags defined by the geologist. Samples for assay are collected in an individual clear plastic bag, one of the two identical sample tags is placed in the bag, and the bag is securely stapled shut. The remaining core is returned in sequential order to the core box, and the second identical tag is stapled into the core box at the end of the marked sample interval. The core boxes with the remaining core are stored outside in the core racks for future reference.

As with the delineation and definition drill core samples, several individually packaged and identified samples in sequential order are placed together in a rice sack, which is sealed with a cable tie. The completed sample dispatch form is included in the sack with the last sample in the sequence. The sample lots are transported to the various commercial laboratories by an internal service operated by Agnico Eagle employees or by a commercial courier service operated by the firms Livraison Parco or Max Transport Collectif.

The receiving laboratory validates that the number of samples and the sample numbers match those on the sample dispatch form. If discrepancies are observed by the laboratory, the LaRonde Complex geology departments are contacted before the batch is assayed.

The rejects and pulps from the samples are returned to the core shed at the LaRonde Mine after the QA/QC has been reviewed by the responsible geologist at the LaRonde Complex. Once the pulps and rejects have been received at the core shed, any samples that are to be analyzed at the secondary laboratory are packaged under supervision of the responsible geologist and shipped to the laboratory. Those samples that do not need to be sent for a secondary analysis are stored at the mine site for future reference.

[[%~%]]
## 11.2 Laboratory Accreditation And Certification

The International Organization for Standardization ("ISO") and the International Electrotechnical Commission ("IEC") oversee the specialized system for worldwide standardization. The publication "ISO/IEC 17025 General Requirements for the Competence of Testing and Calibration Laboratories" ("ISO/IEC 17025") sets out the criteria for laboratories seeking to demonstrate that they are technically competent, are operating an effective quality system, and are able to generate technically valid calibration and test results. The standard will form the basis for the accreditation of competence of laboratories by accreditation bodies. ISO 9001 is for management support and procedures, internal audits and corrective actions. It provides a framework for existing quality functions and procedures.

The Proficiency Testing Program for Mineral Analysis Laboratories ("PTP-MAL") is a way in which a mineral analysis laboratory can evaluate its performance for one or more analytical methods independently of internal quality control. The participation in this program is mandatory if the laboratory is to be accredited or is to retain its accreditation for mineral analysis activities by the Standards Council of Canada to ISO/IEC 17025 standards.

Since 2014, diamond drill core samples from the delineation and definition drilling programs at LaRonde Complex have been sent to the Company's LaRonde Laboratory located on the Property. Prior to 2014, drill core samples from the definition drilling programs were assayed at Bourlamaque Laboratories. The LaRonde Laboratory (also named AEM Regional Laboratory) is an internal laboratory. However, in the Certificate of Proficiency Test the laboratory rating has been assessed as "satisfactory" for gold, silver, copper, zinc and lead by PTP-MAL through recentyears up to 2022 and has been accredited by the Standards Council of Canada for ISO 17043/IEC (CAN-P-43), CAN-P-1579.

ALS Global's Val-d'Or Geochemistry facility has acted as the principal laboratory for assaying of the exploration and conversion drill core samples at the LaRonde Complex. ALS occasionally uses other laboratories belonging to the ALS Global Group for LaRonde Complex samples. ALS has had ISO 9001 certification since 2008 and ISO/IEC 17025 accreditation since 2005 through the Standards Council of Canada. ALS is a commercial laboratory independent of the LaRonde Complex and the Company.

Since 2014, the LaRonde Complex has used Bourlamaque Laboratories as its secondary laboratory for external check assays on pulps. Bourlamaque Laboratories has been assessed "satisfactory" for test samples (2022 and previous years) for gold, copper, silver and zinc by PTPMAL and accredited by the Standards Council of Canada for ISO 17043/IEC (CAN-P-43), CAN-P-1579. Bourlamaque Laboratories is a commercial laboratory independent of the LaRonde Complex and the Company.

[[%~%]]
## 11.3 Laboratory Preparation, Assays And Measurements

[[%~%]]
### 11.3.1 Sample Preparation

The core sample preparation and assaying methods of the primary and secondary laboratories are similar. The principal steps are outlined below, and the sample preparation and analytical methodologies are summarized in Table 11.1.

1. Samples are received, sorted and logged into the laboratory LIMS program.
2. Samples are dried at $110^{\circ} \mathrm{C}$ to $135^{\circ} \mathrm{C}$ and weighed. For SG measurements, samples are weighed in air and water, and dried a second time.
3. Samples are crushed using 10 mesh for $>70 \%$ pass through a 2 mm screen.
4. Crushed samples are split to 250 grams using a rotary type splitter.
5. Samples are pulverized so that more than $85 \%$ passes through a $75 \mu \mathrm{~m}$ screen.
6. Once the samples have passed through the $75 \mu \mathrm{~m}$ screen, they are taken to the weighing room to be weighed.

[[%~%]]
### 11.3.2 Sample Assaying

Samples from the LaRonde Mine are analyzed for gold, silver, base metals and specific gravity (see Table 11.1), while samples from the LZ5 Mine generally are analyzed only for gold. However, when required at the LZ5 Mine, silver, copper, zinc, lead and SG are also analyzed.
For gold at the ALS and Bourlamaque Laboratories, a 30 gram representative pulp aliquot is split from the pulp and analyzed by fire assay ("FA") and atomic absorption spectrometry determination ("FAAA method"). However due to the high sulphide content in the orebodies at LaRonde, samples with a high sulphide content tend to fail during the fire assay stage. Thus, for samples that are suspected to have a high sulphide content, a 15 -gram pulp sample is used. Only a 15 gram pulp aliquot is required from LaRonde Laboratory for the same FAAA method.
For samples returning results greater than $10 \mathrm{~g} / \mathrm{t}$ gold ( $5 \mathrm{~g} / \mathrm{t}$ gold threshold for ALS or LaRonde Zone 5 samples), a second 15 gram pulp sample is assayed by FA with a gravimetric finish ("FAGV method").For base metals analysis, a representative pulp aliquot passes through an aqua regia (two acids) digestion and then either a determination by microwave plasma atomic emission spectroscopy ("MP-AES") at LaRonde Laboratory, or a determination by atomic absorption spectroscopy ("AAS") at the ALS or Bourlamaque laboratories.

[[%~%]]
### 11.3.3 Specific Gravity

All assay samples sent from the LaRonde Mine to the LaRonde and ALS laboratories have specific gravity ("SG") measurements taken using a standard water immersion method on the core samples. Due to a more homogenous SG values for ore at LZ5 (around 2.9), assay samples from the LZ5 Mine sent to the LaRonde Laboratory generally do not have SG measurements taken. Assay samples from exploration projects at the LaRonde Complex (including the exploration at LZ5) that are sent to the ALS laboratory are subjected to SG tests. Table 11.2 indicates the expected specific gravity by rock type at the LaRonde Complex.Table 11.1 - Summary of gold, silver, base metals and SG analysis at LaRonde Complex

| Laboratory | Sample Preparation |  |  |  | Analytical Methodology |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | Core weight ( kg ) | Sample ID | Crushing procedure | Pulverizing procedure | Analytes | Lab code | Analytical method | Detection limit |
| Primary Laboratory: AEM Regional Laboratory (aka LaRonde Laboratory) | 1.5 to 6.5 kg (avg 5 kg : 0.5 to 1.5 m , SG varying between 2.7 to $4.4 \mathrm{t} / \mathrm{m}^{3}$ ) for $B Q$ and $N Q$ core sizes | Prefix for DDH samples: CALRD or CABZD | $\begin{gathered} >70 \% \\ \text { passing } \\ <2 \mathrm{~mm} \\ (10 \text { mesh }) \\ \text { screen } \end{gathered}$ | $\begin{aligned} & 250 \mathrm{~g} \\ & \text { pulverized to } \\ & >85 \% \\ & \text { passing } 75 \\ & \text { micron (200) } \\ & \text { mesh screen } \end{aligned}$ | Au | Au_g/t_PY-AA-15G | Fire Assay / <br> AA finish on 15 g | $0.03 \mathrm{~g} / \mathrm{t}$ |
|  |  |  |  |  | Au | Au_g/t_PY-GV-15G | Fire Assay / <br> Gravimetric finish on 15 g | re-assay above $10 \mathrm{~g} / \mathrm{t}^{*}$ |
|  |  |  |  |  | Ag | Ag_g/t_ATQA_AES-0.25G | Aqua Regia / MP-AES | $1.0 \mathrm{~g} / \mathrm{t}$ |
|  |  |  |  |  | Cu | Cu_\%_ATQA-AES-0.25G | Aqua Regia / MP-AES | $0.003 \%$ |
|  |  |  |  |  | Zn | ZN_\%_ATQA-AES-0.25G | Aqua Regia / MP-AES | $0.003 \%$ |
|  |  |  |  |  | Pb | $\mathrm{Pb}_{-} \%$_ATQA-AES-0.25G | Aqua Regia / MP-AES | $0.003 \%$ |
|  |  |  |  |  | SG | Densite_specifique_---_GRAV | Specific Gravity (air/water weight) |  |
| Primary Laboratory: ALS Global (Val-d'Or) | 1.5 to 6.5 kg (avg 5 kg : 0.5 to 1.5 m , SG varying between 2.7 to $4.4 \mathrm{t} / \mathrm{m}^{3}$ ) for $B Q$ and $N Q$ core sizes | Prefix for chip samples: CALRC or CABZC | CRU-31 Fine crushing $>70 \%$ passing $>2 \mathrm{~mm}$ | Pul-31 250 g pulverized to $>85 \%$ passing 75 micron (200) mesh screen | Au | Au-AA25 | Fire Assay / <br> AA finish on 15 g or 30 g | $0.01 g t$ |
|  |  |  |  |  | Au | Au-GRA21 | $\begin{gathered} \text { Fire Assay / } \\ \text { Gravimetric finish on } 15 \mathrm{~g} \text { or } \\ 30 \mathrm{~g} \end{gathered}$ | re-assay above $5 \mathrm{~g} / \mathrm{t}^{*}$ |
|  |  |  |  |  | Ag | Ag-AA46 | Aqua Regia / AA | $0.001 \%$ |
|  |  |  |  |  | Cu | Cu-AA46 | Aqua Regia / AA | $0.001 \%$ |
|  |  |  |  |  | Zn | Zn-AA46 | Aqua Regia / AA | $0.001 \%$ |
|  |  |  |  |  | Pb | Pb-AA46 | Aqua Regia / AA | $0.001 \%$ |
|  |  |  |  |  | SG | OA-GRA08 | Specific Gravity (air/water weight) |  |
| Secondary Laboratory: <br> Bourlamaque Assay Laboratories | Pulps or rejects for check assays |  |  | $\begin{aligned} & 250 \mathrm{~g} \\ & \text { pulverized to } \\ & >85 \% \\ & \text { passing } 75 \\ & \text { micron (200) } \\ & \text { mesh screen } \end{aligned}$ | Au | Au ppm PY-AA | Fire Assay / AA finish on 15 g | $0.01 \mathrm{~g} / \mathrm{t}$ |
|  |  |  |  |  | Au | Au g/y PY-GRAV | Fire Assay / Gravimetric finish on 15 g | re-assay* above $10 \mathrm{~g} / \mathrm{t}$ |
|  |  |  |  |  | Ag | Ag ppm AA | Aqua Regia / AA | $0.002 \%$ |
|  |  |  |  |  | Cu | Cu\% AA | Aqua Regia / AA | $0.002 \%$ |
|  |  |  |  |  | Zn | $\mathrm{Zn} \% \mathrm{AA}$ | Aqua Regia / AA | $0.002 \%$ |
|  |  |  |  |  | Pb | $\mathrm{Pb} \% \mathrm{AA}$ | Aqua Regia / AA | $0.002 \%$ |

*Triggers another assay by fire assay with gravimetric finishTable 11.2 - Specific gravity by rock type (field names) and percentage of sulphides in the rock unit at LaRonde Complex

| Percentage of observed sulphides (\%) | Rock description | Rock type code | SG |
| :--: | :--: | :--: | :--: |
| $0-5$ | Unmineralized rock LZ5 | Waste | average at 2.8 |
|  | Unmineralized felsic rock | V9a or V9i | 2.7 to 2.9 |
|  | Unmineralized intermediate to mafic rock | V6 or V7 | 2.7 to 3.1 |
| $5-30$ | Mineralized intermediate to mafic rock ( $10 \%$ disseminated sulphides or stockwork) LZ5 | V6SZ | average at 2.9 |
|  | Mineralized felsic rock (5-30\% disseminated sulphides or stockwork) | V9a SZ, V2 SZ | 2.8 to 3.4 |
|  | Mineralized intermediate to mafic rock (5-30\% disseminated sulphides or stockwork) | V6SZ |  |
| $30-70$ | Semi-massive sulphide zone | SZ | 3.2 to 4.0 |
| $70-100$ | Massive sulphide zone | SZM | $>3.9$ |

[[%~%]]
## 11.4 Quality Assurance And Quality Control (Qa/Qc) Protocols

As of 2009 the QA/QC protocols at the LaRonde Complex include the insertion of certified reference materials ("CRMs" or "standards"), blanks and coarse duplicates as well as external pulp duplicate check assays. One of each standard, blank and coarse duplicate is inserted into the sample stream at approximately every 20 samples for a target of $5 \%$.
The QA/QC program does not include a systematic field duplicate control.
Table 11.3 summarizes the QA/QC protocols at the LaRonde Complex.
For the period that covers the 2022 MRMR (November 1, 2021 to October 30, 2022) a total of 17,031 samples were sent for analysis with the addition of 3,161 QA/QC samples (blanks, standards, and duplicates) inserted into the sample stream. Table 11.4 summarizes the insertion rate of the QA/QC samples into the sample stream for the primary laboratories during this period at the LaRonde Complex.
Table 11.5 summarizes the number of assays per laboratory by drill hole type during the same period at the Property. This QA/QC program has been in place since 2009. An average of $\pm 10,000$ samples per year are sent for analysis for a total of more than 142,000 samples since 2009.
Prior to importation of each assay certificate (csv file format) into the database, a validation is performed by the responsible geologist to check for any detectable errors or inconstancies. These errors could include: file structure or standard nomenclature, missing data, sample inversion or suspicious results not reflected by the corresponding log description. Any problems are resolved and corrections are made prior to first importation.Table 11.3 - Summary of the QA/QC protocols at LaRonde Complex

| Laboratory | QA/QC |  |  |
| :--: | :--: | :--: | :--: |
|  | Standards | Blanks | Duplicates |
| Primary laboratory: AEM Regional Laboratory (aka LaRonde Laboratory) | LaRonde Mine: <br> Custom standards prepared in 2013: LRD-4-2013, LRD-52013 and LRD-6-2013; <br> New standards in preparation: LRD-7-2021, LRD-8-2021 and LRD-9-2021 <br> LZ5 Mine: Certified Reference Material from Rock Labs: SG84, SJ80, SK93, SJ95 <br> 1 standard for 1 to 29 samples; 2 standards for 30 to 49 samples; 3 standards for 50 to 69 samples, etc. | Sample of approximately 1.0 to 1.5 m of barren rhyodacite (V9i) or basalt (V7) core taken from distal hanging/footwall of the 20 North lens <br> 1 blank for <br> 1 to 29 samples; <br> 2 blanks for <br> 30 to 49 samples; <br> 3 blanks for <br> 50 to 69 samples, etc. | Coarse reject duplicate at lab <br> 1 duplicate for 1 to 29 samples; 2 duplicates for 30 to 49 samples; 3 duplicates for 50 to 69 samples, etc. |
| Secondary laboratory: <br> Bourlamaque Assay Laboratories |  |  | Check pulps on zone: <br> $1 / 20$ ratio for delineation and definition holes; <br> $1 / 5$ ratio for exploration holes |

Table 11.4 - Summary of insertion rates for QA/QC samples at LaRonde Complex between November 1, 2021 and October 31, 2022

| Type | Number of samples | Insertion rate (\%) |
| :-- | :--: | :--: |
| Assays | 17,031 | - |
| Standards | 818 | 4.8 |
| Duplicates | 817 | 4.8 |
| Blanks | 817 | 4.8 |
| Check assays, secondary laboratory | 709 | 4.2 |
| Total | $\mathbf{3 , 1 6 1}$ | $\mathbf{1 8 . 6}$ |Table 11.5 - Distribution of number of assays per laboratory and drill hole type for LaRonde Complex from November 1, 2021 to October 30, 2022

| Laboratory | Delineation | Definition | Exploration | Conversion | Total |
| :-- | --: | --: | --: | --: | --: |
| AEM Regional Laboratory | 7,808 | 2,902 | 664 | 100 | 11,474 |
| ALS Global | - | - | 4,457 | 1,100 | 5,557 |
| Bourlamaque (check assays) | 346 | 167 | - | 196 | 709 |
| Total (including check assays) | $\mathbf{8 , 1 5 4}$ | $\mathbf{3 , 0 6 9}$ | $\mathbf{5 , 1 2 1}$ | $\mathbf{1 , 3 9 6}$ | $\mathbf{1 7 , 7 4 0}$ |

The historical QA/QC programs (before 2003) at Bousquet could not be tested or validated due to the absence of original certificates. However, a validation of the quality of historical data was made in 2010-11 with a campaign of re-assaying 22 historic holes stored at the Bousquet No. 1 core shack. The list of these holes is reported in Belzile (2011a) which confirms that historical data were reliable and could be used for mineral resource estimation.

Two validation reports of the quality of historical data were made in 2019 and 2020 with a campaign of re-assaying 12 historic holes stored at the Bousquet core shacks for the Massive Zone of Bousquet No. 2 (Area 11-3) and for the Zone 3 area of Bousquet No. 1. The list of these holes is reported in Pitre (2019) and Pitre (2020a), and it is the opinion of the QP responsible for this section that historical data were reliable and could be used for mineral resource estimation.

In 2009, the Company created and implemented a formal reporting system for all QA/QC data to improve the reaction to and follow-up of results. From 2003 to 2009, the previous QA/QC program was based on insertion of reference materials and pulp duplicates. A short summary was produced each year to report QA/QC failures and the actions taken in response.

[[%~%]]
### 11.4.1 Certified Reference Materials

CRMs are used to detect problems with the sample batches and/or to detect any possible longterm biases in the overall dataset. Before 2009, non-certified standards were used at the LaRonde Mine. Since 2009, custom certified reference materials in three grade groups were prepared using reject material from chip samples or delineation core rejects from the LaRonde Mine. All custom standards were manufactured at CDN Laboratories in Langley, B.C., and certified, again by Barry Smee Consulting. The custom standards - certified for gold, silver, copper, zinc and lead - are used primarily for the LaRonde Mine drill core samples. Commercial CRMs purchased from Rock Labs (only for gold) are used for the LZ5 Mine.

Results for inserted standards must pass the standard deviation ("SD") test. Standards with results exceeding $\pm 3 \mathrm{SD}$, are systematically flagged and when required, re-runs are requested for the mineralized samples (including the standard) around the failed standard. Once the re-run assay data are received, the results are compared to the original data to ensure there are no biases in the results. If the results are acceptable and comparable to the original data, an average is calculated for those samples. If the results differ above $20 \%$, exclusions of data may be required.

QA/QC data are inspected on a day-to-day basis upon receiving the assay certificates, whereas the QA/QC reports are typically generated every six months. Figure 11.1 presents the graphic results for the CRMs for the period from November 1, 2019 to October 31, 2022 from the LaRonde Laboratory and the ALS and Bourlamaque laboratories. From this period, a total of 2,780 CRM samples were submitted using seven different CRMs covering gold grades between 0.93 and $11.40 \mathrm{~g} / \mathrm{t}$ gold. Overall, $89.4 \%$ of the CRMs passed the $\pm 3 \mathrm{SD}$ test. Then, 104 batches of sampleswere re-assayed. After re-assays, only three certificates were rejected. Overall, the CRMs performed well and demonstrated the general reliability of assay results from all three laboratories.
The QP responsible for this section of the Technical Report considers the QA/QC program for monitoring accuracy using standards to be reliable and valid based on the results.
![img-22.jpeg](img-22.jpeg)

Figure 11.1 - Performance and distribution of all CRM gold results expressed in Z-score relative to expected value for LaRonde Complex (November 1, 2019 to October 31, 2022)

[[%~%]]
### 11.4.2 Blank Samples

Potential contamination during the preparation stages is monitored by the routine insertion of "blank" samples that follow the same preparation and analytical methods as drill core sample. At the LaRonde Complex during the review of the QA/QC program in 2008, the first action taken was to include a blank sample in every hole logged and sampled. The blank samples are selected by the geologist at the core shack from well-known non-mineralized basaltic or rhyodacitic units from exploration, definition or delineation holes. Blank material from core is also used as a reference material for SG analysis.
The detection limit is $0.03 \mathrm{~g} / \mathrm{t}$ gold for the LaRonde Laboratory and $0.01 \mathrm{~g} / \mathrm{t}$ gold for the ALS and Bourlamaque laboratories. The actual limit for failure with a re-run request is fixed at $0.15 \mathrm{~g} / \mathrm{t}$ gold (i.e., 5x the detection limit of the LaRonde Laboratory). Between 2019 and 2022, a total of 1,914 blanks were submitted and, of those blanks, $98.0 \%$ returned a result below the $0.15 \mathrm{~g} / \mathrm{t}$ gold threshold (Figure 11.2). The majority of the re-run results returned similar values to the original. For the few cases where contamination was suspected, the laboratory was advised and asked toInvestigate. From these results, the QP responsible for this section of the Technical Report considers the results from the blanks to be reliable and demonstrating that very little to no carry over or contamination is present in the assay results for this period.
![img-23.jpeg](img-23.jpeg)

Figure 11.2 - Performance of blanks for gold at LaRonde Complex (November 1, 2019 to October 31, 2022)

[[%~%]]
### 11.4.3 Coarse Duplicates

The LaRonde Complex uses coarse duplicates to address the representativeness of the results. During the drill-core sampling stage, the geologist chooses a sample every 20 samples from which the laboratory must take two different 250-gram fractions from the crushed sample and follow the same process for pulverization and assaying.
A scatter plot showing the repeatability of the coarse duplicates for gold from the LaRonde Complex is presented in Figure 11.3. During the three years ended October 31, 2022, 1,976 coarse duplicates assays were received for the LaRonde Complex. The overall results show a calculated mean grade of $3.72 \mathrm{~g} / \mathrm{t}$ gold compared to the original calculated mean of $3.69 \mathrm{~g} / \mathrm{t}$ gold. The correlation coefficient ( r ) is above 0.98 . Base metals show the same repeatability. The statistical comparisons of the duplicate and original results demonstrate that sample preparation at the crushing stage is acceptable, and no bias is introduced during sample preparation. The precision of analytical methods used by the laboratory is adequate. The nugget effect at the LaRonde Complex is considered to be low.![img-24.jpeg](img-24.jpeg)

Figure 11.3 - Scatter plot of coarse duplicates for gold at LaRonde Complex (November 1, 2019 to October 31, 2022)
![img-25.jpeg](img-25.jpeg)

Figure 11.4 - Scatter plot of check assays (Bourlamaque Laboratories) versus original assays of pulp duplicates for gold at LaRonde Complex (November 1, 2019 to October 31, 2022)

[[%~%]]
### 11.4.4 Check Assays

To assess the accuracy of assays from the primary laboratories, pulp samples from the mineralized zones are collected at a rate of $5 \%$ and sent to a secondary laboratory (Bourlamaque Laboratories) for delineation and definition holes. The percentage increases to a rate of $20 \%$ for exploration and conversion holes with an economic intersection. During the three years ended October 31, 2022, 1,504 pulp duplicates assays were received for the LaRonde Complex. The overall results show a calculated mean grade of $1.14 \mathrm{~g} / \mathrm{t}$ gold compared to the original calculated mean of $1.17 \mathrm{~g} / \mathrm{t}$ gold, with a correlation coefficient of 0.987 (Figure 11.4). A low bias is noticed, particularly for low grade values, but it does not affect the quality of data used in the MRMR. The results from the check assays for the Property support the validity and reliability of the data.

[[%~%]]
## 11.5 Opinion On Adequacy Of Sample Preparation, Security And Assay Procedures

The QP responsible for this section of the Technical Report is of the opinion that the sample preparation, analysis, QA/QC and security procedures, and monitoring methods for the Property follow the industry accepted standards, and that data are of good quality, are reliable and can be used for mineral resource and mineral reserve estimation as described in Sections 14 and 15 of this Technical Report.

[[@~@]]
# 12 Data Verification

This section summarizes the data verification procedures of the diamond drill hole database used for the 2022 MRE at the LaRonde Complex. The Property database comprises two different databases composed of data gathered by Agnico Eagle and by multiple previous owners since 1929. The databases are grouped into two Business Units: LaRonde and Bousquet.

Agnico Eagle uses the Fusion geological data management system by Datamine to manage the drill hole and chip database at the LaRonde Complex. Chip samples are also included in the same Fusion database but are not used for the MRE. Chips are mainly used to refine the final 3D modeling at the stope design step.
The database is stored on Agnico Eagle's server and managed by the dedicated Fusion Support team of the Company's Technical Services group. The Fusion Support team manages all aspects of the database and its access.
All drilling campaigns by Agnico Eagle at the LaRonde Complex during the past 20 years have been logged in Datamine's DHLogger logging software. The process of data verification for the LaRonde Complex has been performed internally by AEM geologists and a second level of verification by DHLogger system that can capture discrepancies based on database pre-compiled structure.

All the databases for the Property include the collar information, downhole survey data, assay results and geological description (lithology, alteration, structure, mineralization, mineralogy, texture, vein and Rock Quality Designation data).
Every two years, the Company employs an external auditor to audit the entire estimation process at the Property. The auditor's reports for the Property have confirmed that the data acquisition, data management, quality control of the information, data archiving and all related protocols respect NI 43-101 requirements. Recommendations and improvements suggested in every audit are addressed and documented by the Geology Department at the LaRonde Complex.

[[%~%]]
## 12.1 Historical Database (Previous Owners)

The Bousquet drill hole database included historical holes drilled by previous owners prior to the acquisition of the Bousquet Complex by Agnico Eagle in 2003. An early step that the Company's Technical Services group took to integrate the historical data was to review the Bousquet database. This process began in 2010 for the LZ5 project data. The review was used to validate the accuracy of approximately 740 holes that were included in the mineral resource estimate for the potential re-exploitation of a Zone 5 open pit. No major problems were found in the data, and corrections were made where original data were available. Minor corrections included: transcription errors from original paper logs to database; transcription errors for collar coordinates and down-hole surveys; and conversion errors from imperial to metric for footage and assay grade.
Another early step was the importation of 4,687 historical holes from the Bousquet and Ellison properties into the Agnico Eagle database from csv files, including a rigorous validation process documented in Hallé (2015). In 2014-15, prior to the Fusion database importation, the Geology Department of LaRonde corroborated a minimum of $10 \%$ of drill holes by comparing electronic data to the original data in original drill logs (i.e., print logs).
The validation process includes checks on:

- Drill hole names/numbers
- Collar coordinates- Downhole surveys
- Assays (critical elements for mineral resource estimation)
- Lithological units and Rock Quality Designation results (when available)

When errors were detected, a check was made to determine the type of error, namely punctual or systematic, and in the case of a systematic errors, the validation process was further extended to include other further drill holes. Corrections were applied to the electronic database. After all corrections, a series of data importations were made from corrected electronic data into the Company's Central Fusion database. Final verifications were made from imported data to check if errors were detected during the importation process.
Minor transcription errors and imperial-to-metric unit conversion errors were found inside and outside the limit of the current mineral resource estimation, and corrections were applied for each group of errors to improve the data validity. Moreover, 3D visualization of mining infrastructure (such as exploration drifts) with drill hole collars confirmed the positioning of underground historical holes.

This process confirmed the reliability of the database within the mineralized areas of the Bousquet site. As there may still have been minor errors or inaccuracies, a resampling campaign was completed on 22 historical drill holes (stored at the Bousquet No. 1 core shack) from the 2010 drilling campaign. Of these, only the re-assaying results were included in the 2022 MRE.
Following a recommendation from an external audit from Pelletier (2019), a validation campaign during 2019 of historical data of Bousquet No. 2 was carried out with the resampling of eight historic holes that intersected the Massive Zone below Level 11-3. (For detailed results, see Pitre (2019)). After a comparison of the historical data with the results (from LaRonde Laboratory) of the resampling campaign, it is the opinion of the QP responsible for this section of the Technical Report that the assessment concluded that the quality of historic data did not compromise the overall quality of the 2022 MRE.
With new access to the Zone 3 area at the LZ5 Mine at the end of 2019, a review of the archived files has shown the absence of 596 drill holes (mostly delineation holes) in the database compared to the original available logs. A compilation by the Geology Department of LaRonde was completed in February 2020, resulting of integration of 596 collar coordinates and drill hole depths, 2,009 down-hole surveys and 16,683 assay samples into the Bousquet database.
Overall, the spatial fit between historical results at the Bousquet property and recent core descriptions, as well as grade distributions, and success of LZ5 reconciliation (see Section 14) over the past three years has been verified and is considered satisfactory by the QP responsible for this section of the Technical Report.

[[%~%]]
## 12.2 Validation Of Current Work

The following items are reviewed by the geologist responsible for all new holes completed before each year-end MRE under the QP's supervision: collar location and general information, downhole surveys, assays and QA/QC results. Once the verification process is completed, each drill hole is identified as verified in the database. At this point, drill holes to be excluded or QP rejected (e.g., QA/QC failures) from the MRE process are identified. The list of excluded holes is revised for each MRE process.
The QP responsible for this section of the Technical Report has reviewed the reports and is of the opinion that the data verification programs undertaken on the data collected from the LaRonde Complex adequately support the geological interpretations, the analytical and database quality,and therefore support the use of the data in Mineral Resource and Mineral Reserve estimation, based on the following:

- Drill hole review (description and photos, collar and downhole surveys, assays, etc.)
- QA/QC review (respecting protocols and procedures)
- Core shack and laboratory site visits
- Spatial validation of the models
- Statistic validations by checks on values in the data table (import errors, special values)

The QP responsible for this section also reviewed and acted on recommendations from the external audit reviews (Pelletier (2019); Carrier (2021)).

[[%~%]]
## 12.3 Conclusion

Continuous and extensive data verification has been undertaken over the life of the LaRonde Complex. It is the opinion of the QP responsible for this section of the Technical Report that the protocols employed for data acquisition and the data validation system are reliable for the Mineral Resource and Mineral Reserve estimates described in Sections 14 and 15 of this Technical Report. Overall, the data verification completed by the QP responsible for this section has demonstrated that data acquisition and protocols at the LaRonde Complex are acceptable.
The QP responsible for this section of the Technical Report is of the opinion that the database is valid and of sufficient quality to be used for the mineral resource and mineral reserve estimations described in Sections 14 and 15 of this Technical Report.

[[@~@]]
# 13 Mineral Processing And Metallurgical Testing

[[%~%]]
## 13.1 Mineral Processing At Laronde Complex

The LaRonde processing plant (formerly named Dumagami) was commissioned in 1988 at a nominal capacity of 2,000 tpd. Initially, the plant consisted of crushing, grinding, gravity, cyanidation and carbon in pulp ("CIP") precious metals recovery circuits followed by an adsorption, desorption and recovery ("ADR") circuit. Successive expansions took place in the early 2000s in order to introduce flotation circuits that allowed for the recovery of base metals such as copper, zinc and lead. In addition, the CIP circuit was replaced by a Merrill-Crowe circuit to compensate for the increase in the silver to gold ratio values varying from 10 to 20 and thus allowing for the optimal recovery of the precious metals.
A first expansion to 3,600 tpd occurred in 2000, followed by an expansion to 5,000 tpd in 2001 and finally to $7,000 \mathrm{tpd}$ in 2002. The gravity circuit was dismantled during this expansion period as the newer ore zones did not contain enough gold recoverable by gravity to economically justify the gravity circuit's use. Maximum peaks above nominal milling capacity were observed over periods of several quarters following the optimization of the various circuits during the years following the expansion in 2002. A technical report for the LaRonde Mine dated March 2005 summarizes the various modifications made to the LaRonde processing plant.
Typical grind size for LaRonde has ranged from 80 to $90 \%$ passing $75 \mu \mathrm{~m}$ during the last two decades.
In 2008, the processing of bulk pyrite \& gold flotation concentrate from the Goldex Mine began. This flotation concentrate is transported from Goldex to LaRonde by tanker truck and is pumped directly into the cyanidation circuit of the LaRonde processing plant for recovery of gold.
The LZ5 processing plant (formerly named Lapa) was initially used to process ore from the Company's Lapa Mine in the region. This plant consisted of crushing, grinding, gravity, cyanidation and CIP gold recovery circuit followed by an ADR circuit. Start-up occurred in early 2008 with Lapa ore at a milling rate of $1,500 \mathrm{tpd}$. Nominal capacity was increased to $1,750 \mathrm{tpd}$ following years of optimization. The Lapa Mine ceased operations in 2018, which allowed for the processing of ore from the LZ5 Mine at the Lapa/LZ5 processing plant since 2019. Nominal capacity for processing LZ5 ore has been optimized to 2,000 tpd.
Typical grind size for Lapa and LZ5 has ranged from 80 to $90 \%$ passing $38 \mu \mathrm{~m}$ during the last decade.
The LaRonde and LZ5 processing plants were collectively renamed the "LaRonde Complex" processing plant in 2019 with the start of the processing of LZ5 ore. This name change reflected the various new synergies of shared services such as maintenance, a centralized control room, and a regional assay laboratory that have allowed for further optimization of operating costs. As a result, nominal capacities of the two processing plants are now regrouped into a global complex capacity of $8,200 \mathrm{tpd}$, allowing ore from zones at either of the LaRonde and LZ5 mines to be treated in one of the two processing plants according to the particularities of the ore treated. For example, an ore containing base metals or precious metals associated with minerals easily recoverable by flotation and difficult to leach by cyanide would be processed at the LaRonde processing plant while an ore containing only precious metals would be processed at the LZ5 processing plant. Figure 13.1 and Figure 13.2 show the locations of the major components of the LaRonde Complex processing plant.
Section 17 summarizes the historical and recent modifications that allow the processing-plant complex to be flexible in the treatment of ores showing very different properties.![img-26.jpeg](img-26.jpeg)

Figure 13.1 - Processing plant at LaRonde Complex, showing locations of major mill components (looking northwest)
![img-27.jpeg](img-27.jpeg)

Figure 13.2 - Processing plant at LaRonde Complex, showing locations of major mill components (looking south)

[[%~%]]
## 13.2 Metallurgical Testwork At Laronde Complex

The following presents the history of the metallurgical testwork that has been carried out on the LaRonde and LZ5 orebodies that will be mined during approximately the next 10 to 14 years. All the metallurgical information provided by the historical and recent testwork programs is relevant to the upcoming LaRonde ore to be processed, as ore sourced from the LaRonde Extension portion of the orebody has been extracted and milled since the end of 2011 from 269 and 293 mining pyramids. Upcoming LZ5 ore is similarly a deeper extension of the historical and currently mined ore. Testwork results are thus considered representative of the LaRonde Complex's current and future production, and the Technical Report is based on the hypothesis that the metallurgical properties of the entire LaRonde, LZ5 and Goldex deposits are comparable to those of the historical production. It is the opinion of the QP responsible for this section of the Technical Report that this composite sample at mineral-reserves level is reliable and representative for metallurgical testwork that is evaluating overall metal recoveries. Based on geological data, the sampling is considered to be feasibility level.
The selection of samples for LaRonde and LZ5 ore was carried out jointly by the Geology and Metallurgy teams of the LaRonde Complex.
In the composite longitudinal section of the LaRonde Complex shown in Figure 13.3, the areas in yellow (open pit), and grey and black (underground) correspond to sectors that have been mined out while the orange areas correspond to the mineral reserves horizons to be mined and processed in the life of mine over the next decade. Sectors in blue illustrate mineral resources that are not currently in the mining plan and whose potential to be transferred to mineral reserves remains to be determined. The locations of samples taken for metallurgical testing are illustrated by areas circled in red.
![img-28.jpeg](img-28.jpeg)

Figure 13.3 - Composite longitudinal section of LaRonde Complex (looking north) showing sampling locations for metallurgical testworkComminution and recovery characterization testwork by flotation and cyanidation was carried out at the site's metallurgy laboratory by experienced engineers and technicians according to protocols that have been developed and used successfully at LaRonde for almost 20 years. Particular attention was paid to deleterious elements in flotation concentrates to validate potential penalties in smelter contracts. Chemical analyses by induced coupled plasma optical emission spectrometer ("ICP-OES") on 52 elements were carried out on all flotation concentrates.

[[%~%]]
### 13.2.1 Laronde Metallurgical Testwork

Precious and base metals recoveries are presented in this subsection using both mathematical models developed during years of production at LaRonde, and historical datasets. Values for modelled recoveries are compared with the actual values obtained in a time series format to illustrate their agreement. Recoveries obtained during recent testwork were also compared to the various models and they show similar behaviour. (An analogous approach was adopted for reagents consumption and a summary of all unit consumption is presented in Section 17.)
The series of LaRonde metallurgical testwork is listed below and the metallurgical-test sampling locations are shown in Table 13.1:

- LaRonde East mine zone: LR-2016-LM2, LR-2020-LM1 and LR-2015-LM1
- LaRonde West mine zone: LR-2015-LM2, LR-2016-LM1, LR-2017-LM1, LR-2017-LM2 and LR-2017-LM3
- Zone 11-3: LR-2019-LM1, LP1-2022-LM2

Variability testwork was used to validate that the ore can be processed through the mill without major modification. A test plan is in place to replicate parts of the mill and the targets to achieve. For example, the necessary time to achieve the P80 is calculated at $75 \mu \mathrm{~m}$ for each metallurgical lot. It gave initial results about the degree of difficulty to grind the material and whether more testing is needed to further refine understanding of the grindability of the ore. In flotation, copper and precious metal recoveries are important at that step to ensure good global metal precious recoveries in the mill. Lead was also analyzed and followed to ensure it remains a minor element in the process. In leaching, the residence times are reproduced to synchronize with the mill. Additional testwork was completed to evaluate the impacts of grind size, leaching time, reagent dosage and other parameters in order to assess mill improvements as well as any future potential optimization. Also, master composite testworks are created based on mining sequences to validate the synergy between them.

Table 13.1 - Metallurgical test results for gold, silver, copper and zinc at LaRonde Complex

| Metallurgical <br> lot | Gold <br> feed <br> grade <br> $(\mathrm{g} / \mathrm{t})$ | Silver <br> feed <br> grade <br> $(\mathrm{g} / \mathrm{t})$ | Copper <br> feed <br> grade <br> $(\%)$ | Zinc <br> feed <br> grade <br> $(\%)$ | Gold <br> recovery <br> in <br> copper <br> flotation <br> $(\%)$ | Copper <br> recovery <br> $(\%)$ | Zinc <br> recovery <br> $(\%)$ | Global <br> gold <br> recovery <br> $(\%)$ | Global <br> silver <br> recovery <br> $(\%)$ |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| LR-2016-LM2 | 5.51 | 7.9 | 0.42 | 0.08 | 75.11 | 95.49 | - | 94.00 | - |
| LR-2020-LM1 | 1.05 | 80.6 | 0.48 | 12.70 | 80.27 | 85.75 | 98.96 | 89.98 | - |
| LR-2015-LM1 | 6.52 | 12.1 | 0.26 | 0.03 | 77.87 | 92.82 | - | 96.39 | 80.47 |
| LR-2015-LM2 | 6.25 | 3.3 | 0.03 | 0.02 | - | - | - | 89.83 | 71.25 || Metallurgical <br> lot | Gold <br> feed <br> grade <br> (g/t) | Silver <br> feed <br> grade <br> (g/t) | Copper <br> feed <br> grade <br> (\%) | Zinc <br> feed <br> grade <br> (\%) | Gold <br> recovery <br> in <br> copper <br> flotation <br> (\%) | Copper <br> recovery <br> (\%) | Zinc <br> recovery <br> (\%) | Global <br> gold <br> recovery <br> (\%) | Global <br> silver <br> recovery <br> (\%) |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| LR-2016-LM1 | 4.76 | 36.4 | 0.48 | 5.05 | 63.82 | 71.81 | 94.58 | 96.15 | 95.92 |
| LR-2017-LM1 | 5.70 | 46.2 | 0.39 | 3.98 | 86.89 | 88.07 | 83.14 | 96.62 | 96.73 |
| LR-2017-LM2 | 15.80 | 20.1 | 0.36 | 0.20 | 65.80 | 91.61 | - | 93.41 | - |
| LR-2017-LM3 | 9.44 | 32.3 | 0.61 | 0.75 | 67.22 | 88.94 | 57.45 | 94.52 | 94.92 |
| LR-2019-LM1 | 3.47 | 8.6 | 0.10 | 0.08 | 68.43 | 72.47 | - | 89.66 | - |
| LP1-2022-LM2 | 7.21 | 16.3 | 0.11 | 0.24 | 71.19 | 49.79 | 84.92 | 94.81 | 91.43 |
| BZ-2020-LM1 | 2.82 | 1.3 | 0.02 | - | 72.98 | 60.44 | - | 90.44 | - |
| BZ-2020-LM2 | 1.52 | 5.5 | 0.15 | 0.21 | 81.66 | 90.68 | 77.25 | 96.28 | 82.87 |
| BZ-2016-LM15 | 1.59 | 1.2 | 0.04 | - | 87.21 | - | - | 94.31 | - |
| Minimum | - | - | - | - | 64 | 50 | 57 | 90 | 71 |
| Maximum | - | - | - | - | 87 | 95 | 99 | 97 | 97 |
| Average | - | - | - | - | $\mathbf{7 4 . 9}$ | $\mathbf{8 0 . 7}$ | $\mathbf{8 2 . 7}$ | $\mathbf{9 3 . 6}$ | $\mathbf{8 7 . 7}$ |

Deleterious elements (e.g., arsenic, bismuth, antimony, etc.) in metallurgical lots are followed by ICP scan. Results are analyzed to ensure they are within the smelter contract range for the LaRonde Complex.
Goldex gold-pyrite concentrate ("TCGO") is added to the LaRonde leaching circuit to recover the gold, thereby allowing the Goldex mill to avoid using a cyanide circuit. The TCGO performance is followed by laboratory leaching tests one to two times per week. This performance model for one month is based on the previous monthly results, and it is key operator information for the circuit that follows. Teams from Goldex completed their own testwork on new ore zones at Goldex to validate the feasibility through the entire process. They follow parts of the LaRonde test procedure to validate the leaching process and the associated gold recovery for Goldex ore.
LZ5 ore entering the LaRonde mill is included in the mill model performance. LZ5 and LaRonde ores have the same metal performance, and the payable metal distribution is based on the material feeding the mill (tonnes and grade). Metallurgical lots of LZ5 are tested with LaRonde metallurgical lots to validate the synergy between the two sets of ores.
The LaRonde mill follow-up mainly consists of circuit performance validation. Laboratory flotation (on a monthly basis) and leaching tests (on a weekly basis) were completed to compare with the mill results. A sampling campaign throughout the mill to validate equipment performance was completed. Calibration validation on online and inline probes was performed to ensure the system is performing optimally.
Ore sourced from the LaRonde Extension portion of the orebody has been extracted and milled since the end of 2011 (from 269 and 293 mining pyramids). This ore is representative of the LaRonde Mine's current and future production. LaRonde ore contains gold, silver, copper and zinc as payable metal. The main deleterious elements have been arsenic, bismuth and antimony that would mostly be recovered in the copper concentrate. Deleterious elements were sampled biweekly at different points in the mill to follow deleterious distribution in each circuit.

[[%~%]]
### 13.2.2 Laronde And Lz5 Cyanide Destruction Testwork

Additional testwork was completed on cyanide destruction of tailing with the $\mathrm{INCO} \mathrm{SO}_{2} / \mathrm{O}_{2}$ process to validate the impacts of LZ5 ore on residence time and reagent dosage. The tests were done on three sets of ores: LaRonde, LZ5 and a mix of LaRonde and LZ5. Currently, LaRonde cyanide destruction is a function of a different mix of LaRonde/LZ5 ore. An additional tank is under construction to destroy the cyanide coming from LZ5 plant (because of residence time), and tests show that the addition of copper sulphate will not be required to obtain the target results. The reagent dosage for LZ5 ore was the same as for LaRonde ore.
The following testwork was performed for the cyanide destruction process:

- $\mathrm{SO}_{2} / \mathrm{O}_{2}: 1114-\mathrm{E}-132-002-\mathrm{TCR}-001$ M0301 - Testwork Report LaRonde Agnico Eagle
- $\mathrm{SO}_{2} / \mathrm{O}_{2}: 1114-\mathrm{E}-132-002-\mathrm{REP}-002 \_R 0$


[[%~%]]
### 13.2.3 Laronde And Lz5 Dewatering Testwork

In 2018, trade-off studies were completed to determine the future of tailing deposition including a comparison between traditional deposition by slurry, spigot, paste and dry stack. Each option was evaluated based on OPEX, CAPEX and closure cost, and a risk analysis was completed for each solution. Following the evaluation process, dry stack was selected as the best method for future tailing deposition at the LaRonde Complex.
Further tests were then completed to design the dry stack deposit at the LaRonde Complex site at a higher elevation. To determine the required equipment, the testwork was separated into two processes: thickening and filtration (filter press).
The testwork relating to the tailing thickening process included:

- 1114-E-132-004-REP-001 Test Work Report Thickener RevA
- Agnico Eagle Tailing Thickener Testwork Tech memo-R1 Outotec

The filter press was chosen based on testing and Agnico Eagle's experience operating mills at Meliadine in Nunavut and Pinos Altos in Mexico. At the LaRonde Complex processing plant, three filter presses will be installed to ensure operation to 10,000 tpd.
The testwork relating to tailing filtration (filter press) included:

- 1114-E-132-004-REP-001 Test Work Report RevB
- 1114-E-132-004-TCR-005 test de filtration CTRI


[[%~%]]
### 13.2.4 Lz5 Metallurgical Testwork

The gold performance model was based on the previous year's daily performance and included gold solid and liquid tailing. Laboratory leaching tests and sampling throughout the mill consisted of monthly following. With the LZ5 Mine being at the beginning of its life, whenever a new ore zone is discovered, the Geology team will construct composites from the new ore zone for metallurgical testing.

[[%~%]]
#### 13.2.4.1 Metallurgical Testing Of Lz5 Ore In 2020

With respect to sample selection, the composites used for testwork in 2020 at LZ5 Mine were:

- BZ-2020-LM1 (LZ5 zone 3HW)
- BZ-2020-LM2 (LZ5 zone 2)
- BZ-2016-LM15 (east and west zone 3)

Master composite metallurgical testwork results for the LZ5 Mine are listed in Table 13.2.

Table 13.2 - Metallurgical test results for gold, silver, copper and zinc at LZ5 Mine

| Metallurgical <br> lot | Gold <br> feed <br> grade <br> (g/t) | Silver <br> feed <br> grade <br> (g/t) | Copper <br> feed <br> grade <br> (\%) | Zinc <br> feed <br> grade <br> (\%) | Gold <br> recovery <br> in copper <br> flotation <br> (\%) | Copper <br> recovery <br> (\%) | Zinc <br> recovery <br> (\%) | Global <br> gold <br> recovery <br> (\%) | Global <br> silver <br> recovery <br> (\%) |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| BZ-2020-LM1 | 2.82 | 1.3 | 0.02 | - | 72.98 | 60.44 | - | 90.44 | - |
| BZ-2020-LM2 | 1.52 | 5.5 | 0.15 | 0.21 | 81.66 | 90.68 | 77.25 | 96.28 | 82.87 |
| BZ-2016-LM15 | 1.59 | 1.2 | 0.04 | - | 87.21 | - | - | 94.31 | - |
| Minimum | - | - | - | - | - | - | - | 90.44 | - |
| Average | - | - | - | - | - | - | - | $\mathbf{9 3 . 6 8}$ | - |

[[%~%]]
## 13.3 Mills Metals Recoveries

The models for metals recoveries are created based on data from the previous year.

[[%~%]]
### 13.3.1 Laronde Mill

Modelled 2023 and actual recovery rates for gold, silver and copper in copper concentrate at the LaRonde mill for 2021-22 are shown in Figure 13.4, Figure 13.5 and Figure 13.6, respectively. Modelled 2023 and actual recovery rates for zinc and gold in zinc concentrate at the LaRonde mill for 2021-22 are shown in Figure 13.7 and Figure 13.8, respectively.![img-29.jpeg](img-29.jpeg)

Figure 13.4 - Gold recovery rates in copper concentrate at LaRonde mill
![img-30.jpeg](img-30.jpeg)

Figure 13.5 - Silver recovery rates in copper concentrate at LaRonde mill![img-31.jpeg](img-31.jpeg)

Figure 13.6 - Copper recovery rates in copper concentrate at LaRonde mill
![img-32.jpeg](img-32.jpeg)

Figure 13.7 - Zinc recovery rates in zinc concentrate at LaRonde mill![img-33.jpeg](img-33.jpeg)

Figure 13.8 - Gold recovery rates in zinc concentrate at LaRonde mill

[[%~%]]
### 13.3.2 Leaching And Cip

Examples of gold reject in the precious metals circuit on a monthly basis in recent years are shown in Figure 13.9.

Examples of silver and liquid silver reject in the precious metals circuit on a monthly basis in recent years are shown in Figure 13.10 and Figure 13.11, respectively.![img-34.jpeg](img-34.jpeg)

Figure 13.9 - Gold reject in precious metals circuit (monthly)
![img-35.jpeg](img-35.jpeg)

Figure 13.10 - Silver reject in precious metals circuit (monthly)![img-36.jpeg](img-36.jpeg)

Figure 13.11 - Liquid silver reject in precious metals circuit (monthly)

[[%~%]]
### 13.3.3 Goldex Pyrite/Gold Concentrate (Tcgo) In Laronde Mill

Based on laboratory testwork during the previous month for the Goldex pyrite/gold concentrate (TCGO) in the LaRonde mill, a model is determined and sent to the Goldex Mine. An example of using monthly data to build a monthly model for TCGO is shown in Figure 13.12.
![img-37.jpeg](img-37.jpeg)

Figure 13.12 - TCGO, gold reject versus gold feed grade at LaRonde mill

[[%~%]]
### 13.3.4 Lz5 Ore In Laronde Mill

For LZ5 ore processed in the LaRonde mill, the models applied were the same as for LaRonde ore processed in the LaRonde mill. The metals distribution for LZ5 ore was applied in a similar fashion as the metals distribution for LaRonde ore.

[[%~%]]
### 13.3.5 Lz5 Mill

The gold liquid tailing model is fixed at $0.012 \mathrm{~g} / \mathrm{t}$. Modelled 2023 and actual recovery rates for gold at the LZ5 mill for 2021-22 is shown in Figure 13.13.
![img-38.jpeg](img-38.jpeg)

Figure 13.13 - Gold recovery rates at LZ5 mill

[[@~@]]
# 14 Mineral Resource Estimates

The 2022 Mineral Resource Estimate (the "2022 MRE") for the Property consists of 9 block models ("BMs") covering the following deposits:

- LaRonde deposits (5 BMs, underground)
- LZ5 deposits (4 BMs, underground)

The LaRonde and LZ5 deposits were modelled and estimated for the purpose of underground mining and this report refers to these deposits as "underground mines".
The 2022 MRE was prepared by David Pitre, P.Eng., P.Geo., an employee of Agnico Eagle, using all available information. These estimates use information acquired during Agnico Eagle's drilling programs and validated historical data. They also use accumulated data from previous annual production, milling, reconciliation and MRMR reports.
The effective date of the 2022 MRE is December 31, 2022. The effective date is the date of closure for depletion of voids and stockpile status report.

[[%~%]]
## 14.1 Methodology

The 2022 MRE models were mainly prepared and updated using Datamine Studio RM v.1.9.36 ("Datamine") by LaRonde Division staff, and Leapfrog GEO ("Leapfrog") by AEM Technical Services staff (for LP1 zones; Zones 3-1 and 3-4). Both Datamine and Leapfrog were used for the geological modelling of the underground projects. Datamine was used for resource estimation for all projects, which consisted of 3D block modelling and inverse power distance squared ("ID2") interpolation. Ordinary kriging ("OK") and Nearest Neighbour interpolation were also used for validation purposes. Statistical studies, capping, and variography were completed using Sage 2001 software and/or Snowden Supervisor (v.8.13.1.2 and earlier versions). Validations were carried out in Datamine and/or Deswik. Mineral Resources were reported within optimized mineable shapes constructed with Datamine or Deswik v.2022.2.623 (SO 4.1.3566) software.
The main steps in the estimation methodology were as follows:

1. Compile and validate the diamond drill hole databases.
2. Update the geological model, the mineralized zones interpretation and the voids model.
3. Generate the drill hole intercepts and composites for each mineralized zone.
4. Perform basic statistics (capping).
5. Perform geostatistical analysis and variography.
6. Interpolate grade within the block models.
7. Validate the block models.
8. Establish mineral resource classification criteria.
9. Assess the mineral resources with the "reasonable prospects for eventual economic extraction", select appropriate cut-off grades and constraint volumes of optimal mineable shapes (using a Shape Optimizer algorithm).
10. As required, model depletion and pillar exclusion.
11. Generate a Mineral Resource Estimate.

[[%~%]]
## 14.2 Drill Hole Database

The 2022 MRE used one central SQL database (Datamine Fusion V.9.5.7.3) covering all Agnico Eagle properties and managed by AEM Fusion Support Group. The drill holes and chip samples for resource estimation were extracted from the Company's Datamine Fusion database and have a cut-off date of October 31, 2022. Chip samples were used for geological modelling but not for interpolation. Drillholes are from 1929 to 2022. Company drill hole and historical drill holes are shown in Figure 10.1, which is a longitudinal view of the LaRonde Complex property with all the drill holes used for the 2022 MRE. Only validated historical drill holes retained by the QP were used for interpolation (see Section 12).

Table 14.1 summarizes the contents and close-out date of each drill hole database.

Table 14.1 - Drill hole database summary by deposit

| Deposit / Business <br> Unit Database | No. of <br> holes | Length <br> (m) | No. of <br> samples | Average <br> sample <br> length <br> (m) | No. of new <br> holes since <br> last EOY <br> MRMR | Close-out <br> date |
| :-- | --: | --: | --: | --: | --: | :--: |
| LaRonde | 8,509 | $1,421,380$ | 269,522 | 1.21 | 164 | Oct. 31, 2022 |
| Bousquet | 6,694 | 782,578 | 353,345 | 1.27 | 105 | Oct. 31, 2022 |
| Total LaRonde Complex | $\mathbf{1 5 , 2 0 3}$ | $\mathbf{2 , 2 0 3 , 9 5 8}$ | $\mathbf{6 2 2 , 8 6 7}$ | $\mathbf{1 . 2 4}$ | $\mathbf{2 6 9}$ | Oct. 31, 2022 |

[[%~%]]
### 14.2.1 Qp Specific Validations In 2022

Estimations are based on diamond drillhole information up to October 31, 2022. The QP completed a database validation and the following minor inconsistencies were identified and/or corrected:

- Some of the 2022 diamond drillhole collars were not surveyed at the time of the closure of the database. Instead, the planned collar location and direction were used to locate the drill holes on an ongoing drilling section. The distances between real collars and planned collars are negligible.
- There are mineralized intervals located outside of the wireframe due downhole survey errors or inaccuracy. These samples were translated into the wireframe. The translations for each hole are documented and affect only some longer exploration holes.
- Some of the longest exploration holes (mainly from exploration drift 215 and shaft stations 170, 194 and 206) with low intersection angles were excluded after definition drilling with better intersection angles. A detailed list of the holes that have been excluded for estimates is compiled.
- Block models in LaRonde I (i.e., above level 245) for zones 7, 20 North and 20 South were not updated for the current MRE as there had been no new drilling and these areas are not part of the current mining plan. No mineral resources are reported in these areas.

[[%~%]]
## 14.3 Geological Models

The broad geological model for the LaRonde Complex was created using exploration, conversion, definition and delineation drill logs (see Section 10). Economic zones are spatially associated with a series of mineralized lenses along specific horizons, showing all the same east-west trend and steeply dipping towards the south, parallel to the regional stratigraphy.
Individual models were prepared and updated for each zone, horizon or group of associated zones. Wireframes for each zone are modelled as hard boundaries with commonly sharp contacts between barren footwalls and hanging walls, and subeconomic to economic sulphide horizons (lenses). Both explicit and implicit modelling are used for the 2022 MRE. Implicit modelling (or vein modeling) to build wireframes is currently the most common method with the Datamine or Leapfrog software. Explicit modelling with strings and wireframes is still used for some zones that have not been updated or reworked in recent years. The near-surface area is constrained by topographic and overburden surfaces.
Each deposit was divided into mineralized zones that follow the general orientation of the mineralization. The mineralized zones consist of 43 solids: 19 solids for LaRonde and 24 solids for LZ5 (Figure 14.1). Zone limits are based mainly on the presence of sulphide (more than 5\% pyrite) and gold/base metals grades. These mineralized zones are used as resource domains for further statistical analysis, block modelling and grade interpolation. Some of these zones are combined while others are subdivided prior to serving as resource domains. Some mineralized zones have no new drilling or mining activity and were consequently not updated in recent years.
For all zones, the minimum thickness ranges from 2.8 to 3.0 m , depending on the deposit. For the LaRonde deposit, the majority of the lenses are polymetallic. High grade zones are defined using a guideline based on the Net Smelter Return ("NSR" in \$) value. The minimum cut-off grade guideline for modelling ranges from $\$ 50$ to $\$ 90$ NSR which represents a significant concentration of gold, silver, chalcopyrite (containing copper) and/or sphalerite (containing zinc). For the LZ5 deposit, high grade sulphide zones (or domains) are generally defined using a minimum cut-off grade around $1.0 \mathrm{~g} / \mathrm{t}$ gold as a guideline for modelling, which corresponds to a $5 \%$ pyrite content.
For all zones at the LaRonde Complex, the minimum thickness ranges from 2.8 to 3.0 m , depending on the deposit. In some cases where the lateral contact of the mineralized horizon is sharp, the solids were limited to 25 to 50 m beyond the last hole, which represents approximately half the drilling spacing. However, some lenses extend laterally over several hundreds of metres and solids are consequently extended on those horizons.
The topographical surface was generated using data from the survey of the site combined with the collar survey data. The overburden/bedrock surfaces were generated from overburden intervals (i.e., casing lengths) recorded in drill logs.

[[%~%]]
## 14.4 Voids Model

The voids model represents historical and current underground workings on the Property (i.e., combined stopes, drifts, caving areas and shafts). All new drifts and newly mined stopes are surveyed in 3D by the survey crew of the Engineering Department. The voids model is used to deplete the mineral resource model to account for the historical and current workings.
The underground project voids model used for the LZ5 deposit was created from historical plans and sections of Bousquet no. 1 mine. The voids model shows a good match with historical plans and drill hole location data and has been locally validated with recent holes or intersection with the old and new drifts. Figure 14.1 presents an isometric view with voids model for the LaRonde Complex.![img-39.jpeg](img-39.jpeg)

Figure 14.1 - Mineralized and void solids for the deposits on the Property

[[%~%]]
## 14.5 High-Grade Capping

All assayed drill hole intervals that intersected the interpreted mineralized zones were coded in the database. Basic univariate statistics on gold and base metals values were used to perform geostatistical analysis.
High-grade capping for gold analysis (and for silver analysis when silver is present) was performed on all resource domains. High-grade capping analysis for copper and zinc and mill reconciliation reports demonstrated that capping was not necessary. High-grade capping values ( $\mathrm{Au}, \mathrm{Ag}$ ) were selected for the majority of the domains based on the effect of high-grade values on the mean and standard deviation, along with the results of probability and histogram plots. High-grade capping is always applied on original assays.
The high-grade capping is based on several criteria that are well established in the gold mining industry (see examples in Figure 14.2 and Table 14.2):

- The reconciliation between of the block model and reconciled production at the mill
- The coefficient of variation ("CV") should preferably not be higher than 2.0 after capping
- The top $1 \%$ of the population ( 99 th percentile) should not represent more than $10 \%$ of the metal content
- If observable, the upper break of the curve in the log probability plotFigure 14.2 shows an example of a log probability plot for the west area of the Zone 20 North domain, and the selected grade capping on the curve.
![img-40.jpeg](img-40.jpeg)

Figure 14.2 - An example of grade capping treatment based on log probability curve, Domain 19W

Table 14.2 - An example of capping treatment on Zone 20 North block model area based on CV criteria

| Zone | Domain | Capping grade Au g/t | Maximum <br> Au g/t | Uncapped mean Au g/t | Capped mean Au g/t | Nb <br> assays <br> total | Nb <br> assays <br> capped | CV <br> before <br> capping | $\begin{gathered} \text { Assays } \\ \% \\ \text { affected } \end{gathered}$ | Metal reduction \% |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| 20N Gold North | 17 | 200 | 1,431.6 | 3.77 | 3.29 | 3,107 | 8 | 6.87 | 3.08 | $0.3 \%$ | $-13 \%$ |
| 20N Gold | 19 | 200 | 1,338.1 | 5.29 | 5.03 | 15,296 | 20 | 3.53 | 1.79 | $0.1 \%$ | $-5 \%$ |
| 20N Zinc South | 20 | 30 | 268.3 | 1.64 | 1.07 | 888 | 7 | 7.40 | 2.92 | $0.8 \%$ | $-35 \%$ |
| 20N Gold (West mine) | 190 | 200 | 2,220.0 | 7.68 | 6.70 | 3,971 | 16 | 5.49 | 2.26 | $0.4 \%$ | $-13 \%$ |
| 20N lens | 900 | 30 | 256.8 | 0.89 | 0.86 | 29,487 | 31 | 3.12 | 1.96 | $0.1 \%$ | $-3 \%$ |
| LG | $\begin{gathered} 901- \\ 902 \end{gathered}$ | 5 | 53.1 | 0.28 | 0.26 | 5,311 | 46 | 3.58 | 2.41 | $0.9 \%$ | $-7 \%$ |Table 14.3 presents the variation of the high-grade capping values by deposit, along with the number of domains effectively containing mineral resources per deposit or area.

Table 14.3 - Summary of capping grades for drill hole samples by zone or domain

| Domain type | Mineral deposit | Shaft or property | Block Model horizon (BM, underground) | Zone or Domain | High-grade gold capping values (g/t) | High-grade silver capping values (g/t) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| High grade domains (HG) | LaRonde | LaRonde | Zone 6 | Zone 6 | 30 | 1,000 |
|  |  |  | Zone 7 | Zone 7 | 69 | 857 |
|  |  |  | Zone 20 North | 19 N | 200 | 100 |
|  |  |  |  | 19, 19W | 200 | 1,000 |
|  |  |  |  | 20 | 30 | 1,000 |
|  |  |  | Zone 20 South | 21 | 20 | 225 |
|  |  |  | Zone 22 | Zone 22 | 34 | 200 |
|  |  | LP1 | Dumagami | Various | 30 to 50 | 200 |
|  |  |  |  | Zone 7 | 10 | 100 |
|  |  |  | Fringe | Various | 30 to 50 | 100 to 200 |
|  |  |  | Massive Zone (11-3) | Massive FW \& HW <br> (MF, MH) | 50 | 150 |
|  |  |  |  | Massive intermediate (MI) | 50 | 100 |
|  | LZ5 | Bousquet \& Ellison | Zone 5 | Zone 4, 41, 5, 51 | 20 | n/a |
|  |  |  | Zone 3 | Zone 1, 3FW, 3HW | 35 | n/a |
|  |  |  |  | Zone 2 | 20 | n/a |
|  |  |  | Zone 3-1 | Various | 30 to 50 | 200 |
|  |  |  | Zone 3-4 | Zone 3-4 | 30 | 100 |
| Low grade domains (LG) | LaRonde | LaRonde | Zone 6 | Zone 6 LG | 5 | 1,000 |
|  |  |  | Zone 7 | Zone 7 | 69 | 857 |
|  |  |  | Zone 20 North LG | 900 | 30 | 1,000 |
|  |  |  | Zone 20 North Waste | 901, 902 | 5 | 200 |
|  |  |  | Zone 20 South | 21 | 20 | 225 |
|  |  | LP1 | Dumagami | LG | 10 | 100 |
|  |  |  | Fringe | LG | 10 | 100 |
|  |  |  | Massive (11-3) | LG | 10 | 50 |
|  | LZ5 | Bousquet \& Ellison | Zone 5 | LG | 5 | n/a |
|  |  |  | Zone 3 | LG | 5 | n/a |
|  |  |  | Zone 3-1 | LG | 10 | 100 |
|  |  |  | Zone 3-4 | LG | 10 | 50 |

[[%~%]]
## 14.6 Compositing

Sample compositing was used to ensure uniform sample support for geostatistical analysis and grade interpolation. Codes were applied to the drill hole database for each interpreted zone/domain before compositing. The compositing length selected is the nominal (or most frequent) sampling length.The length of composite samples is 1.5 m for all zones, which is approximately equivalent to the average sampling length (Figure 14.3). The composite length in the ore zone was set at 1.5 m but allowed to vary from the specified length to distribute the tail length over the entire intercept. The minimum length is 0.5 m and maximum length is 2.2 m . The composite length outside ore zone was set at 1.0 m or 1.5 m depending on the thickness of the footwall or hanging wall modelling.
![img-41.jpeg](img-41.jpeg)

Figure 14.3 - Example of a sample length frequency histogram showing a majority of sample lengths at 1.5 m for Zone 5

Sample grades below the detection limit (e.g., $0.03 \mathrm{~g} / \mathrm{t}$ gold) were given a value of half of the detection limit (e.g., $0.015 \mathrm{~g} / \mathrm{t}$ gold) prior to compositing, during the importation process in the central Fusion database. Because there is good visual control of the mineralization, non-assayed samples were given a value of $0.0 \mathrm{~g} / \mathrm{t}$ gold prior to compositing. Drill core recovery approaches $100 \%$, so non-recovered core intervals were given a value of $0.0 \mathrm{~g} / \mathrm{t}$ gold prior to compositing. The potential risk to underestimate is considered negligible by the QP.
The composites were validated by using a statistical analysis of the composites versus the raw dataset.

[[%~%]]
## 14.7 Specific Gravity (Sg) And Density Data

For the LaRonde deposit, due to the important variation in the sulphide contents between ore zones, systematic SG measurements are performed on core samples using standard water immersion method (weight in water / in air) in the primary labs (ALS Chemex for exploration / conversion and LaRonde Regional Laboratory for delineation). On occasion, SG measurements were also determined by the pycnometer method on pulps. It is the QP's opinion that SG measurements are appropriate and a good estimation of the density for the MRE purpose, since there are no voids/porosity in the rock. SG/Density is estimated along with all metals in the block models.

Validation of historical SG values (Pitre 2019) in the 11-3 Project has outlined some high values exceeding 5.0 in near-100\% pyrite samples. The main recommendation to have a capping of 5.0 to all historical SG values has been applied. For the LP1 area, the Technical Services team, incollaboration with the QP, has selected fixed density values based on previous reports (Bédard 2005) and validation with available data.

For the LZ5 deposit, statistical validation has been calculated for SG data from historical drill holes when available and from recent drill holes, to fix an average density value for ore and another average value for waste. This simplification of density values is a result of the homogeneous mineralization style (5-20\% sulphide zone within volcanic rocks) giving an average density value of $2.9 \mathrm{~g} / \mathrm{cm}^{3}$ for ore and dilution, and $2.82 \mathrm{~g} / \mathrm{cm}^{3}$ for waste. These values are similar to those assigned in previous mineral resources and mineral reserves reports for Bousquet (e.g., (Bédard 2005)).

The internal 2022 reconciliation reports and previous reports show a very good concordance (difference less $\pm 2 \%$ ) between mill production tonnage and estimated tonnage from geological models. The actual density value of $2.9 \mathrm{~g} / \mathrm{cm}^{3}$ for LZ5 ore is considered to be highly reliable, while SG measurements to estimate the bulk density for LaRonde are also considered to be adequate. Table 14.4 presents the summary of the density by zone or domains.
![img-42.jpeg](img-42.jpeg)

Figure 14.4 - Example of histogram for measured SG for samples of LZ5 inside the resource (MSO) envelope, argument to fix density at $2.9 \mathrm{~g} / \mathrm{cm}^{3}$Table 14.4 - Summary of densities by zone or domain

| Domain type | Mineral deposit | Shaft or property | Block Model horizon (BM, underground) | Zone or domain | Density $\left(\mathrm{g} / \mathrm{cm}^{3}\right)$ | Specific conditions |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| High grade domains (HG) | LaRonde | LaRonde | Zone 6 | Zone 6 | Assayed \& interpolated |  |
|  |  |  | Zone 7 | Zone 7 |  |  |
|  |  |  | Zone 20 North | 19 N |  |  |
|  |  |  |  | 19 |  |  |
|  |  |  |  | 19W |  |  |
|  |  |  |  | 20 |  |  |
|  |  |  | Zone 20 South | 21 |  |  |
|  |  |  | Zone 22 | Zone 22 |  |  |
|  |  | LP1 | Dumagami | Various | 2.9 to 3.5 | Variable, based on domain |
|  |  |  |  | Zone 7 | 2.9 |  |
|  |  |  | Fringe | Various | 3.2 to 4.3 | Variable, based on domain |
|  |  |  | Massive Zone (11-3) | Massive (FW, I \& HW) | Assayed \& interpolated | Capping at 5.0 $\mathrm{g} / \mathrm{cm}^{3}$ |
|  | LZ5 | Bousquet \& Ellison | Zone 5 | Zone 4, 41, 5 \& 51 | 2.9 |  |
|  |  |  | Zone 3 | Zone 1, 2, 3FW \& 3 HW | 2.9 |  |
|  |  |  | Zone 3-1 | Various | 3.2 |  |
|  |  |  | Zone 3-4 | Zone 3-4 | 3.0 to 3.2 |  |
| Low grade domains (LG) | LaRonde | LaRonde | All Horizons | All Zones | Assayed \& interpolated |  |
|  |  | LP1 | Dumagami \& Fringe | LG | 2.8 to 3.0 | Variable, based on domain |
|  |  |  | Massive Zone (11-3) | LG | Assayed \& interpolated |  |
|  | LZ5 | Bousquet \& Ellison | Zone 5 \& Zone 3 | LG | 2.9 |  |
|  |  |  | Zone 3-1, <br> Zone 3-4 | LG | 2.8 to 3.0 | Variable, based on domain |

[[%~%]]
## 14.8 Variography And Search Ellipsoids

The mineral resource estimates for the LaRonde Complex BMs rely on several geostatistical reports written by different authors between 2010 and 2022. The variography from previous authors was reviewed and reused when considered appropriated by the QP. Table 14.5 lists the geostatistical reports that contributed to the 2022 MRE.
For the BMs of the LaRonde and LZ5 deposits, the 3D variography was carried out on capped composites in Snowden Supervisor 8.12.0.1 or previous versions when performed by Agnico Eagle personnel, or Sages 2001 by D'Amours (2010).Table 14.5 - List of geostatistical reports for the Property

| Deposit | Zone or area | Focus of report | Geostatistical report (author, year) | Author affiliation |
| :--: | :--: | :--: | :--: | :--: |
| LaRonde | Zone 20 North | 20 North, LaRonde Extension | Pitre and Bastien (2022) | LaRonde Division |
|  |  | 20 North, LaRonde Extension | Patry (2018); <br> Patry (2015) | AEM Technical Services |
|  |  | 6, 7, 20 North, 20 South, above Level 245 | D'Amours (2012) | Consultant: <br> GéoPointCom |
|  | LP1 (Dumagami and Fringe area) | Fringe, 4D and 7 | Lacoursière (2021) | AEM Technical Services |
|  | LP1 (Massive Zone -11-3 area) | Massive FW \& HW | Lacoursière (2017) | AEM Technical Services |
| LZ5 | Zone 5 Area | $4,41,5,51$ | Belzile (2011b) | Consultant: Belzile Solutions Inc. |
|  |  |  | D'Amours (2010) | Consultant: <br> GéoPointcom |
|  | Zone 3-1 and Zone 3-4 | Zone 3-1 and Zone 3-4 | Lacoursière (2021) | AEM Technical Services |
|  | Zone 3 Area | 1, 2, 3FW, 3HW | Pitre (2020a) | LaRonde Division |

Due to the major regional deformation, all orebodies of the LaRonde Complex have a similar tabular shape and show a subvertical east-west trend, a dip to the south and a strong, steeply southwest-stretching lineation, as shown in Figure 14.7. This geometry largely controls all the continuity models for all metals, as shown in Figure 14.6.
Directional variograms and correlograms were used to establish the relationship between composited samples for each element required in the ordinary kriging (OK) grade estimation (Au $\pm \mathrm{Ag}, \mathrm{Cu}, \mathrm{Pb}, \mathrm{SG}$ ). The same relationships would be applied to the blocks in the estimation. In order to look for directions of variability, the variography was measured and compared along different directions until the best results for range were found. Orthogonal intermediate axes were then established. The best-fit model orientations roughly correspond to the strike, dip and plunge of each mineralized zone.

The modelled variogram orientations and ranges are used in the search parameter files for each zone. The dynamic anisotropy option of Datamine is used to align search ellipsoid with the axes of mineralisation.

The continuity models were then created by selecting nuggets in the downhole direction and one or two structures were modelled resulting in an orientation (rotations) and ranges (major, semimajor and minor axes) of continuity. Figure 14.5 shows an example of experimental variograms for Zone 3 of the LZ5 deposit from Pitre (2020a). Table 14.6 summarizes the search parameters for gold with Datamine convention for the angles.![img-43.jpeg](img-43.jpeg)

Figure 14.5 - Example of experimental gold variogram for Zone 3 HW of LZ5 deposit: first row shows strike, dip and plunge continuity and second row shows NormalScores variograms along major, semi-major and minor axes (Pitre 2020a)Table 14.6 - Search parameters for gold

| Deposit | Block Model Horizon | Domain Codes | Ellipsoid orientation (3,1,3 axis rule) |  |  | Search Ellipsoid dimension (SVOL1) |  |  | Sample selection parameter |  |  | Ellipse X multiplicator (2nd \& 3rd pass) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  |  |  | Dip Direction | Dip | Plunge | SDIST1 | SDIST2 | SDIST3 | Min <br> No. | Max <br> No. | Maxkey | SVOLFAC2, SVOLFAC3 |
|  |  |  | SANGLE1 | SANGLE2 | SANGLE3 |  |  |  |  |  |  |  |
| LaRonde | Zone 6 | 6, 61, 62 | 180 | 70 | 105 | 50 | 30 | 5 | 3 | 12 | 2 | 2, 4 |
|  | Zone 20 North | 17 | 175 | 75 | 120 | 80 | 45 | 5 | 3 | 14 | 2 | 2, 3 |
|  |  | 19 | 175 | 75 | 110 | 55 | 25 | 5 | 3 | 14 | 2 | 2, 3 |
|  |  | 190 | 175 | 75 | 120 | 30 | 20 | 5 | 3 | 14 | 2 | 2, 4 |
|  |  | 20 | 175 | 75 | 120 | 40 | 30 | 5 | 3 | 14 | 2 | 2, 3 |
|  |  | 900 | 175 | 75 | 120 | 85 | 60 | 5 | 3 | 14 | 2 | 2, 4 |
|  |  | 901, 902 | 175 | 75 | 120 | 35 | 35 | 5 | 3 | 14 | 2 | 2, 4 |
|  | LP1 - Fringe | 101, 102, 106, 107 | 170 | 80 | 90 | 40 | 35 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 103, 104, 105, 108 | 175 | 80 | 110 | 40 | 35 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 1000, 1100, 1200 | 180 | 80 | 90 | 80 | 80 | 10 | 4 | 16 | 3 | 2, 3 |
|  | LPl - <br> Dumagami | 201 | 180 | 80 | 120 | 25 | 20 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 301, 302 | 180 | 90 | 180 | 25 | 25 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 2000 | 180 | 80 | 50 | 50 | 50 | 10 | 4 | 16 | 3 | 2, 3 |
|  |  | 3000 | 180 | 90 | 90 | 80 | 80 | 10 | 4 | 16 | 3 | 2, 3 |
|  |  | 4000 | 180 | 90 | 180 | 80 | 80 | 10 | 4 | 16 | 3 | 2, 3 |
|  |  | 5000 | 175 | 85 | 90 | 80 | 80 | 10 | 4 | 16 | 3 | 2, 3 |
|  | LP1 - Zone Massive | 37, 39 | 180 | 70 | 10 | 30 | 30 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 38 | 175 | 80 | $-170$ | 35 | 35 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 999 | 175 | 80 | $-170$ | 35 | 35 | 5 | 6 | 16 | 5 | 2, 3 |
| LZ5 | Zone 3-1 | 401, 402 | 175 | 80 | 140 | 30 | 30 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 407, 408, 410 | 180 | 90 | 130 | 30 | 25 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 412, 413 | 180 | 80 | 110 | 30 | 25 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 415 | 175 | 85 | 120 | 35 | 15 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 416 | 180 | 85 | 100 | 30 | 25 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 6000 | 180 | 80 | 110 | 30 | 20 | 10 | 4 | 16 | 3 | 2, 3 |
|  |  | 7000 | 175 | 85 | 150 | 30 | 30 | 4 | 4 | 16 | 3 | 2, 3 |
|  |  | 8000, 10000 | 180 | 70 | 180 | 30 | 30 | 10 | 4 | 16 | 3 | 2, 3 |
|  |  | 9000 | 180 | 85 | 100 | 30 | 30 | 10 | 4 | 16 | 3 | 2, 3 |
|  | Zone 3-4 | 501, 502, 506 | 180 | 85 | 90 | 50 | 50 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 503, 504, 505, 507 | 180 | 80 | 100 | 50 | 50 | 5 | 3 | 12 | 2 | 2, 3 |
|  |  | 11000, 12000 | 180 | 80 | 90 | 80 | 80 | 10 | 4 | 16 | 3 | 2, 3 |
|  | Zone 5 | 5, 51, 999 | 2 | $-80$ | 100 | 40 | 40 | 5 | 7 | 15 | 3 | 2, 3 |
|  |  | 4, 41 | 2 | $-80$ | 106 | 25 | 25 | 5 | 7 | 15 | 3 | 2, 3 |
|  | Zone 3 | 1, 2, 999 | $-175$ | 80 | 120 | 40 | 25 | 5 | 3 | 12 | 3 | 2, 3 |
|  |  | 3, 31 | $-175$ | 80 | 100 | 40 | 25 | 5 | 3 | 12 | 3 | 2, 3 |
|  |  | 31 | $-175$ | 80 | 100 | 40 | 25 | 5 | 3 | 12 | 3 | 2, 3 |The interpolation strategy (described further in Section 14.10) involved three cumulative passes. Typically, the cumulative passes are characterized by increasing search ranges. The ranges of the search ellipsoids are derived from the variography range results.
For the majority of LaRonde Complex BMs, the ranges of the first pass correspond to the first or second structure, the second pass is $2 x$ the first pass or second structure, and the third pass is $3 x$ to $4 x$ the first pass. For the Zone 3 area at LZ5, the ellipsoid sizes are based on variogram ranges at a certain percentage of the sill. First pass and second pass have been respectively fixed at $1 / 3$ and $2 / 3$ of the third pass (range at the sill).

Figure 14.6 presents an example of mineralized zone and search ellipsoid for BMs.
![img-44.jpeg](img-44.jpeg)

Figure 14.6 - 3D view example of the search ellipse orientation based on variography domains of Zones 19, 19N, 19W and 20S in LaRonde deposit

[[%~%]]
## 14.9 Block Modelling

Each block model for the Property was created or updated in Datamine StudioRM. Block model dimensions, orientations and block sizes were based on the mining method, the orebody geometry and the drill hole spacing.The geometry of orebodies at LaRonde Complex are very similar, with an east-west trending subvertical tabular shape showing steep elongation towards the southwest as reflected by the general orientation and shape of all search ellipsoids (Figure 14.6).
The block size selected for LaRonde and LZ5 follows the standard practice not to be smaller than $1 / 3$ of the sample grid spacing which is generally 15 m by 30 m .
The block size ( $X, Y$ and $Z$ ) varies from $10 \mathrm{~m} \times 3 \mathrm{~m} \times 10 \mathrm{~m}$ for the LaRonde deposit to $5 \mathrm{~m} \times 1.5 \mathrm{~m}$ x 7.5 m for the LZ5 deposit. These parameters represent approximately $1 / 3$ of the stope dimensions. The thickness of 1.5 m to 3 m along the Y axis corresponds to the typical length of a composite sample is 1.5 m , or the minimum mining width at 3 m . No rotation was applied for all Block Models.

Sub-celling of the block model was used to allow the parent block to be split and more accurately fill the volume of the 3D solids (Split and Resol parameters in Datamine). Interpolation was carried out into full parent cells and subsequent sub-cells inherent in this interpolated grade. Table 14.7 summarizes the Datamine block model properties for each deposit.

Typically, a block model is estimated for each different domain (multiple high grades zones, low grade to barren footwall or hanging wall for dilution, and void or mined out) with each having its own parameters. For a specific area, these different block models were combined before stope optimization and volumetric reporting.

[[%~%]]
## 14.10 Grade Estimation

For the LaRonde Complex, all lenses included in the Mineral Resource and Mineral Reserve estimate were defined using the ID2 interpolation method for the block model grade estimation ( $\mathrm{Au}, \pm \mathrm{Ag}, \mathrm{Cu}, \mathrm{Zn}, \mathrm{SG}$ ). Hard boundary selection of samples was used for each zone or domain. Dynamic anisotropy method (Datamine software) is applied to reflect dip and direction changes for all domains. Search angles are coded in the block model.
The ID2 method is quick, relatively simple and, to an extent, accounts for grade variability according to distance and direction (based on variograms). The choice of the actual power (ID2) used for the estimation has been based on the commonly accepted method used by Agnico Eagle at the LaRonde mine and other projects. Comparison between ID2 and OK returns similar results in terms of amount of contained metal (ounces of gold) calculated during the estimation process.
Up to three interpolation passes are generally used with increasing search ellipse sizes and less restrictive parameters.

Table 14.8 presents a summary of interpolation parameters used for each block model by deposit.Table 14.7 - Datamine Block Model properties at the Property

| Mineral deposit | Coordinate system | Geological zone or lens Block Model horizon (BM, underground) | BM prototype / Datamine parameters |  |  |  |  |  |  |  |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  |  |  | XMIN | YMIN | ZMIN | XDIM | YDIM | ZDIM | NBX | NBY | NBZ | Split (XZ plan) | Resol (along Y) |
| LaRonde | LaRonde Mine grid | Zone 20 North | 5500 | 2340 | 1000 | 10 | 3 | 10 | 210 | 220 | 162 | 2 | 10 |
|  |  | Zone 6 | 4500 | 2200 | 200 | 10 | 3 | 10 | 360 | 333 | 270 | 2 | 10 |
|  |  | Massive Zone (11-3) | 5300 | 2400 | 2800 | 5 | 3 | 10 | 200 | 350 | 100 | 2 | 6 |
|  |  | LP1 - Fringe | 5300 | 2700 | 2600 | 5 | 1.5 | 10 | 405 | 450 | 250 | 2 | 5 |
|  |  | LP1 - Dumagami | 5300 | 2700 | 2600 | 5 | 1.5 | 10 | 405 | 450 | 250 | 2 | 5 |
| LZ5 | Bousquet Mine grid | Zone 5 | 6000 | 6000 | 3800 | 5 | 1.5 | 7.5 | 300 | 400 | 165 | 2 | 5 |
|  |  | Zone 3 | 6400 | 6000 | 3850 | 5 | 1.5 | 7.5 | 350 | 266 | 153 | 2 | 5 |
|  |  | Zone 3-1 | 6300 | 5500 | 1500 | 5 | 1.5 | 10 | 440 | 734 | 400 | 2 | 5 |
|  |  | Zone 3-4 | 4700 | 5800 | 2000 | 5 | 1.5 | 10 | 490 | 400 | 320 | 2 | 5 |Table 14.8 - Summary of interpolation parameters typically used for gold grade estimation at the Property

| Deposit | Block model name | Pass | Min. no. of comp. | Max. no. of comp. | Max. no. of comp. per DDH | Principal ranges* |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| LaRonde <br> (LaRonde grid) | Zone 6 | 1 | 3 | 12 | 2 | 50 |
|  |  | 2 | 3 | 12 | 2 | 100 |
|  |  | 3 | 2 | 12 | 2 | 200 |
|  | Zone 20 North | 1 | 3 | 12 | 2 | 45 |
|  |  | 2 | 3 | 12 | 2 | 90 |
|  |  | 3 | 3 | 12 | 2 | 180 |
|  | LP1 - Fringe | 1 | 3 | 12 | 2 | 40 |
|  |  | 2 | 3 | 12 | 2 | 80 |
|  |  | 3 | 3 | 12 | 2 | 120 |
|  | LP1 - Dumagami | 1 | 3 | 12 | 2 | 25 |
|  |  | 2 | 3 | 12 | 2 | 50 |
|  |  | 3 | 3 | 12 | 2 | 75 |
|  | LP1 - Massive Zone | 1 | 3 | 12 | 2 | 30 |
|  |  | 2 | 3 | 12 | 2 | 60 |
|  |  | 3 | 3 | 12 | 2 | 90 |
| LZ5 <br> (Bousquet grid) | Zone 3-1 | 1 | 3 | 12 | 2 | 30 |
|  |  | 2 | 3 | 12 | 2 | 60 |
|  |  | 3 | 3 | 12 | 2 | 90 |
|  | Zone 3-4 | 1 | 3 | 12 | 2 | 50 |
|  |  | 2 | 3 | 12 | 2 | 100 |
|  |  | 3 | 3 | 12 | 2 | 150 |
|  | Zone 5 | 1 | 7 | 15 | 3 | 40 |
|  |  | 2 | 7 | 15 | 3 | 80 |
|  |  | 3 | 1 | 15 | 3 | 120 |
|  | Zone 3 | 1 | 3 | 12 | 3 | 40 |
|  |  | 2 | 3 | 12 | 3 | 80 |
|  |  | 3 | 3 | 12 | 3 | 120 |

*Interpolation parameters could vary for each resource domain. The parameters shown in this table are the most common.

[[%~%]]
## 14.11 Validation Of The Grade Estimation

Each block model was validated visually and statistically, and by comparing with other estimation methods. The validation of the resource block model against reconciliation of production is presented in Section 15.

[[%~%]]
### 14.11.1 Visual Validation

The visual validation, through cross-section and plan view comparisons of composite grade versus block grade, confirmed that the block models honour the drill hole composite data and provide an appropriate local estimate of grades. Figure 14.7 and Figure 14.8 present examples of visual validation between block grade and composite grade.![img-45.jpeg](img-45.jpeg)

Figure 14.7 - Validation of Zone 5 area gold block model, comparing drill hole composites (coloured drill hole traces) and block model grade values (coloured cell) with the same gold grade legend (north-south section 6700E, looking west).![img-46.jpeg](img-46.jpeg)

Figure 14.8 - Validation of Zone 20 North copper block model, comparing drill hole composites (coloured drill hole traces) and block model grade values (coloured cell) with the same copper grade legend (plan view Level 275).

[[%~%]]
### 14.11.2 Statistical Validation

The statistical comparisons between composites and respective model interpolations were completed for each block model. Table 14.9 presents an example of the basic statistics of the composites and the interpolated blocks for gold of the LP1 - Massive Zone.
The difference between the gold grade of the mean blocks and the gold grade of the composites is considered acceptable.

Table 14.9 - Validation of basic statistics of interpolated blocks and composite points (Au of LP1 - Massive Zone) by Domains

| HG domains | Support | No. | $\begin{gathered} \text { Min } \\ (\mathrm{Au} \mathrm{~g} / \mathrm{t}) \end{gathered}$ | Max <br> (Au g/t) | Median (Au g/t) | SD | Mean (Au g/t) | Mean difference |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Massive FW | Composites | 1,607 | 0.00 | 50.00 | 1.95 | 4.10 | 3.15 | $0 \%$ |
|  | Blocks | 74,987 | 0.01 | 48.83 | 2.63 | 2.28 | 3.16 |  |
| Massive HW | Composites | 1,763 | 0.00 | 50.00 | 3.23 | 8.03 | 6.24 | $-18 \%$ |
|  | Blocks | 81,880 | 0.00 | 46.66 | 3.29 | 4.42 | 5.13 |  |

[[%~%]]
### 14.11.3 Interpolation Method Comparison

ID2 is the preferred interpolation method. It is used throughout the Property and based on variography analysis. Uncapped ordinary kriging (UOK), capped ordinary kriging (OK) and Nearest Neighbour (NN) methods are used as a method of comparison. The ID2 models show a good match with the OK models. Examples of OK, ID2 and NN comparison are in Figure 14.9.
![img-47.jpeg](img-47.jpeg)

Figure 14.9 - Swath plot in easting of the LP1 - Massive Zone HW block model, comparing OK, ID2 and NN block model gold grade values

[[%~%]]
## 14.12 Mineral Resource Classification

Mineral resource classification for the Property is based on the robustness of the various available data and model characteristics, including but not limited to the following:

- Quality and reliability of drilling and sampling data
- Drill hole density
- Confidence in the geological interpretation
- Geological and grade continuity of the mineralization
- Variogram models and search-ellipse criteria
- Interpolation parameters
- Distance of underground opening in ore zones

The 2022 MRE resource classification criteria are used to code each optimized mineable shape, result of the optimization process as measured, indicated or inferred mineral resources. The classification criteria were adjusted manually for all LaRonde Complex deposits to avoid scatteredblocks. Commonly, an area is manually defined based on the drill hole density and is used to improve mineral resource classification. Table 14.10 shows the common drill hole spacing criteria for this classification process.

Table 14.10 - Common drill hole spacing criteria for mineral resources classification

| Resource category | Zone / Area | Horizontal spacing (m) | Vertical spacing (m) | Other criteria |
| :--: | :--: | :--: | :--: | :--: |
| Measured | LaRonde Penna Shaft | 15 | 30 | No more than 15 m from a developed area |
|  | LP1 | 15 to 20 | 20 to 30 |  |
|  | LZ5 | 15 to 20 | 20 to 30 |  |
| Indicated | LaRonde Penna Shaft | 50 to 80 | 60 to 80 | No more than half the distance between economic and non-economic drill-hole intervals in known ore shoots |
|  | LP1 | 50 | 60 |  |
|  | LZ5 | 60 | 80 |  |
| Inferred | All zones / areas | 100 | 120 | No more than half the distance between economic and non-economic drill-hole intervals in known ore shoots |

[[%~%]]
## 14.13 Economic Parameters (Cut-Off Grades)

The 2022 MRE combines different underground scenarios, each assigned a cut-off grade ("COG") by area as described below.

The LaRonde and LZ5 deposits included three areas (Zone 20 North in the former and Zone 5 and Zone 3 in the latter) that are presently in production. One other area, namely LP1 - Massive Zone (11-3 area) is currently in development with expected production beginning in 2023.
Metal prices and exchange rates assumptions are revised annually and are provided by the Company's Vice President of Mineral Resources Management. These assumptions are usually based on a three-year moving average and consensus prices obtained by collating the prices used by peers in the industry. The Company's assumptions for 2022 are in Table 14.11.

Table 14.11 - Economic assumptions parameters used in 2022 MRE

| Parameter | Unit | Value |
| :-- | :--: | :--: |
| Gold price | US\$/oz | 1,300 |
| Exchange rate | C\$ per US\$ | 1.30 |
| Gold price | C\$/oz | 1,690 |
| Silver price | US\$/oz | 18.00 |
| Copper price | US\$/lb | 3.00 |
| Zinc price | US\$/lb | 1.00 |
| Lead price | US\$/lb | 0.90 |The COG values are derived from the current economic parameters presented in this section and in Section 15. To capture all material with a reasonable potential for economic extraction, the COG values for resources are fixed at $80 \%$ of the reserve COG calculation based on the economic parameters presented in Table 14.12 and Table 14.13.

The Life of Mine ("LOM") internal documents produced in 2022 and updated in terms of cost per tonne in the "Budget 2023" process were the basis for production cost and cut-off grade determination. Cost parameters are based on estimates from actual and projected OPEX costs of the LaRonde Complex. Mill recovery parameters are based on the past and actual production, milling and reconciliation reports, or on the results of metallurgical testwork for future areas of mining.

The LaRonde deposit consists in a series of polymetallic lenses. Base metals are a significant source of revenues and COG is expressed on an NSR basis. Gold and base metals grades, mill recovery, metal prices, smelter and refining charges, and metal prices are all integrated into the NSR calculation and coded into the polymetallic block models.

For the mineral resources of the LaRonde deposit, the COG values range from C\$56/t NSR for the near-surface LP1 area (Fringe and Dumagami) to C\$80/t NSR for the LP1 Massive Zone area (11-3). For LaRonde at depth (Zone 20 North and Zone 6), the mineral resource COG is C\$175/t NSR.

The LZ5 deposit consists of a series of relatively gold-rich sulphide lenses with a very low base metals content, so COG is expressed on a simple gold grade ( $\mathrm{g} / \mathrm{t}$ ) basis. A variable COG is currently used at LZ5, mainly based on haulage distance to the surface and as a function of the stope size (see Section 15). For the mineral resources of LZ5, the COG values range from 1.16 $\mathrm{g} / \mathrm{t}$ to $1.64 \mathrm{~g} / \mathrm{t}$ gold, except for Zone 3-1 and Zone 3-4 below 750 m where COG values range between 2.07 to $2.24 \mathrm{~g} / \mathrm{t}$ gold.

Mineral resources from LP1 area (Fringe and Dumagami) and Zones 3-1 and 3-4 below 750 m were not updated with 2022 parameters because no new drilling or economic studies were completed in 2022 in those areas. Information is derived from the official 2021 MRE report (internal).

[[%~%]]
## 14.14 Constraining Surfaces And Volumes

The final underground block models were converted into sub-blocked models in Deswik software to produce the underground mineable stope optimization ("MSO") shapes based on the COG (variable or not) and a typical minimal stope dimensions of $15 \mathrm{~m} \times 30 \mathrm{~m} \times 3 \mathrm{~m}$ (length, height, width) and a series of other parameters described in Section 15. The MSO parameters are the same for mineral reserves and mineral resources, except for the COG. Optimization is performed with external dilution. The MSO shapes are used as constraints to determine the underground mining mineral resource and include internal dilution (i.e., the portion of material below COG but located inside the MSO shapes).Table 14.12 - Input parameters used to determine the COG at LaRonde deposit

| Input parameter for COG calculation | Unit | LaRonde deposit (Penna Shaft area) | LaRonde deposit (LP1 -11-3 area) | LaRonde deposit (LP1 - <br> Fringe and <br> Dumagami area) |
| :--: | :--: | :--: | :--: | :--: |
| Average mining cost | C\$/t mined | 128.66 | 49.29 | 40.62 |
| Processing costs | C\$/t milled | 47.26 | 47.42 | 29.92 |
| G\&A | C\$/t milled | 38.38 | 3.84 | 4.32 |
| Total mineralized material based costs | C\$/t milled | 214.3 | 100.55 | 74.86 |
| Au mill recovery | \% | 94.14 |  | 95.18 |
| Ag mill recovery | \% | 73.45 |  | 73.66 |
| Cu mill recovery | \% | 80.72 |  | 78.41 |
| Zn mill recovery | \% | 68.99 |  | 74.65 |
| Smelting cost $(\mathrm{Cu}+\mathrm{Au})$ | C\$/t milled | 9.25 |  |  |
| Smelting cost (Zn) | C\$/t milled | 2.50 |  |  |
| Zn circuit adjustment with $\mathrm{Zn}>=2.75 \%$ | C\$/t of Zn concentrate | 400 |  |  |
| Zn circuit adjustment with $\mathrm{Zn}<2.75 \%$ | C\$/t of Zn concentrate | 560 |  |  |
| Royalty | \% | 0, (5\% NPR on <br> Terrex property) | 2 | 2 or 0 (LaRonde property) |
| First Nation royalty | C\$/g | 0.34 |  | 0.308 |
| Reserve Net Smelter Return COG <br> (Developed / Short Term / Long Term) | C\$/t | 198 / 214 / 219 | 100.55 | 75 |
| $\begin{gathered} \text { Resource NSR COG } \\ (80 \% \text { of calculated long-term COG) } \end{gathered}$ | C\$/t | 175 | 80 | 56 |

Table 14.13 - Input parameters used to determine the COG at LZ5 deposit

| Input parameter for COG calculation | Unit | LZ5 deposit <br> (Zone 3 + 5 area, Zone 3-1 above 750 m) | LZ5 deposit <br> (Zone 3-4 and Zone 3-1 below 750 m) |
| :--: | :--: | :--: | :--: |
| Average mining cost | C\$/t mined | 49.12 | 90.47 |
| Processing costs | C\$/t milled | 25.88 | 33.20 |
| G\&A | C\$/t milled | 4.97 | 23.92 |
| Total mineralized material-based costs | C\$/t milled | 79.97 | 147.59 |
| Au mill recovery | \% | 94.6 | 94.6 |
| Refining cost | C\$/oz | 21.46 | 3.61 |
| Royalty | \% | 2 or 0 (Ellison property) | 2 or 0 (Ellison property) |
| First Nation royalty | C\$/g | 0.34 | 0.308 |
| Average reserve COG* | g/t Au | 1.62 | 2.99 |
| Average resource COG* (75\% of calculated COG) | g/t Au | 1.30 | 2.24 |

*Variable COG used

[[%~%]]
## 14.15 Mineral Resource Estimate

The QP responsible for this section of the Technical Report has classified the 2022 MRE as Measured, Indicated, and Inferred mineral resources based on geological and grade continuity, data density, search ellipse criteria, drill hole density, and interpolation parameters. The QP responsible for this section of the Technical Report is of the opinion that the requirement of reasonable prospects for eventual economic extraction has been met by having a cut-off grade that uses reasonable inputs combined with constraining optimized mining volumes for the underground scenarios. Each optimized underground mining volume contains only one mineral resource classification level.

The 2022 MRE is considered to be reliable and based on quality data and substantial geological knowledge. The mineral resource estimates follow CIM Definition Standards for Mineral Resources \& Mineral Reserves (CIM Standing Committee on Reserve Definitions 2014). Economic viability of mineral resources that are not mineral reserves is not demonstrated.
The QP responsible for this section of the Technical Report is not aware of any environmental, permitting, legal, title, taxation, socio-economic, marketing, political or other relevant factors that could materially impact the 2022 MRE.
Table 14.14, Table 14.15 and Table 14.16 display the results of the 2022 MRE for the LaRonde and LZ5 deposits, exclusive of mineral reserves, all for the underground mining scenarios. The results of indicated mineral resources are presented diluted (with external dilution), while the results of inferred mineral resources are presented undiluted (without external dilution).Table 14.14 - Mineral Resource Estimate for LaRonde Complex as at December 31, 2022 (exclusive of Mineral Reserves)

| Deposit | Category | Tonnage <br> (000 t) | Gold grade <br> (g/t) | Gold <br> (000 oz.) |
| :--: | :--: | :--: | :--: | :--: |
| LaRonde | Measured | 0 | - | 0 |
|  | Indicated | 5,959 | 2.96 | 566 |
|  | $\mathrm{M}+\mathrm{I}$ | 5,959 | 2.96 | 566 |
|  | Inferred | 2,942 | 4.91 | 464 |
| LaRonde Zone 5 | Measured | 0 | - | 0 |
|  | Indicated | 9,774 | 2.08 | 652 |
|  | $\mathrm{M}+\mathrm{I}$ | 9,774 | 2.08 | 652 |
|  | Inferred | 12,376 | 3.13 | 1,244 |
| LaRonde Complex Total | Measured | 0 | - | 0 |
|  | Indicated | 15,733 | 2.41 | 1,219 |
|  | $\mathrm{M}+\mathrm{I}$ | 15,733 | 2.41 | 1,219 |
|  | Inferred | 15,317 | 3.47 | 1,708 |

Mineral Resource Estimate notes:

1. The Qualified Person, as defined by NI 43-101, for the Mineral Resource Estimate, is David Pitre, P.Eng., P.Geo. The effective date of the 2022 MRE is December 31, 2022.
2. Mineral Resources are reported exclusive of Mineral Reserves. Mineral Resources are not Mineral Reserves and do not have demonstrated economic viability.
3. The Mineral Resource Estimate follows CIM 2014 Definition Standards.
4. The cut-off grades were calculated using a gold price of US\$1,300/oz; a silver price of US\$18/oz; a copper price of US $\$ 3.00 / \mathrm{lb}$ : a zinc price of US $\$ 1.00 / \mathrm{lb}$; an exchange rate of $\mathrm{C} \$ 1.30$ per US\$; a mining cost varying from C\$40.62/t to C\$128.66/t (underground mining); a processing cost from of C\$29.92/t to C\$47.72/t; and a G\&A cost from C\$3.84/t to C\$38.38/t. The resources cut-off grade (gold or NSR basis) is defined and fixed at $80 \%$ of the reserves cut-off grade.
5. The assays were capped prior to compositing at 1.5 m .
6. The Mineral Resources were estimated using Datamine Studio RM v.1.9.36 using hard boundaries where the zone continuity is demonstrated on composited assays. The ID2 method was used to interpolate a block model. The final constraining surfaces and volumes were constructed with Datamine or Deswik v.2020.3.655 (SO 3.1.1) software.
7. Results are presented in-situ and exclusive of Mineral Reserves. 1.0 troy ounce $=$ metric tons $x$ grade / 31.1035. Calculations used metric units (metres, tonnes, grams per tonne). The number of tonnes and gold ounces were rounded to the nearest thousand. Any discrepancies in the totals are due to rounding effects.
8. The QP is not aware of any known environmental, permitting, legal, title-related, taxation, socio-political, marketing or other relevant issues that could materially affect the mineral resource estimate.
9. The results of indicated resources are presented diluted (MSO shapes with external dilution), while the results of inferred resources are presented undiluted (without external dilution). All the reported mineral resources are considered to have reasonable prospects for economic extraction.Table 14.15 - Mineral Resource Estimate for LaRonde deposit, as at December 31, 2022 (exclusive of Mineral Reserves)

| Zone by category | Tonnage <br> $(\mathbf{t})$ | Gold <br> grade <br> $(\mathbf{g} / \mathbf{t})$ | Silver <br> grade <br> $(\mathbf{g} / \mathbf{t})$ | Copper <br> grade <br> $(\%)$ | Zinc <br> grade <br> $(\%)$ | Gold <br> (oz.) | Silver <br> (oz.) | Copper <br> $(\mathbf{k g})$ | Zinc <br> $(\mathbf{k g})$ |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Indicated Mineral Resource (Underground) |  |  |  |  |  |  |  |  |  |
| LP1 - Zone 7 | 88,965 | 1.45 | 9.95 | 0.14 | 0.46 | 4,141 | 28,453 | 122,440 | 406,824 |
| LaRonde Zone 20 North | $2,145,075$ | 2.00 | 36.16 | 0.24 | 1.71 | 295,217 | $1,232,043$ | $3,612,871$ | $27,339,359$ |
| LP1 - Zone 4D | 908,421 | 1.75 | 3.39 | 0.27 | 0.22 | 51,200 | 98,949 | $2,479,611$ | $1,961,334$ |
| LP1 - Fringe HW and FW | $2,214,728$ | 2.38 | - | - | - | 169,386 | - | - | - |
| LP1 - Massive | 601,609 | 2.40 | 4.46 | 0.05 | 0.03 | 46,455 | 86,227 | 281,208 | 158,363 |
| Total Indicated <br> Mineral Resources | $\mathbf{5 , 9 5 8 , 7 9 8}$ | $\mathbf{2 . 9 6}$ | $\mathbf{7 . 5 5}$ | $\mathbf{0 . 1 1}$ | $\mathbf{0 . 5 0}$ | $\mathbf{5 6 6 , 3 9 9}$ | $\mathbf{1 , 4 4 5 , 6 7 2}$ | $\mathbf{6 , 4 9 6 , 1 3 1}$ | $\mathbf{2 9 , 8 6 5 , 8 8 1}$ |
| Inferred Mineral Resource (Underground) |  |  |  |  |  |  |  |  |  |
| LaRonde Zone 6 | 194,258 | 3.27 | 27.15 | 0.43 | 1.68 | 20,437 | 169,569 | 841,565 | $3,264,197$ |
| LaRonde Zone 20 North | $1,536,961$ | 4.76 | 53.65 | 0.18 | 2.95 | 361,050 | $1,707,869$ | $5,604,070$ | $22,774,215$ |
| LP1 - Zone 4D | $1,194,108$ | 2.12 | 3.23 | 0.30 | 0.23 | 81,261 | 124,035 | $3,607,731$ | $2,687,143$ |
| LP1 - Fringe HW and FW | 16,290 | 2.34 | - | - | - | 1,223 | - | - | - |
| Total Inferred <br> Mineral Resources | $\mathbf{2 , 9 4 1 , 6 1 7}$ | $\mathbf{4 . 9 1}$ | $\mathbf{2 1 . 1 6}$ | $\mathbf{0 . 3 4}$ | $\mathbf{0 . 9 8}$ | $\mathbf{4 6 3 , 9 7 1}$ | $\mathbf{2 , 0 0 1 , 4 7 3}$ | $\mathbf{1 0 , 0 5 3 , 3 6 6}$ | $\mathbf{2 8 , 7 2 5 , 5 5 4}$ |Table 14.16 - Mineral Resource Estimate for LZ5 deposit, as at December 31, 2022 (exclusive of Mineral Reserves)

| Zone by category | Tonnage <br> $(\mathbf{t})$ | Gold grade <br> $(\mathbf{g} / \mathbf{t})$ | Gold <br> (oz.) |
| :-- | :--: | :--: | :--: |
| Indicated Mineral Resource (Underground) |  |  |  |
| Zone 5 | $2,326,107$ | 1.56 | 116,372 |
| Zone 51 | 631,933 | 2.32 | 47,043 |
| Zone 4 and Zone 41 | $1,401,985$ | 2.41 | 108,470 |
| Zone 1 | $1,487,122$ | 1.88 | 89,846 |
| Zone 2 | $1,386,427$ | 1.64 | 73,231 |
| Zone 3 HW | $1,941,916$ | 2.47 | 154,075 |
| Zone 3 FW | 349,314 | 2.58 | 29,012 |
| Zone 3-1 FW | 35,834 | 6.44 | 7,419 |
| Zone 3-1 HW | 213,661 | 3.91 | 26,889 |
| Total Indicated Mineral Resources | $\mathbf{9 , 7 7 4 , 2 9 9}$ | $\mathbf{2 . 0 8}$ | $\mathbf{6 5 2 , 3 5 7}$ |
| Inferred Mineral Resource (Underground) |  |  |  |
| Zone 5 | $6,420,700$ | 2.24 | 463,346 |
| Zone 4 and Zone 41 | $1,616,717$ | 2.99 | 155,198 |
| Zone 1 | 81,950 | 3.17 | 8,360 |
| Zone 3 HW | 590,215 | 2.83 | 53,736 |
| Zone 3 FW | $1,498,932$ | 4.14 | 199,488 |
| Zone 3-4 South | $1,419,193$ | 5.11 | 233,222 |
| Zone 3-4 North | 389,881 | 6.39 | 80,079 |
| Zone 3-1 FW | 33,934 | 3.68 | 4,019 |
| Zone 3-1 HW | 324,088 | 4.49 | 46,792 |
| Total Inferred Mineral Resources | $\mathbf{1 2 , 3 7 5 , 6 1 1}$ | $\mathbf{3 . 1 3}$ | $\mathbf{1 , 2 4 4 , 2 3 9}$ |
|  |  |  |  |

[[@~@]]
# 15 Mineral Reserve Estimates

[[%~%]]
## 15.1 Reserve Block Model

The design for the underground operations of the LaRonde Mine and the LZ5 Mine at the LaRonde Complex was prepared from all mineral resource block models updated as at December 31, 2022 (as discussed in Section 14). These models were supplied as a Datamine file and included the following items: in-situ gold and base metals grade, density, NSR value and mined-out status. The latter is the status of rock mass in a given volume and can represent the voids created during past underground operations.
A reserve and resource block model was developed from these block models to integrate additional parameters and to modify factors such as mining recovery, dilution (external waste and backfill) and royalties. As a result, the Mineral Reserve estimate for the LaRonde Complex includes mineral reserves in the underground LaRonde and LZ5 mines, and mineral reserves in silos and stockpiles.

[[%~%]]
## 15.2 Methodology

The main steps in the methodology of the mineral reserve estimate were as follows:

1. Transfer all verified BMs to the Engineering Department.
2. Update the mineral reserves MSO parameters (dilution, pillars, geometry) based on appropriate COG evaluations and reconciliation results.
3. Run all required optimization process scenarios and constraint volumes of optimal mineable shapes (using MSO).
4. Validate and categorize stope solids created during the optimization process. Mineral Reserves must be exclusive of Mineral Resources.
5. Update the mining plan (underground design) with the newly defined reserve mineable shape and block model.
6. Extract required development from planned stopes.
7. Add modifying factors (mining recovery rates and backfill dilution) to the reserve block model in the mineable shapes.
8. Generate a Mineral Reserve statement.

[[%~%]]
## 15.3 Mineable Shape Optimization (Mso)

Mineable shape optimization was conducted to determine the optimal economic shapes of the underground operations in 3D. This task was undertaken using Deswik v.2022.2.623 (SO 4.1.3566) software, based on an algorithm developed by Alford Mining Systems, which describes MSO as "a strategic mine planning tool that automates the design of stope shapes for a range of stoping methods for underground mines. Using constraints detailing mining method and design parameters MSO provides the optimal stope shape design to maximize the value of an orebody." The MSO method works on a block model of the orebody and progressively constructs lists of related blocks that should or should not be mined. Then the method uses the values of the blocks to define an optimized 3D shape with the highest possible total economic value, subject to the required parameters specified in the software.

[[%~%]]
### 15.3.1 Summary Of Economic Parameters

Table 14.11, Table 14.12 and Table 14.13 in Section 14 summarize the parameters used in calculating the COG for the optimization process. All monetary amounts in the tables are in Canadian dollars unless specified otherwise. The base case selling price for gold is $\mathbf{C} \$ 1,690$ per ounce. The LaRonde and LZ5 deposits are divided into zones based on mining area and metallic content (i.e., gold-only or polymetallic).

[[%~%]]
### 15.3.2 Cut-Off Grades (Nsr And Gold)

The economic value of the ore is integrated into the block model and could be expressed as gold grades for gold-rich lenses or as NSR values for polymetallic lenses. Each COG is calculated using the parameters described in Section 14.13.
At the LaRonde Mine, when the orebody is polymetallic, the COG is calculated based on aftermining costs. The NSR-based COG equals the cost of extracting and processing the ore and general and administrative ("G\&A") and environmental and services costs. It is defined as follows:

$$
N S R \operatorname{cog}=C m+C p+C a
$$

where:

| NSRcog | NSR cut-off value (C\$/t) |
| :-- | :-- |
| Cm | Total cost of mining (C\$/t milled) |
| Cp | Total cost of processing (C\$/t milled) |
| Ca | Administrative and services cost (C\$/t milled) |

The NSR value for polymetallic ore is calculated with a formula function of the metal prices and mill recovery, the smelting costs (for copper and zinc concentrates) and the royalties. It is defined as follows:

$$
\begin{aligned}
N S R=[\mathrm{Au} * & (\mathrm{P}_{\mathrm{Au}} * r A u)+\mathrm{Ag} *\left(\mathrm{P}_{\mathrm{Ag}} * r A g\right)+\mathrm{Cu} *\left(\mathrm{P}_{\mathrm{Cu}} * r C u\right)+Z n *\left(\mathrm{P}_{\mathrm{Zn}} * r Z n\right)] \\
& -[S M C u+S M Z n+R y]
\end{aligned}
$$

where:

| NSR | NSR value of ore (C\$/t) |
| :-- | :-- |
| Au, Ag, Cu, Zn | Metal grade |
| $\mathrm{P}_{\mathrm{Au}}, \mathrm{P}_{\mathrm{Ag}}, \mathrm{P}_{\mathrm{Cu}}, \mathrm{P}_{\mathrm{Zn}}$ | Metal price (C\$/oz or C\$ per lb) |
| rAu, rAg, rCu, rZn | Metallurgical recovery (\%) |
| SM Cu, SM Zn | Smelting costs (C\$/t) |
| Ry | Royalties (C\$/t) |On an annual basis, the Geology Qualified Person and the metallurgist review and update the NSR formula used for MRMR estimates. Metal grades are derived from the block model estimation. Metal prices are provided by the Vice President of Mineral Resources Development via AEM internal communication at the beginning of the MRMR estimation process (see Section 14).

The metallurgist establishes metallurgical recovery rates and smelting costs. All costs are taken and derived from the LOM and Budget 2023 reports of the LaRonde Complex.
For the mineral reserves of the LaRonde deposit, the COG is C\$100.55/t NSR for the LP1 Massive Zone area (11-3). For the LaRonde deposit at depth (Zone 20 North and Zone 6) the mineral reserve COG ranges from C\$198/t NSR for short-term developed mineral reserves to C\$214/t NSR for mid-term mineral reserves and C\$219/t NSR for long-term mineral reserves. Mineral reserves are only defined in Zone 20 North (LaRonde 2 and LaRonde 3 areas) and Massive Zone (LP1 area).
The COG is expressed in gold grade when only gold is considered (mostly at LZ5 Mine). The COG is that grade where revenue from produced gold equals the cost of extracting and processing the ore, and then refining and selling the gold. It is defined as follows:

$$
g=\frac{\mathrm{Cm}+\mathrm{Cp}+\mathrm{Ca}}{\mathrm{r} *(\mathrm{P}-\mathrm{Cs})}
$$

where:

| g | Cut-off grade ( $\mathrm{g} / \mathrm{t}$ gold) |
| :-- | :-- |
| r | Metallurgical or mill recovery (\%) |
| P | Price of gold (C\$/oz) |
| Cs | Cost of selling (including royalties) (C\$/oz gold) |
| Cm | Total cost of mining (C\$/t mined) |
| Cp | Total cost of processing (C\$/t milled) |
| Ca | Administrative and services cost (C\$/t milled) |

At the LZ5 Mine, all the ore is transported to the surface via a ramp. The haulage distance (a function of depth) and the stope size (a function of zone thickness) are two specific criteria that significantly impact the mining costs. Mining costs increase with depth but decrease with the opportunity to mine a larger stope. Therefore, a calculated variable COG is used for LZ5, derived from mining costs variation estimation. For the mineral reserves of LZ5, the COG values (see Section 14.13) range from 1.32 to $1.75 \mathrm{~g} / \mathrm{t}$ gold for the Zone 5 area.

[[%~%]]
### 15.3.3 Mso Parameters

The MSO algorithm required several parameters to perform optimization, as shown in Table 15.1. These parameters include:

- Optimization fields of BM source (gold grade, NSR value, density)
- Material exclusion rules
- Slope size and orientation (length, height, width, side ratio, dip and strike tolerance)
- Pillar size (minimum and maximum width)
- Dilution (footwall and hanging wall)
- COG

Figure 15.1 shows an isometric view of the 3D volumes and MSO selection and categorization results for Zone 20 North at the LaRonde Mine. These solids are validated with high-grade wireframes and mined out solids (utilizing a Cavity Monitoring System, or "CMS").

[[%~%]]
### 15.3.4 Mso Visual Validation

The visual validation, through cross-section and plan-view comparisons of MSO-generated stopes versus blocks with values above selected COG, confirmed that the MSO process is appropriate and valid. Figure 15.1 presents an example of visual validation between optimized stopes results vs block model.

[[%~%]]
## 15.4 Mineral Reserve Classification

The mineral reserves are reported according to CIM Definition Standards. As these standards state, resource model blocks classified as Measured and Indicated ("M\&I") included in the underground mining plan are reported as Proven and Probable mineral reserves. In contrast, Inferred mineral resources cannot be used in mineral reserve estimates and therefore have not been included in the LOM schedule. Mineral reserve classification for the Property is based essentially on the same criteria as mineral resource classification (see Section 14.12). The Proven mineral reserve category corresponds to the Measured mineral resource criteria, while the Probable mineral reserve category corresponds to the Indicated mineral resource criteria (see Table 14.10).Table 15.1 - Summary of MSO optimization parameters based on Mineral Reserves, as at December 31, 2022

|  |  | LaRonde deposit |  | LZ5 deposit |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Parameter |  | Zone 20 North | LP1 - Massive Zone (11-3 Area) | Zone 5 area |  | Zone 3 |
|  |  |  |  | Levels 9-30 <br> (30 m height stopes) | Below level 30 <br> (40 m height stopes) |  |
| Block model | Optimization field | NSRC | NSRC | AUC12 | AUC12 | AUC12 |
|  | Optimization field type | VALUE | VALUE | Grade | Grade | Grade |
| Orientation and region | Method | Vertical |  |  |  |  |
|  | Slope orientation plane | XZ |  |  |  |  |
| Length and height | Slope length ( m ) | 15 |  |  |  |  |
|  | Slope height | Gradient polyline |  |  |  |  |
| Width and pillar width | Slope minimum width ( m ) | 3 |  |  |  |  |
|  | Slope pillar ( m ) | 7 | 6 | 7.5 | 7.5 | 5 |
| Side ratio | Top to bottom | 2.25 | 2 | 3 | 3 | 3 |
|  | Front to back | 2.25 | 2 | 3 | 3 | 3 |
| Dilution | Hanging wall (ELOS in m) | 2 | 1.25 | 0.5 | 0.7 | 1 |
|  | Footwall (ELOS in m) | 1 | 0.5 | 1 | 1.3 | 2 |
| Dip and strike | Use control surface to govern stope shapes | True |  |  |  |  |
|  | Minimum ( ${ }^{\circ}$ ) | 50 | 50 | 60 | 60 | 60 |
| Dip | Maximum ( ${ }^{\circ}$ ) | 140 | 130 | 130 | 130 | 130 |
|  | Maximum change ( ${ }^{\circ}$ ) | 30 | 15 | 25 | 25 | 25 |
| Strike | Minimum ( ${ }^{\circ}$ ) | $-15$ | $-25$ | $-45$ | $-45$ | $-45$ |
|  | Maximum ( ${ }^{\circ}$ ) | 15 | 25 | 45 | 45 | 45 |
|  | Maximum change ( ${ }^{\circ}$ ) | 15 | 15 | 15 | 15 | 15 |
| COG | COG Version <br> (Resource COG $=80 \%$ of Reserve COG) | COG Reserve <br> Short term = C\$198 <br> Mid term = C\$214 <br> Long term = C\$219 <br> COG Resources = C\$175 | Reserve $=\mathrm{C} \$ 100.55$ <br> Resource $=\mathrm{C} \$ 80$ | COG variable \#1 <br> Zone $5-30 \mathrm{~m}$ | COG variable \#2 <br> Zone $5-40 \mathrm{~m}$ | COG variable \#4 <br> Zone $3-30 \mathrm{~m}$ |
|  | Evaluation method | Exact geometric |  |  |  |  |
| Density | Ore $\left(t / m^{3}\right)$ | BM | BM | 2.9 | 2.9 | 2.9 |
|  | Waste $\left(t / m^{3}\right)$ | BM | BM | 2.8 | 2.8 | 2.8 |
| Royalty (\% NSR) | LaRonde property | $0 \%$ |  |  |  |  |
|  | Terrex property | $5 \%$ NPR |  |  |  |  |
|  | Bousquet property |  | $2 \%$ | $2 \%$ | $2 \%$ | $2 \%$ |![img-48.jpeg](img-48.jpeg)

Figure 15.1 - Example of validation of MSO solids generated at specific COG and blocks of the block model above the COG in the isometric view of Level 314 at Zone 20 North at C\$198 NSR COG

[[%~%]]
## 15.5 Underground Mining Plan Design

After the mineral reserve classification process, the Geology and Mine Engineering teams validate the reserve block model. An underground mining plan is then designed to include all the mineral reserve blocks. At this point, each MSO solid (3D volume) is separated into one solid for required development for mining and another solid for the expected longhole production stope (Figure 15.2). This separation helps to optimize the LOM mining plan through Deswik Scheduler software by permitting the teams to model various mining-plan scenarios. Development is also considered separately from the stopes since they have slightly different mining costs, recovery and dilution.
Development solids are considered with factors of $0 \%$ dilution and $100 \%$ mining recovery rate. Development COGs are derived from the reserve COG minus development and productionrelated costs. For the LaRonde Mine, development COGs range from C\$51 NSR at LP1 - Massive Zone to C\$81 NSR at Zone 20 North. For the LZ5 Mine, development COG is fixed at $1.0 \mathrm{~g} / \mathrm{t}$ gold.
![img-49.jpeg](img-49.jpeg)

Figure 15.2 - Isometric view (looking northeast) of Zone 20 North, levels 311 to 335, West mine, showing examples of MSO solids split into stope and development solids

[[%~%]]
## 15.6 Modifying Factors: Dilution And Mining Recovery

After mining, each mined stope undergoes a retro-analysis process based on a 3D survey (CMS) of the empty cavity. The CMS interpretations are used to calculate the realized dilution (footwall and hanging wall and also paste/backfill dilution), mining recovery, overbreak, etc. The reconciliation tables and CMS data provide information to adjust dilution and mining recovery ratesfor every mining area. The CMS reconciliation is performed at the end of every quarter and discussed with Technical Services. Dilution/recovery rates are adjusted by the geologist/engineer for every stope based on history and previous results. Table 15.2 and Table 15.3 summarize yearly historical realized dilution, expressed in Equivalent Linear Overbreak Slough ("ELOS") in metres, and backfill dilution and mining recovery rates. These tables also show selected parameter values used in the estimation.

External dilution (footwall and hanging wall) parameters are included in the MSO process step. Backfill (paste fill or rock-cemented backfill) dilution and mining recovery rates are applied as a final step before compilation and the Mineral Reserves statement.Table 15.2 - Realized dilution and mining recovery estimated from CMS interpretations for LaRonde deposit per year (FW for footwall, HW for hanging wall)

| Year | Number of stopes | ELOS FW (m) | Maximum ELOS FW (m) | FW dilution (\%) | ELOS HW (m) | Maximum ELOS HW (m) | HW dilution (\%) | Total waste dilution (\%) | Backfill dilution (\%) | Mining recovery (\%) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| 2011 | 106 | 0.83 | 3.24 | 11.9 | 1.77 | 9.89 | 27.1 | 39.0 | 3.2 | 104 |
| 2012 | 101 | 0.78 | 2.93 | 9.9 | 1.52 | 9.19 | 23.8 | 33.7 | 2.7 | 95 |
| 2013 | 104 | 0.85 | 5.63 | 10.5 | 1.33 | 10.23 | 16.9 | 27.4 | 2.6 | 88 |
| 2014 | 96 | 0.77 | 4.36 | 8.5 | 1.08 | 7.13 | 14.8 | 23.3 | 1.2 | 88 |
| 2015 | 102 | 0.94 | 5.52 | 9.9 | 0.88 | 5.57 | 12.7 | 22.6 | 3.2 | 85 |
| 2016 | 94 | 1.00 | 5.72 | 14.0 | 1.33 | 7.98 | 24.3 | 38.3 | 3.1 | 90 |
| 2017 | 98 | 0.90 | 6.17 | 11.7 | 1.75 | 8.53 | 23.4 | 35.0 | 3.5 | 89 |
| 2018 | 97 | 0.89 | 3.95 | 11.0 | 1.39 | 5.99 | 23.1 | 34.0 | 4.1 | 87 |
| 2019 | 103 | 0.97 | 3.61 | 13.6 | 1.46 | 6.56 | 22.5 | 36.2 | 5.2 | 85 |
| 2020 | 86 | 0.92 | 3.37 | 11.1 | 1.22 | 8.53 | 17.1 | 28.2 | 3.3 | 83 |
| 2021 | 79 | 1.11 | 4.51 | 12.1 | 1.64 | 7.53 | 24.6 | 36.7 | 4.9 | 88 |
| 2022 | 55 | 0.87 | 3.87 | 9.9 | 1.64 | 5.11 | 18.0 | 27.9 | 6.5 | 89 |
| Total / <br> Average | 1,121 | 0.90 | 6.17 | 11.2 | 1.41 | 10.23 | 20.8 | 32.0 | 3.5 | 89 |
| Parameter values used in the estimation |  | 1.0 |  |  | 2.0 |  |  |  | 0\% to 4\% Avg.: 2\% | 85\% for Primary stope; 100\% for Secondary stope; 100\% for Developments |Table 15.3 - Realized dilution and mining recovery estimated from CMS interpretations for LZ5 deposit per year

| Year | Number of stopes | ELOS FW (m) | Maximum ELOS FW (m) | FW dilution (\%) | ELOS HW (m) | Maximum ELOS HW (m) | HW dilution (\%) | Total waste dilution (\%) | Backfill dilution (\%) | Mining recovery (\%) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| 2018 | 16 | 0.26 | 0.91 | 3.4 | 0.30 | 0.88 | 2.9 | 6.2 | 0.7 | 93 |
| 2019 | 33 | 0.44 | 3.01 | 3.9 | 0.64 | 2.16 | 5.9 | 9.9 | 2.1 | 93 |
| 2020 | 37 | 0.44 | 1.63 | 5.1 | 0.86 | 2.23 | 7.8 | 12.9 | 4.3 | 88 |
| 2021 | 46 | 0.43 | 1.37 | 4.9 | 1.08 | 3.67 | 8.9 | 13.8 | 2.1 | 96 |
| 2022 | 49 | 0.53 | 1.76 | 6.4 | 1.00 | 3.44 | 10.9 | 17.2 | 3.3 | 94 |
| Total / <br> Average | 181 | 0.45 | 3.01 | 5.1 | 0.90 | 3.67 | 8.5 | 13.6 | 2.7 | 93 |
| Parameter values used in the estimation |  | 0.5 |  |  | 1.0 |  |  |  | $0 \%$ to $4 \%$ <br> Average: $2 \%$ | 92 |![img-50.jpeg](img-50.jpeg)

Figure 15.3 - Isometric view of categorized MSO solids and voids model, based on the December 31, 2022, Mineral Resource and Mineral Reserve estimate

[[%~%]]
## 15.7 Mineral Reserves

The Mineral Reserve estimate for the LaRonde Complex includes two underground mines and related silos and stockpiles. The mineral reserves are reported according to CIM Definition Standards. As these standards state, resource model blocks classified as Measured and Indicated ("M\&I") included in the underground mining plan are reported as Proven and Probable mineral reserves. In contrast, Inferred mineral resources cannot be included in mineral reserve estimates and therefore have not been included in the LOM schedule. The stope outlines include a variable dilution envelope around economic ore blocks and enclose marginal material surrounded by economic mineralization.

In most cases, the dilution envelope and enclosed waste are mineralized and have an estimated dilution grade part of the block model. ELOS for dilution is assigned to each mining block or stope (Footwall and Hanging wall). The ore tonnage and grades reported in Table 15.4, Table 15.5 and Table 15.6 include diluted tonnages, grades, and mining recovery rates as estimated from the detailed mining shapes.Table 15.4 - Mineral Reserve estimate for LaRonde Complex, as at December 31, 2022 (gold only)

| Deposit | Category | Tonnage <br> (000 t) | Gold <br> grade <br> (g/t) | Gold <br> (000 oz.) |
| :-- | :-- | --: | --: | --: |
| LaRonde | Proven | 2,809 | 5.23 | 473 |
|  | Probable | 9,497 | 6.69 | 2,042 |
|  | Proven and Probable | 12,306 | 6.36 | 2,515 |
| LZ5 | Proven | 4,904 | 2.08 | 327 |
|  | Probable | 5,490 | 2.17 | 383 |
|  | Proven and Probable | 10,394 | 2.12 | 710 |
| LaRonde Complex Total | Proven | $\mathbf{7 , 7 1 3}$ | $\mathbf{3 . 2 3}$ | $\mathbf{8 0 0}$ |
|  | Probable | $\mathbf{1 4 , 9 8 7}$ | $\mathbf{5 . 0 3}$ | $\mathbf{2 , 4 2 5}$ |
|  | Proven and Probable | $\mathbf{2 2 , 6 9 9}$ | $\mathbf{4 . 4 2}$ | $\mathbf{3 , 2 2 5}$ |

Notes to accompany the Mineral Reserve estimate:

1. Mineral Reserves have been estimated by David Pitre, P.Eng., P.Geo., an employee of Agnico Eagle Mines Ltd, LaRonde Division, and a "Qualified Person" as defined by NI 43-101. The Mineral Reserve estimate conforms to CIM 2014 Standards.
2. Mineral Reserves are reported by deposit at various calculated cut-off grades, based on NSR for polymetallic lenses or based on gold grades for gold-rich lenses. The cut-off grades and NSR values are based on metal price assumptions of US\$1,300/oz for gold, US\$18/oz for silver, US\$3.00/lb for copper, US\$1.00/lb for zinc, actual realized gold and base metals processing recovery (Table 15.1), and operating cost assumptions based on 2023 LaRonde Complex LOM mining plan and Budget.
3. Tonnage and ounces columns are rounded to the nearest thousand.Table 15.5 - Mineral Reserve estimate for LaRonde deposit, as at December 31, 2022

| Mineral reserves by zone | Tonnage <br> $(\mathbf{t})$ | Gold <br> grade <br> $(\mathbf{g} / \mathbf{t})$ | Silver <br> grade <br> $(\mathbf{g} / \mathbf{t})$ | Copper <br> grade <br> $(\%)$ | Zinc <br> grade <br> $(\%)$ | Gold <br> $(\mathbf{o z}$.) | Silver <br> $(\mathbf{o z}$.) | Copper <br> $(\mathbf{k g})$ | Zinc <br> $(\mathbf{k g})$ |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Proven Mineral Reserve (Underground) |  |  |  |  |  |  |  |  |  |  |  |
| LaRonde 2 - Zone 20 North | $1,894,001$ | 5.19 | 14.33 | 0.19 | 0.54 | 315,805 | 872,663 | $3,550,918$ | $10,305,834$ |  |  |
| LaRonde 3 - Zone 20 North | 417,468 | 5.31 | 8.00 | 0.33 | 0.08 | 71,289 | 107,407 | $1,365,719$ | 338,763 |  |  |
| Terrex-LaRonde 2 - Zone 20 North | 426,198 | 5.53 | 34.76 | 0.28 | 2.41 | 75,722 | 476,246 | $1,182,788$ | $10,286,481$ |  |  |
| LP1- Massive Zone | 20,010 | 2.22 | 5.54 | 0.08 | 0.07 | 1,428 | 3,563 | 16,580 | 14,369 |  |  |
| Silos and stockpiles | 51,274 | 5.08 | 15.33 | 0.24 | 0.88 | 8,368 | 25,274 | 124,820 | 452,432 |  |  |
| Total Proven Mineral Reserves | $\mathbf{2 , 8 0 8 , 9 5 2}$ | $\mathbf{5 . 2 3}$ | $\mathbf{1 6 . 4 5}$ | $\mathbf{0 . 2 2}$ | $\mathbf{0 . 7 6}$ | $\mathbf{4 7 2 , 6 1 2}$ | $\mathbf{1 , 4 8 5 , 1 5 3}$ | $\mathbf{6 , 2 4 0 , 8 2 6}$ | $\mathbf{2 1 , 3 9 7 , 8 7 9}$ |  |  |
| Probable Mineral Reserve (Underground) |  |  |  |  |  |  |  |  |  |  |  |
| LaRonde 2 - Zone 20 North | $1,130,689$ | 6.75 | 3.72 | 0.05 | 0.06 | 245,240 | 135,325 | 522,115 | 656,326 |  |  |
| LaRonde 3 - Zone 20 North | $1,591,667$ | 5.36 | 24.33 | 0.35 | 1.63 | 274,334 | $1,245,159$ | $5,646,453$ | $25,897,475$ |  |  |
| Terrex-LaRonde 2 - Zone 20 North | $1,858,802$ | 6.73 | 38.03 | 0.36 | 2.42 | 402,290 | $2,272,708$ | $6,638,559$ | $44,914,419$ |  |  |
| Terrex-LaRonde 3 - Zone 20 North | $3,559,348$ | 8.55 | 22.77 | 0.38 | 0.95 | 978,312 | $2,606,003$ | $13,529,241$ | $33,763,517$ |  |  |
| LP1 - Massive Zone | $1,356,215$ | 3.26 | 7.21 | 0.08 | 0.06 | 142,265 | 314,260 | $1,085,125$ | 865,323 |  |  |
| Total Probable Mineral Reserves | $\mathbf{9 , 4 9 6 , 7 2 1}$ | $\mathbf{6 . 6 9}$ | $\mathbf{2 1 . 5 3}$ | $\mathbf{0 . 2 9}$ | $\mathbf{1 . 1 2}$ | $\mathbf{2 , 0 4 2 , 4 4 1}$ | $\mathbf{6 , 5 7 3 , 4 5 4}$ | $\mathbf{2 7 , 4 2 1 , 4 9 3}$ | $\mathbf{1 0 6 , 0 9 7 , 0 6 0}$ |  |  |
| Total Proven \& Probable Mineral Reserves | $\mathbf{1 2 , 3 0 5 , 6 7 3}$ | $\mathbf{6 . 3 6}$ | $\mathbf{2 0 . 3 7}$ | $\mathbf{0 . 2 7}$ | $\mathbf{1 . 0 4}$ | $\mathbf{2 , 5 1 5 , 0 5 3}$ | $\mathbf{8 , 0 5 8 , 6 0 7}$ | $\mathbf{3 3 , 6 6 2 , 3 1 8}$ | $\mathbf{1 2 7 , 4 9 4 , 9 3 9}$ |  |  |Table 15.6 - Mineral Reserve estimate for LZ5 deposit, as at December 31, 2022

| Mineral Reserves by zone | Tonnage <br> $(\mathbf{t})$ | Gold grade <br> $(\mathbf{g} / \mathbf{t})$ | Gold <br> (oz.) |
| :-- | --: | --: | --: |
| Proven Mineral Reserve (Underground) |  |  |  |
| B1 - Zone 4 and Zone 41 | 34,466 | 1.99 | 2,210 |
| B1 - Zone 5 | $3,910,831$ | 2.02 | 253,450 |
| B1 - Zone 1 | 219,287 | 2.10 | 14,803 |
| B1 - Zone 2 | 475,498 | 2.32 | 35,406 |
| B1 - Zone 3 HW | 173,020 | 2.87 | 15,946 |
| B1 - Zone 3 FW | - | - | - |
| Silos and stockpiles | 90,544 | 1.92 | 5,596 |
| Total Proven Mineral Reserves | $\mathbf{4 , 9 0 3 , 6 4 5}$ | $\mathbf{2 . 0 8}$ | $\mathbf{3 2 7 , 4 1 1}$ |
| Probable Mineral Reserve (Underground) |  |  |  |
| B1 - Zone 4 and Zone 41 | 38,130 | 1.55 | 1,901 |
| B1 - Zone 5 | $3,964,481$ | 2.15 | 274,643 |
| B1 - Zone 2 | 43,464 | 2.21 | 3,089 |
| B1 - Zone 3 HW | 182,686 | 2.57 | 15,106 |
| B1 - Zone 3 FW | 56,507 | 2.70 | 4,896 |
| E - Zone 5 | $1,177,090$ | 2.14 | 81,099 |
| E - Zone 4 and Zone 41 | 27,578 | 2.19 | 1,941 |
| Total Probable Mineral Reserves | $\mathbf{5 , 4 8 9 , 9 3 7}$ | $\mathbf{2 . 1 7}$ | $\mathbf{3 8 2 , 6 7 5}$ |
| Total Proven and Probable Mineral Reserves | $\mathbf{1 0 , 3 9 3 , 5 8 2}$ | $\mathbf{2 . 1 2}$ | $\mathbf{7 1 0 , 0 8 6}$ |

Based on the information presented in Sections 16 to 22 of the Technical Report, the LaRonde Division can demonstrate the economic viability of the proposed extraction and processing of the Proven and Probable mineral reserves found within the mine plan at the LaRonde Complex.
The QP responsible for this section of the Technical Report is not aware of any mining, metallurgical, infrastructure, permitting or other relevant factors that would materially affect the Mineral Reserve estimate.

[[%~%]]
## 15.8 Tonnage And Grade Reconciliation Versus Mineral Reserves

At the LaRonde Complex, a detailed reconciliation process compares mineral reserve estimates to realized production at the mill. This validation process has several purposes: to validate if the resource block model is accurate; to monitor and adequately adjust mineral reserves parameters such as dilution and mining recovery rate; and to measure the ability to predict tonnage and grade in the Company's different forecast and budgeting processes. In addition, this reconciliation allows the Geology and Engineering departments to adjust the parameters of the mineral reserve estimate if needed.

Tonnage and grade reconciliation between mineral reserves and production balanced with the mill is carried out by LaRonde Division employees monthly with an annual compilation. Table 15.7 and Table 15.8 present the annual reconciliation results for production beginning in 2011 up to December 2022 for the LaRonde deposit and since the start of production in 2018 up to December 2022 for the LZ5 deposit.

For the LaRonde deposit annually, the variance between mill production and mineral reserves, based on contained gold, has ranged from $+0.7 \%$ to $+40.5 \%$ with an average over the last 10 years of $+19.0 \%$. On average, the realized gold grade is $4.5 \%$ higher than estimated with the mineral reserves, while tonnes are $13.8 \%$ higher than estimated. Although some variation occurs every month, typical in many operations, the overall reconciliation demonstrates good representativity of the reserve block model and the production parameters used for the mineral reserves are conservative. Upgrade on gold grades is interpretated to be the result of a late goldremobilization event that is difficult to capture with diamond drilling.
For the LZ5 deposit during the last three complete years of production, the variance between mill production and mineral reserves, based on contained gold, has ranged from $+11.1 \%$ to $+56.2 \%$ with an average of $+29.7 \%$ since the beginning. The positive variance is explained by the extraction of tonnes between a short-term COG (based on three-month metal prices average) and the mineral reserve COG in conjunction with a higher realized gold price than expected. The inclusion of these opportunities in the mining plan did not negatively impact the expected grades. On average, the realized gold grade is $5.7 \%$ higher than estimated with the mineral reserves, while tonnes are $22.7 \%$ higher than estimated. Initially designed with a 2,000 tpd output, LZ5 is expected to produce at 3,200 tpd and periodically up to 3,800 tpd. The overall reconciliation for LZ5 demonstrates good representativity of the reserve block model and the production parameters used for the mineral reserves.

[[%~%]]
### 15.8.1 Reconciliation Of Stopes Production Versus Mineral Resource Block Model With Cms

The CMS allows the LaRonde Complex's Technical Services to have a 3D survey of every stope mined out. The Geology Department performs a reconciliation study on every stope mined out by interrogating the Mineral Resource block model within the "As-mined" CMS survey shape. The Mineral Resource for that stope can then be compared to the actual production reconciled with the mill. This comparison is valuable to validate Mineral Resource model parameters without the effect of mining performances as dilution and mining recovery. This validation is performed using the actual volume of the mined block. Table 15.9 and Table 15.10 compare 3D reconciliated stopes for the LaRonde and LZ5 mines through recent years.
Over the past 10 years of production at the LaRonde Mine, the annual variance between mill production and mineral resource block model (Table 15.9), based on contained gold, has averaged $10.4 \%$ and ranged from $+0.6 \%$ to $+20.5 \%$. The positive upgrade is related to late gold remobilization in narrow super-high grade ( $>80 \mathrm{~g} / \mathrm{t}$ gold) quartz veins. After review, gold cappinghas been increased (at the end of 2020) to 200 g/t gold in almost all domains of Zone 20 North at depth to improve reconciliation performance.

Based on contained gold, Table 15.10 shows the variance between mill production and the mineral resource block model at the LZ5 Mine has averaged $6.4 \%$ over the entire mine life, with a range of $+5.1 \%$ to $+7.6 \%$. The overall reconciliation demonstrates good representativity of the resource block model and the production.Table 15.7 - Annual reconciliation between Mineral Reserves and production, reconciled with milling results for LaRonde deposit

| Year | Ore mined (reconciled to mill) |  |  | Mineral Reserves |  |  | Variance |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | Tonnage <br> (t) | Gold <br> (oz.) | Gold <br> grade <br> (g/t) | Tonnage <br> (t) | Gold <br> (oz.) | Gold <br> grade <br> (g/t) | \% oz. | \% gold <br> grade | \% tonnage |
| 2011 | 1,833,583 | 101,508 | 1.72 | 1,567,541 | 88,829 | 1.76 | $14.3 \%$ | $-2.3 \%$ | $17.0 \%$ |
| 2012 | 2,014,862 | 153,024 | 2.36 | 1,912,579 | 151,953 | 2.47 | $0.7 \%$ | $-4.4 \%$ | $5.3 \%$ |
| 2013 | 2,098,836 | 174,674 | 2.59 | 1,960,038 | 172,123 | 2.73 | $1.5 \%$ | $-5.2 \%$ | $7.1 \%$ |
| 2014 | 1,880,989 | 199,011 | 3.29 | 1,855,062 | 195,039 | 3.27 | $2.0 \%$ | $0.6 \%$ | $1.4 \%$ |
| 2015 | 1,983,214 | 255,092 | 4.00 | 1,745,443 | 228,608 | 4.07 | $11.6 \%$ | $-1.8 \%$ | $13.6 \%$ |
| 2016 | 1,864,275 | 280,387 | 4.68 | 1,504,511 | 235,983 | 4.88 | $18.8 \%$ | $-4.1 \%$ | $23.9 \%$ |
| 2017 | 2,168,651 | 346,542 | 4.97 | 1,779,856 | 275,803 | 4.82 | $25.6 \%$ | $3.1 \%$ | $21.8 \%$ |
| 2018 | 1,803,057 | 308,696 | 5.33 | 1,663,613 | 260,227 | 4.87 | $18.6 \%$ | $9.5 \%$ | $8.4 \%$ |
| 2019 | 1,908,353 | 334,791 | 5.46 | 1,672,585 | 265,218 | 4.93 | $26.2 \%$ | $10.6 \%$ | $14.1 \%$ |
| 2020 | 1,630,472 | 290,619 | 5.54 | 1,433,085 | 230,216 | 5.00 | $26.2 \%$ | $11.0 \%$ | $13.8 \%$ |
| 2021 | 1,737,607 | 316,000 | 5.66 | 1,438,564 | 255,859 | 5.53 | $23.5 \%$ | $2.3 \%$ | $20.8 \%$ |
| 2022 | 1,703,582 | 308,091 | 5.63 | 1,349,296 | 219,229 | 5.05 | $40.5 \%$ | $11.3 \%$ | $26.3 \%$ |
| Total | 22,627,481 | 3,068,436 | 4.22 | 19,882,171 | 2,579,087 | 4.03 | $19.0 \%$ | $4.5 \%$ | $13.8 \%$ |Table 15.8 - Annual reconciliation between Mineral Reserves and production, reconciled with milling results for LZ5 deposit

| Year | Ore mined (reconciled to mill) |  |  | Mineral Reserves |  |  | Variance |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | Tonnage <br> (t) | Gold <br> (oz.) | Gold <br> grade <br> (g/t) | Tonnage <br> (t) | Gold <br> (oz.) | Gold <br> grade <br> (g/t) | \% oz. | \% gold <br> grade | \% tonnage |
| 2018 | 224,643 | 18,521 | 2.56 | 291,838 | 19,286 | 2.06 | $-4.0 \%$ | $24.8 \%$ | $-23.0 \%$ |
| 2019 | 869,569 | 63,463 | 2.27 | 674,543 | 42,617 | 1.97 | $48.9 \%$ | $15.5 \%$ | $28.9 \%$ |
| 2020 | 967,990 | 65,204 | 2.10 | 643,827 | 41,743 | 2.02 | $56.2 \%$ | $3.9 \%$ | $50.3 \%$ |
| 2021 | 1,124,014 | 74,927 | 2.07 | 883,961 | 57,599 | 2.03 | $30.1 \%$ | $2.3 \%$ | $27.2 \%$ |
| 2022 | 1,167,466 | 77,015 | 2.05 | 1,053,879 | 69,338 | 2.05 | $11.1 \%$ | $0.3 \%$ | $10.8 \%$ |
| Total | 4,353,682 | 299,130 | 2.14 | 3,548,048 | 230,583 | 2.02 | $29.7 \%$ | $5.7 \%$ | $22.7 \%$ |Table 15.9 - Annual reconciliation between Actual Ore Mined from stopes (reconciled to mill) and Mineral Resource block model interrogated within as-mined CMS shapes for LaRonde deposit

| Year | Actual Ore Mined (reconciled to mill) |  |  | Mineral Resources BM mined (inside CMS) |  |  | Variance |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | Tonnage <br> (t) | Gold <br> (oz.) | Gold <br> grade <br> (g/t) | Tonnage <br> (t) | Gold <br> (oz.) | Gold <br> grade <br> (g/t) | $\%$ <br> oz. | \% <br> gold <br> grade | \% <br> tonnes |
| 2011 | 1,832,532 | 101,432 | 1.72 | 1,804,180 | 96,170 | 1.66 | $5.5 \%$ | $3.8 \%$ | $1.6 \%$ |
| 2012 | 1,918,286 | 144,070 | 2.34 | 1,872,417 | 137,143 | 2.28 | $5.1 \%$ | $2.5 \%$ | $2.4 \%$ |
| 2013 | 1,909,182 | 156,968 | 2.56 | 1,868,337 | 156,006 | 2.60 | $0.6 \%$ | $-1.5 \%$ | $2.2 \%$ |
| 2014 | 1,719,316 | 181,540 | 3.28 | 1,712,199 | 177,300 | 3.22 | $2.4 \%$ | $2.0 \%$ | $0.4 \%$ |
| 2015 | 1,802,304 | 231,131 | 3.99 | 1,705,264 | 220,416 | 4.02 | $4.9 \%$ | $-0.8 \%$ | $5.7 \%$ |
| 2016 | 1,670,146 | 250,199 | 4.66 | 1,621,406 | 236,632 | 4.54 | $5.7 \%$ | $2.6 \%$ | $3.0 \%$ |
| 2017 | 1,953,718 | 311,788 | 4.96 | 1,819,256 | 270,528 | 4.63 | $15.3 \%$ | $7.3 \%$ | $7.4 \%$ |
| 2018 | 1,611,113 | 276,909 | 5.35 | 1,595,031 | 248,944 | 4.85 | $11.2 \%$ | $10.1 \%$ | $1.0 \%$ |
| 2019 | 1,690,054 | 299,213 | 5.51 | 1,640,192 | 255,851 | 4.85 | $16.9 \%$ | $13.5 \%$ | $3.0 \%$ |
| 2020 | 1,439,050 | 261,517 | 5.65 | 1,399,619 | 224,422 | 4.99 | $16.5 \%$ | $13.3 \%$ | $2.8 \%$ |
| 2021 | 1,548,687 | 280,829 | 5.64 | 1,466,460 | 256,279 | 5.44 | $9.6 \%$ | $3.8 \%$ | $5.6 \%$ |
| 2022 | 1,418,086 | 257,791 | 5.65 | 1,389,813 | 213,999 | 4.79 | $20.5 \%$ | $18.1 \%$ | $2.0 \%$ |
| Total | 20,512,474 | 2,753,386 | 4.18 | 19,894,173 | 2,493,692 | 3.90 | $10.4 \%$ | $7.1 \%$ | $3.1 \%$ |Table 15.10 - Annual reconciliation between Actual Ore Mined from stopes (reconciled to mill) and Mineral Resource block model interrogated within as-mined CMS shapes for LZ5 deposit

| Year | Actual Ore mined (reconciled to mill) |  |  | Mineral Resources BM mined (inside CMS) |  |  | Variance |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | Tonnage <br> (t) | Gold <br> (oz.) | Gold <br> grade <br> (g/t) | Tonnage <br> (t) | Gold <br> (oz.) | Gold <br> grade <br> (g/t) | $\%$ <br> oz. | \% <br> gold <br> grade | \% <br> Tonnage |
| 2018 | 203,314 | 16,935 | 2.59 | 206,846 | 15,967 | 2.40 | $6.1 \%$ | $7.9 \%$ | $-1.7 \%$ |
| 2019 | 609,515 | 44,671 | 2.28 | 606,634 | 41,509 | 2.13 | $7.6 \%$ | $7.1 \%$ | $0.5 \%$ |
| 2020 | 676,118 | 46,108 | 2.12 | 676,833 | 42,863 | 1.97 | $7.6 \%$ | $7.7 \%$ | $-0.1 \%$ |
| 2021 | 961,064 | 64,349 | 2.08 | 967,211 | 60,705 | 1.95 | $6.0 \%$ | $6.7 \%$ | $-0.6 \%$ |
| 2022 | 1,007,548 | 68,699 | 2.12 | 1,029,342 | 65,340 | 1.97 | $5.1 \%$ | $7.4 \%$ | $-2.1 \%$ |
| Total | 3,457,559 | 240,762 | 2.17 | 3,486,867 | 226,384 | 2.02 | $6.4 \%$ | $7.3 \%$ | $-0.8 \%$ |

[[%~%]]
## 15.9 Sensitivity Of Mineral Reserves To Gold Prices

Table 15.11 summarizes the results of a sensitivity study conducted on Proven and Probable mineral reserves at the LaRonde deposit, where a $\pm$ US $\$ 130$ ( $\pm 10 \%$ ) variation from a fixed gold price of US $\$ 1,300$ was applied. The study found that the LaRonde deposit exhibits low sensitivity to gold prices, with an average variance of $2.8 \%$, attributed mainly to its high-grade deposit. As a result, the average NSR value for the LaRonde deposit is close to C\$357 per tonne for a longterm COG of C\$219 NSR per tonne (mid-term COG of C\$214 NSR). On the other hand, the LZ5 deposit shows a higher sensitivity ( $12.5 \%$ average variance) to gold prices, as expected for a lower grade deposit (Table 15.12). The average gold grade at the LZ5 deposit is $2.12 \mathrm{~g} / \mathrm{t}$ gold, for an average COG of $1.62 \mathrm{~g} / \mathrm{t}$ gold.

Table 15.11 - Mineral Reserve sensitivity for LaRonde deposit

|  | At <br> US\$1,300/oz. | At <br> US\$1,430/oz. |  | At <br> US\$1,170/oz. |  | Average variance |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Category by zone | Total gold (oz.) | Gold gain (oz.) | Variance (\%) | Gold loss (oz.) | Variance (\%) | In ounces (oz.) | In percentage (\%) |
| Proven and Probable Mineral Reserves |  |  |  |  |  |  |  |
| Total - LaRonde | $2,371,360$ | 37,184 | $1.6 \%$ | $(81,714)$ | $-3.4 \%$ | 59,449 | $2.5 \%$ |
| LP1 - Massive <br> Zone (Area 11-3) | 143,693 | 9,030 | $6.3 \%$ | $(10,616)$ | $-7.4 \%$ | 9,823 | $6.8 \%$ |
| Total Proven and Probable Mineral Reserves | 2,515,053 | 46,214 | $1.8 \%$ | $(92,330)$ | $-3.7 \%$ | 69,272 | $2.8 \%$ |

Table 15.12 - Mineral Reserve sensitivity for LZ5 deposit

|  | At <br> US\$1,300/oz. | At <br> US\$1,430/oz. |  | At <br> US\$1,170/oz. |  | Average variance |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Category by zone | Total gold (oz.) | Gold <br> gain <br> (oz.) | Variance (\%) | Gold <br> loss <br> (oz.) | Variance (\%) | In ounces (oz.) | In percentage (\%) |
| Proven and Probable Mineral Reserves |  |  |  |  |  |  |  |
| Zone 5 | 620,840 | 72,492 | $11.7 \%$ | $(81,922)$ | $-13.2 \%$ | 77,207 | $12.4 \%$ |
| Zone 3 Area | 89,247 | 10,515 | $11.8 \%$ | $(11,883)$ | $-13.3 \%$ | 11,199 | $12.5 \%$ |
| Total Proven and Probable <br> Mineral Reserves | 710,087 | 83,007 | $11.7 \%$ | $(93,805)$ | $13.2 \%$ | 88,406 | $12.5 \%$ |

[[@~@]]
# 16 Mining Methods

At the LaRonde Complex, several critical factors must be considered when selecting the most suitable mining methods. These factors include geology and geotechnical information, orebody geometry, productivity, and mining experience. Additional considerations are lateral development, production and backfilling.
The LaRonde Complex currently uses variations of the longhole open stoping method. Benefits of longhole mining include reduced exposure to risk as a non-entry method, higher productivity and lower costs. In transverse longhole open stope mining, the ore is undercut at the top and bottom of the block from cross-cuts off the footwall drift, providing access for drilling and mucking. Next, a primary-secondary sequence is applied using paste backfill ("pastefill"). In longitudinal retreat mining, the stope is undercut in ore at the top and bottom of the block providing access for drilling and mucking.
At the LaRonde Mine at the LaRonde Complex, based on the experience acquired by the Company since the beginning of the operation, longitudinal and transverse longhole open stoping are the main mining methods used for the extraction of the orebody. The longitudinal method is used for narrow ore widths above Level 215. The transverse mining method is the standard mining method for the operation below Level 215. This method is well adapted to address concerns regarding the high stress conditions encountered in the lower levels of the LaRonde Mine. Below Level 269, the distance between levels is maintained at 30 metres.
Different mining sequences are used to manage the stress front in the operation. The primarysecondary sequence is used with an overhand advance. An underhand mining method has been developed in the operation and it allows flexibility in accessing stopes without creating multiple sill pillars to achieve production. Combining overhand and underhand mining sequences creates a diamond-shaped mining front that helps push the stress away from the orebody to reduce the seismic risk. With the deepening of the mine, a pillarless sequence has been implemented in the abutments where the stress concentration nearby the stopes needed to be pushed back more progressively. The pillarless sequence consists of mining the stopes sequentially to remove the usage of temporary pillars, rather than a primary-secondary stope sequence. This mining sequence has been successfully used in overhand mining front since 2019. Starting in 2023, East Mine at depth is transitioning towards a pillarless mining sequence to reduce the seismic risk of the West underhand abutment. The pillarless sequence results in a longer cycle time when compared to the primary-secondary sequence, resulting in a reduced mining rate. However, this method reduces the seismic risk and promotes the sustainability of the operation in the long run.
At the LZ5 Mine, two variations of longhole open-stope mining are used. The transverse longhole stoping is used in sectors with poor ground quality versus the longitudinal retreat method in areas with better ground quality, or the width of the orebody cannot justify the costs of transverse mining. A geotechnical analysis is used to determine the typical stope sizes. The rock quality and hydraulic radius of the exposed hanging wall, footwall and back of the stope are also critical factors. Stope dimensions range between 30 m and 40 m in height, 15 m in length and up to 30 m in width.

[[%~%]]
## 16.1 Production Rate And Expected Life Of Mine

[[%~%]]
### 16.1.1 Laronde Mine

The 2023 LOM indicates scheduled production from 2023 to 2036 at the LaRonde Mine (Table 16.1). During this period, 12.9 million tonnes of ore will be hoisted via the Penna Shaft. An average of 3,915 tpd of ore is scheduled to be produced from 2023 to 2027, to be followed by declining extraction rates until mineral reserve depletion in 2036.The LOM planning process constantly evolves with multiple parameters, such as the mineral reserves assessment, mining sequence adjustments, and mining operational parameters. Deswik mine planning software was used to help create the LOM at the LaRonde Mine.

Table 16.1 - 2023 LOM production at LaRonde Mine (2023-2036)

|  | 2023 | 2024 | 2025 | 2026 | 2027 | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 | 2035 | 2036 |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Tonnage <br> mined <br> $(000 \mathrm{t})$ | 1,488 | 1,452 | 1,448 | 1,387 | 1,371 | 988 | 985 | 912 | 730 | 549 | 438 | 438 | 365 | 312 |
| Recovered <br> gold (oz.) | 214,319 | 217,492 | 234,068 | 230,592 | 241,814 | 211,550 | 216,370 | 179,558 | 204,660 | 96,769 | 99,768 | 103,817 | 80,028 | 64,375 |

[[%~%]]
### 16.1.2 Lz5 Mine

The 2023 LOM production plan for the LZ5 Mine is presented in Table 16.2. There is a slight variance between the 2023 LOM for LZ5 and the mineral reserves, as the year-end 2022 mineral reserve estimation was completed after the 2023 LOM. However, the variance will not significantly impact the mining strategies in the LOM production plan because the additions or losses are within the orebody trend and will be mined using the same mining rates and methods.
Over the LOM, approximately 10.5 million tonnes will be mined at a rate of 3,200 to 3,800 tpd. The mine will produce about 90,000 oz. of gold annually at peak production. Deswik mine planning software was used to help create this LOM at LZ5 Mine. Historical rates for mining activities such as mucking, hauling and drilling were utilized in the Deswik mine planning software to create an accurate LOM. Other factors that were applied included equipment and workforce capabilities.

Table 16.2 - 2023 LOM production at LZ5 Mine (2023-2032)

|  | 2023 | 2024 | 2025 | 2026 | 2027 | 2028 | 2029 | 2030 | 2031 | 2032 |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Tonnage mined <br> $(000 \mathrm{t})$ | 1,155 | 1,155 | 1,236 | 1,371 | 1,371 | 1,371 | 975 | 750 | 500 | 133 |
| Recovered gold <br> (oz.) | 71,421 | 72,881 | 81,403 | 94,907 | 90,287 | 93,930 | 65,115 | 48,178 | 34,045 | 8,662 |

[[%~%]]
## 16.2 Requirement For Development

[[%~%]]
### 16.2.1 Laronde Mine

In LOM 2023, a total of 70.4 km of horizontal development will be required for the operation from 2023 to 2036, including 11.8 km planned in 2023 (Table 16.3). The annual amount of development until 2036 will be reduced progressively until the end of the operation. Vertical development is mainly to extend the intake and exhaust network by combining $16^{\prime}$ and $22^{\prime}$ diameter raises for the main network and $14^{\prime}$ diameter raises used for the escape way and delivery of fresh air to the level. In addition, smaller diameter raises ranging from $6^{\prime}$ to $8^{\prime}$ are used on specific occasions for secondary ventilation.Table 16.3 - 2023 LOM development at LaRonde Mine (2023-2036)

|  | 2023 | 2024 | 2025 | 2026 | 2027 | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 | 2035 | 2036 |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Horizontal <br> development <br> (m) | 11,771 | 10,215 | 8,639 | 8,148 | 6,565 | 5,918 | 4,489 | 3,820 | 3,396 | 2,270 | 2,153 | 1,124 | 1,099 | 852 |
| Vertical <br> development <br> (m) | 454 | 191 | 466 | 206 | 463 | 111 | 194 | 179 | 37 | 218 | 0 | 221 | 0 | 0 |

[[%~%]]
### 16.2.2 Lz5 Mine

All horizontal development at LZ5 will be achieved with a dedicated mine development crew consisting of Agnico Eagle and CMAC contractor personnel. Over the mine life, 35.5 km of horizontal development will be needed to extract the mineral reserves at LZ5 (Table 16.4). However, the development will be decreased substantially after 2027 once the major mine infrastructure has been established.
Vertical development at LZ5 will be achieved with contractors for the larger 12' diameter exhaust raises and an AEM raisebore for the smaller 6' diameter raises. Vertical development is used at LZ5 to create the 6' secondary emergency egress and the 12' main exhaust raise.

Table 16.4 - 2023 LOM development at LZ5 Mine (2023-2032)

|  | 2023 | 2024 | 2025 | 2026 | 2027 | 2028 | 2029 | 2030 | 2031 | 2032 |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Horizontal <br> development <br> (m) | 7,045 | 7,110 | 6,450 | 6,100 | 5,070 | 1,290 | 690 | 450 | 190 | 0 |
| Vertical <br> development <br> (m) | 425 | 248 | 116 | 271 | 73 | 0 | 0 | 0 | 0 |  |

[[%~%]]
## 16.3 Backfill

All stopes at the LaRonde Mine and LZ5 Mine require backfill to maintain long term stability. Backfill is either an unconsolidated waste rock fill ("URF") or consolidated paste backfill. URF is used in secondary transverse longhole stopes that will not be exposed to further mining. The consolidated pastefill is used in primary transverse longhole stopes and longitudinal longhole stopes which will be exposed to future mining.

[[%~%]]
### 16.3.1 Laronde Mine

The surface paste backfill plant has been designed to produce 200 tonnes of pastefill per hour. From the pastefill plant attached to the LaRonde mill, the backfill is delivered on a batch basis underground by a network of pipes and boreholes up to 6" in diameter to the selected empty stopes. Slag and cement are used as binder at a ratio of 80:20, respectively. The typical formulation has an average of $6 \%$ binder. For secondary stopes, waste rock is commonly used to fill the void (unconsolidated rock fill) and reduce the demand to hoist this material to surface.

[[%~%]]
### 16.3.2 Lz5 Mine

Paste backfill is an engineered product consisting of mill tailings and binder. They are mixed with water to create a thickened paste that is delivered by borehole and pipes to the stopes. Both slag and T10 Portland cement are used as a binder with average content by weight of $3.8 \%$ over the LOM.

Paste backfill for LZ5 is provided from a dedicated paste fill plant at surface that has a capacity of 140 tonnes per hour. The tailings for backfilling are supplied by the LaRonde mill.

[[%~%]]
## 16.4 Mining Fleet And Machinery

[[%~%]]
### 16.4.1 Laronde Mine

The waste/ore material is mucked out with $8 \mathrm{yd}^{3}$ or $11 \mathrm{yd}^{3}$ scoops, dumped into 40 -tonne or 50 tonne trucks and then transported up to the material handling system. The equipment utilized at the LaRonde Mine is summarized in Table 16.5.

The system comprises two parts, with the first used for tonnage above Level 215. Trucks dump the waste/ore material in a silo above the crusher on Level 152. The crushed material, less than 4" in size, is linked at the Penna Shaft (Shaft \#3) with a conveyor and then hoisted to surface.
In the second part below Level 215, the ore is brought to a network comprising two vertical silos close to the orebody with dump points at Level 284 and Level 290. These silos are linked and feed a coarse conveyor over 900 m to reach the crusher at Level 280 close to the Shaft \#4 station. The crushed material ( $<4^{\prime \prime}$ in size) is then skipped via Shaft \#4 and transferred to Shaft \#3 via a conveyor. Finally, the material is skipped (vertically conveyed) to surface using Shaft \#3.
The waste material is trucked to the silo near the station on Level 278 where it will be skipped by Shaft \#4. The transfer of waste material from Shaft \#4 to Shaft \#3 is performed using trucks, and the waste material is then skipped to surface via Shaft \#3.

Table 16.5 - Mining fleet and machinery utilized at LaRonde Mine

| Equipment | Quantity |  |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: |
|  | 2023 | 2024 | 2025 | 2026 | 2027 |
| Trucks (40-50 tm) | 17 | 18 | 18 | 18 | 17 |
| Scoops (8-11 yd ${ }^{3}$ ) | 18 | 16 | 16 | 16 | 15 |
| Jumbos | 7 | 7 | 5 | 4 | 4 |
| Bolters | 24 | 23 | 21 | 21 | 19 |
| LT Drill | 5 | 6 | 6 | 5 | 5 |
| Raise bore | 3 | 3 | 3 | 3 | 3 |

[[%~%]]
### 16.4.2 Lz5 Mine

The LZ5 Mine is accessed via a ramp with production and development being achieved with rubber-tired underground mining equipment. As no shaft exists, all ore and waste from the LZ5 Mine are brought to surface using haul trucks. The mine currently uses 50-tonne trucks and 11-$\mathrm{yd}^{3}$ scoops for production purposes, with the machinery chosen as an optimum compromise between productivity and size. All development at LZ5 is achieved with mechanized equipment. The mining fleet required to meet production and development targets for the next five years is outlined in Table 16.6.

The mucking and hauling fleet at LZ5 is an automated fleet. The scoops and trucks at LZ5 can be operated remotely from surface when no personnel are underground. It has allowed the mine to remain productive during ten 2 -hour shift changes per week and two 14 -hour night shifts on the weekend. The transformation of these previously "lost" hours into productive hours has improved the productivity of the mine.

Table 16.6 - Mining fleet and machinery utilized at LZ5 Mine

| Equipment | Quantity |  |  |  |  |
| :-- | :--: | :--: | :--: | :--: | :--: |
|  | $\mathbf{2 0 2 3}$ | $\mathbf{2 0 2 4}$ | $\mathbf{2 0 2 5}$ | $\mathbf{2 0 2 6}$ | $\mathbf{2 0 2 7}$ |
| Trucks (50 tm) | 10 | 13 | 14 | 14 | 14 |
| Scoops $\left(11 \mathrm{yd}^{3}\right)$ | 5 | 6 | 6 | 6 | 6 |
| Scoops $\left(8 \mathrm{yd}^{3}\right)$ | 2 | 2 | 2 | 2 | 2 |
| Jumbos | 3 | 3 | 3 | 3 | 2 |
| Bolters | 5 | 5 | 5 | 5 | 4 |
| Scissor lifts | 7 | 7 | 7 | 5 | 5 |

[[%~%]]
## 16.5 Geotechnical Parameters

[[%~%]]
### 16.5.1 Laronde Mine

With the depth of the LaRonde Mine extending below 3,000 m, the in-situ stress influences the ground conditions surrounding the excavations. Historically, the LaRonde Mine was more prone to squeezing ground at a higher mine elevation, resulting in some seismicity. At depth, the opposite is observed due to higher stress conditions and better rock mass properties. As a result, the squeezing ground is less present or occurs later in the life of the excavations with less severity than encountered in previous mining at the LaRonde Mine.

An example of the intact rock properties encountered at Level 290 at the LaRonde Mine is presented in Table 16.7.Table 16.7 - Intact rock properties at LaRonde Mine at Level 290

| Rock type | $\sigma \mathbf{c}(\mathbf{M P a})$ | $\mathbf{E}(\mathbf{G P a})$ | $\mathbf{v}(\mathbf{m m} / \mathbf{m m})$ |
| :-- | :--: | :--: | :--: |
| Rhyolite (V9i) | $210-240$ | $60-64$ | $0.24-0.28$ |
| Rhyodacite (V9iG) | $175-210$ | $50-60$ | 0.28 |
| Ore (SZ) | $180-245$ | $70-75$ | $0.25-0.30$ |
| Basalt (V7) | $210-280$ | $42-65$ | 0.30 |
| Andesite (V6) | 200 | 42 | 0.34 |

Seismicity is a primary aspect of the operation, requiring a team of rock mechanics experts to manage the seismic risk. The Company acquired site-specific expertise in mitigating seismic risk over several years of operations at LaRonde. As a result, the mine has gradually been extended to present-day depths below 3 km from surface. However, the objective remains to minimize the seismic risk by introducing mitigation measures to keep a safe work environment while maintaining reasonable production rates.

Seismic events are recorded by a state-of-the-art seismic system from consulting firm ESG Solutions. At the LaRonde Complex, more than 140 sensors are used to record and locate the seismic events. A regional seismic network is available to manage large scale events and is used to measure the magnitude on the Richter scale. An engineer is always on call to respond to any abnormal seismic response from the operation.
Seismicity is usually associated with production blasting. A non-entry protocol is designated for each stope following the history of the previous blasts in the vicinity. The protocol could close the level partially or entirely, extending the impact over many levels. The duration of the protocol is typically 12 hours following the final production blast; however, it may vary depending on the seismic response history of the sector. This strategy avoids having personnel close to any major seismic response following a blast. A non-entry protocol during the first few hours is also used for development headings where a significant seismic response is recorded after a development blast. A special procedure has been developed to address the situation for the entire blasting cycle to minimize the seismic-risk exposure of the workforce.

Different ground support strategies have been developed in response to various anticipated ground conditions. Standard ground support elements such as rebar in the roof and friction bolts in the walls are used in areas without seismicity. In the case of seismicity, dynamic ground support elements are used to prevent or minimize damage from seismic events.
The level designs have been changed to consider the stress induced by the stopes (Figure 16.1). Previously the level was designed to manage the squeezing ground by using a fork system that allows for rapid disposal of the centre access after stopes are mined out and used west-east accesses to complete the mining. These accesses that are developed later in the life of the level do not have the same amount of deformation and may have long term stability. However, at a higher stress level, this fork design has the disadvantage of having a greater proportion of access development located in the stress front (i.e., high stress environment). Thus, the access development is subject to more potential damage. To minimize this risk, the level design has been changed to have a main access in a north-south orientation with a main haulage drive that the stress will progressively shadow the mining front. The history of the LaRonde Mine has demonstrated that north-south accesses are less prone to stress-induced damage.![img-51.jpeg](img-51.jpeg)

Fork system at Level 272
![img-52.jpeg](img-52.jpeg)

Figure 16.1 - Illustration of the location of high stress environments on Level 272 and below Level 305 at LaRonde MineTo reduce the risk of mining personnel being exposed to significant seismic events, it is common practice in areas where the Engineering Department expects high-stress levels after a production blast to use teleoperation from the surface. In this case, the area where the scoop is in operation is closed with barriers and access is prohibited to mining personnel so that the equipment is exposed to seismicity without mining personnel being present. In the West mine, this strategy has been used in most stopes blasted since March 2020. For the East mine, this application will be used increasingly in the future with the deepening of the operation.
The mining sequence is also a key mitigation factor to attempt to push the stress away from the orebody to reduce the seismic risk. A primary-secondary approach remains the most productive approach in the deep and high stress conditions of LaRonde. It allows a rapid ramp-up of the lead stope ensuing a high mining rate and gives the possibility to dispose waste material in secondary stopes during backfilling. However, a large stress envelope is redistributed after blasting the primary stope, resulting in stress concentration on the flank and in the secondary stopes. For the most seismic areas, a pillarless sequence is implemented to reduce furthermore the seismic risk. This approach allows to push progressively the stress away from the excavation, ensuring that the excavations are away from the stress concentrations (Figure 16.2). However, the pillarless mining method allows a slower ramp-up of the lead stope resulting in a lower mining rate, and a higher pastefill requirement.
![img-53.jpeg](img-53.jpeg)

Figure 16.2 - Illustration of stress changes in a primary-secondary mining approach versus a pillarless mining approach

Managing seismic risk management is a fundamental aspect of the LaRonde Mine operations. This is achieved through various measures including designing appropriate levels, sequencing mining activities, managing worker exposure, and gaining a deep understanding of the mine's geology. As mining operations reach greater depths, these risk management strategies need to adapt and embrace innovation and open-mindedness to remain effective over the life of the mine.

[[%~%]]
### 16.5.2 Lz5 Mine

The geotechnical parameters of the mine drive the ground control practices at the LZ5 Mine. The mine maintains a 3D drill core database that is continuously updated and contains drill core observations and Rock Quality Designation data ("RQD"). The major rock domains present at the mine have been identified from this database (Table 16.8). In addition, representative samples of the main domains are regularly tested to determine rock properties including Unconfined Compressive Strength, Young Modulus and Poisson Ratio.Table 16.8 - Rock parameters by domain at LZ5 Mine

| Domain | Description | UCS | RQD | Q' |
| :--: | :--: | --: | --: | --: |
| 1 | HW basalt | 160 | 75 | 9.4 |
| 2 | Zone 3 ore zone | $19-68$ | $0-75$ | $0.3-2.1$ |
| 3 | Zone 3 shear zone | $19-38$ | $0-50$ | $0.3-2.1$ |
| 4 | Intermediary basalt zone | $80-160$ | $50-75$ | $2.1-9.4$ |
| 5 | Zone 5 ore zone | $19-68$ | $25-75$ | $0.7-2.1$ |
| 6 | Zone 5 shear zone | 38 | 25 | 2.1 |
| 7 | FW basalt | 160 | 75 | 9.4 |

Three ground control support standards are used at the mine depending on the drift's orientation, dimensions and geotechnical parameters. The three standards use: friction bolts in the walls; rebar; and friction bolts in the back and wire mesh. The ground support length increases as ground quality decreases or the orientation becomes unfavourable. The galvanized friction bolts have a diameter of 35 mm and a length of 3 to 5 feet. Rebar has a diameter of $5 / 8^{\prime \prime}$ and a length from $6^{\prime} 2^{\prime \prime}$ to $7^{\prime} 6^{\prime \prime}$. The wire mesh is galvanized and is gauge 6 . At intersections with larger spans, the mine makes use of $10-\mathrm{ft}$ rebar or cable bolts.

To ensure safety in areas with large spans and lower-quality rock mass, LZ5 employs ground control monitoring. This is accomplished through instrumented cable bolts to monitor load and elongation in the backs. In addition, a Maptek 3D scanner is used to monitor the convergence of drifts in areas of lower rock quality. This monitoring allows the mine personnel to react proactively to changing ground conditions.

[[%~%]]
## 16.6 Mine Ventilation

[[%~%]]
### 16.6.1 Laronde Mine

The LaRonde Mine is ventilated at 1,500,000 cubic feet per minute ("cfm") with a network of 16 ' and 22 ' diameter raises (intake and exhaust) in a push-pull system. The system is located on surface with two fans at the intake ( 1,750 horsepower or "hp" each) and two fans at the exhaust (3,500 hp each). In addition, underground booster fans have been built during the operation extension on the exhaust side. A 6,000 hp booster fan is located on Level 194. Currently, two additional booster fans are being installed at Level 275 with capacities of 2,500 hp and 4,250 hp. They will be commissioned in 2023.
A cooling plant cools the intake air and allows good working conditions at depth. The capacity is 11,000 refrigerated tonnes ( 38.6 kilowatt or "kW") and the plant is available throughout the year, depending on the outside temperature. An extension is planned for the West mine by adding 2,500 refrigerated tonnes $(8.8 \mathrm{~kW})$ in the future on Level 308.
A ventilation heater is also in place at the intake to heat the cold air in winter ( $100 \mathrm{MMBtu} / \mathrm{h}$ or $30,000 \mathrm{~kW}$ ). The trigger is set to $-20^{\circ} \mathrm{C}$ to allow the best temperature to minimize natural gas consumption.

[[%~%]]
### 16.6.2 Lz5 Mine

The LZ5 Mine is currently ventilated at 340,000 cfm to evacuate and dilute any pollutants created by mining activities. As the fleet's size increases with the mine's deepening, the ventilation rate will be increased to $520,000 \mathrm{cfm}$. The ventilation requirements were assessed using the Quebec Mining Health and Safety Laws which prescribe ventilation requirements for all diesel equipment operating at the mine.
LZ5's ventilation network is a pull system that utilizes the ramp as an intake and a 12-ft raise as the exhaust. The ventilation is driven by 75 hp exhaust fans on multiple levels that push air directly into the exhaust. These smaller exhaust fans eliminate the need for a main exhaust fan. A diagram of the ventilation network is shown in Figure 16.3.
The LZ5 Mine is in a region where temperatures fall below $0^{\circ}$ Celsius in winter. To keep the mine temperature above $8^{\circ} \mathrm{C}$ at all times, the intake system is equipped with 44 MBtu natural gas burners. The mine is directly connected to the Energir natural gas network.
![img-54.jpeg](img-54.jpeg)

Figure 16.3 - Diagram of the ventilation network at LZ5 Mine, showing the ramp (magenta) and raises (green)

[[%~%]]
## 16.7 Mine Dewatering And Drainage

[[%~%]]
### 16.7.1 Laronde Mine

A portion of the infiltration water at the LaRonde Mine is collected by a pumping station for the Dumagami mine, which allows for the LaRonde Mine to not be contaminated with acidic water. The rest of the water is derived from operations (drilling, pastefill, dust suppression, etc.). A part of this water is reused by utilizing a Mudwizard mud-treatment system to remove mud and sediments and to provide clean water for the equipment. The overflow is pumped to surface and treated.

[[%~%]]
### 16.7.2 Lz5 Mine

The LZ5 Mine was developed adjacent to the former Bousquet No. 1 mine, which was flooded after it closed. Therefore, the former Bousquet No. 1 mine workings must be dewatered 30 m below the current mining at the LZ5 Mine to operate safely. Boreholes, submersible well pumps, and pumping stations are utilized to dewater, and all water is subject to treatment at the surface before it is either reused or discharged. Figure 16.4 illustrates the existing dewatering network.
In addition to pumping water from the flooded Bousquet No. 1 mine, mining personnel at LZ5 must pump out water from current mining activities and groundwater infiltration. Therefore, collected water is accumulated in sumps connected to the old Bousquet No. 1 mine with boreholes. This allows one dewatering system to remove water from three sources: the old workings, the current mining areas and groundwater infiltration.
![img-55.jpeg](img-55.jpeg)

Figure 16.4 - Schematic diagram of current dewatering network at LZ5 Mine

[[@~@]]
# 17 Recovery Methods

The processing plant at the LaRonde Complex is comprised of two mills: LaRonde and LZ5. The LaRonde mill has a capacity of 7,200 tpd on a yearly basis, and processes ore containing precious metals (gold and silver) recovered by a carbon in pulp ("CIP") process and ore containing base metals (copper, zinc and lead sulphides) recovered by a flotation process. The LZ5 mill has a capacity of 2,000 tpd and processes gold ore using gravity and carbon in leach ("CIL") processes.

[[%~%]]
## 17.1 Metallurgical Processes And Flowsheet At Laronde Mill

At the LaRonde mill, some major modifications were completed in the mid-2010s. In 2013, the Merrill-Crowe process was replaced by a CIP process to improve recoverability of gold as the orebody was starting to become richer in gold at depth (silver/gold ratio below 5).
In 2016, a study was conducted to compare different expert systems at the LaRonde mill and a multi-disciplinary team was created to validate and, if needed, correct all equipment used in control loops. Expert systems were subsequently added in the grinding circuit and in the copper flotation circuit to maximize recovery and chemical dosage. An expert system was also added at the LZ5 mill in the grinding circuit to maximize tonnage and grind efficiency. A single, collaborative control room was put in place for both mills, where an alarm committee monitors the alarm system to optimize any required intervention by operational teams. The performance of the LaRonde mill from 2010 to 2022 and notable modifications are summarized in Table 17.1.
The LaRonde mill consists of grinding, copper flotation, zinc flotation, and precious metals recovery circuits, a paste fill plant and a refinery (Figure 17.1). Mill criteria are in Table 17.2.

Table 17.1 - Summary of performance at LaRonde mill (2010-22)

| Year | Tonnage per year (t) | Gold grade (g/t) | Gold recovery (\%) | Gold produced (oz.) | Comment |
| :--: | :--: | :--: | :--: | :--: | :--: |
| 2010 | 2,592,292 | 2.17 | 90.04 | 162,647 |  |
| 2011 | 2,406,342 | 1.79 | 89.64 | 124,177 |  |
| 2012 | 2,358,499 | 2.36 | 89.80 | 160,929 | First ore from LR extension project |
| 2013 | 2,319,132 | 2.63 | 92.61 | 181,818 | Merrill-Crowe replaced with CIP and Zadra stripping circuit |
| 2014 | 2,085,346 | 3.24 | 94.36 | 204,743 |  |
| 2015 | 2,241,424 | 3.91 | 95.09 | 267,857 |  |
| 2016 | 2,240,144 | 4.44 | 95.60 | 305,806 | Addition of grinding expert system |
| 2017 | 2,246,114 | 5.05 | 95.62 | 348,842 | Creation of collaborative control room and alarm committee |
| 2018 | 2,108,070 | 5.32 | 95.38 | 343,600 | Addition of copper flotation expert system |
| 2019 | 2,057,187 | 5.46 | 95.00 | 343,172 | LZ5 included in LaRonde |
| 2020 | 1,706,447 | 5.53 | 95.01 | 288,297 | Temporary COVID-19 shutdown. LZ5 in LaRonde |
| 2021 | 1,837,300 | 5.50 | 95.10 | 308,946 |  |
| 2022 | 1,669,900 | 5.62 | 94.36 | 284,780 | Start-up of the residue filtration plant |![img-56.jpeg](img-56.jpeg)

Figure 17.1 - Flowsheet for LaRonde mill (7,200 tpd milling rate)Table 17.2 - Criteria for LaRonde mill

| Sector | Measurement | Minimum | Maximum | Unit |
| :--: | :--: | :--: | :--: | :--: |
| Grinding | Tonnage | 240 | 370 | $\mathrm{Mt} / \mathrm{h}$ |
|  | SAG power | - | 4,500 | kW |
|  | Ball mill power | - | 5,000 | kW |
|  | Mill availability | - | $96.5 \%$ |  |
|  | Gold | - | - | Based on leaching feed |
|  | Silver | - | - | Based on leaching feed |
| Copper flotation | Copper | $0.12 \%$ | $0.5 \%$ |  |
| Zinc flotation | Zinc | $0.3 \%$ | $3.0 \%$ |  |
| Leach | Residence time | 24 | 19.5 | hours |
| CIP | Residence time | 10 | 8.6 | hours |
|  | Gold feed | - | 2.0 | $\mathrm{g} / \mathrm{Mt}$ |
|  | Silver | - | 10.0 | $\mathrm{g} / \mathrm{Mt}$ |
|  | Flow | - | 360 | $\mathrm{~m}^{3} / \mathrm{h}$ |
| Stripping | Carbon load | - | 8,000 | $\mathrm{g} / \mathrm{Mt}$ |
|  | Number of strips | - | 30 | Strips/month |
|  | Carbon tonnage | - | 10 | Mt |
| Cyanide destruction |  | - | 8,000 | Mt/day |
| Paste fill | Tonnage | 160 | 220 | $\mathrm{Mt} / \mathrm{h}$ |

[[%~%]]
### 17.1.1 Crushing

The ore is crushed underground with a jaw crusher. The opening is set at 4.5 inches. There is a standard installation for the grizzly with a hammermill feeding the jaw crusher.

[[%~%]]
### 17.1.2 Grinding

The grinding circuit begins with a truck dump linked by a conveyor gallery to a 5,000-tonne coarse ore bin. The coarse ore bin feeds a semi-autogenous grinding ("SAG") mill in closed loops with hydrocyclones followed by a ball-mill circuit. The grind is determined by the secondary battery of hydrocyclones, and the target is fixed at P80 of $75 \mu \mathrm{~m}$. The grinding circuit product is then sent to the copper flotation circuit. An expert system is operating the circuit.

[[%~%]]
### 17.1.3 Copper Flotation

For copper flotation, the first step is the rougher flotation and its product is sent to copper cleaning flotation with its reject sent to the next step at the zinc flotation. The rougher is composed of a flotation column to produce a part of the final copper concentrate followed by contact cell and mechanical cell that produces the primary concentrate to feed the cleaner stage with a maximum copper recovery. The copper cleaning flotation is necessary to obtain a salable copper concentrate by upgrading the copper content to $19.5 \%$. It is composed of a first cleaner stage of tank cell and a second cleaner stage of contact cell. An expert system is operating the circuit by using data from camera and Courier6 (X-ray online).

[[%~%]]
### 17.1.4 Zinc Flotation

The first step of zinc flotation is a rougher stage, and its product is sent to zinc cleaning flotation with its reject sent to the next step at the precious metal circuit. The rougher is composed by tanks cells to produce the primary concentrate to feed the cleaner stage with a maximum zinc recovery. The zinc cleaning flotation is necessary to obtain a salable zinc concentrate by upgrading the zinc content to $54 \%$. It is composed of a first cleaner stage of mechanical cell, a second cleaner stage of flotation column and a third cleaner stage of flotation column. Circuit optimization is done using data coming from Courier6.

[[%~%]]
### 17.1.5 Leaching And Cip

The precious metals circuit processing the tails from the base metal flotation circuit consists of a leaching circuit, a CIP circuit and a refinery to pour gold doré. The leaching circuit consists of providing contact time between precious metals, oxygen and cyanide to lixiviate the gold and silver. A cyanide control system ("CCS") ensures an optimum cyanide dosage along the leaching circuit. The CIP circuit provides time for the carbon to adsorb the gold onto the carbon. The configuration is a typical countercurrent system using Kemix screen and carbon transfer pump. The carbon concentration in tank is followed by probe (C2 meter) to optimize carbon transfer.

[[%~%]]
### 17.1.6 Stripping And Electrowinning

The stripping and electrowinning process consists of chemically desorbing gold from carbon and onto plates for recovery. The carbon is sent to an acid wash column for removal of contaminants. After the acid wash, the carbon is moved to an elution column. A barren solution containing cyanide and caustic soda at a determined temperature and pressure will desorb gold from carbon and become the pregnant solution. The pregnant solution goes to the electrowinning circuit to plate the gold onto anodes. That solution is then returned to the barren solution and circulated to obtain the optimum stripping efficiency. The process was designed by Como Engineering at 8 Mt of carbon. The gold plating obtained from the electrowinning circuit is poured to produce doré.

[[%~%]]
### 17.1.7 Paste Fill And Cyanide Destruction

The paste fill plant is in operation depending on the mining plan. The precious metal reject is sent to the cyanide destruction tank to undergo the $\mathrm{INCO} \mathrm{SO}_{2} / \mathrm{O}_{2}$ process, and then thickened to obtain paste mixed with cement and slag based on a specific recipe. The Mine Engineering Department will create the recipe based on production database/mechanical resistance tests. The paste is then sent underground to the mined-out stopes for curing. For more information on the paste fill process, refer to Section 16.4.

[[%~%]]
### 17.1.8 Residue Filtration Plant And Preparation For Dry Stack

Construction of the dry stack mill was completed in 2022 with start-up in October 2022. The mill is situated after the tailing pump of the LaRonde and LZ5 mills, where they will feed a thickener of 36 metres. The overflow will go into the C 5 cell and the pulp into two retention tanks (for 8 hours retention time). A vibrating screen will be installed to prevent large particles ( $>5 \mathrm{~mm}$ ) from entering the filter press. The materials are pumped to the filter press to be dried by three filter presses (Outotec FFP3512) at a capacity of up to 10,000 tpd. The dry stack mill is designed to be adaptive to tonnage, which can vary depending on any mill shutdowns and on the pulp sent to the paste fill plant. After drying, material flows through a conveyor to a stockpile at the corner of the A4 tailing pond. The dry stack flowsheet is presented in Figure 17.2 and images of the mill are presented in Figure 17.3, Figure 17.4 and Figure 17.5.![img-57.jpeg](img-57.jpeg)

Figure 17.2 - Dry stack flowsheet for LaRonde Complex![img-58.jpeg](img-58.jpeg)

Figure 17.3 - 3D representation of the dry stack mill at LaRonde Complex
![img-59.jpeg](img-59.jpeg)

Figure 17.4 - Dry stack, filter press floor![img-60.jpeg](img-60.jpeg)

Figure 17.5 - Exterior view of dry stack mill under construction at LaRonde Complex

[[%~%]]
### 17.1.9 Chemical Consumption

A list of the main reagent and consumables consumption for the LaRonde Complex's mill for 2022 is shown in Table 17.3.

Table 17.3 - Average consumption of mill reagents and consumables in 2022 at LaRonde Complex

| Sector | Consumables | Quantity | Unit |
| :--: | :--: | :--: | :--: |
| Grinding | Steel balls 5" | 0.54 | $\mathrm{kg} / \mathrm{t}$ |
|  | Steel balls $11 / 4 "$ | 0.97 | $\mathrm{kg} / \mathrm{t}$ |
| Copper flotation | Aerophine 3418A | 0.004 | $\mathrm{kg} / \mathrm{t}$ |
|  | MIBC (frother) | 0.015 | $\mathrm{kg} / \mathrm{t}$ |
| Zinc flotation | Aerophine 3418A | 0.004 | $\mathrm{kg} / \mathrm{t}$ |
|  | $\mathrm{CuSO}_{4}$ | 0.189 | $\mathrm{kg} / \mathrm{t}$ |
| Leaching | Cyanide | 0.87 | $\mathrm{kg} / \mathrm{t}$ |
|  | Lime | 0.91 | $\mathrm{kg} / \mathrm{t}$ || Sector | Consumables | Quantity | Unit |
| :--: | :--: | :--: | :--: |
|  | Oxygen | 0.70 | $\mathrm{m}^{3} / \mathrm{t}$ |
| Precious metal | Carbon | 0.026 | $\mathrm{kg} / \mathrm{t}$ |
|  | Cyanide | 27 | $\mathrm{kg} / \mathrm{m}^{3}$ pregnant solution |
|  | Hydrochloric acid | 106 | $\mathrm{kg} / \mathrm{m}^{3}$ pregnant solution |
|  | Caustic soda | 92 | $\mathrm{kg} / \mathrm{m}^{3}$ pregnant solution |
| Cyanide destruction | $\mathrm{SO}_{2}$ | 0.90 | $\mathrm{kg} / \mathrm{t}$ |
|  | Oxygen | 0.27 | $\mathrm{m}^{3} / \mathrm{t}$ |
|  | Lime | 0.08 | $\mathrm{kg} / \mathrm{t}$ |
| General | Lime | 2.067 | $\mathrm{kg} / \mathrm{t}$ |
| Water treatment plant | Sodium silicate | 0.14 | $\mathrm{kg} / \mathrm{m}^{3}$ water |
|  | Peroxide | 0.252 | $\mathrm{kg} / \mathrm{m}^{3}$ water |
|  | Lime | 0.266 | $\mathrm{kg} / \mathrm{m}^{3}$ water |
|  | Ferric sulphate | 0.105 | $\mathrm{kg} / \mathrm{m}^{3}$ water |
| Final water treatment plant (biological) | Sodium carbonate | 0.856 | $\mathrm{kg} / \mathrm{m}^{3}$ water |
|  | Phosphoric acid | 0.004 | $\mathrm{kg} / \mathrm{m}^{3}$ water |
|  | Carbon dioxide | 0.03 | $\mathrm{kg} / \mathrm{m}^{3}$ water |
|  | Alun | 0.051 | $\mathrm{kg} / \mathrm{m}^{3}$ water |
| Acid water treatment plant | Lime | 0.466 | $\mathrm{kg} / \mathrm{m}^{3}$ water |

[[%~%]]
## 17.2 Metallurgical Processes And Flowsheet At Lz5 Mill

A new mill was built in 2007 to process the Lapa ore on the LaRonde site. The mill was situated beside the existing LaRonde mill to allow synergy between the two operations. The LZ5 mill processed Lapa ore from 2008 to 2017, and LZ5 ore from 2018 to the present. The mill has a jaw crusher circuit followed by grinding circuit (SAG and ball mills), a gravity circuit and a leaching circuit with electrowinning gold recovery. The synergies between the LaRonde and LZ5 mills have been mainly related to the workforce, chemicals, and all environmental facilities including tailing and water treatment.
The performance of the LZ5 mill from 2013 to 2022 and notable events are summarized in Table 17.4

The LZ5 mill consists of a grinding a precious metals recovery circuit and paste fill (Figure 17.6), and mill criteria are presented in Table 17.5.Table 17.4 - Summary of Lapa and LZ5 gold production (2013-22)

| Year | Tonnage per year (t) | P38 $\boldsymbol{\mu m}$ (\%) | Gold <br> grade <br> (g/t) | Gold recovery (\%) | Gold produced (oz.) | Total gold produced (oz.) | Comment |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| 2013 | 640,422 | 84.3 | 6.08 | 77.54 | 101,215 | 101,215 | Lapa ore containing refractory gold |
| 2014 | 638,844 | 83.9 | 5.59 | 80.86 | 92,821 | 92,821 |  |
| 2015 | 508,727 | 84.2 | 5.87 | 80.60 | 98,486 | 98,486 |  |
| 2016 | 592,683 | 85.9 | 4.64 | 83.69 | 73,930 | 73,930 |  |
| 2017 | Lapa: <br> 398,249 | 89.0 | 4.24 | 89.25 | 48,479 | 48,479 | Operating 9 months |
| 2018 | Lapa: <br> 311,013 <br> LZ5: <br> 97,275 | 88.2 | $\begin{gathered} 2.94 \\ 2.80 \end{gathered}$ | $\begin{gathered} 82.77 \\ 96.02 \end{gathered}$ | $\begin{gathered} 34,144 \\ 17,379 \end{gathered}$ | $\begin{gathered} 34,144 \\ 18,367 \end{gathered}$ | Re-start LZ5 mill. <br> End of Lapa; beginning of LZ5. |
| 2019 | 699,324 | 87.2 | 2.29 | 95.04 | 48,954 | 60,172 | LaRonde mill: 170,245 Mt, 11,218 oz. |
| 2020 | 643,435 | 88.5 | 2.12 | 94.42 | 41,402 | 61,919 | Temporary COVID-19 shutdown. LaRonde mill: 324,555 Mt, 20,276 oz. |
| 2021 | 754,407 | 87.5 | 2.13 | 94.75 | 48,934 | 71,043 | LaRonde mill: 369,607 Mt, 22,110 oz. |
| 2022 | 655,602 | 85.5 | 2.11 | 94.80 | 42,109 | 71,344 | LaRonde mill: 490,186 Mt, 29,234 oz. |

Table 17.5 - Criteria for LZ5 mill

| Sector | Measurement | Minimum | Maximum | Unit |
| :-- | :-- | --: | --: | :--: |
| Grinding | Tonnage | 60 | 102 | $\mathrm{Mt} / \mathrm{h}$ |
|  | P80 |  | 38 | $\mu \mathrm{~m}$ |
|  | Mill availability |  | $97 \%$ |  |
|  | Gold feed grade | 1 | 4 | $\mathrm{~g} / \mathrm{Mt}$ |
| CIL | Carbon load |  | 6,000 | $\mathrm{~g} / \mathrm{Mt}$ |
|  | Flow | 81 | 137 |  |
| Stripping | Carbon capacity |  | 2 | Tons |
|  | Number of strips |  | 27 | Strips/month |
| Paste fill | Tonnage | 80 | 160 | $\mathrm{Mt} / \mathrm{h}$ |![img-61.jpeg](img-61.jpeg)

Figure 17.6 - Flowsheet for LZ5 mill (2,000 tpd milling rate)

[[%~%]]
### 17.2.1 Crushing

The LZ5 ore is crushed by a mobile jaw crusher operated by a contractor. The opening is set at 4 inches. In 2019, the mill crusher was stopped, and replaced by the current mobile crusher. The mill-crusher installation remains in place but is by-passed to allow the material to go through the circuit.

[[%~%]]
### 17.2.2 Grinding

The grinding circuit began with a truck dump linked by a conveyor gallery to a 900-tonne coarse ore bin. The coarse ore bin feeds a SAG mill in closed loops with hydrocyclones followed by a ball mill circuit. The grind was determined by the secondary battery of hydrocyclones, and the target is fixed at P80 of $38 \mu \mathrm{~m}$. The grinding circuit product is sent to the precious metal circuit. An expert system is operating the grinding circuit.

[[%~%]]
### 17.2.3 Leaching And Cil

The precious metals circuit that processes the grinding circuit product consists of a leaching circuit and a CIL circuit. The leaching circuit provides contact time between precious metals, oxygen and cyanide to lixiviate the gold and silver. The CIL circuit provides time to adsorb the gold into the carbon.

[[%~%]]
### 17.2.4 Stripping And Electrowinning

The stripping and electrowinning process consists of chemically desorbing gold from carbon and onto plates for recovery. The carbon is sent to an acid wash column for removal of contaminants. After the acid wash, the carbon is moved to an elution column. A barren solution containing cyanide and caustic soda at a determined temperature and pressure will desorb gold from carbon and become the pregnant solution. The pregnant solution goes to the electrowinning circuit to plate the gold onto anodes. That solution is then returned to the barren solution and circulated to obtain the optimum stripping efficiency. The process was designed by Como Engineering at 2 Mt of carbon. The gold plating obtained from the electrowinning circuit is poured to produce doré.

[[%~%]]
### 17.2.5 Paste Fill

The paste fill plant is in operation depending on the mining plan. The precious metal reject is sent to the cyanide destruction tank to undergo the $\mathrm{INCO} \mathrm{SO}_{2} / \mathrm{O}_{2}$ process, and then thickened to obtain paste mixed with cement and slag based on a specific recipe. The paste is then sent underground to the mined-out stopes for curing.

[[%~%]]
### 17.2.6 Chemical Consumption

Table 17.6 lists the main reagent and consumables consumption for the LZ5 mill in 2022.Table 17.6 - Average consumption of mill reagents and consumables at LZ5 mill in 2022

| Sector | Consumables | Quantity | Unit |
| :--: | :--: | :--: | :--: |
| Grinding | Steel balls 4" | 0.176 | $\mathrm{kg} / \mathrm{t}$ |
|  | Steel balls 3" | 0.28 | $\mathrm{kg} / \mathrm{t}$ |
|  | Steel balls 3/4" | 0.57 | $\mathrm{kg} / \mathrm{t}$ |
| Leaching | Cyanide | 0.62 | $\mathrm{kg} / \mathrm{t}$ |
|  | Lime | 0.94 | $\mathrm{kg} / \mathrm{t}$ |
|  | Oxygen | 0.71 | $\mathrm{m}^{3} / \mathrm{t}$ |
| Precious metal | Carbon | 0.020 | $\mathrm{kg} / \mathrm{t}$ |
|  | Hydrochloric acid | 0.044 | $\mathrm{kg} / \mathrm{t}$ |
|  | Caustic soda | 0.090 | $\mathrm{kg} / \mathrm{t}$ |
| Cyanide destruction | $\mathrm{SO}_{2}$ | 0.04 | $\mathrm{kg} / \mathrm{t}$ |
|  | Oxygen | 0.12 | $\mathrm{kg} / \mathrm{t}$ |
|  | Lime | 0.1 | $\mathrm{kg} / \mathrm{t}$ |

[[%~%]]
## 17.3 Energy Management

Natural gas is mainly used to operate the kiln (carbon regeneration), to operate the water heater at the water biological plant and to heat the processing plant.
Other equipment use electricity as an energy source, and portions of the buildings at LaRonde Complex are heated with electricity.
For more information on energy equipment, refer to Section 18.

[[%~%]]
## 17.4 Water Management

Fresh water is sourced from Lac Chassignolle and is principally used in chemical preparation and in preparing paste fill to avoid the presence of sulphate in cement paste.
Process water originates from the thickener prior to leaching and this process water is recirculated to the grinding circuit.
Reclaim water originates from basin \#2 and is added throughout the circuit where additional water is required.
For more information on water treatment, refer to Section 20.5.

[[@~@]]
# 18 Project Infrastructure

The LaRonde Complex is located on a site that spans over 6 km from west to east and has five major sectors: the LaRonde Mine, the LZ5 Mine, the processing plants, the regional offices and the tailings management area (see Figure 5.1 in Section 5).
Electrical power is supplied to the site by Hydro-Québec's existing 120 kV Cadillac main substation. A 120 kV line feeds the main substation where two step-down transformers provide the total site demand and distribute the power via seven feeders at 25 kV . The underground distribution is provided by four of these seven feeders which step down the voltage from 25 kV to 4.16 kV . The total connected power for the entire complex is expected to reach approximately 85 MVA.

[[%~%]]
## 18.1 Mine Infrastructure

[[%~%]]
### 18.1.1 Laronde Mine

The LaRonde Mine was originally developed utilizing a 1,207-metre shaft (Shaft \#1) and an underground ramp access system. The ramp access system is available down to Level 25 of Shaft \#1 and continues down to Level 320 at the Penna Shaft (Shaft \#3). The mineral reserves accessible from Shaft \#1 were depleted in September 2000 and Shaft \#1 is no longer in use. A second production shaft (Shaft \#2), located approximately 1.2 km to the east of Shaft \#1, was completed in 1994 to a depth of 525 m and was used to mine zones 6 and 7 . Both ore zones were depleted in March 2000 and the workings were allowed to be flooded up to Level 6 (approximately 280 m depth). The Penna Shaft, located approximately 800 m to the east of Shaft \#1, was completed down to a depth of 2,250 m in March 2000. The Penna Shaft is used to mine zones 20 North, 20 South, 21, 6 and 7.
In 2006, the Company initiated construction to extend the infrastructure at the LaRonde Mine to access the ore below Level 245. Hoisting from this deeper part of the LaRonde Mine began in the fourth quarter of 2011 and commercial production was achieved in November 2011. Access to the deeper part of the LaRonde Mine is provided through an 823-metre internal shaft (Shaft \#4, completed in November 2009) starting from Level 203, for a total depth of 2,858 m from surface. A ramp is used to access the lower part of the orebody down to $3,200 \mathrm{~m}$ in depth. The internal winze system is used to hoist ore from depth to facilities on Level 215, approximately 2,150 m below surface, where it is transferred to the Penna Shaft hoist.
A cooling plant on Level 262 began operating in December 2013. This cooling system is necessary to reduce the frequency of heat-related delays experienced in prior years. In 2021, a new cooling plant on Level 308 (East mine) was put into operation. This cooling system was essential in order to reach Level 332 (East mine) and provide it with adequate temperatures for mining operations. To reach Level 335 (West mine), a new cooling system is planned on Level 308W which is expected to be operational in 2024.
The installation of a coarse ore conveyor system from Level 293 to the crusher on Level 280 was completed in September 2015. Starting in 2023, a dedicated haulage ramp will be operational starting from Level 317, going through 314W to end at the hammer 290 station to access the ore in Zone 20 North. The Company's longer-term plan is to use automated trucks in this haulage ramp.
Access to fresh air is provided by the Penna Shaft and generally provided to each sublevel via a network of raises up to 6.7 m in diameter that connect to the surface. Electric motor-driven ventilators with a total capacity of 1.25 million cfm force climate-controlled air underground.In the same way, a separate network of raises allows for the evacuation-generally from each sublevel to surface-of heat and noxious gases (emanating mainly from underground diesel motor equipment and explosive combustion gases) also using electric motor-driven ventilators.
In 2014, an underground booster fan (6,000 hp) located at Level 194 was commissioned. In addition, the construction of two booster fans (total of $6,000 \mathrm{hp}$ ) started in 2021 and they are planned to be commissioned in the first quarter of 2023. These boosters will increase the capacity to exhaust air from the bottom levels as the mine continues to be expanded to the west and at depth.

The LaRonde Mine's main underground infrastructure is illustrated in Figure 18.1.![img-62.jpeg](img-62.jpeg)

Figure 18.1 - Section view of the main underground infrastructure at LaRonde Mine, looking north

[[%~%]]
### 18.1.2 Lz5 Mine

The Company's regional Centre of Services and Development ("CSD") contains the dry and the offices required to run the LZ5 Mine. The rest of the LZ5 Mine infrastructure is located around the former LZ5 open pit (mined out by the previous owner), and includes the garage, electrical substation, backfill plant, ore and waste stockpiles, the crusher, ventilation intake and exhaust, and numerous other smaller infrastructure such as the diesel reservoir (Figure 18.2).
![img-63.jpeg](img-63.jpeg)

Figure 18.2 - Aerial view of LZ5 Mine site highlighting major surface infrastructure
The underground LZ5 Mine has a relatively simple design as shown in Figure 18.3. Each level is accessed by a ramp located at the south end of the orebody and consisting of a cross cut drift from which drawpoints are used to mine the orebody either longitudinally or by transverse mining. Numerous smaller infrastructure items such as explosive depots, electrical substations and pumping stations are located on these levels.![img-64.jpeg](img-64.jpeg)

Figure 18.3 - Diagram of LZ5 Mine's 2022 LOM underground infrastructure and stopes (longitudinal view, looking north)

[[%~%]]
## 18.2 Milling Facilities At Laronde Complex

The milling facilities for the LaRonde Complex are located on site near Route 395. The infrastructure in this area includes the LaRonde and LZ5 mills, the ore stockpile, assay laboratory, surface mobile shop, office building, warehouse and paste backfill plant (Figure 18.4).![img-65.jpeg](img-65.jpeg)

Figure 18.4 - Aerial view of the milling facilities at LaRonde Complex, highlighting major surface infrastructure

[[%~%]]
## 18.3 Tailings Management Area And Water Treatment Plants

The water treatment infrastructure for the LaRonde Complex is located near the main tailings pond, and it includes the peroxy-silicate plant and the biological plant (final water treatment plant) (Figure 18.5, Figure 18.6 and Figure 18.7). The water pump station that recirculates water to the mill is located in the same area.![img-66.jpeg](img-66.jpeg)

Figure 18.5 - Aerial view of the tailings management area at LaRonde Complex, highlighting major components
![img-67.jpeg](img-67.jpeg)

Figure 18.6 - Aerial view of ventilation and tailings infrastructure at surface at LaRonde Complex, highlighting major components![img-68.jpeg](img-68.jpeg)

Figure 18.7 - Aerial view of the water treatment infrastructure at LaRonde Complex, highlighting major components

[[@~@]]
# 19 Market Studies And Contracts

[[%~%]]
## 19.1 Marketing

The LaRonde Complex currently extracts marketable gold, silver, copper and zinc.
The marketable metals produced are shipped to smelters and refineries in the form of doré bars, copper concentrate and zinc concentrate.

[[%~%]]
### 19.1.1 Doré

The LaRonde Complex's gold/silver doré bars are produced from the leaching circuit following the copper and zinc flotation circuit. The bars are transported by a reputable security firm from the LaRonde Complex to a refinery.

[[%~%]]
### 19.1.2 Copper Concentrate And Zinc Concentrate

The LaRonde Mine has produced and marketed copper concentrate since 1988 and has produced and marketed zinc concentrate since 1998. Both concentrates contain marketable levels of precious metals and the concentrates have had no quality issues as per metal contained or deleterious metals.

The concentrates can be trucked from the LaRonde Complex directly to a smelter or to a storage facility and then transferred by rail directly to the smelter or to an export port.

[[%~%]]
### 19.1.3 Marketing Contracts

The terms are within market parameters for the negotiated contracts at the LaRonde Complex for transportation, refining and smelting activities.

For the copper and zinc concentrate smelting contracts, the monetary terms such as the metal accountability, penalties, quotation periods and payment timing are all defined, as are the principal non-monetary terms. Specific terms are unique to each contract and are negotiated in accordance with international best practices. The treatment charges and refining charges for both materials are negotiated annually.

[[%~%]]
## 19.2 Material Supplier Contracts

Agnico Eagle has signed supplier contracts that are directly associated with operations at the LaRonde Complex for various consumable supplies and services provided. The duration (period of validity) of the contract is specific to each one and may vary.

The material supplier contracts exceeding C\$5 million per year at the LaRonde Complex are listed in Table 19.1.

The process of awarding contracts is performed by an internal committee that initially selects the potential suppliers who are then invited to read and bid on the tender. The prospective suppliers must respect the terms and schedules of the tender in order to proceed to the next stage in the process. Once the tenders are received and analyzed by the internal committee, a meeting is held with management of the suppliers to review the proposals. After both parties have agreed upon the final proposal, Agnico Eagle's Legal Department will then write up a contractual agreement that must be signed by all stakeholders.Table 19.1 - Material supplier contracts exceeding C\$5 million per year at LaRonde Complex

| Supplier | Products / Consumables / Supplies |
| :--: | :--: |
| Acier Fastech Inc. | Steel structure for dry stack project |
| Covoro Mining Solutions Canada Company | Cyanide |
| DSI Underground Canada Ltd. | Ground support |
| Huiles HLH Ltée. | Fuel and gasoline |
| Hydro-Québec | Electricity |
| L Fournier \& Fils Inc. (Béton) | Concrete supply |
| MacLean Engineering | Mining equipment, OEM parts and services |
| Magotteaux Ltée. | Grinding media |
| Marcel Baril Ltée. | Mine mesh |
| Pneus GBM (Rouyn-Noranda) | Tire supply and services |
| Sandvik Mine \& Const Canada Inc. | Mining equipment, rock tools, OEM parts and services |
| Toromont CAT Quebec VD | Mining equipment, OEM parts and services |
| Supplier | Services / Contractors |
| Galarneau Entrepreneur General Inc. | Dam construction and crushing / transport on site |
| Groupe Minier CMAC THYSSEN Inc. | Mining services and workforce |
| Groupe Promec Inc. | Workforce and equipment |
| LJL Mécanique Électrique Inc. | Workforce |
| Machines Roger International Inc. | U/G diamond drilling and development |

The results of the QP review support the assumptions in the Technical Report. The QP responsible for this section of the Technical Report is of the opinion that the terms, rates and charges for material contracts are within industry norms.

[[@~@]]
# 20 Environmental Studies, Permitting, And Social \& Community Impact

[[%~%]]
## 20.1 Environmental Studies

The first environmental studies at the LaRonde Complex were completed by Beak Consultants (1981b) and (1981a). Since then, many additional environmental studies have been completed in compliance with various permitting requirements.
The LaRonde Complex has a history of mining and development spanning more than 30 years. The footprint of the complex is relatively limited, but the knowledge and practice of environmental protection in the mining industry has evolved and been refined from a different approach in the 1970s and 1980s to the environmental management of the 2020s.
The utilization of PAG waste rock for construction on the Property is one of the visible long-lasting impacts of the LaRonde Complex. Many mitigations have been put in place over the years to limit the impact on the site itself.
All environmental studies performed at the LaRonde Complex were positive and demonstrated limited impacts on the environment due to the mining operation. No endangered species or sensitive land are present in the surrounding area to limit operations and development at the LaRonde Complex. All required permits that were based on environmental studies have been obtained by the Company from the Government of Québec and the Government of Canada.

[[%~%]]
## 20.2 Impact And Site Monitoring

Mining and mineral-processing operations and exploration activities at the LaRonde Complex are subject to extensive federal, provincial and local laws and regulations that govern waste disposal, hazardous material management, environmental protection, mine safety and other related matters.

All identified environmental impacts and risks arising from activities at the LaRonde Complex are monitored and mitigated by the Company. Numerous solutions to reduce the impacts and risks of operations at the LaRonde Complex have been implemented as required.
Agnico Eagle's environmental monitoring program at the LaRonde Complex ensures that all activities on the Property comply with the Company's permits and the applicable laws and regulations for the mining industry in Quebec. The program includes the following main components:

- Vibrations
- Noise
- Effluent quality
- Groundwater level and quality
- Solid and hazardous waste management
- Mine waste management
- Accidental spills
- Greenhouse gas emissions

The monitoring program for each of the above items is defined in the "Autorisation ministérielle" (Ministerial Authorization) in terms of applicable performance criteria, location and number of measurement points, methodology, control measures, frequency, and reporting requirements.There are also numerous vibrating wire piezometers, survey monuments, inclinometers and Casagrande piezometers installed on the tailings and water storage areas to monitor stability of the dikes at the TSF, as shown in Figure 20.1.![img-69.jpeg](img-69.jpeg)

Figure 20.1 - Locations at LaRonde Complex's tailing storage facility of vibrating wire piezometers, survey monuments, inclinometers and monitoring wells (piezometers) installed on the tailings and water storage areas to monitor dike stability

[[%~%]]
## 20.3 Vibrations And Air Overpressure

A vibration and air-overpressure monitoring program was implemented to verify compliance with Directive 019 (MELCCFP, Quebec) with a limit of $12.5 \mathrm{~mm} / \mathrm{s}$ caused by the mining blasts. Eleven ground vibration and air overpressure monitoring stations were installed in Val-d'Or, Lac-Joannès (Rouyn-Noranda) and Preissac (Pont Tancrède neighbourhood) to monitor the effects of blasting activity and induced seismicity (Figure 20.2).
![img-70.jpeg](img-70.jpeg)

Figure 20.2 - Location of geophones installed in the communities near the Westwood, LaRonde and Goldex mining operations

[[%~%]]
## 20.4 Noise

An ambient noise monitoring program was implemented to verify compliance with regulatory standards. The sound levels related to mining activities at the LaRonde Complex have been monitored continuously without interruption since 2020 at five monitoring stations (four in Preissac and one in Camping Lac Normand) (Figure 20.3). One station measures residual noise, while the others measure ambient noise. The data are reconciled by a consultant to evaluate the impact of construction and mining activities. Since 2001 a program has been in place to measure noise continuously at specific spots in the surrounding area. Since 2006, the mine activities at the LaRonde Complex are 100\% in compliance with Instruction Note 98-01 (MELCCFP).![img-71.jpeg](img-71.jpeg)

Figure 20.3 - Locations of the permanent noise monitoring stations near LaRonde Complex

[[%~%]]
## 20.5 Final Effluent

The final effluent follows a series of water treatment plants (see Section 20.16). The final effluent has been 100\% compliant with Directive 019 (provincial) and MDMER (federal) limits since 2005. Most of the measured parameters are less than half of the mandated limits.

[[%~%]]
## 20.6 Groundwater

The groundwater monitoring program is based on sampling from 84 monitoring wells installed mainly around the TSF and its polishing ponds, as well as in the wider area surrounding the LaRonde Complex.
The monitoring is performed twice a year (spring and end of summer) and a report is prepared and sent to the regulator with the annual report for the monitoring wells included in the Ministerial Authorization.

Some hydrological studies were performed in previous years for various purposes (e.g., permitting) and all have shown limited impact outside of the complex area.

[[%~%]]
## 20.7 Solid And Hazardous Waste Management

The solid wastes generated on-site that can be recycled are transported to recycling centres, and those that cannot be recycled are sent to accredited facilities. Hazardous waste is managed in accordance with Quebec regulations.

[[%~%]]
## 20.8 Spills

All spills are reported immediately to the authorities. They are recorded in a database provided for this purpose (Intelex) and the spills are recovered quickly. Spill analysis enables measures to be put in place to reduce the risks and to prevent spill recurrence.

[[%~%]]
## 20.9 Greenhouse Gas Emissions

The LaRonde Complex has voluntarily acceded to the provincial program for carbon exchange ("SPEDE") for the monitoring, declaration and control of greenhouse gas emissions.

[[%~%]]
## 20.10 Emergency Response Plan

The LaRonde Complex has an Emergency Response Plan that outlines all the risks that could have consequences for health and safety, the environment, the Property or the surrounding community. The aim of the emergency plan is to act with diligence and assurance. It was updated in 2021.

[[%~%]]
## 20.11 Waste Rock Management

The annual production of waste rock is relatively limited from an underground mine compared to an open pit operation. At the LaRonde Complex, three waste rock stockpiles are used for the current operations: the LZ5 waste rock stockpile at the bottom of pit 5; the Penna waste rock stockpile located south of main TSF for acid generating material; and a non-acid generating rock stockpile, north of LZ5. Almost all waste rock is used within three years for TSF development (upstream raises) and, in the near future, for filtered tailings management.
The historical waste rock piles have mitigation measures in place to control any acid rock drainage. All of these historical piles will be used at the TSF for filtered tailings transition. For example, in 2019, most of the Penna waste rock pile was used to build the last cofferdam of the main tailings pond. From 2023 to 2028, all waste rock will be moved in phases to pond A4 to stabilize tailings prior to filtered tailings disposal.

[[%~%]]
## 20.12 Tailings Management

[[%~%]]
### 20.12.1 General

Tailings management practices at the LaRonde Complex incorporate evolving international best practices for design and management, as endorsed by the Canadian Dam Association and the Mining Association of Canada.
Approximately 35\% of tailings are used underground in paste backfill. The excess was managed in the Main TSF and its Extension A4. The Main TSF was constructed in 1988 and was confined by Dike 1 and Dike 2. In 1997, the footprint was extended to the East (Extension East) with the construction of Dike 7. The Main TSF was raised by the central method between 2000 and 2002. Starting in 2004, the Main TSF was raised by the upstream method. In 2010, Extension A4 (east of the Main TSF) was constructed. The Main TSF and Extension A4 combined cover approximately 171 hectares.

Beginning in 1988, tailings deposition had been in the form of slurry - a process that continued through October 2022. Since October 26, 2022, filtered tailings have been deposited within the Extension A4 footprint in order to reduce the environmental footprint. Dry stack deposition in theExtension A4 and eventually in the Main TSF should cover the needs of the LaRonde Complex through 2036, which is the current LOM. This change in technology will reduce geotechnical risks and ultimately the reclamation costs compared to slurry deposition.

This significant change in tailings management was required to increase storage capacity to fulfill LOM needs. A trade-off study started in 2018 followed by an engineering phase have confirmed that the filtered tailings management is the best choice to reduce the footprint impact, to control the geotechnical risk and to optimize the reclamation costs and requirement (reprofiling).
For water management, construction of a new water cell (Cell 5) was completed in October 2022 at a location east of Extension A4. Cell 5 will allow for the management of water for the transition to filtered tailings deposition. This cell is lined with LLDPE geomembrane with till under it as a second protection layer. The dikes have been constructed with non-ARD waste rock, gravel and sand with three layer of filters. Clay have been excavated in the foundation of the dike for stability.
A series of polishing ponds completes the mine waste management infrastructure. The filtration plant was commissioned during the third quarter of 2022 and became fully operational during the fourth quarter of 2022 at a location directly south of the Main TSF in order to convey the filtered tailings in Extension A4.
The current characteristics of the tailings are presented in Table 20.1.

Table 20.1 - Tailings characteristics for LaRonde Mine and LZ5 Mine

| Parameter | LaRonde Mine | LZ5 Mine |
| :-- | :-- | :-- |
| Production rate | 2.55 Mt/year <br> 7,000 tpd | 0.73 Mt/year <br> 2,000 tpd |
| Design tailings density | $30-35 \%$ solid | $35-40 \%$ solid |
| Particle size distribution and <br> plasticity | $80 \%$ passing $75 \mu \mathrm{~m}$ | $80 \%$ passing $38 \mu \mathrm{~m}$ |
| Average bulk density | $1.65 \mathrm{t} / \mathrm{m}^{3}$ | $1.5 \mathrm{t} / \mathrm{m}^{3}$ |
| Average specific gravity | 3.3 | 2.8 |
| Beach slope | $0.2 \%$ to $2.8 \%$ in Main TSF and $1.4 \%$ in A4 | $0.4 \%$ to $2.4 \%$ |

[[%~%]]
### 20.12.2 Tailings Deposition

Slurry tailings are currently delivered to the filtration plant from the LaRonde Mine ore treatment plant and from the LZ5 Mine ore treatment plant. The tailings characteristics of each ore treatment plant are different.
The LaRonde Mine's tailings are primarily used to feed the two paste fill plants at the LaRonde Mine and the LZ5 Mine. The remaining LaRonde Mine tailings and all tailings from the LZ5 process plant are sent to the filtration plant. The resulting filtered tailings mix is sent to the TSF. The tailings are acid generating and need to be managed accordingly. In the first years, filtered tailings will be placed in lift and compacted in Extension A4.A previously completed geochemical study assisted in developing a strategy for deposition and mitigation to prevent ARD. The study recommends the phased implementation of a progressive rehabilitation program.
The characteristics of the tailings at the LaRonde Complex have been favourable for the construction of upstream raises on the Main TSF since 2004. The upstream raises are made of waste rock produced over the years, reducing the quantity as well of waste rock in the stockpiles. Most raises are 2 m high and 25 m apart, except for one raise of 6 m with additional berms to comply with safety regulations and meet industry best practices.

[[%~%]]
### 20.12.3 Geotechnical Investigation And Monitoring

A major geotechnical site investigation was completed between 2018 and 2022 in the Main TSF, Extension A4 and polishing ponds. The objectives were to fill data gaps from previous investigations on foundation soils and tailings, to collect samples for laboratory testing, and to install geotechnical monitoring instruments. Including the newly installed instruments, there are currently 103 vibrating wire piezometers ("VWPs"), 18 inclinometers ("INCs"), 39 monitoring wells ("PZs"), and 30 survey monuments ("MAs"). These instruments monitor porewater pressure, lateral deflections and settlement.
Data from the geotechnical investigations and monitoring instruments are used for the engineering studies of infrastructure on the Property. The design for the TSF was updated over the mine life to meet best practices and standards of the industry. The observational approach has been applied since the initial design. The objective is to confirm that the infrastructure behaviour fulfills the design intent, or to modify the design accordingly if required. Therefore, the design is dependent on the monitoring and surveillance program.

[[%~%]]
### 20.12.4 Overall Stability Of The Tailings Storage Facility

Stability analyses of the mine waste management infrastructure are completed by the Design Engineer and verified by the Engineer of Record whenever necessary. Stability is analyzed in the context of current industry standards and best practices. The review process is integrated, which involves external experts through the organization of an Independent Review Board.
Mining induced seismicity is adequately monitored by on-line VWP, with six instruments measuring water pressure every 0.1 second. Other VWP are also monitored on-line at a reduced frequency of 2 seconds. An accelerometer is installed above the tailings in the Main TSF in order to measure any seismic events. The various safety factors that are deployed meet and exceed the minimum requirements.

[[%~%]]
## 20.13 Water Management

The LaRonde Complex is recognized as a mining-industry leader in water treatment. After being pumped to the tailings pond, water is directed to Polishing Pond \#1 before being sent to a water treatment plant for destruction of cyanide complexes and for metal precipitation with peroxide, silicate, lime and ferrous sulphate (WTP).
After lime precipitation in Polishing Pond \#2, a water treatment plant using a biological process (FWTP) eliminates toxicity via the degradation of residual ammonia and thiocyanate. Commissioned in 2004, this plant can process more than 2 million $\mathrm{m}^{3}$ of water per year. All current provincial and federal limits are never exceeded. Some water originating from Polishing Pond \#2 is sent to Polishing Pond \#3B prior to mill usage.The precipitation water in the area of the mills infrastructure and old waste rock pile \#1 is sent to Pit \#4 prior to the acid water treatment plant (AWTP).
The dewatering from the LaRonde Mine is sent to the main tailings pond prior to being sent to the water treatment plant (WTP, FWTP). The dewatering from the LZ5 Mine is sent to Pit \#4 prior to being sent to the AWTP.

[[%~%]]
## 20.14 Permitting For Laronde Complex

Since October 2012, the LaRonde Complex holds an "Attestation d'assainissement" (Sanitation Attestation) granted by the MELCCFP. This document is renewable every five years and identifies the environmental conditions that must be met by the Company while carrying out industrial activities at the complex. The MELCCFP uses the Industrial Waste Reduction Program (Programme de réduction des rejets industriels or "PRRI") to update the provincial annual report requirements.

The attestation compiles all environmental requirements related to the operation of the industrial facility already stated in the Certificates of Authorization. Since the attestation has been issued, annual fees are applicable to mine operation waste in the environment through the PRRI. The fees are calculated on contaminant load to air and water, and to the tonnage of stored waste rock and tailings.

Before carrying out any new activities on-site at the LaRonde Complex, the Company must submit any applications and obtain the permits and authorizations from the relevant government authorities.

In July 2019, the MELCCFP delivered a unified Certificate of Authorization that regroups and consolidates all the previous Certificates of Authorization for the LaRonde Mine and the LZ5 Mine. This document is important because it recognizes the LaRonde Complex as one mining operation, thereby providing the Company more flexibility for mining production and operation of the ore treatment plants.

The current project to convert the tailings management to dry stack has received all permits and authorizations.

[[%~%]]
## 20.15 Notices Of Non-Compliance

The LaRonde Complex has not received any notices of non-compliance from federal or provincial regulators during the past three years. In 2019, the Company received a notice of non-compliance from the federal regulator due to a delay in sending a report and in 2017 the Company received a notice of non-compliance from the provincial regulator for a delay in declaring a spill.

[[%~%]]
## 20.16 Community Relations

Respect for the communities in which Agnico Eagle operates is a core value of the Company's sustainability policy. The Company has always strived to work collaboratively with its neighbours to identify ways to improve practices and foster harmonious and sustainable relationships. The Company considers this collaboration to be essential to its success and it understands that to maintain this success, it must be transparent, open and responsive to the communities' needs and expectations, respectful of their values and accountable in how the Company manages its business. Over time, the Company has developed and maintained mechanisms for successful collaboration and communication with neighbours.Agnico Eagle's efforts in the area of community relations are based on key values of trust, family, respect, responsibility and equality that define the Company and guide its actions. The five values represent a vital link to the Company's history, are rooted in Company culture and are essential to the Company's success.

[[%~%]]
### 20.16.1 Good Neighbour Framework

As part of Agnico Eagle's processes for community engagement, dissemination of information and consultation, the Company has voluntarily worked with citizen stakeholders to develop a "Good Neighbour Framework" that is consistent with the Company's key values.
The Good Neighbour Framework for the LaRonde Complex applies to the Municipality of Preissac and the Cadillac neighbourhood (City of Rouyn-Noranda).
The objectives of the Good Neighbour Framework are:

- To contribute to harmonious relationships between the LaRonde Complex and neighbours in a context where mining operations are likely to generate impacts, including seismic events.
- To take into account the concerns of the neighbours, thus contributing to strengthening community relations in a proactive manner.
- To promote the early identification and resolution of concerns, thereby leading to better management of impacts while preventing potential harm.
- To systematically and appropriately address complaints filed by individuals who consider themselves affected by activities at the LaRonde Complex.

The Good Neighbour Framework was first presented to the community near the LaRonde Complex at a local assembly of stakeholders in 2019. The 65 people in attendance participated in an exercise to measure overall responsiveness. The framework itself received a $94 \%$ satisfaction level and the co-development approach had a $96 \%$ satisfaction rate among neighbours.
The Good Neighbour Framework has been developed jointly with concerned stakeholders and it aims to reach an agreement on the essential conditions for good neighbourliness as well as measures and actions to be deployed to prevent, manage and mitigate the impacts of activities at the LaRonde Complex.
Three groups have been involved in co-developing the framework: the Harmonization Table (see Section 20.16.2), the Cadillac Neighbourhood Council and the Preissac Municipal Council.
In June 2022, Agnico Eagle proceeded to revised the Good Neighbour Framework. The Company's approach to the revision received a satisfaction level of $93 \%$ from stakeholders and the solutions of the revised framework received a satisfaction level of $92 \%$. A total of 33 attendees participated in the assembly.
The Company and its stakeholders at the LaRonde Complex have played a role in hosting three series of events to engage with the local community: a citizens co-development workshop; consultation with under-represented neighbours; and a validation of the framework though a public meeting.
For the Company, it is important to avoid any situation where stakeholders feel they have no recourse when faced with potential concerns related to the LaRonde Complex.The Good Neighbour Framework has grouped such potential concerns into four main areas: property damage, seismic disturbance, community development support and knowledge building. All of the solutions outlined in the framework have been carefully developed and are part of a proactive program of dialogue with the various stakeholders.

This framework may be modified in the future through consultation and collaboration to identify proposed changes that meet the original objectives of the framework.

[[%~%]]
#### 20.16.1.1 Property Damage And Related Claims

The operations of the LaRonde Complex may generate seismic events felt or perceived by neighbours. In order to address the concern of potential property damage caused by seismic events, a network of seismograph stations covering the entire territory of the neighbouring communities is in place to measure for vibrations continuously. These seismograph stations are the responsibility of a consultant external to the LaRonde Complex and the Company.
An individual seismograph station consists of a geophone connected by cellular modem to a data acquisition system located in a central server. An analysis module processes the measurements and then archives them on a secure website. Personnel from the LaRonde Complex can consult these measurements at any time but cannot modify them. Seismograph stations are also located directly on the mine site. All of these seismograph stations are located within a radius of approximately 7 km from the underground mining area where the majority of seismic events occur.
In collaboration with the various stakeholders, the LaRonde Complex has put in place a dedicated framework for claiming property damage, without admission of liability and in a context of good neighbourliness. This process is an integral part of the Good Neighbour Framework and the process is communicated to the stakeholders. A system is also in place to effectively receive concerns, complaints and comments. This system is publicized in the Good Neighbour Framework and on Agnico Eagle's regional public webpage.
As part of a broader improvement process, a community relations officer from the Company will contact the party lodging the complaint again after the complaint has been closed in order to determine the level of satisfaction with the complaint-handling process.

[[%~%]]
#### 20.16.1.2 Notifications After Seismic Events And Seismic-Related Disturbance

Seismic events generated by underground mining operations at the LaRonde Complex may be felt in the vicinity. In the interest of harmonious relationships and proper dissemination of information to the community, notices are sent to the public when a seismic event of a Richter magnitude of 2.3 or higher is felt at the surface. A notification is sent to all persons who have subscribed to the free, automated notification system.
Richter magnitude 2.5 was first chosen as the basis for issuing a notice to the community following analysis of the history of seismic events and the vibrations generated by them. It was shown that below this magnitude, seismic events generated vibrations that were not felt, or were only minimally felt, in neighbouring communities and these events never approached the standard limits of the Government of Quebec's Mining Directive 019 to which the LaRonde Complex voluntarily follows. In the 2022 review of the framework, citizens requested that the Company send its notification at a Richter magnitude of 2.3 or higher.
Notifications of seismic events are sent to the public subscribers via text message (SMS), email and telephone (automated voice message). The LaRonde Complex carries out regular communication activities to encourage citizens to subscribe to these notifications, which contain the following information:- Date, time and Richter magnitude of the seismic event
- The possibility (or not) of exceeding the vibration levels of the USBM and the Government of Quebec's Mining Directive 019 where damage is possible
- Any impact of the event on LaRonde Complex operations
- Contact details for more information

A seismic-related disturbance is mainly related to the unpredictability of seismic events and the fear of damage to property. In order to mitigate the disturbance, the measures that are deployed relate to the adaptation of underground mining operations and the continuation of the information and communication process.
The Company has developed and is continually refining a mining plan at the LaRonde Complex that takes into consideration that underground mining activities can generate significant seismic events. A team of experts takes measures to maximize worker safety and minimize impacts to communities. These measures include:

- Avoidance of hazardous areas
- Optimized blasting schedule for work sites
- Optimized blasting sequence
- Proper orientation of drifts
- Backfilling of work sites


[[%~%]]
#### 20.16.1.3 Community Development Support

To support community development in the region surrounding the LaRonde Complex, the Company prioritizes three objectives: to invest in the communities; to contribute to the maintenance of property values in the surrounding communities; and to encourage its employees to move closer to the mine site. An employee wishing to purchase or build a residential property in the communities of Preissac or Cadillac may benefit from financial assistance offered by the Company, if he or she meets all the conditions related to his or her employee status and the conditions related to the property.
A regional donation and sponsorship program is in place and is aligned with the Company's corporate donation policy. A regional budget that varies annually as needed ensures the pursuit and achievement of these objectives.

[[%~%]]
#### 20.16.1.4 Knowledge Building

Several information and communication activities are deployed on a regular basis with the aim of improving the level of knowledge of stakeholders regarding the LaRonde Complex and seismicity. The following knowledge-building measures have been prioritized:

- Stakeholder information workshops
- Information and awareness activities with the school community
- Development of information tools for the general public
- Exchanges with citizens of the communities concerned

[[%~%]]
#### 20.16.1.5 Well Monitoring

A follow-up program for monitoring private wells has been set up to determine whether seismic events resulting from the Company's mining operations can influence the condition of drinking water collection structures. About 10 wells will be selected according to different criteria in order to obtain a representative sample of all the wells. The criteria will be:

- Type of well and date of construction
- Depth of the well
- Type of soil

After the wells are selected, there will be an annual analysis of the wells that will include measurements of flow rate, water volume and water quality (e.g., potable or not). Visual surveys of the interiors of the wells will also be conducted using a camera.
The information collected in this program will then be communicated to the private well owners. This information could also be used as a reference in the case of a future claim concerning a well.

[[%~%]]
### 20.16.2 Other Local Communication Activities

The Company hosts approximately four citizen workshops per year in the community. The theme and form of these workshops may vary over time but the objectives remain the same: to create an opportunity for direct, open and transparent exchange with neighbours of the LaRonde Complex as well as to create an opportunity to provide the neighbours with knowledge related to the Company's operations and the broader mining sector.
The Harmonization Table was created with the purpose of bringing together representatives of all stakeholders to exchange information, consult and adapt in order to reach common objectives with local stakeholders, and to arrive at consensual solutions to issues defined by the community. The Company intends to hold three to four of such meetings of the Harmonization Table annually.
The Harmonization Table is comprised of the following organizations and their representatives:

- Agnico Eagle, General Manager
- Agnico Eagle, General Superintendent of Surface Operations
- Agnico Eagle, Assistant Superintendent for Communications and Community Relations
- Agnico Eagle, Community Relations Advisor
- Municipality of Preissac, Mayor
- Municipality of Preissac, Municipal Councillor
- Municipality of Preissac, Development Officer
- Municipality of Preissac, General Director
- City of Rouyn-Noranda, Chief of Land Use Planning
- City of Rouyn-Noranda, Land Use Planner
- City of Rouyn-Noranda, Municipal Councillor
- Quartier de Cadillac, Community Service Coordinator
- MRC Abitibi, Director of Land Use Planning- CREAT (regional environmental council in Abitbi-Témiscamingue), Representative
- Pikogan Aboriginal Community, Representative
- Camping Lac Normand, Owner
- Camping Lac Normand, Employee
- Club de motoneige de Malartic, Liaison Officer

Furthermore, during important activities for the neighbouring communities, the Company ensures that it is present and participating in order to support local communities.

[[%~%]]
### 20.16.3 First Nation Collaboration Agreement

The LaRonde Complex initiated a collaborative process with the First Nation community of Abitibiwinni in the autumn of 2020. This process is ongoing.
The objectives of the proposed Collaboration Agreement with the Abitibiwinni First Nation are:

- To develop and maintain a long-term relationship between the Parties of the agreement based on trust, mutual respect and collaboration.
- To provide, from a sustainable development perspective, for the participation of the First Nation with respect to the Mining Camp, notably through training programs, employment opportunities and advancement, measures to adapt working conditions, priority in the awarding of contracts, measures relating to environmental protection and financial commitments.
- To confirm the collaboration and support of the First Nation towards Agnico Eagle regarding the Mining Camp.
- To facilitate the development and operation of the Mining Camp in a safe, efficient and profitable manner for the benefit of the Parties of the agreement.


[[%~%]]
## 20.17 Closure And Reclamation

[[%~%]]
### 20.17.1 Closure And Reclamation Plan

The objective of the Closure and Reclamation Plan ("Reclamation Plan") is to return the LaRonde Complex site to a condition that limits risks to public health and safety and to the environment. The Quebec Mining Act requires mining operations to submit a rehabilitation plan and a financial guarantee covering $100 \%$ of the cost of rehabilitation work.
With the assistance of consulting firm Golder, the LaRonde Reclamation Plan was prepared and initially submitted to the Government of Quebec's Ministry of Energy and Natural Resources (Ministère de l'Énergie et des Ressources Naturelles du Québec, or "MERN") in May 1996. The last update of this Reclamation Plan was submitted in February 2021 and accepted by the MERN on June 21, 2022, with total estimated costs of $\$ 197.8$ million. Currently, $\$ 140.8$ million are already submitted in financial guarantees and the financial guarantee payment schedule was established by the MERN for 2023 and 2024 (100\%).
A second Reclamation Plan for the Bousquet Area (LZ5 Mine) is independent and not included in the scope of LaRonde Mine's Reclamation Plan. This is due to the area being almost restored prior to the construction and development of the LZ5 Mine.The last Bousquet closure plan was approved by the MERN on July 26, 2018. The last revision was submitted on October 13, 2022 and is currently under review by the MERN and MELCCFP. The current letter of credit is established at $\$ 4,039,007$ (100\% of the cost estimate in the 2018 update).
The following objectives have been defined for the 2021 Reclamation Plan:

- To develop a remediation plan based on techniques that are environmentally adapted to the required closure.
- To ensure that during work and after its completion, public-health and safety risks are minimized.

The major elements included in the 2021 Reclamation Plan are:

- As the tailings and waste rock are acid generating, a membrane of LLDPE will be used with the associated granular cover to protect its integrity. The choice of this technology is based on the limited availability of till in the area and the efficiency of the membrane to prevent acid rock drainage.
- All infrastructure included in the filtered tailings management project were added in the last revision (filtration plant, Cell 5, filtered tailings storage, etc.).
- All costs are updated for the mill clean-up and dismantling.
- Further updates are included relating to unit costs (revegetation, sand, till, waste rock excavation, etc.).

The effluent and tailings site control structures will be operated until the MELCCFP determines that the required criteria have been met. These physical structures will then be dismantled. The work integrity follow-up program will include a follow-up inspection of the stability of structures that will remain after the site remediation process. The effluent processing plant will also be inspected on a regular basis to ensure its good operating condition.
The environmental monitoring will continue for at least 10 years after the completion of site reclamation, or until the results of five consecutive years comply with the conditions of Directive 019 during mine closure.

The agronomic follow-up process will measure the recovery of vegetation on the site and take any corrective action that may be required. This agronomic follow-up inspection will be performed once a year during the first five years following mine closure.

[[%~%]]
### 20.17.2 Closure And Reclamation Costs

The reclamation and closure costs have been estimated for all the items in the Reclamation Plan filed with the MERN in 2021 and approved in 2022. The previous Reclamation Plan approved by the MERN dated May 2013 estimated reclamation and closure costs of C\$83.9 million with irrevocable letters of credit for 100\% of the cost (2016). For the Bousquet (LZ5) Reclamation Plan accepted in July 2018, the estimated reclamation and closure costs presented were C\$4.0 million with irrevocable letters of credit for $100 \%$ of this cost (2020).
Table 20.2 and Table 20.3 show summaries of the estimated closure costs for the LaRonde Complex submitted to the MERN in 2021 and approved in 2022.Table 20.2 - Closure costs for LaRonde Mine area

| Component | Cost (C\$M) |
| :-- | --: |
| Engineering and study | 2.6 |
| Tailings storage facility and waste rock pile | 82.6 |
| Water management facilities | 11.0 |
| Contaminated soil and revegetation | 18.0 |
| Clean-up and dismantling of complex | 24.0 |
| Environmental monitoring and inspections | 6.8 |
| Subtotal | 145 |
| Indirect costs | 27 |
| Contingency | 25.8 |
| Total | $\mathbf{1 9 7 . 8}$ |

Table 20.3 - Closure costs for Bousquet area (LZ5 Mine)

| Component | Cost (C\$M) |
| :-- | --: |
| Pit, stockpiles and raises rehabilitation | 0.5 |
| Water treatment | 0.3 |
| Contaminated soil and revegetation | 0.7 |
| Clean-up and dismantling of infrastructure | 0.8 |
| Environmental monitoring and inspections | 0.6 |
| Subtotal | 2.9 |
| Indirect costs | 0.4 |
| Contingency | 0.7 |
| Total | 4.0 |

[[@~@]]
# 21 Capital And Operating Costs

[[%~%]]
## 21.1 Capital Cost (Capex) Estimates

The Company estimates that the LaRonde Complex will require C\$1,007 million of CAPEX over the life of the mining complex (Table 21.1). Most of the CAPEX is necessary to develop the LZ5, 11-3 and LaRonde + LaRonde 3 projects. Other significant CAPEX investments at the site include mobile equipment, mill upkeep, and upgrades.
All planned CAPEX at the LaRonde Complex is evaluated by the Company using detailed engineering and mine planning. For example, the anticipated CAPEX for underground development has been assessed by creating a detailed mining schedule in Deswik that plans out the CAPEX for tunnel requirements each year. The yearly CAPEX requirement for lateral development is subsequently evaluated using historical development costs.

[[%~%]]
## 21.2 Mine Operating Cost (Opex) Estimates

The operating costs for the LaRonde Complex as estimated in the 2023 LOM are listed in Table 21.2, which is an amalgamation of the operating cost estimates for the LaRonde and LZ5 mines. The average cost per tonne for the site is C $\$ 147$ per tonne.
The LaRonde Mine is a deep mine with inherently higher operating costs than the LZ5 Mine. The operating costs at the two mining operations comprising the LaRonde Complex are further detailed below.

[[%~%]]
### 21.2.1 Laronde Mine

The average OPEX at the LaRonde Mine over the LOM is C\$195 per tonne. All the OPEX estimates have been calculated using historical mining data generated at the LaRonde Mine and adapted to current and anticipated mining parameters.
Table 21.3 shows the general operating cost estimate over the last LOM used for the MRMR estimate as of December 31, 2022.

[[%~%]]
### 21.2.2 Lz5 Mine

The average OPEX at the LZ5 Mine over the LOM is C\$85 per tonne. Most of the costs are associated with the production and milling business units, as shown in Table 21.4, which lists the general operating cost estimate over the last LOM used for the MRMR estimate as at December 31, 2022.
All costs at the LZ5 Mine are evaluated by determining the driver of each business unit and its historical cost. Adjustments are made for aspects such as inflation. Each driver's quantity is based on the detailed mining plan created using Deswik mining software. This method ensures that costs are accurately evaluated over the LOM as the quantity of each driver will change over the LOM.Table 21.1 - Capital costs (CAPEX) at LaRonde Complex (2023 to 2036) as estimated in 2023 LOM (C\$M)
![img-72.jpeg](img-72.jpeg)Table 21.2 - Operating costs (OPEX) at LaRonde Complex (2023 to 2036) as estimated in 2023 LOM (000 C$)$

| Business Unit | Year |  |  |  |  |  |  |  |  |  |  |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | 2023 | 2024 | 2025 | 2026 | 2027 | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 | 2035 | 2036 | Total |
| UG Geology | 3,910 | 3,556 | 3,627 | 2,681 | 2,160 | 1,495 | 1,364 | 1,270 | 1,139 | 730 | 567 | 567 | 547 | 353 | 23,966 |
| UG Development | 41,480 | 34,680 | 34,308 | 36,421 | 27,202 | 22,309 | 17,630 | 14,677 | 10,397 | 7,514 | 7,994 | 4,352 | 4,192 | 6,375 | 269,529 |
| UG Production | 64,608 | 67,647 | 68,914 | 71,771 | 69,371 | 60,955 | 51,608 | 43,295 | 29,456 | 15,782 | 11,410 | 11,084 | 9,524 | 8,276 | 583,701 |
| UG Services | 49,999 | 48,868 | 47,937 | 48,549 | 46,722 | 38,377 | 36,345 | 32,637 | 24,995 | 16,158 | 11,299 | 11,650 | 9,422 | 8,292 | 431,251 |
| UG Maintenance | 74,629 | 74,581 | 75,403 | 76,935 | 75,068 | 60,915 | 57,693 | 51,418 | 40,221 | 25,790 | 18,657 | 18,856 | 15,547 | 13,446 | 679,159 |
| Mill Production | 46,488 | 44,449 | 45,243 | 45,574 | 44,763 | 32,439 | 28,089 | 23,203 | 13,496 | 1,007 | 240 | (0) | (916) | 1,138 | 32, 211 |
| Mill Services | 29,865 | 27,734 | 26,712 | 26,756 | 26,239 | 21,652 | 19,697 | 16,839 | 13,851 | 8,018 | 5,494 | 5,378 | 4,516 | 3,812 | 236,563 |
| Mill Maintenance | 29,641 | 27,534 | 27,521 | 27,694 | 27,772 | 22,822 | 21,322 | 17,900 | 13,956 | 8,275 | 6,016 | 5,763 | 5,014 | 4,291 | 245,519 |
| Site Administration | 42,745 | 43,233 | 43,735 | 42,426 | 41,163 | 31,994 | 31,018 | 29,295 | 23,347 | 17,213 | 13,187 | 13,257 | 11,278 | 8,303 | 392,193 |
| Site Services <br> Maintenance | 3,843 | 3,847 | 3,647 | 3,649 | 3,649 | 1,614 | 2,013 | 2,221 | 1,518 | 778 | 449 | 953 | 902 | 633 | 29,715 |
| Site Services | 5,426 | 5,375 | 5,065 | 5,247 | 5,247 | 5,247 | 4,634 | 3,779 | 3,246 | 2,348 | 1,810 | 1,280 | 980 | 977 | 50,660 |
| Direct production expenses | 392,634 | 381,503 | 382,111 | 387,703 | 369,354 | 299,818 | 271,412 | 236,534 | 175,622 | 103,612 | 77,122 | 73,139 | 61,006 | 55,896 | 3,267,465 |
| Private royalty | 3,825 | 7,969 | 8,485 | 9,022 | 8,785 | 7,375 | 6,146 | 5,162 | 9,866 | 5,888 | 5,985 | 4,869 | 5,736 | 4,745 | 93,859 |
| Total production expenses after stockpile | 396,459 | 389,472 | 390,596 | 396,725 | 378,139 | 307,193 | 277,557 | 241,696 | 185,488 | 109,501 | 83,107 | 78,009 | 66,742 | 60,641 | 3,361,324 |
| Total operating costs | 396,459 | 389,472 | 390,596 | 396,725 | 378,139 | 307,193 | 277,557 | 241,696 | 185,488 | 109,501 | 83,107 | 78,009 | 66,742 | 60,641 | 3,361,324 |
| Treated tonnes (t) | 2,644 | 2,607 | 2,685 | 2,759 | 2,743 | 2,360 | 1,960 | 1,663 | 1,230 | 683 | 438 | 438 | 365 | 312 | 22,886 |
| OPEX (C\$ per tonne) | 150 | 149 | 145 | 144 | 138 | 130 | 142 | 145 | 151 | 160 | 190 | 178 | 183 | 194 | 147 |Table 21.3 - Operating costs (OPEX) at LaRonde Mine (2023 to 2036) as estimated in 2023 LOM (000 C$)$

| Business Unit | Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | 2023 | 2024 | 2025 | 2026 | 2027 | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 | 2035 | 2036 | Total |
| UG Geology | 2,956 | 2,741 | 2,452 | 2,092 | 1,648 | 983 | 983 | 963 | 915 | 686 | 567 | 567 | 547 | 353 | 18,453 |
| UG Development | 31,258 | 25,223 | 23,769 | 23,296 | 18,671 | 17,129 | 14,588 | 12,105 | 9,519 | 7,153 | 7,994 | 4,352 | 4,192 | 6,375 | 205,624 |
| UG Production | 41,004 | 43,119 | 41,306 | 41,816 | 38,721 | 28,350 | 28,464 | 25,122 | 18,483 | 14,320 | 11,410 | 11,084 | 9,524 | 8,276 | 361,001 |
| UG Services | 39,877 | 39,197 | 37,579 | 37,339 | 35,825 | 26,269 | 25,457 | 24,272 | 18,858 | 14,588 | 11,299 | 11,650 | 9,422 | 8,292 | 339,924 |
| UG Maintenance | 62,528 | 61,922 | 60,315 | 60,316 | 59,088 | 42,576 | 42,018 | 39,312 | 31,114 | 23,636 | 18,657 | 18,856 | 15,547 | 13,446 | 549,331 |
| Mill Production | 30,079 | 30,104 | 30,335 | 28,816 | 29,111 | 18,815 | 18,872 | 16,018 | 10,674 | 1,726 | 240 | (0) | (916) | 1,138 | 215,012 |
| Mill Services | 21,189 | 19,809 | 18,870 | 18,020 | 18,175 | 12,818 | 13,014 | 11,780 | 9,565 | 6,907 | 5,494 | 5,378 | 4,516 | 3,812 | 169,347 |
| Mill Maintenance | 19,603 | 19,275 | 19,090 | 18,314 | 18,898 | 13,047 | 13,579 | 12,043 | 10,053 | 7,233 | 6,016 | 5,763 | 5,014 | 4,291 | 172,219 |
| Site Administration | 38,496 | 38,902 | 39,159 | 37,792 | 36,529 | 27,809 | 26,956 | 25,654 | 20,920 | 16,565 | 13,187 | 13,257 | 11,278 | 8,303 | 354,806 |
| Site Services <br> Maintenance | 3,188 | 3,191 | 3,020 | 3,029 | 3,029 | 1,095 | 1,533 | 1,751 | 1,315 | 981 | 449 | 953 | 902 | 633 | 25,069 |
| Site Services | 4,163 | 4,112 | 3,872 | 4,045 | 4,045 | 4,045 | 3,600 | 2,931 | 2,503 | 1,872 | 1,810 | 1,280 | 980 | 977 | 40,233 |
| Direct production expenses | 294,340 | 287,597 | 279,766 | 274,875 | 263,740 | 192,935 | 189,065 | 171,953 | 133,918 | 95,667 | 77,122 | 73,139 | 61,006 | 55,896 | 2,451,019 |
| Private royalty | 560 | 4,288 | 4,419 | 4,289 | 4,297 | 2,654 | 2,836 | 2,654 | 8,099 | 5,353 | 5,985 | 4,869 | 5,736 | 4,745 | 60,785 |
| Total production expenses after stockpile | 294,900 | 291,884 | 284,184 | 279,164 | 268,037 | 195,589 | 191,901 | 174,607 | 142,017 | 101,021 | 83,107 | 78,009 | 66,742 | 60,641 | 2,511,803 |
| Total operating costs | 294,900 | 291,884 | 284,184 | 279,164 | 268,037 | 195,589 | 191,901 | 174,607 | 142,017 | 101,021 | 83,107 | 78,009 | 66,742 | 60,641 | 2,511,803 |
| Treated tonnes (000 t) | 1,488 | 1,452 | 1,448 | 1,387 | 1,371 | 988 | 986 | 913 | 730 | 549 | 438 | 438 | 365 | 312 | 12,865 |
| OPEX (C\$ per tonne) | 198 | 201 | 196 | 201 | 195 | 198 | 195 | 191 | 195 | 184 | 190 | 178 | 183 | 194 | 195 |Table 21.4 - Operating costs (OPEX) at LZ5 Mine (2023 to 2036) as estimated in 2023 LOM (000 C$)$

| Business Unit | Year |  |  |  |  |  |  |  |  |  |  |  |  |  | Total |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | 2022 | 2023 | 2024 | 2025 | 2026 | 2027 | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 | 2035 | 2036 |
| UG Geology | 954 | 815 | 1,175 | 589 | 512 | 512 | 381 | 307 | 225 | 44 | - | - | - | - | 5,513 |
| UG Development | 10,222 | 9,457 | 10,540 | 13,125 | 8,531 | 5,180 | 3,042 | 2,571 | 878 | 360 | - | - | - | - | 63,906 |
| UG Production | 23,604 | 24,527 | 27,608 | 29,955 | 30,650 | 32,605 | 23,144 | 18,172 | 10,973 | 1,462 | - | - | - | - | 222,700 |
| UG Services | 10,122 | 9,671 | 10,358 | 11,211 | 10,897 | 12,108 | 10,888 | 8,365 | 6,137 | 1,570 | - | - | - | - | 91,327 |
| UG Maintenance | 12,101 | 12,659 | 15,088 | 16,619 | 15,980 | 18,338 | 15,674 | 12,107 | 9,107 | 2,154 | - | - | - | - | 129,828 |
| Mill Production | 16,409 | 14,345 | 14,907 | 16,758 | 15,651 | 13,624 | 9,217 | 7,185 | 2,822 | (719) | - | - | - | - | 110,199 |
| Mill Services | 8,677 | 7,925 | 7,842 | 8,736 | 8,063 | 8,834 | 6,683 | 5,058 | 4,287 | 1,111 | - | - | - | - | 67,216 |
| Mill Maintenance | 10,038 | 8,258 | 8,431 | 9,380 | 8,874 | 9,775 | 7,743 | 5,857 | 3,902 | 1,041 | - | - | - | - | 73,299 |
| Site Administration | 4,250 | 4,331 | 4,576 | 4,634 | 4,634 | 4,185 | 4,062 | 3,642 | 2,426 | 648 | - | - | - | - | 37,387 |
| Site Services <br> Maintenance | 655 | 655 | 627 | 620 | 620 | 519 | 480 | 470 | 203 | (203) | - | - | - | - | 4,646 |
| Site Services | 1,263 | 1,263 | 1,193 | 1,202 | 1,202 | 1,202 | 1,034 | 848 | 743 | 477 | - | - | - | - | 10,426 |
| Direct Production Expenses | 98,294 | 93,907 | 102,345 | 112,829 | 105,614 | 106,883 | 82,346 | 64,581 | 41,703 | 7,945 | - | - | - | - | 816,447 |
| Private Royalty | 3,265 | 3,681 | 4,066 | 4,733 | 4,488 | 4,721 | 3,310 | 2,508 | 1,767 | 535 | - | - | - | - | 33,074 |
| Total Production Expenses After Stockpile | 101,559 | 97,588 | 106,411 | 117,561 | 110,102 | 111,604 | 85,656 | 67,089 | 43,471 | 8,480 | - | - | - | - | 849,521 |
| Total operating costs | 101,559 | 97,588 | 106,411 | 117,561 | 110,102 | 111,604 | 85,656 | 67,089 | 43,471 | 8,480 | - | - | - | - | 849,521 |
| Treated tonnes (000 t) | 1,155 | 1,155 | 1,237 | 1,372 | 1,372 | 1,372 | 975 | 750 | 500 | 134 | - | - | - | - | 10,021 |
| OPEX (C\$ per tonne) | 88 | 84 | 86 | 86 | 80 | 81 | 88 | 89 | 87 | 63 | - | - | - | - | 85 |

[[@~@]]
# 22 Economic Analysis

With the LaRonde Complex being a producing asset of the Company, the Company is not required to include information in this section as the Technical Report does not describe a material expansion of current production.
The Company has performed an economic analysis for the existing LaRonde Mine and LZ5 Mine at the LaRonde Complex using a gold price of using a gold price of $\mathrm{C} \$ 1,938$ per ounce, at the forecasted production rates, metal recoveries, and capital and operating cost estimated in the Technical Report. The Company confirms that the outcome is a positive cash flow that supports the mineral reserve estimate. Due to the nature of the mining business, these conditions can change significantly over relatively short periods of time. Consequently, actual results may be significantly more or less favourable.

[[@~@]]
# 23 Adjacent Properties

The Westwood Mine, owned and operated by Iamgold Corporation, is located on the Doyon property immediately west of the Ellison property at the LaRonde Complex. Westwood is an underground operation that began commercial gold production in July 2014. Westwood shares the same geological setting as the LaRonde Complex and it is part of the Doyon-BousquetLaRonde Mining Camp.
None of the other adjacent properties are considered relevant or material to the disclosure in the Technical Report.

[[@~@]]
# 24 Other Relevant Data And Information

No additional information or explanation is necessary within the terms of reference of the Technical Report.

[[@~@]]
# 25 Interpretations And Conclusions

The LaRonde Complex Property in the historic mining camp of Doyon-Bousquet-LaRonde, Québec, has produced 78.2 million tonnes of ore grading $4.63 \mathrm{~g} / \mathrm{t}$ gold for a total of 10.8 million ounces of gold to the end of 2022. The Property hosts the operating LaRonde and LZ5 underground mines, which the Company forecasts will produce annually up to 325,000 ounces of gold during the next seven years.
Commercial production at LaRonde Shaft \#1 began in 1988. Since then, LaRonde's commercial production never stopped but has fluctuated through a long history of successful exploration programs and acquisitions. Over 1.4 million metres of drilling has been completed by Agnico Eagle to date to expand known mineralized zones and discover new zones.
The Mineral Resources and Mineral Reserves for the Property are suitable for public reporting. As such, the Mineral Reserves are based on Measured and Indicated Mineral Resources, and do not include any Inferred Mineral Resources. Measured and Indicated Mineral Resources are exclusive of Proven and Probable Mineral Reserves and do not have demonstrated economic viability. The Mineral Resources and Mineral Reserves are compliant with NI 43-101 requirements and CIM 2014 Definition Standards.
The 2022 MRE is considered to be reliable and thorough, and based on quality data and reasonable hypotheses and parameters. The 2022 MRE further demonstrated the geological and grade continuities for several deposits on the LaRonde Complex Property and updated the mineral resource and mineral reserve estimates using data up to December 31, 2022.
The LaRonde Complex Property is estimated to contain (exclusive to the mineral reserves) total Measured and Indicated Mineral Resources of 15.7 million tonnes grading $2.41 \mathrm{~g} / \mathrm{t}$ gold for a total of 1.22 million ounces of gold and Inferred Mineral Resources of 15.3 million tonnes grading 3.47 $\mathrm{g} / \mathrm{t}$ gold for a total of 1.71 million ounces of gold.
The Mineral Resources and Mineral Reserves estimates for the LaRonde Complex Property are effective as at December 31, 2022.
The Life-of-Mine plans and Mineral Reserve estimate for the LaRonde Complex were developed from the geological block model prepared by AEM's LaRonde Division. As at the date of the Technical Report, the QPs have not identified any legal, political, or environmental risks that would materially affect potential development of the Mineral Reserves.
The total Proven and Probable Mineral Reserves at the LaRonde Complex are estimated at 22.7 million tonnes at $4.42 \mathrm{~g} / \mathrm{t}$ gold for 3.2 million ounces of gold. Most of the Mineral Reserve tonnage $(66 \%)$ is in the Probable category.
According to the 2023 LOM, production from the LaRonde Mine is scheduled between 2023 to 2036. Approximately 3,900 tonnes per day are to be extracted from 2023 to 2027, before the rate progressively declines until depletion is completed in 2036.

According to the 2023 LOM, production from the LZ5 Mine is planned from 2022 to 2032. Approximately 3,200 to 3,800 tonnes per day will be extracted until 2028. Starting in 2028 production will occur at a progressively declining rate until depletion in 2032.

Variations of the longhole open stoping mining method are used at the LaRonde Complex. At the LaRonde Mine, longitudinal and transverse longhole stoping are mainly used above Level 215. For lower levels, transverse open stoping method is almost exclusively used to address the mining in deep and high stress conditions. Overhand and underhand mining sequences, as well in primary-secondary or as in pillarless sequences, are implemented in different abutments of themine. The mining sequence is a key parameter to progressively divert stress from the orebody to reduce the seismic risk.

The mineral processing of the remaining ore from LaRonde and LZ5 will be performed in the current LaRonde mill and LZ5 mill. After the LaRonde mill start-up in 1988, many modifications were made to the mill that improved performance and operational flexibility. Subsequent metallurgical testwork confirmed that the material mined from the LaRonde and LZ5 deposits will be similar in the upcoming years and no major modifications will be required at the mill. However, some minor differences can have a small impact on some reagent consumption and the operating cost would then be adjusted accordingly. The current reagent addition systems have the capacity required to respond adequately to any such minor variations.

The results within the Technical Report are subject to variations in operational conditions including, but not limited to, the following:

- Assumptions related to commodity and foreign exchange
- Unanticipated inflation of capital or operating costs
- Significant changes in equipment productivities
- Geological continuity of the mineralized structures
- Geotechnical assumptions in underground infrastructure design
- Seismic activity due to deep mining operation
- Ore dilution or loss
- Throughput and recovery rate assumptions
- Changes in regulatory requirements that may affect the operation or future closure plans
- Changes in closure plan costs
- Change in workforce availability

The LaRonde Division of Agnico Eagle has performed an economic analysis using a gold price of C\$1,938 per ounce of gold. Minable stope shapes and COG were generated using a gold price of C\$1,690 per ounce of gold, at the forecasted production rates, metal recoveries, and capital and operating costs estimated in the Technical Report. The QPs responsible for the economic analysis in the Technical Report confirm that the outcome is a positive cash flow for the LaRonde Complex.

Environmental monitoring programs at the LaRonde Complex cover all aspects of the identified environmental impacts. These programs have been rigorously implemented and their results comply with all governmental and community requirements.

[[@~@]]
# 26 Recommendations

As the LaRonde Complex is an operating mining complex with no planned expansions, the QPs responsible for the Technical Report have no meaningful recommendations to make.

[[@~@]]
# 27 References

Anderson, J. B. "A Feasibility Study of the Preproduction and Operating Plans of Dumagami Mines Limited in Cadillac-Bousquet Townships, Province of Quebec." Consulting engineering report for Dumagami Mines Ltd., 1987.
Beak Consultants. "Étude des incidences environnementales du développement de la mine Dumagami, Cantons de Bousquet et de Cadillac, Comté Abitibi." Project A1445. Consulting firm report for Agnico Eagle, 1981b.
Beak Consultants. "Étude des répercussions environnementales du développement de la mine Bousquet, Canton de Bousquet, Comté Abitibi." Project A1427. Consulting firm report for Agnico Eagle, 1981a.
Bédard, N. Bousquet / Ellison, Rapport des Réserves/Ressources. Internal report, Agnico Eagle Mines Ltd., 2005, 12 p.
Belzile, E. Construction de blocs modèles Mine Bousquet - Zone 5. Unpublished report by consultant for Agnico Eagle Mines Ltd., Belzile Solutions Inc., 2011b, 11 p.
Belzile, E. Validation des données historiques, Mine Bousquet - Zone 5. Unpublished memorandum, Belzile Solutions Inc., 2011a, 6 p.
Boily-Auclair, É. Contrôles lithologiques et structuraux sur la nature, le style et la géométrie des zones aurifères de la Zone 5 du complexe minier LaRonde, Abitibi, Québec. Unpublished M.Sc. thesis, Institut national de la recherche scientifique, Eau, Terre et Environnement, Québec, 2022, 129 p.
Boily-Auclair, É, P. Mercier-Langevin, P. -S. Ross, and D. Pitre. Stratigraphic Setting of the LZ5 and Ellison Mineralized Zones, LaRonde Zone 5 Project, Doyon-Bousquet-LaRonde Mining Camp, Abitibi, Quebec. Vol. Open File 8712, in Targeted Geoscience Initiative 5: Contributions to the Understanding of Canadian Gold Systems, edited by P. MercierLangevin, C. J.M. Lawley and S. Castonguay, pp. 57-73. Geological Survey of Canada, 2020.

Card, K. D. A Review of the Superior Province of the Canadian Shield. Vols. 13: 5-13. Geoscience Canada, 1990.
Carrier, A. Internal Audit of the 2020 Mineral Resource and Mineral Reserve Estimate for the LaRonde Complex and the LaRonde Zone 5 Mine. Internal report, Agnico Eagle Mines Ltd., 2021, 27 p.
Chown, E. H., R. Daigneault, W. Mueller, and J. Mortensen. "Tectonic Evolution of the Northern Volcanic Zone, Abitibi Belt, Quebec." Canadian Journal of Earth Sciences Vol. 29 (1992): pp. 2211-2225.
CIM Standing Committee on Reserve Definitions. CIM Definition Standards for Mineral Resources \& Mineral Reserves. Canadian Institute of Mining, Metallurgy and Petroleum, 2014, 10 p.
D'Amours, C. Géostatistique Projet Bousquet Zone 4 et 5. Unpublished report by consultant, GéoPointCom, 2010, 13 p.
D'Amours, C. "Vérification des paramètres géostatistiques à utiliser pour l'estimation des réserves et ressources." Unpublished report by consultant for LaRonde Division at Agnico Eagle Mines Ltd., 2012, 34 p.De Chavigny, P. "Campagne de forage Été 2006, Propriété Terrex (PN-125), Mines Agnico-Eagle Ltée, Division Exploration, Canton Bousquet, Abitibi, Québec. GM-62833." Internal report, 2007, 37 p .
Dionne, L., and S. Boyd. "Agreement for Agnico Eagle Mines Limited to purchase Barrick Gold Corporation's interest in the El Coco property." Confidential document (including 3 schedules) signed June 9, 1999, 1999, 6 p.
Dubé, B., et al. "The Bousquet-2-Dumagami World-class Archean Au-rich Volcanogenic Massive Sulfide Deposit, Abitibi, Quebec: Metamorphosed Submarine Advanced Argillic Alteration Footprint and Genesis." Economic Geology Vol. 109 (2014): pp. 121-166.
Dubé, B., P. Mercier-Langevin, M. Hannington, and D. Davis. Le gisement de sulfures massifs aurifères volcanogènes LaRonde, Abitibi, Québec: Altérations, minéralisations et implications pour l'exploration. Ministère des Ressources naturelles, de la Faune et des Parcs du Québec. MB 2004-03, 2004, 112 p.
Dubé, B., P. Mercier-Langevin, M. Hannington, B. LaFrance, P. Gosselin, and G. Gosselin. "The LaRonde Penna World-Class Au-rich Volcanogenic Massive Sulfide Deposit, Abitibi, Quebec: Mineralogy and Geochemistry of Alteration and Implications for Genesis and Exploration." Economic Geology Vol. 102 (2007): pp. 633-666.
Dubé, B., P. Mercier-Langevin, M. Hannington, D. Davis, and J. Moorhead. Le gisement de sulfures massifs aurifères volcanogènes LaRonde, Abitibi, Québec: géologie, structure, altération, minéralisations et implications pour l'exploration, . Internal report on synthesis of Doyon, Bousquet-LaRonde mining camp. Feb. 27, 2003., Agnico Eagle Mines Ltd., 2003.
Gagnon, J. M. "Évaluation du potentiel économique de la zone 20 Sud de la mine LaRonde (Mines Agnico-Eagle Ltée), Canton de Cadillac, Comté d'Abitibi-Est." Report presented to M.Christian Morin, service des titres d'exploration, MRNQ, 2000, 17 p.

Girard, P. H., et al. LaRonde II Project 2006 Feasibility Study. Internal study, Agnico Eagle Mines Ltd., 2006.
Hallé, V. Mise en contexte - Trous de Bousquet. Internal report, LaRonde Division at AgnicoEagle Mines Ltd., 2015, 29 p.
Hodgson, C. J., and J. V. Hamilton. Gold Mineralization in the Abitibi Greenstone Belt: End-stage Results of Archean Collisional Tectonics? Vol. Monograph 6, in The Geology of Gold Deposits: The Perspective in 1988, edited by R. R. Keays, W. R.H. Ramsay and D. I. Groves, pp. 86-100. Economic Geology, 1989.
Lacoursière, F. Geostats_Satellites. Multiple files in internal folder from Technical Services, Agnico Eagle Mines Ltd., 2021.
Lacoursière, F. LaRonde Zone 11-3. Internal report, Agnico Eagle Mines Ltd., 2017, 19 p.
Lafrance, B., J. Moorhead, and D. Davis. "Cadre géologique du camp minier de Doyon-BousquetLaRonde. ET 2002-07." 2003, 43 p.
Lafrance, B., J. Moorhead, and D. W. Davis. Stratigraphie et volcanologie des parties ouest et centrale de la Formation de Bousquet. Internal report and poster on synthesis of Doyon and Bousquet-LaRonde mining camp, Agnico Eagle Mines Ltd., 2002.
Laplante, C. Rapport sur le programme d'exploration 2002, Propriété EI Coco, Canton Cadillac, Québec NTS 32D/08 et 32 D/01. Volume 1. GM-59818. Internal report, Agnico Eagle Mines Ltd., 2002, 399 p.
Legault, M. H. 2001 Ore Reserve Report. Internal report, Agnico Eagle Mines Ltd., 2001.Lombardi , D. 2001 Diamond Drilling Program on the Agnico-Eagle El Coco property, Cadillac twp, Abitibi, Quebec. Internal report, Agnico Eagle Mines Ltd., 2001, 14 p.
Lombardi, D. 2000 Diamond Drilling Program on the Agnico-Eagle Sphinx/El Coco properties, Cadillac twp, Abitibi, Quebec. Internal report, Agnico Eagle Mines Ltd., 2000, 12 p.
Marquis, P., C. Hubert, A.C. Brown, E. Scherkus, P. Trudel, and L.D. Hoy. Géologie de la mine Donald J. LaRonde (Dumagami), Cadillac, Québec. Ministère de l'Énergie et des Ressources du Québec, 1992, ET 89-06.
Mercier-Langevin, P. Campagne de forage, Propriété Ellison, Hiver 2006, Mines Agnico-Eagle Ltée, Division Exploration, Canton Bousquet, Abitibi, Québec. Volume 1/2. GM-62983. Agnico Eagle Mines Ltd., 2006, 306 p.
Mercier-Langevin, P. Géologie du gisement de sulfures massifs volcanogènes aurifères LaRonde, Abitibi, Québec. Unpublished Ph.D. thesis, Institut national de la recherche scientifique, Eau, Terre et Environnement, Québec, 2005, 694 p.
Mercier-Langevin, P., B. Dubé, F. Blanchet, D. Pitre, and A. Laberge. "The LaRonde Penna AuRich Volcanogenic Massive Sulfide Deposit, in Archean Base and Precious Metal Deposits, Southern Abitibi Greenstone Belt, Canada." Reviews in Economic Geology Vol. 19 (2017): pp. 225-245.
Mercier-Langevin, P., B. Dubé, M. D. Hannington, D. W. Davis, B. Lafrance, and G. Gosselin. "The LaRonde Penna Au-Rich Volcanogenic Massive Sulfide Deposit, Abitibi Greenstone Belt, Quebec: Part I. Geology and Geochronology." Economic Geology Vol. 102 (2007a): pp. 585-609.
Mercier-Langevin, P., B. Dubé, M. D. Hannington, M. Richer-Laflèche, and G. Gosselin. "The LaRonde Penna Au-rich Volcanogenic Massive Sulfide Deposit, Abitibi Greenstone Belt, Quebec: Part II. Lithogeochemistry and Paleotectonic Setting." Economic Geology Vol. 102 (2007b): pp. 611-631.
Mercier-Langevin, P., M. D. Hannington, B. Dubé, and V. Bécu. "The Gold Content of Volcanogenic Massive Sulfide Deposits." Mineralium Deposita Vol. 46 (2011): pp. 509539.

Moorhead, J., et al. "Synthèse du camp minier de Doyon-Bousquet-LaRonde." Résumé of poster presented to annual meeting of Ministère des Ressources Naturelles à Québec, 2000.
Mueller, W., R. Daigneault, J. Mortensen, and E. H. Chown. "Archean Terrane Docking: Upper Crust Collision Tectonics, Abitibi Greenstone Belt, Quebec, Canada." Tectonophysics Vol. 265 (1996): pp. 127-150.
Patry, S. May 2018 Geostatistical Study Report, LaRonde. Internal report, Agnico Eagle Mines Ltd., 2018, 94 p.
Patry, S. Memo sur la révision des paramètres géostatitiques, Mine LaRonde. Internal report, Agnico Eagle Mines Ltd., 2015, 283 p.
Pelletier, C. Internal Audit of the 2018 Mineral Resource and Mineral Reserve Estimate for the LaRonde Mine, LZ5 and Bousquet No2 Project. Internal report, Agnico Eagle Mines Ltd., 2019, 21 p.
Pitre, D. Geostatistical Study Report for Bousquet \#1, Zone 3 Area, LaRonde Complex. Internal report, LaRonde Division at Agnico Eagle Mines Ltd., 2020a.
Pitre, D. QA/QC Report, LaRonde Zone 5, First Half of 2020. Internal report, LaRonde Division at Agnico Eagle Mines Ltd., 2020b.Pitre, D. Validation of Historical Data of Bousquet \#2, Resampling Campaign 2019 of Resource in Massive Zone, Below Level 11-3. Internal report, LaRonde Division at Agnico Eagle Mines Ltd., 2019, 17 p.
Pitre, D., and G. Bastien. Geostatistical Study Report, LaRonde Complex. Internal report, LaRonde Division at Agnico Eagle Mines Ltd., 2022.
Pitre, D., et al. Bousquet Zone 5 Project, Quebec, Canada. Internal feasibility study on the Mineral Resources and Mineral Reserves, Agnico Eagle Mines Ltd., March 2012, 94 p.
Poulsen, K. H., K. D. Card, and J. M. Franklin. "Archean Tectonic and Metallogenic Evolution of the Superior Province of the Canadian Shield." Precambrian Research Vol. 58 (1992): pp. 25-54.

Teasdale, N., A. Brown, and G. Tourigny. Gîtologie de la Mine Bousquet 2. Ministère des Ressources Naturelles du Québec, 1996, 43 p.
Tourigny, G., et al. Géologie de la Mine Bousquet. Ministère des Ressources Naturelles du Québec, 1992, 99 p.
Trudel, P., P. Sauvé, G. Tourigny, C. Hubert, and L. Hoy. Synthèse des caractéristiques géologiques des gisements d'or de la région de Cadillac (Abitibi). Vols. MM 91-01. Ministère des Ressources Naturelles du Québec, 1992.
Turcotte, P., et al. Prefeasibility Study, LaRonde Zone 5. Internal report, Agnico Eagles Mines Ltd., 2017, 276 p.
Valliant, R. I., C. Mongeau, and R. Doucet. The Bousquet Pyritic Gold Deposit, Bousquet Region, Quebec: Descriptive Geology and Preliminary Interpretations on Genesis. Vol. 24, in Geology of Canadian Gold Deposits, pp. 41-49. Canadian Institute of Mining and Metallurgy, 1982.
Vermette, D. 2001 diamond drilling program on the Agnico-Eagle El-Coco property, Cadillac twp, Abitibi, Quebec. Internal report, Agnico Eagle Mines Ltd., 2002, 15 p.
Yergeau, D. Géologie du gisement synovolcanique aurifère atypique Westwood, Abitibi, Québec. Unpublished Ph.D. thesis, Institut national de la recherche scientifique, Eau, Terre et Environnement, Quebec, 2015, 671 p.