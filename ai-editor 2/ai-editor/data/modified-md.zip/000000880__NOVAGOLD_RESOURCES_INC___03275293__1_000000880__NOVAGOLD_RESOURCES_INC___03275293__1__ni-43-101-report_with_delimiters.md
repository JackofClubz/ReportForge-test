# NOVAGOLD 

## NOVAGOLD

## NI 43-101 Technical Report on the Donlin Gold Project, Alaska, USA

Prepared for: NOVAGOLD RESOURCES INC.
Prepared by:
Kirk Hanson, MBA, PE. Effective Date: June 1, 2021
Michael Woloschuk., P.Eng. Project No.: 244444
Henry Kim, P.Geo.# Important Notice 

This report was prepared for NOVAGOLD RESOURCES INC. (NOVAGOLD) by Wood Canada Limited (Wood). The quality of information, conclusions and estimates contained herein is consistent with the level of effort involved in Wood's services and based on: i) information available at the time of preparation, ii) data supplied by outside sources, and iii) the assumptions, conditions and qualifications set forth in this report. This report is intended to be used by NOVAGOLD, subject to the terms and conditions of its contract with Wood. Except for the purposes legislated under Canadian provincial and territorial securities law, any use of, or reliance on, this report by any third party is at that party's sole risk.# WOOd 

## CERTIFICATE OF QUALIFIED PERSON

Kirk Hanson, P.E.
Wood Group USA Inc.
10876 S River Front Pkwy \#250
South Jordan, UT 84095 USA

I, Kirk Hanson, MBA, P.E. am employed as a Technical Director, Open Pit Mining with Wood Group USA, Inc.
This certificate applies to the technical report titled NI 43-101 Technical Report on the Donlin Gold Project, Alaska, USA with an effective date of $1^{\text {st }}$ June 2021 (the "Technical Report").

I am registered as a Professional Engineer in the State of Idaho (\#11063), State of Nevada (\#10640) and the State of Alaska (\#12126). I graduated with a B.Sc. degree from Montana Tech of the University of Montana in 1989, and from Boise State University, with an MBA degree in 2004.

I have practiced my profession for 32 years. I was Engineering Superintendent at Barrick's Goldstrike operation, where I was responsible for all aspects of open-pit mining, mine designs, mine expansions and strategic planning. After earning an MBA in 2004, I was assistant manager of operations and maintenance for the largest road department in Idaho. In 2007, I joined AMEC (now Wood) as a principal mining consultant. Over the past 14 years, I have been the mining lead for multiple scoping, pre-feasibility, and feasibility studies. I have prepared or supervised preparation on numerous mining projects involving open pit mining methods, and audited mineral reserve estimates for mining operations in arctic mining locations. I have also completed financial modelling for multiple mines as part of completing the scoping, pre-feasibility and feasibility studies.

As a result of my experience and qualifications, I am a Qualified Person as defined in National Instrument 43-101 Standards of Disclosure for Mineral Projects (NI 43-101), for those sections and sub-sections of the technical report that I take responsibility.

The date of my most recent visit to the Donlin Gold project was 18 to 20 September 2020.

I am responsible for Sections 1.1-1.3, 1.7, 1.16-1.17, 1.19-1.25, 2, 3, 12.3, 12.5, 12.6.2, 12.6.4, 15, 16, 18, 19, 20, 21, 22, 25.6, 25.8 $-25.12,26$, and 27 of the Technical Report.

I am independent of NOVAGOLD Resources Inc. as independence is described by Section 1.5 of NI 43-101.
I have been involved with the Donlin Gold project since 2008, during preparation of the feasibility study and subsequent study updates since then. I was a co-author of the Donlin Creek Gold Project Alaska, USA, NI 43-101 Technical Report on Second Updated Feasibility Study with an effective date of 18 November 2011. I was involved in an extensive data verification exercise and cost estimate update on the feasibility study during 2020 and 2021, in support of the preparation of this Technical Report.

I have read NI 43-101 and the sections and sub-sections of the Technical Report for which I am responsible have been prepared in compliance with that Instrument.

As of the effective date of the Technical Report, to the best of my knowledge, information and belief, the sections and sub-sections of the Technical Report for which I am responsible contain all scientific and technical information that is required to be disclosed to make those sections of the Technical Report not misleading.

Dated: 30 July 2021
"Signed and sealed"

Kirk Hanson, MBA P.E.# WOOd. 

## CERTIFICATE OF QUALIFIED PERSON

Mike Woloschuk. P.Eng. Wood Group USA Inc. 10876 S River Front Pkwy \#250
South Jordan, UT 84095 USA

I, Mike Woloschuk, P.Eng. am employed as a Vice President Global Business Development, Mining \& Minerals with Wood Group USA, Inc.

This certificate applies to the technical report titled NI 43-101 Technical Report on the Donlin Gold Project, Alaska, USA with an effective date of June $1^{\text {st }}, 2021$ (the "Technical Report").

I am registered as a Professional Engineer in the Province of Ontario, Canada (\#90453986), since 1997. I graduated with a B.Sc. degree in Chemistry (Advanced) from the University of Saskatchewan, in 1992, and a B.Sc. in Chemical Engineering from the University of Saskatchewan, in 1995.

I have practiced my profession for 26 years. Prior to joining Wood I was: 2016 - 2018 Group Industry Director, Gold with FLSnidth and was involved in technology development leadership, project execution strategy, and provision of technical solutions to gold mining clients; 2012 -2015 with Waterton Global Resource Management where I led multi-discipline teams through due diligence and technical evaluations, managed mining project studies and EPCM consultants; 2010 - 2012 Barrick Gold as Senior Director, Evaluations \& Capital Projects including Donlin Gold project; 2008 - 2010 Aker Solutions (now Jacobs) as process manager or process lead for several advanced base metal mining studies; 2006 - 2008 Bateman Engineering as process lead for conventional and POX gold recovery mining project; 2001 - 2006 process manager or process engineer on several nickel processing operations in Australia and South Pacific; 1999 - 2001 Cameco as process lead on various uranium process operations; 1995 - 1999 Falconbridge involved in development of hydromet processes at Sudbury operations and Kidd Creek concentrator in Ontario.

As a result of my experience and qualifications, I am a Qualified Person as defined in National Instrument 43-101 Standards of Disclosure for Mineral Projects (NI 43-101), for those sections and sub-sections of the technical report that I take responsibility.

I visited the Donlin Gold project site on 15 September 2010.

I am responsible for Sections 1.14, 1.18, 2.3, 11.2, 12.4, 12.6.3, 13, 17, 18.2, 21, 25.4, 25.7, 26, and 27 of the Technical Report.

I am independent of NOVAGOLD Resources Inc. as independence is described by Section 1.5 of NI 43-101.
I was involved with the Donlin Gold project during 2010 - 2012 as part of Barrick's owner team steering committee for the feasibility study update. I was involved in an extensive data verification exercise and cost estimate update on the feasibility study during 2020 and 2021, in support of the preparation of this Technical Report.

I have read NI 43-101 and the sections and sub-sections of the Technical Report for which I am responsible have been prepared in compliance with that Instrument.

As of the effective date of the Technical Report, to the best of my knowledge, information and belief, the sections and sub-sections of the Technical Report for which I am responsible contain all scientific and technical information that is required to be disclosed to make those sections of the Technical Report not misleading.

Dated: 30 July 2021
"Signed and sealed"

Mike Woloschuk, P.Eng.# WOOd. 

## CERTIFICATE OF QUALIFIED PERSON

Henry Kim, P.Geo.:
Wood Canada Limited
\#400-111 Dunsmuir St.
Vancouver, $B C$,
Canada V6B 5W3

I, Henry Kim, P.Geo. am employed as a Senior Resource Geologist with Wood Canada Limited.
This certificate applies to the technical report titled NI 43-101 Technical Report on the Donlin Gold Project, Alaska, USA with an effective date of 1 June 2021 (the "Technical Report").

I am registered as a Professional Geoscientist with Engineers and Geoscientists British Columbia. I graduated with a B.Sc. degree in geology from University of British Columbia in 2008. I completed the Applied Geostatistics Citation Program, with the University of Alberta in 2014.

I have practiced my profession for 14 years. I have been involved in exploration drilling programs involving core logging, sampling, QAQC, and database validation. I conducted onsite grade control and management of mine operation crews for an open pit mine in eastern Canada. I have conducted audits and due diligence exercises on geological models, sampling databases, drill hole spacing studies, preparation of resource models, validation of mineral resource estimates, and mineral resource estimates on advanced mining studies and active mine operations.

As a result of my experience and qualifications, I am a Qualified Person as defined in National Instrument 43-101 Standards of Disclosure for Mineral Projects (NI 43-101), for those sections and sub-sections of the technical report that I take responsibility.

The date of my most recent visit to the Donlin Gold project was 18 to 20 September 2020.

I am responsible for Sections 1.4-1.6, 1.8-1.13, 1.15, 2.3, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12.1, 12.2, 12.6.1, 14, 23, 24, 25.1-25.3, 25.5, 26, and 27 of the Technical Report.

I am independent of NOVAGOLD Resources Inc. as independence is described by Section 1.5 of NI 43-101.
I was involved in an extensive data verification exercise on the geological model and sampling database, and validation exercise on the Donlin mineral resource estimate during 2020 and 2021, in support of the preparation of this Technical Report.

I have read NI 43-101 and the sections and sub-sections of the Technical Report for which I am responsible have been prepared in compliance with that Instrument.

As of the effective date of the Technical Report, to the best of my knowledge, information and belief, the sections and sub-sections of the Technical Report for which I am responsible contain all scientific and technical information that is required to be disclosed to make those sections of the Technical Report not misleading.

Dated: 30 July 2021
"Signed and stamped"

Henry Kim, P.Geo.CONTENTS
1.0 SUMMARY ..... $1-1$
1.1 Principal Outcomes ..... $1-1$
1.2 Location, Climate, and Access ..... $1-2$
1.3 Agreements ..... $1-3$
1.4 Mineral Tenure ..... $1-3$
1.5 Surface Rights ..... $1-4$
1.6 Royalties ..... $1-4$
1.7 Environment, Permitting and Social and Community Impact ..... $1-5$
1.8 Geology and Mineralization ..... $1-6$
1.9 Exploration ..... $1-7$
1.10 Exploration Potential ..... $1-7$
1.11 Drilling ..... $1-8$
1.12 Sample Analysis and Security ..... $1-9$
1.13 Data Verification ..... $1-10$
1.14 Metallurgical Testwork ..... $1-10$
1.15 Mineral Resource Estimate ..... $1-15$
1.16 Mineral Reserve Estimate ..... $1-18$
1.17 Proposed Mine Plan ..... $1-20$
1.18 Process Design ..... $1-21$
1.19 Planned Project Infrastructure ..... $1-23$
1.20 Markets ..... $1-24$
1.21 Capital Costs ..... $1-24$
1.22 Operating Costs ..... $1-26$
1.23 Economic Analysis ..... $1-26$
1.24 Conclusions ..... $1-28$
1.25 Recommendations ..... $1-28$
2.0 INTRODUCTION ..... 2-1
2.1 Terms of Reference ..... 2-1
2.2 Qualified Persons ..... 2-4
2.3 Site Visits and Scope of Personal Inspections ..... 2-4
2.4 Effective Dates ..... 2-5
2.5 Previous Technical Reports ..... 2-5
2.6 Information Sources and References ..... 2-6
3.0 RELIANCE ON OTHER EXPERTS ..... 3-1
3.1 Mineral Tenure, Surface Rights, Agreements, and Royalties ..... 3-1
3.2 Taxation ..... 3-2
4.0 PROPERTY DESCRIPTION AND LOCATION ..... 4-1
4.1 Location ..... 4-1
4.2 Property Ownership History ..... 4-14.3 Lease Rights ..... $4-3$
4.4 Mineral Tenure ..... $4-4$
4.5 Surface Rights ..... $4-5$
4.6 Royalties and Encumbrances. ..... $4-5$
4.7 Permits ..... $4-6$
4.8 Environmental Liabilities ..... $4-6$
4.9 Social License ..... $4-7$
4.10 Significant Risk Factors ..... $4-7$
4.11 Comments on Section 4 ..... $4-7$
5.0 ACCESSIBILITY, CLIMATE, LOCAL RESOURCES, INFRASTRUCTURE, AND PHYSIOGRAPHY ..... $5-1$
5.1 Accessibility ..... $5-1$
5.2 Climate ..... $5-1$
5.3 Local Resources and Infrastructure ..... $5-1$
5.4 Physiography ..... $5-2$
5.5 Sufficiency of Surface Rights ..... $5-2$
5.6 Comments on Section 5 ..... $5-2$
6.0 HISTORY ..... $6-1$
7.0 GEOLOGICAL SETTING AND MINERALIZATION ..... $7-1$
7.1 Regional Geology ..... $7-1$
7.2 Project Geology ..... $7-2$
7.2.1 Lithologies ..... $7-2$
7.2.2 Structure ..... $7-3$
7.3 Deposit Setting ..... $7-4$
7.4 Paragenesis ..... $7-4$
7.5 Deposit Geology ..... $7-5$
7.5.1 Sedimentary Rocks ..... $7-5$
7.5.2 Igneous Rocks ..... $7-6$
7.5.3 Structure ..... $7-8$
7.6 Deposits ..... $7-10$
7.7 Mineralization ..... $7-11$
7.7.1 Vein and Disseminated Mineralization ..... $7-11$
7.8 Alteration ..... $7-13$
7.9 Minor Elements ..... $7-13$
7.10 Comments on Section 7 ..... $7-14$
8.0 DEPOSIT TYPES ..... $8-1$
8.1 Comments on Section 8 ..... $8-1$
9.0 EXPLORATION ..... $9-1$
9.1 Grids and Surveys ..... $9-1$
9.2 Geological Mapping ..... $9-1$
9.3 Geochemical Sampling ..... $9-1$
9.4 Geophysics ..... $9-1$9.5 Pits and Trenches ..... 9-2
9.6 Petrology, Mineralogy, and Research Studies ..... 9-2
9.7 Geotechnical and Hydrological Studies ..... 9-2
9.8 Metallurgical Studies ..... 9-3
9.9 Exploration Potential ..... 9-3
9.9.1 Far Side ..... 9-3
9.9.2 Duqum ..... 9-5
9.9.3 Snow / Quartz ..... 9-5
9.9.4 Dome ..... 9-6
9.9.5 Ophir ..... 9-6
9.10 Comments on Section 9 ..... 9-6
10.0 DRILLING ..... $10-1$
10.1 Drill Methods ..... $10-1$
10.2 Geological Logging ..... $10-4$
10.3 Recovery ..... $10-5$
10.4 Collar Surveys ..... $10-5$
10.5 Down-hole Surveys ..... $10-5$
10.6 Geotechnical and Hydrological Drilling ..... $10-6$
10.7 Metallurgical Drilling ..... $10-6$
10.8 Condemnation Drilling ..... $10-6$
10.9 Twin Drilling ..... $10-6$
10.10 Summary of Drill Intercepts ..... $10-6$
10.11 Comments on Section 10 ..... $10-18$
11.0 SAMPLE PREPARATION, ANALYSES, AND SECURITY ..... $11-1$
11.1 Sampling Methods ..... $11-1$
11.2 Metallurgical Sampling ..... $11-1$
11.3 Density / Specific Gravity Determinations ..... $11-1$
11.4 Analytical and Test Laboratories ..... $11-3$
11.5 Sample Preparation and Analysis ..... $11-4$
11.6 Quality Assurance and Quality Control ..... $11-5$
11.6.1 1995-2002 QA/QC Protocol ..... $11-5$
11.6.2 2005-2006 QA/QC Protocol ..... $11-6$
11.6.3 2007-2010 QA/QC Protocol ..... $11-6$
11.6.4 2017 QA/QC Protocol ..... $11-6$
11.6.5 2020 QA/QC Protocol ..... $11-6$
11.6.6 Standard Reference Materials ..... $11-7$
11.6.7 Blank Materials ..... $11-7$
11.7 Databases ..... $11-7$
11.8 Sample Security ..... $11-8$
11.9 Comments on Section 11 ..... $11-8$
12.0 DATA VERIFICATION ..... $12-1$
12.1 Drill Hole Database ..... $12-1$12.1.1 Wood (2002) ..... $12-1$
12.1.2 NOVAGOLD (2005) ..... $12-1$
12.1.3 NOVAGOLD (2008) ..... $12-1$
12.1.4 Wood (2011) ..... $12-2$
12.2 Geology and Resource Data ..... $12-2$
12.2.1 Wood (2021) ..... $12-2$
12.3 Mining and Infrastructures ..... $12-3$
12.3.1 Operations Water Treatment Plan ..... $12-4$
12.3.2 TSF, WRF, Contact and Freshwater Dams, and Water Diversion Structures ..... $12-5$
12.3.3 Natural Gas Pipeline ..... $12-5$
12.4 Metallurgy and Mineral Process ..... $12-6$
12.5 Economic Analysis ..... $12-6$
12.6 Comments on Section 12 ..... $12-7$
12.6.1 Geology and Resources ..... $12-7$
12.6.2 Mining and Infrastructure ..... $12-7$
12.6.3 Metallurgy and Mineral Process ..... $12-7$
12.6.4 Financial Model ..... $12-8$
13.0 MINERAL PROCESSING AND METALLURGICAL TESTING ..... $13-1$
13.1 Metallurgical Testwork ..... $13-1$
13.1.1 Domains ..... $13-1$
13.1.2 Gold Department ..... $13-4$
13.1.3 Mercury, Chlorine, Carbonates and Organic Carbon Department ..... $13-5$
13.1.4 Samples ..... $13-5$
13.1.5 Comminution ..... $13-6$
13.1.6 Flotation ..... $13-19$
13.1.7 Pressure Oxidation (POX) ..... $13-25$
13.1.8 Neutralization ..... $13-34$
13.1.9 Carbon-in-Leach (CIL) ..... $13-41$
13.1.10 Thickening and Counter-Current Decantation (CCD) Washing ..... $13-46$
13.1.11 Environmental Testwork ..... $13-47$
13.2 Recovery Estimates ..... $13-48$
13.2.1 Flotation ..... $13-48$
13.2.2 Pressure Oxidation (POX) ..... $13-54$
13.2.3 Overall Plant Gold Recovery ..... $13-55$
13.3 Metallurgical Variability ..... $13-55$
13.4 Deleterious Elements ..... $13-56$
13.5 Comments on Section 13 ..... $13-56$
14.0 MINERAL RESOURCE ESTIMATES ..... $14-1$
14.1 Key Assumptions / Basis of Estimate ..... $14-1$
14.2 Geological Models ..... $14-1$
14.3 Exploratory Data Analysis ..... $14-3$
14.4 Density Assignment ..... $14-4$14.5 Grade Capping / Outlier Restrictions ..... $14-5$
14.5.1 Gold, Sulphur, Arsenic, Mercury, and Antimony Grade Caps ..... $14-5$
14.5.2 Neutralization Potential Grade Caps ..... $14-5$
14.6 Composites ..... $14-6$
14.6.1 Gold, Sulphur, Arsenic, Mercury, and Antimony Composites ..... $14-6$
14.6.2 Neutralization Potential Composites ..... $14-6$
14.7 Gold and Sulphur Indicator Models ..... $14-7$
14.7.1 Overburden ..... $14-8$
14.8 Variography Performed in Support of Probability Assisted Grade Model ..... $14-8$
14.9 Estimation / Interpolation Methods ..... $14-9$
14.9.1 Gold ..... $14-9$
14.9.2 Sulphur ..... $14-9$
14.9.3 Arsenic, Mercury, and Antimony ..... $14-10$
14.9.4 Calcium, Magnesium and Carbon Dioxide ..... $14-10$
14.9.5 Neutralization Potential ..... $14-10$
14.9.6 Classification of Waste Rock Management Categories ..... $14-11$
14.10 Dilution ..... $14-12$
14.11 Classification of Mineral Resources ..... $14-12$
14.12 Reasonable Prospects of Eventual Economic Extraction ..... $14-12$
14.12.1 Block Value Calculations for Marginal Cut-off Application ..... $14-14$
14.13 Wood QP Review ..... $14-15$
14.14 Mineral Resource Currency Check ..... $14-18$
14.15 Mineral Resource Statement ..... $14-18$
14.16 Comments on Section 14 ..... $14-20$
15.0 MINERAL RESERVE ESTIMATES ..... $15-1$
15.1 Key Assumptions / Basis of Estimate ..... $15-1$
15.2 Dilution and Mining Losses ..... $15-2$
15.3 Conversion Factors from Mineral Resources to Mineral Reserves ..... $15-5$
15.3.1 Mining Costs ..... $15-5$
15.3.2 Processing Costs ..... $15-6$
15.3.3 General and Administrative (G\&A) Cost ..... $15-6$
15.3.4 Metallurgical Recovery ..... $15-7$
15.3.5 Refining, Freight, and Royalties ..... $15-8$
15.3.6 Metal Prices ..... $15-8$
15.3.7 Pit Slopes ..... $15-8$
15.3.8 Sensitivity of Optimized Pit ..... $15-10$
15.4 Mineral Reserves Statement ..... $15-10$
15.5 Comments on Section 15 ..... $15-11$
16.0 MINING METHODS ..... $16-1$
16.1 Throughput Considerations ..... $16-1$
16.2 Pit Design ..... $16-1$
16.3 Geotechnical Considerations ..... $16-1$16.3.1 Rock Mass Model ..... $16-1$
16.3.2 Open Pit Slope Design ..... $16-2$
16.3.3 Recommended Design Parameters ..... $16-3$
16.4 Pit Phases ..... $16-3$
16.5 Haul Roads ..... $16-5$
16.6 Production Schedule ..... $16-6$
16.6.1 Planned Production Schedule ..... $16-6$
16.6.2 Pit-Phase Mining Rates ..... $16-7$
16.6.3 Process Feed Plan ..... $16-8$
16.7 Ore Stockpiles ..... $16-11$
16.8 Waste Rock Scheduling and NAG/PAG Management ..... $16-12$
16.8.1 Overburden Scheduling and Concurrent Reclamation ..... $16-14$
16.9 Water Management and Treatment ..... $16-14$
16.10 Ore Control ..... $16-14$
16.11 Blasting and Explosives ..... $16-15$
16.12 Mining Equipment ..... $16-15$
16.12.1 Drilling ..... $16-16$
16.12.2 Loading ..... $16-16$
16.12.3 Hauling ..... $16-16$
16.12.4 Secondary Fleet ..... $16-16$
16.12.5 Support Equipment ..... $16-17$
16.12.6 Maintenance Considerations ..... $16-17$
16.12.7 Communications Considerations ..... $16-17$
16.13 Work Schedule ..... $16-21$
16.14 Comments on Section 16 ..... $16-21$
17.0 RECOVERY METHODS ..... $17-1$
17.1 Plant Design ..... $17-1$
17.1.1 General ..... $17-1$
17.1.2 Crushing and Coarse Ore Stockpile ..... $17-3$
17.1.3 Grinding and Pebble Crushing ..... $17-3$
17.1.4 Flotation ..... $17-4$
17.1.5 Thickening, Concentrate Storage, Acidulation, and CCD Washing ..... $17-6$
17.1.6 Autoclave Plant ..... $17-6$
17.1.7 CCD POX Thickening and Washing ..... $17-8$
17.1.8 Flotation Tailings Neutralization ..... $17-8$
17.1.9 Solids CIL Neutralization ..... $17-9$
17.1.10 Carbon-in-Leach Cyanidation Circuit ..... $17-9$
17.1.11 Cyanide Destruction System ..... $17-10$
17.1.12 Carbon Elution, Electrowinning, Reactivation, and Gold Refining ..... $17-10$
17.1.13 Mercury Abatement Systems ..... $17-11$
17.1.14 Reagent Preparation ..... $17-13$
17.2 Process Services ..... $17-14$
17.2.1 Air and Gaseous Oxygen ..... $17-14$17.2.2 Plant Water Distribution ..... $17-14$
17.3 Process Ventilation ..... $17-16$
17.4 Control System ..... $17-17$
17.5 Laboratories ..... $17-18$
17.6 Process Feed Schedule ..... $17-18$
17.7 Comments on Section 17 ..... $17-20$
18.0 PROJECT INFRASTRUCTURE ..... $18-1$
18.1 Access and Logistics. ..... $18-1$
18.1.1 Port-to-Mine Access Road ..... $18-1$
18.1.2 Road Construction ..... $18-1$
18.1.3 Airstrip ..... $18-2$
18.1.4 Cargoes ..... $18-3$
18.1.5 Fuel ..... $18-3$
18.2 Site Facilities ..... $18-4$
18.2.1 Site Investigations ..... $18-4$
18.2.2 Plant Site Design Considerations ..... $18-5$
18.2.3 Plant Site Facilities ..... $18-7$
18.3 Camps and Accommodation ..... $18-8$
18.4 Waste Storage Facilities ..... $18-9$
18.4.1 Location ..... $18-9$
18.4.2 Acid-base Accounting ..... $18-9$
18.4.3 Construction Plan ..... $18-11$
18.5 Tailings Storage Facilities ..... $18-12$
18.5.1 Design Considerations ..... $18-14$
18.6 Water Management ..... $18-17$
18.6.1 Water Balance ..... $18-17$
18.6.2 Construction Water Management Strategy ..... $18-17$
18.6.3 Operations Water Management Strategy ..... $18-23$
18.6.4 Closure Water Management Strategy ..... $18-27$
18.7 Bethel Marine Terminal ..... $18-29$
18.8 Jungjuk Port Site ..... $18-30$
18.9 Power and Electrical ..... $18-31$
18.10 Natural Gas Pipeline ..... $18-33$
18.11 Fuel ..... $18-33$
18.11.1 Diesel ..... $18-33$
18.11.2 Natural Gas ..... $18-34$
18.12 Comment on Section 18 ..... $18-34$
19.0 MARKET STUDIES AND CONTRACTS ..... $19-1$
19.1 Marketing Partnership Agreement ..... $19-1$
19.2 Gold Marketing ..... $19-1$
19.3 Comments on Section 19 ..... $19-1$
20.0 ENVIRONMENTAL STUDIES, PERMITTING, AND SOCIAL COMMUNITY IMPACT ..... $20-1$20.1 Baseline Studies ..... $20-1$
20.2 Environmental Issues ..... $20-1$
20.3 Closure Plan ..... $20-5$
20.3.1 Water Treatment Plant ..... $20-6$
20.3.2 Tailings Storage Facility ..... $20-6$
20.3.3 Waste Rock Facility ..... $20-6$
20.3.4 Roads and Airstrip ..... $20-7$
20.3.5 Foundations and Buildings ..... $20-7$
20.3.6 Waste Disposal ..... $20-7$
20.3.7 Port Facilities, Access Road, Airstrip, and Personnel Camp ..... $20-7$
20.3.8 Mobile Equipment ..... $20-7$
20.3.9 Trust Fund and Financial Assurance ..... $20-8$
20.3.10 Closure Cost Estimate ..... $20-8$
20.4 Permitting ..... $20-9$
20.4.1 Exploration Stage Permitting ..... $20-20$
20.4.2 Pre-Application Phase ..... $20-20$
20.4.3 The NEPA Process and Permit Applications ..... $20-21$
20.4.4 Laws, Regulations, and Permit Requirements ..... $20-22$
20.5 Considerations of Social and Community Impacts ..... $20-22$
20.5.1 Stakeholders ..... $20-24$
20.5.2 Community Development and Sustainability ..... $20-26$
20.6 Comments on Section 20 ..... $20-27$
21.0 CAPITAL AND OPERATING COSTS ..... $21-1$
21.1 Capital Cost Estimates ..... $21-1$
21.1.1 Basis of Estimate ..... $21-3$
21.1.2 Initial Capital Direct Cost Updates ..... $21-5$
21.1.3 Owner's Initial Capital Costs ..... $21-7$
21.1.4 Indirect Initial Capital Costs ..... $21-7$
21.1.5 Initial Capital Contingency ..... $21-7$
21.1.6 Sustaining Capital ..... $21-8$
21.1.7 Initial Capital Cost Summary ..... $21-9$
21.2 Operating Cost Estimates ..... $21-10$
21.2.1 Basis of Estimate ..... $21-11$
21.2.2 Mine Operating Costs ..... $21-14$
21.2.3 Process Operating Costs ..... $21-15$
21.2.4 General and Administrative Operating Costs ..... $21-17$
21.2.5 Operating Cost Summary ..... $21-18$
21.3 Comments on Section 21 ..... $21-19$
22.0 ECONOMIC ANALYSIS ..... $22-1$
22.1 Valuation Methodology ..... $22-1$
22.2 Financial Model Parameters ..... $22-1$
22.2.1 Production Forecast ..... $22-1$22.2.2 Metallurgical Recoveries ..... $22-2$
22.2.3 Smelting and Refining Terms. ..... $22-2$
22.2.4 Metal Prices ..... $22-2$
22.2.5 Capital Costs ..... $22-2$
22.2.6 Operating Costs ..... $22-2$
22.2.7 Royalties ..... $22-4$
22.2.8 Working Capital ..... $22-4$
22.2.9 Taxes ..... $22-4$
22.2.10 Closure Costs and Salvage Value ..... $22-5$
22.2.11 Financing ..... $22-5$
22.2.12 Inflation ..... $22-6$
22.3 Economic Results ..... $22-6$
22.4 Sensitivity Analysis ..... $22-9$
22.5 Comment on Section 22 ..... $22-11$
23.0 ADJACENT PROPERTIES ..... $23-1$
24.0 OTHER RELEVANT DATA AND INFORMATION ..... $24-1$
25.0 INTERPRETATION AND CONCLUSIONS ..... $25-1$
25.1 Agreements, Mineral Tenure, Surface Rights, and Royalties ..... $25-1$
25.2 Geology and Mineralization ..... $25-1$
25.3 Exploration, Drilling, and Data Analysis ..... $25-2$
25.4 Metallurgical Testwork ..... $25-3$
25.5 Mineral Resource Estimation ..... $25-4$
25.6 Mineral Reserve Estimation ..... $25-5$
25.7 Process Design ..... $25-6$
25.8 Infrastructure Considerations ..... $25-8$
25.9 Environmental, Social Issues and Permitting ..... $25-10$
25.10 Capital and Operating Cost Estimates ..... $25-12$
25.11 Economic Analysis ..... $25-13$
25.12 Conclusions ..... $25-13$
26.0 RECOMMENDATIONS ..... $26-1$
27.0 REFERENCES ..... $27-1$
TABLES

Table 1-1: Mineral Resources Summary Table, (Inclusive of Mineral Reserves) Effective Date 11 July 2011, Henry Kim, P.Geo ..... $1-17$
Table 1-2: Proven and Probable Mineral Reserves, Effective Date 27 April 2021, K. Hanson, P.E. ..... $1-19$
Table 1-3: Initial Capital Estimate ..... $1-25$
Table 1-4: Sustaining Capital Estimate ..... $1-25$
Table 1-5: LOM Operating Costs ..... $1-26$
Table 1-6: Summary of Key Evaluation Metrics ..... $1-28$
Table 2-1: Consulting Firms or Entities Contributing to Content in the Technical Report ..... $2-3$Table 2-2: QPs, Areas of Report Responsibility, and Site Visits ..... 2-5
Table 6-1: Exploration Work History Summary for Donlin Gold Property ..... $6-3$
Table 7-1: Donlin Gold Project Stratigraphy ..... $7-6$
Table 7-2: Donlin Gold Project Intrusive Rocks ..... $7-7$
Table 7-3: Vein Stages ..... $7-12$
Table 10-1: RC and Core Drill Summary Table ..... $10-2$
Table 10-2: Drill Hole Intercept Summary Table ..... $10-8$
Table 10-3: Far Side ..... $10-17$
Table 10-4: Duqum ..... $10-17$
Table 10-5: Snow / Quartz ..... $10-17$
Table 10-6: Dome ..... $10-18$
Table 11-1: Specific Gravity Values by Rock Type. ..... $11-3$
Table 11-2: Specific Gravity Values by Grouped Rock Type ..... $11-3$
Table 13-1: Intrusive and Sedimentary Lithologies of the Donlin Gold Project ..... $13-2$
Table 13-2: Major Geological Domains Within the Mine Plan ..... $13-2$
Table 13-3: Vein Types ..... $13-3$
Table 13-4: Typical Sulphide and Metals Mineralization in the Donlin Ores ..... $13-4$
Table 13-5: Grinding Testwork Results from Hazen Research ..... $13-7$
Table 13-6: Summary of Grindability Testing ..... $13-7$
Table 13-7: Comparison of Average Results from 2006 and 2007 Test Programs ..... $13-10$
Table 13-8: Adjustments Made to the 2006 Test Program Data ..... $13-11$
Table 13-9: Orebody Estimation of Crushing Index (Ci) ..... $13-14$
Table 13-10: Orebody Estimation of SAG Power Index (SPI) ..... $13-14$
Table 13-11: Orebody Estimation of Bond Ball Work Index (BWI) ..... $13-14$
Table 13-12: Productivity Improvement Assumptions for the Feasibility Study ..... $13-18$
Table 13-13: CIL Results from Pilot Flotation Tails ..... $13-43$
Table 13-14: Summary of Average Flotation Recovery in Variability Testwork Program, by Geological Domain ..... $13-51$
Table 13-15: Summary of Flotation Recovery in Variability Testwork Program by Geological Domain and Adjusted to MCF2 Pilot Result ..... $13-53$
Table 14-1: Summary of Capping Grades for Major Rock Types ..... $14-5$
Table 14-2: Summary of Capping Values for Neutralization Potential, with COV and GT Lost ..... $14-6$
Table 14-3: Donlin Project Mineral Resource Classification Methodology ..... $14-12$
Table 14-4: Assumptions used for Calculation of Block Value for Mineral Resources (Using 2011 Economic Parameters) ..... $14-13$
Table 14-5: Assumptions used for Calculation of Block Value for Mineral Resources (Using 2020 Economic Parameters) ..... $14-13$
Table 14-6: Process Recoveries used in Calculation of Block Value for Mineral Resources ..... $14-14$
Table 14-7: Mineral Resource Assessment Variance Check from 2011 to 2020 Economic Parameters ..... $14-18$
Table 14-8: Mineral Resources Summary Table, (Inclusive of Mineral Reserves) Effective Date 11 July 2011, Henry Kim, P.Geo. ..... $14-19$
Table 15-1: Assumptions used for Calculation of BVs for Mineral Reserves ..... $15-1$
Table 15-2: Net Model Adjustments (within pit design) ..... $15-4$
Table 15-3: Escalated Mining Costs ..... $15-5$Table 15-4: Escalated Processing Costs ..... $15-6$
Table 15-5: Escalated G\&A Cost ..... $15-7$
Table 15-6: Pit Optimization Process Recoveries ..... $15-7$
Table 15-7: Pit Optimization Slopes ..... $15-9$
Table 15-8: Proven and Probable Mineral Reserves, Effective Date 27 April 2021, K. Hanson, P.E ..... $15-11$
Table 16-1: Summary Projected Mine Production Plan by Year. ..... $16-9$
Table 16-2: Annual Required Drill Fleet ..... $16-18$
Table 16-3: Annual Shovel Fleet Required ..... $16-18$
Table 16-4: Mine Support Equipment ..... $16-19$
Table 16-5: Mine Auxiliary Equipment ..... $16-19$
Table 16-6: Mine Equipment Requirements ..... $16-20$
Table 17-1: Projected Process Schedule and Recoveries ..... $17-19$
Table 18-1 Factors of Safety for Tailings Dam Side-Slopes under Static Conditions ..... $18-15$
Table 20-1: Environmental Baseline Studies (1995 - 2020) ..... $20-2$
Table 20-2: Key Environmental Issues ..... $20-3$
Table 20-3: Estimated Reclamation Costs ..... $20-9$
Table 20-4: Status of Federal, State and Local Permits ..... $20-11$
Table 21-1: Construction Labour Rates ..... $21-3$
Table 21-2: Concrete Material Supply Unit Cost ..... $21-4$
Table 21-3: Fabricated Steel Supply Unit Cost ..... $21-5$
Table 21-4: Initial Capital Cost Contingency ..... $21-8$
Table 21-5: Summary of Initial Capital Costs by Major Area ..... $21-10$
Table 21-6: Comparison of 2011 and 2020 Energy Prices ..... $21-12$
Table 21-7: Process Consumable Unit Cost ..... $21-13$
Table 21-8: LOM Mining Operating Cost by Cost Item ..... $21-14$
Table 21-9: LOM Process Operating Costs ..... $21-16$
Table 21-10: LOM G\&A Operating Cost Estimate by Cost Item ..... $21-17$
Table 21-11: LOM Operating Costs ..... $21-18$
Table 21-12: Annual Operating Costs ..... $21-19$
Table 22-1: Summary of Key Evaluation Metrics ..... $22-6$
Table 22-2: Cash Flow Analysis ..... $22-7$
Table 22-3: Base Case Project Sensitivity to Gold Price (Base Case is highlighted) ..... $22-10$
FIGURES

Figure 2-1: Regional Project Setting ..... $2-2$
Figure 2-2: Local Project Setting ..... $2-2$
Figure 4-1: Donlin Gold Property Land Status Map ..... $4-2$
Figure 7-1: Regional Geology of Central Kuskokwim Area ..... $7-2$
Figure 7-2: Interpreted Property-Scale Igneous Rocks ..... $7-3$
Figure 7-3: Interpreted Surface Geology of Resource Area ..... $7-6$
Figure 7-4: 100 m Bench Level Geology ..... $7-8$
Figure 7-5: Lewis Area Section ..... $7-9$
Figure 7-6: ACMA Area Section ..... $7-9$
Figure 7-7: 100 m Bench Level Gold Distribution ( $>1 \mathrm{~g} / \mathrm{t}$ Au grade blocks) ..... $7-11$
Figure 9-1: Regional Magnetic Image Showing Magnetic Low Intensity Zone ..... $9-4$Figure 9-2: Gold-in-Soils Compilation Plan ..... 9-5
Figure 10-1: Property Drill Hole Location Plan. ..... $10-4$
Figure 10-2: Resource Area Drill Holes ..... $10-7$
Figure 10-3: Example Drill Cross-Section ACMA ..... $10-13$
Figure 10-4: Vertical Cross Section through ACMA and Lewis Block Model, Looking 315* ..... $10-14$
Figure 10-5: Example Drill Cross-Section, Lewis ..... $10-15$
Figure 10-6: Vertical Cross Section through Lewis Block Model, Looking 45* ..... $10-16$
Figure 13-1: Donlin Gold Project Geological Domains ..... $13-3$
Figure 13-2: Test $\mathrm{P}_{80}$ vs. Measured BWI Results on Blend Composite Sample ..... $13-12$
Figure 13-3: Illustration of MCF2 Generic Flowsheet ..... $13-15$
Figure 13-4: Plant Utilization Ramp-up Schedule for Donlin Feasibility Compared to Other Available Commissioned Sites ..... $13-17$
Figure 13-5: Plant Throughput Ramp-up Schedule for Donlin Feasibility Study Compared to Other Available Sites ..... $13-17$
Figure 13-6: Comparison of SGS-Lakefield Dec 2006 Key Bench and Pilot-Plant Results ..... $13-22$
Figure 13-7: Sulphide Oxidation Pressure Oxidation Kinetics at $220^{\circ} \mathrm{C}$ ..... $13-27$
Figure 13-8: Gold Recovery Profiles from Pressure Oxidation at $220^{\circ} \mathrm{C}$ ..... $13-27$
Figure 13-9: 2007 Phase 1 Neutralization Pilot pH Profiles ..... $13-37$
Figure 13-10: Lime Demand Test Results of 2007 Phase 1 Pilot Samples, Plotted against Initial pH ..... $13-38$
Figure 13-11: 2007 Phase 2 Neutralization Pilot pH Profiles ..... $13-39$
Figure 13-12: Lime Demand Test Results of 2007 Phase 2 Pilot Samples, Plotted against Initial pH ..... $13-40$
Figure 13-13: Plot of Neutralization Variability Testing Lime Demand Results at 6 Hours' Residence Time ..... $13-41$
Figure 13-14: MCF2 Pilot-Plant Campaign Survey Results ..... $13-50$
Figure 13-15: Flotation Recovery Trend throughout Mine Life ..... $13-54$
Figure 14-1: Donlin Geology Domains ..... $14-2$
Figure 16-1: ACMA Phases in Plan at 94 m Elevation ..... $16-4$
Figure 16-2: Lewis Phases in Plan at 178 m Elevation ..... $16-5$
Figure 16-3: End-of Mine Plan Layout of Open Pit and WRF ${ }^{1}$ ..... $16-6$
Figure 16-4: Proposed Mining Rate per Pit Phase ..... $16-10$
Figure 16-5: Projected Ore and Waste Production Schedule ..... $16-10$
Figure 16-6: Proposed Locations, Ore Stockpiles ..... $16-11$
Figure 16-7: Donlin Ore Stockpile Projected Capacity by Year ..... $16-12$
Figure 16-8: Waste Dump Locations ..... $16-13$
Figure 17-1: Donlin Gold Project Process Plant Simplified Flow Diagram ..... $17-2$
Figure 17-2: Planned Gold Production by Year ..... $17-20$
Figure 18-1: Basic Route of Mine Access Road ..... $18-2$
Figure 18-2: Plant Site Layout ..... $18-6$
Figure 18-3: Plan of Ultimate Waste Rock Facility ..... $18-10$
Figure 18-4: Location of Tailings Storage Facility ..... $18-13$
Figure 18-5: Construction Water Management Layout ..... $18-18$
Figure 18-6: Operations Water Management Layout ..... $18-24$
Figure 18-7: Closure Water Management Layout ..... $18-28$
Figure 21-1: 2011 to 2020 Initial Capital Cost Changes by Major Area ..... $21-2$
Figure 21-2: 2011 to 2020 Sustaining Capital Cost Changes by Major Area. ..... $21-2$Figure 21-3: 2011 to 2020 Sustaining Capital Cost Changes by Major Area ..... $21-8$
Figure 21-4: 2011 to 2020 Operating Cost Changes by Major Area Excluding Royalties. ..... $21-11$
Figure 21-5: 2020 Mine Operating Cost Adjustments ..... $21-15$
Figure 21-6: 2020 Process Operating Cost Adjustments ..... $21-16$
Figure 21-7: 2020 LOM G\&A Operating Cost Adjustments ..... $21-18$
Figure 22-1: Distribution of Initial Capital and Sustaining Capital ..... $22-3$
Figure 22-2: Operating Costs ..... $22-3$
Figure 22-3: After Tax Cash Flow and $\mathrm{NPV}_{5}$ (\$1,500/oz Gold Price) ..... $22-9$
Figure 22-4: After-Tax $\mathrm{NPV}_{5}$ Sensitivity Analysis ..... $22-10$

[[@~@]]
# 1.0 Summary

NOVAGOLD RESOURCES INC. (NOVAGOLD) requested Wood Canada Limited (Wood) to update content in the Donlin Creek Gold Project, Alaska, USA, NI 43-101 Technical Report on Second Updated Feasibility Study, with an effective date of 18 November 2011 (Donlin 2011 Technical Report) so that it is current. Wood completed an exercise to verify which content in the Donlin 2011 Technical Report remains current, and what was required to update the report content with the latest information. Updated content includes operating costs, capital costs, taxes, long term gold price and the economic analysis. Additionally, work done since 2011 on the property with respect to exploration, drilling, permitting and minor project design changes as a result of recent permitting activities are summarized in the technical report (Report). A data verification exercise was completed by each Wood qualified person (QP) co-authoring the Report.

The Donlin Gold Project (Project) is a 50:50 partnership between NovaGold Resources Alaska, Inc. (a wholly-owned subsidiary of NOVAGOLD), and Barrick Gold U.S. Inc. (a wholly-owned subsidiary of Barrick Gold Corporation (Barrick)). The partners use an operating company, Donlin Gold LLC to manage the Project. For the purposes of this Report, Donlin Gold LLC is used as a synonym for the partnership. Prior to July 2011, Donlin Gold LLC was known as Donlin Creek LLC.

[[%~%]]
## 1.1 Principal Outcomes

Measured and Indicated Mineral Resources, inclusive of Mineral Reserves, estimated for approximately 39 Moz contained gold:

- Measured Mineral Resources: 8 Mt at $2.52 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ ( 0.6 Moz contained gold)
- Indicated Mineral Resources: 534 Mt at $2.24 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ ( 38.4 Moz contained gold)

Proven and Probable Mineral Reserves estimated for approximately 34 Moz contained gold:

- Proven Mineral Reserves: 8 Mt at $2.32 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ ( 0.6 Moz contained gold)
- Probable Mineral Reserves: 497 Mt at $2.08 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ ( 33.3 Moz contained gold)
- 25 year operating mine life
- 27 year process life at $53,500 \mathrm{t} / \mathrm{d}$ throughput (includes two years of stockpile processing at the end of the operating mine life)
- Life of mine (LOM) gold production of 30.4 MozAverage annual gold production:

- 1.3 Moz over the projected LOM
- 1.5 Moz over the first full 5 years
- 1.4 Moz over the first full 10 years

Estimated capital costs:

- Initial capital cost of \$7,402 million
- Sustaining capital cost over the LOM of \$1,723 million

Estimated operating costs:

- $\$ 5.90 / \mathrm{t}$ mined
- $\$ 38.21 / \mathrm{t}$ processed
- \$635/oz Au sold

Economic outcomes at \$1,500/oz gold:

- Total after tax cash flow of \$13,145 million
- After tax $\mathrm{NPV}_{5}$ of $\$ 3,040$ million
- After tax IRR of $9.2 \%$
- After tax payback of 7.3 years.

Currency units throughout this report are United States dollars unless otherwise stated.

[[%~%]]
## 1.2 Location, Climate, And Access

The Donlin deposits are situated approximately 450 km west of Anchorage and 250 km northeast of Bethel up the Kuskokwim River. The closest village is the community of Crooked Creek, approximately 20 km to the south, on the Kuskokwim River. There is no road or rail access to the site. All access to the Project site for personnel and supplies is by air.

The nearest roads are in the Anchorage area. Access to Bethel and Aniak, the regional centres, is limited to river travel by boat or barge in the summer and air travel year-round. The Kuskokwim River is a regional transportation route and is serviced by commercial barge lines.

The area has a relatively dry interior continental climate with typically about 500 mm of total annual precipitation.

[[%~%]]
## 1.3 Agreements

On 1 December 2007, NOVAGOLD entered into a limited liability company agreement with Barrick that provided for the conversion of the Project into a new limited liability company, the Donlin Creek LLC, which is jointly owned by NOVAGOLD and Barrick on a 50/50 basis. In July 2011, the Board of Donlin Creek LLC voted to change the name of the company to Donlin Gold LLC.

The Calista Lease (which runs through April 2031, with provisions to extend beyond that time) currently includes a total of 72 complete sections in the vicinity of the deposit, and additional partial sections associated with the Project infrastructure, leased from Calista Corporation (Calista), an Alaska Native Corporation that holds the subsurface (mineral) estate for Native owned lands in the region. Title to approximately 19,988 hectares of the leased lands has been conveyed to Calista by the Federal Government. Calista owns the surface estate on a portion of these lands.

A separate Surface Use Agreement (SUA) with The Kuskokwim Corporation (TKC), an Alaska Native Village Corporation that owns the majority of the private surface estate in the area, grants non-exclusive surface use rights to Donlin Gold LLC on at least 64 sections overlying or in the vicinity of the mineral deposit, with provisions allowing for adjusting that area in conjunction with adjustments to the subsurface included in the Calista Lease. The SUA was revised and restated and executed by Donlin Gold LLC and TKC to expand the TKC surface lands included in the SUA and update other provisions, effective 6 June 2014. The term of the SUA runs through 30 April 2031, with provisions to continue beyond that time so long as the Calista Lease remains in effect. Calista and Donlin Gold LLC executed an agreement making limited further amendments to the Calista Lease, effective 6 June 2014, in conjunction with the revision of the SUA between Donlin Gold LLC and TKC. The SUA provides Donlin Gold LLC with surface rights to approximately 16,923 hectares.

The Lyman Lease provides the Project rights on the Lyman family small private surface parcel approximately 5.7 hectares in the vicinity of the deposit and placer mining lease with Calista that covers approximately ten square km .

[[%~%]]
## 1.4 Mineral Tenure

The Calista Lease currently includes lands leased from Calista, which holds the subsurface (mineral) estate for Native-owned lands in the region. The leased land is believed to contain approximately 19,988 hectares.In addition to the approximately 19,988 hectares leased from Calista, Donlin Gold LLC holds 493 Alaska State mining claims comprising approximately 29,008 hectares, on State and Stateselected lands in the vicinity of the leased lands in the Kuskokwim and Mount McKinley recording districts, bringing the total mineral land package to approximately 48,996 hectares (the Property).

[[%~%]]
## 1.5 Surface Rights

Donlin Gold LLC, through the Calista Lease, TKC SUA, and Lyman Lease, holds most of the surface rights that will be required to support mining operations in the proposed mining area.

Other lands required for off-site infrastructure, such as the natural gas pipeline, upriver port site, and mine site access road, are categorized as Native, State of Alaska conveyed, or Federal, Bureau of Land Management (BLM) lands.

[[%~%]]
## 1.6 Royalties

The terms for the Calista Lease and TKC SUA include various royalty and other payment provisions and considerations such as shareholder employment and contracting opportunities. Royalty Terms of the Calista Lease include:

- Annual advance minimum royalty (variable) to 2030
- All advance minimum payments are recoverable as a credit against the net smelter return royalty and net proceeds payment
- Net smelter return of $1.5 \%$ for the earlier of the first five years following commencement of commercial production or until initial capital payback
- Conversion to $4.5 \%$ net smelter return after the earlier of five years or initial capital payback
- Net proceeds royalty of $8 \%$ of the net proceeds realized by Donlin Gold LLC commencing with the first quarter in which net proceeds are first realized.

Payment Terms of the TKC SUA include:

- Annual advance minimum payment (variable per milestones)
- All advance minimum payments are recoverable as a credit against the milled tonnage fee and net proceeds payment
- Milled tonnage fee of $\$ 0.40$ per tonne processed for the first 10 years of production- Conversion of the milled tonnage fee to $\$ 0.50$ per tonne processed for all production after 10 years
- Net proceeds payment of 3\% of the net proceeds realized by Donlin Gold LLC commencing with the first quarter in which net proceeds are first realized.

There are currently no Government royalty obligations.

[[%~%]]
## 1.7 Environment, Permitting And Social And Community Impact

There was a focused effort to collect comprehensive environmental baseline data between 1995 and 2013 to lay the groundwork with local and regulatory stakeholders for the successful permitting and development of a large-scale mining operation of the Project. Baseline data collected included studies covering wetland delineation, water quality, fish and aquatic habitats, air quality, wildlife habitats, cultural resources and heritage, subsistence, traditional knowledge, socio-economics, health, mercury data, overburden, ore and waste rock characterization studies, noise, visual aesthetics, and river and land use.

The National Environmental Policy Act (NEPA) process and formal permit applications require the preparation of an environmental impact statement (EIS). Upon completion of the Final EIS, a Joint Record of Decision (JROD) between U.S. Army Corps of Engineers (USACE) and the BLM was finalized on 13 August 2018 in which Alternative 2, the North Route Pipeline option was chosen. The EIS and JROD describe the conditions of the approval and explain the basis for the decision. The State permitting process has been ongoing to comply with the NEPA mitigation requirements and state permitting requirements. Permits are discussed in Section 20.4.

The Report assumes that Donlin Gold LLC will establish a Trust Fund to fund closure and postclosure obligations as allowed by State statutes. That fund must be sufficient to generate sufficient cash flow to cover all reclamation, closure, and post- closure costs, including (but not limited to) construction and maintenance of the spillway from the Tailings Storage Facility (TSF), capital to construct the closure Water Treatment Plant (WTP) and operating costs for perpetual water treatment, and associated facility and access maintenance.

A model was developed for the Trust Fund calculation. The funding amount is estimated at $\$ 7.8$ million provided annually over the construction and operating period, for a total of $\$ 412$ million accrued to the Trust Fund at the start of closure.

In addition to the Trust Fund, financial assurance in the form of letters of credit and/or surety bonds will be required to construct and operate the mine. Per the Donlin Gold Project Reclamation Plan Approval from Alaska Department of Natural Resources (ADNR), financialassurance in the amount of approximately $\$ 322$ million must be submitted in a form and substance approved by ADNR. The cost to maintain this financial assurance is assumed to be approximately $\$ 1.3$ million per year, paid from the start of construction through the end of operations.

[[%~%]]
## 1.8 Geology And Mineralization

The Donlin mineralization model is a high-level, reduced intrusion-related vein system. The ACMA (ACMA is named after the American Creek magnetic anomaly)-Lewis part of the district is a low sulphidation, reduced intrusion related, epizonal system with both vein and disseminated mineral zones.

The Donlin deposits lie in the central Kuskokwim basin of southwestern Alaska, which contains a back-arc continental margin basin fill assemblage of the Upper Cretaceous Kuskokwim Group, and Late Cretaceous volcano-plutonic complexes. The Project area is underlain by a 8.5 km long $\times 2.5 \mathrm{~km}$ wide granite porphyry dike and sill swarm hosted by lithic sandstone, siltstone, and shale of the Kuskokwim Group.

The deposits are hosted primarily in igneous rocks and are associated with an extensive Upper Cretaceous gold-arsenic-antimony-mercury hydrothermal system. The northeast, elongated, roughly 1.5 km wide $\times 3 \mathrm{~km}$ long cluster of gold deposits has an aggregate vertical range that exceeds 945 m . These areas consist of the ACMA and 400 Zone, Aurora and Akivik mineralized areas (grouped as ACMA) and the Lewis, South Lewis, Vortex, Rochelieu and Queen mineralized areas (grouped as Lewis).

Gold occurs primarily in sulphide and quartz-carbonate-sulphide vein networks in igneous rocks and, to a much lesser extent, in sedimentary rocks. Broad disseminated sulphide zones formed in igneous rocks where vein zones are closely spaced. Sub-microscopic gold, contained primarily in arsenopyrite and secondarily in pyrite and marcasite, is associated with illite-kaolinite-carbonate-graphite-altered host rocks.

In the opinion of the QPs, knowledge of the deposit settings, lithologies, and structural and alteration controls on mineralization is sufficient to support Mineral Resource and Mineral Reserve estimation. The mineralization style and setting of the Donlin deposits are also sufficiently well understood to support Mineral Resource and Mineral Reserve estimation.

[[%~%]]
## 1.9 Exploration

Placer gold was first discovered at Snow Gulch, a tributary of Donlin Creek, in 1909. Early stage exploration in the modern era was performed by Resource Associates of Alaska (1974-1975), Western Gold Exploration and Mining Co. LP (WestGold) during 1988-1989 and Teck Exploration Ltd. (Teck) in 1993. Exploration included geological mapping, trenching, rock and soil sampling, an airborne magnetic and VLF survey, ground magnetic surveys, and initial Mineral Resource estimates.

Most of the work completed on the Project has been primarily undertaken, in chronological order, by Placer Dome Inc. (1995 to 2000, and again from 2002 to 2005), NOVAGOLD (2001 to 2002), Barrick (2006) and by Donlin Gold LLC (from 2007 to date).

Activities have included construction of infrastructure to support exploration activities; reconnaissance and geological mapping; aerial photography; rock chip and soil sampling; trenching; max-min electro-magnetic (EM) geophysical surveys; airborne geophysical surveys; Reverse circulation (RC) and core drilling for resource infill, geotechnical, engineering, condemnation, waste rock, calcium carbonate exploration and metallurgical purposes; environmental baseline studies; community consultations; detailed metallurgical testwork; geotechnical and hydrogeological studies; sampling of prospective calcium carbonate source areas; exploration and auger drilling program for sand and gravel sources; a series of Mineral Resource and Mineral Reserve estimates; and initial mining and engineering studies. This work culminated in a feasibility study in 2007, and updates to this study in 2009, 2011 and this Report.

In the opinion of the QPs, the exploration programs completed to date are appropriate to the style of the deposits and prospects within the Project. The exploration and research work support the genetic and affinity interpretations.

[[%~%]]
## 1.10 Exploration Potential

The Property retains exploration potential. The Akivik and East ACMA areas have good potential for lateral extensions of mineralization to the northwest and southeast of the pit footprint. In addition, known gold mineralization is likely to extend at depth, below the base of the designed pit, and in some areas immediately adjacent to the planned pit floor, which has been intersected by current drilling. Several drilled prospects and other exploration targets along the 6 km igneous trend north of the resource area remain under-explored, for example the Snow and Dome prospects.

[[%~%]]
## 1.11 Drilling

Approximately 1,834 exploration and development diamond core ( $90 \%$ ) and RC (10\%) drill holes, totalling $407,720 \mathrm{~m}$, were completed from 1988 through 2010. All but about 20\% (district exploration, carbonate resource, facilities condemnation, hydrology, infrastructure engineering) of this drilling was utilized for the current resource model. Supporting the resource model is a total of 1,396 core ( $89 \%$ ) and RC ( $11 \%$ ) holes totalling $339,733 \mathrm{~m}$, and 282 trenches totalling $21,441 \mathrm{~m}$.

Core sizes used on the Property include: NQ3 ( 45.1 mm core diameter), NQ ( 47.6 mm ), HQ3 ( 61.2 mm ), HQ ( 63.5 mm ), and PQ ( 85 mm ). Since 2002, core drills have been used exclusively for all resource delineation, and RC drilling was relegated to condemnation and hydrology studies.

Standard logging and sampling conventions were used to capture information from the drill core and, where applicable, RC chips. Data captured included lithology, mineralization, alteration (visual), structural and geotechnical, with provision for geologists to add comments on the core if required.

A survey of nearly 200,000 core recovery records in the database revealed an overall length-weighted average core recovery of $95 \%$. Average recovery increases from 80 to $95 \%$ from 0 to 40 m and then ranges from 95 to $100 \%$ below 40 m where overburden and surface weathering effects are generally absent.

Collar survey methods to 2001 included Brunton compass and hip chain, and modern global positioning system (GPS) technology and conventional theodolite survey methods.

The Sperry Sun single-shot camera method was used through 2000 for directional surveys to determine down-hole deviation. Reflex EZ Shot instrumentation was introduced in 2001. Approximately $60 \%$ of the core holes drilled within the resource model area were oriented to collect structural information for geotechnical and geological studies. Core orientation methods included clay impression, EZ Mark, Reflex ACT, and acoustic and optical interviewer instruments.

In 2017, 16 core holes were drilled for model confirmation purposes, and in 2020, 85 additional core holes were drilled to confirm the model and test potential high-grade extensions. These drill results were used by the QP as a part of the validation of the DC9 resource model, which was utilized to estimate the current Mineral Resources and Mineral Reserves.The quantity and quality of the lithological, geotechnical, and collar and down-hole survey data collected in the exploration and delineation drill programs are sufficient to support Mineral Resource and Mineral Reserve estimation in the opinion of the QPs.

Core is digitally photographed and split in half with an electric rock saw equipped with water-cooled diamond saw blades. Drill holes are sampled from the top of bedrock to the end of the hole. The maximum sample length in zones consisting of intrusive rocks or that contain appreciable sulphide/arsenic minerals is 2 m , whereas sample lengths in sedimentary rock zones that lack appreciable sulphide/arsenic minerals can be 3 m . A minimum of three additional 2 m sample intervals are placed before and after each intrusive rock or mineralized zone.

Specific gravity (SG) data were collected primarily in 2006 by Project staff, using the wax immersion, water displacement method. The weighted average of all SG data points was 2.65 for the intrusive units, and 2.71 for the sedimentary units.

In the opinion of the QPs, sampling methods are acceptable, meet industry-standard practice, and are acceptable for Mineral Resource and Mineral Reserve estimation.

Quality assurance and quality control (QA/QC) programs have been in place since 1995, and consist of the insertion of blank, standard reference material (SRM) and duplicate samples.

[[%~%]]
## 1.12 Sample Analysis And Security

The primary laboratory for most assaying has been ALS Global - Geochemistry Analytical Lab (ALS) in Vancouver, BC. During the exploration programs, ALS held accreditations typical for the time, including, at various times, ISO9001:2000 and ISO 9002, and from 2005, ISO/IEC 17025 accreditations.

Most core samples from 2005 through 2008 were crushed at the Donlin camp sample preparation facility and pulverized at the ALS Vancouver laboratory facility. Samples of 2006 core split in Anchorage were shipped to an ALS preparation laboratory for crushing and pulverizing. Crushing requirements have been to $70 \%$ minus 2 mm at the Donlin facility, and subsequently to better than $85 \%$ passing minus $75 \mu \mathrm{~m}$ at ALS.

Approximately 30 g subsample of the pulp was assayed by ALS using fire assay-atomic absorption spectroscopy (AAS). Before 2007, the primary gold assay method was Au-AA23, which had an analytical range of 0.005 to $10 \mathrm{~g} / \mathrm{t} \mathrm{Au}$. The Au-AA25 gold assay method was initiated in 2007 and had an analytical range of 0.01 to $100 \mathrm{~g} / \mathrm{t} \mathrm{Au}$. Samples that exceeded theanalytical limit for a given method were re-assayed by fire-assay and gravimetric finish or "ore grade" fire-assay AAS.

ALS determined the sulphur content of some samples according to the Leco method. The Leco method was also used to analyze samples flagged for acid base accounting (ABA) for carbon content as well as to determine neutralization potential (NP) and acid potential (AP) according to the industry-standard ALS ABA procedure.

Most trace and major element data for drill holes located within the resource model boundary were acquired prior to the 2005 program by various laboratories using industry-standard acid digestions followed by atomic absorption (AA) or inductively coupled plasma (ICP) instrumental determinations. Subsequent multi-element trace analyzes were performed at ALS using aqua regia or four-acid digestions followed by ICP $\pm$ mass spectrometry.

Sample security measures practiced included moving of core from the drill site to the core shack at the end of each drill shift and tracking of sample shipments using industry-standard procedures. The Wood QPs are of the opinion that core storage is secure because of the remote site and camp and access is strictly controlled.

In the opinion of the QPs, the quality of the gold and sulphur analytical data are sufficiently reliable to support Mineral Resource and Mineral Reserve estimation without limitations on Mineral Resource confidence categories and sample preparation, analysis, and security are generally performed in accordance with exploration best practices and industry standards.

[[%~%]]
## 1.13 Data Verification

A number of data verification programs and audits have been performed over the Property history, primarily in support of preparation of technical reports on the Property and in support of mining studies. Checks were performed in 2002 (Wood), 2005 and 2008 (NOVAGOLD), 2011 (Wood), and this Report.

Wood's QPs conducted adequate data verification, as described in Sections 2, 12, and 14 of this Report, to allow them to confirm the data is suitable to be used and to take responsibility for its use in all sections of this Report.

[[%~%]]
## 1.14 Metallurgical Testwork

Testwork completed by SGS-Lakefield Research (SGS-Lakefield), Hazen Research (Hazen), and G\&T Metallurgical Services (G\&T) under Barrick's supervision has shown that the Donlin ore requires pre-treatment prior to cyanidation to recover the gold. Process development work hasdetermined that pressure oxidation (POX) is the preferred method of pre-treatment. Extensive testwork on composites has shown that acceptable gold recoveries can be produced through a combination of flotation pre-concentration, POX, and carbon in leach (CIL) cyanidation.

Air flotation using the MCF2 (mill-chemical-flotation-mill-chemical-flotation) flowsheet provides an estimated LOM average of $93.0 \%$ recovery, with CIL recoveries after POX at approximately $96.6 \%$ for an estimated combined plant total gold recovery of $89.8 \%$. The concentrate pull will vary from $15 \%$ to $17 \%$ and that will result in a concentrate grade of 11 to $15 \mathrm{~g} / \mathrm{t} \mathrm{Au}$.

Process selection is supported by extensive testwork. Placer Dome Inc. undertook an initial phase of testwork from 1995 to 1999 to define the basic process. Early on, it became apparent that direct cyanidation or CIL of whole ore or flotation concentrate returned very low recoveries. Pre-treatment by oxidation was considered necessary.

Placer Dome Inc. testwork included grinding, gravity concentration, flotation, POX, cyanidation, and neutralization. Subsequently from 2002 to 2005, Placer Dome Inc. also explored high pressure grinding rolls (HPGR) comminution, arsenopyrite/pyrite separation, nitrogen aerated flotation, and oxidation both by bio-oxidation and POX.

At the end of 2005, another round of work began with some testing at G\&T, but this was interrupted by the acquisition of Placer Dome Inc. by Barrick, which subsequently assumed management of remaining testwork.

Major programs at the bench-scale level were initiated in 2006 to test grinding, flotation, POX, and neutralization. In addition to bench-scale work, major pilot-plant runs were performed in flotation, POX, and neutralization at the Barrick Technology Centre, SGS-Lakefield, G\&T, and Hazen. Both bench-level and pilot-plant scale testwork were conducted to develop process parameters and expand engineering information.

Additional metallurgical testwork was completed since 2011 including the programs in 2017 and 2018 at AuTec, FLSwidth, and TOMRA. Results show opportunity for plant optimization and potential reductions to process operating and capital costs. However, the recommendations from the testwork include the need for further testing, locked-cycle testing and continuous pilot plant, and more detailed economic evaluation of impacts of any new design parameters. Therefore, the results of the 2017 and 2018 testwork programs are not yet definitive and were not incorporated into the Report.The key testing results and recommendations are summarized as follows:

# Mineralogy 

- Sulphur occurs primarily as pyrite and arsenopyrite. Marcasite is an additional minor sulphide present in the ore. Pyrite contains only a minor portion of the gold, while arsenopyrite is the main gold carrier, with gold in solid solution (sub-microscopic) form. In particular, it is the finest arsenopyrite that has the highest grade of gold. The proportion of pyrite to arsenopyrite ranges from 4 to 2:1, with 3:1 being typical.
- Mercury in the ore at $\sim 2 \mathrm{ppm}$ average is primarily hosted by pyrite in solid solution (sub-microscopic form). No mercury minerals have been observed.
- Arsenic in the ore at $\sim 2,800 \mathrm{ppm}$ average is primarily hosted by arsenopyrite. However, arsenic also occurs as native arsenic and realgar.
- Antimony in the ore at $\sim 80$ to 90 ppm average is primarily hosted by stibnite, but also occurs at trace levels hosted by tetrahedrite.
- Chloride in the ore at $\sim 20$ to 25 ppm average is primarily hosted by muscovite but is also carried to a lesser degree by apatite.
- Carbonate in the ore at $2.4 \%$ to $2.5 \%$ (analysis specified as $\mathrm{CO}_{2}$ ). The most common carbonate within the Donlin ores is ferroan dolomite (impure dolomite containing varying quantities of iron) followed by ankerite. Calcite and siderite are present but not common.


## Direct Leach / CIL

- The whole ore is refractory to direct and CIL cyanidation processing, with very low recoveries ( $<15 \%$ ) from either leaching methodology. High gold recovery is achieved by destruction of the sulphidic host matrix of the gold.


## Crushing / Grinding

- The ores are considered moderately hard, with an average Ball Work Index (BWI) of $15 \mathrm{kWh} / \mathrm{t}$ and an average Minnovex semi-autogenous grinding (SAG) power index (SPI) of 88 minutes.
- The ores are amenable to SAG milling with reasonable operating efficiencies.
- Ore hardness is controlled significantly by rock lithology.# Flotation 

- Flotation gold recoveries are highest from intrusive ores ( $94.7 \%$ to $97.5 \%$ ), lower from the sedimentary ores ( $89.7 \%$ to $91.3 \%$ ), and problematic for partially geologically oxidized ores (average $75.7 \%$ ).
- All the testwork showed a very close relationship between arsenic and gold recovery, indicating the presence of gold in close combination with that element.
- An MCF2 style milling, chemical addition, and flotation duplicated flowsheet provides a recovery increase of $1.8 \%$ to a flotation concentrate and is economically favoured for Donlin ore.
- Using the MCF2 flowsheet, it is possible to concentrate the gold-bearing sulphides into a $7 \%$ sulphur concentrate recovering an overall average $93.0 \%$ of the gold (including $10 \%$ oxide ore in blend) into $15 \%$ of the plant feed mass. Required flotation residence time and reagent dosages are relatively high compared to other iron sulphide flotation processes.
- The partially oxidized (altered) ores, which are predominantly near surface, perform poorly through flotation, with an average flotation recovery of $75.7 \%$. Initial testing using sulphidizing reagents to promote flotation recovery improvement have been unsuccessful on these ores.
- CIL leaching of the flotation tailings does not yield economically justifiable recovery of gold.


## Pressure Oxidation (POX)

- POX allows for $96.6 \%$ recovery of the gold in CIL following oxidation.
- A concentrate pre-acidification circuit (to dissolve carbonates) and subsequent chloride removal CCD wash of the pre-acidified concentrate (using uncontaminated waters) was indicated and has been incorporated as part of the process flowsheet.
- As a precautionary measure, a mercury recovery system will be incorporated on the autoclave gas products prior to emission to the atmosphere.


## Neutralization

- The presence of carbonates in the flotation tailings allows for autoclave acid solution neutralization, thus decreasing the overall lime requirements. The carbonate content in the ore represents a stoichiometric ratio of carbonate to total sulphur of 1.49 .# CIL / Gold Recovery 

- CIL processing of washed autoclave product provides for optimized gold recoveries of $96 \%$ to $97 \%$, requiring relatively low amounts of cyanide.
- Lime consumption of the CIL feed can be minimized by operating the CIL circuit at a pH of $\sim 9.0$ to minimize lime consumption by precipitation of magnesium hydroxide. The Donlin ore contains a naturally high content of magnesium ( 6,500 to 6,600 ppm average), which is liberated from the ore through reaction with acid, both in the autoclave and neutralization circuits. Since this testwork program was completed, an alternative to operating at low pH in CIL has been identified whereby soluble magnesium is removed prior to CIL to enable operation at conventional pH .
- Reagent addition is minimized by high efficiency washing of the autoclave product to $98 \%$ or greater washing efficiency.
- Pilot testing of the CIL circuit on autoclaved blended concentrate demonstrated that CIL recovery is not sensitive to carbon gold loadings. However, the carbon elution circuit has been designed to allow for low carbon loadings in the event that preg-robbing concentrates are encountered.
- Mercury leached into solution from the autoclave product by cyanide, which is not adsorbed onto carbon, is controlled to low levels within the recirculating process water streams by precipitation as a sulphide using a Cherokee UNR 829 reagent.
- Current design incorporates mercury gas/vapour recovery systems on the carbon regeneration kiln, electrowinning, retort system, and smelting furnace off-gases.


## Environmental Considerations

- The high temperature and POX process is considered best practice for generation of stable arsenic compounds suitable for long-term disposal in a tailings storage facility. Sufficient iron content is present in the Donlin ores to provide the recommended minimum stoichiometric ratio of $4: 1$ iron to arsenic.
- A portion of the arsenic in the Donlin ores is water soluble and liberates into solution within the operation of the grinding and flotation circuits alone.
- The tailings decant water from the Donlin process plant will likely contain elevated levels (above current aquatic life or drinking water standard) of $\mathrm{As}, \mathrm{Hg}, \mathrm{Mn}, \mathrm{Mo}, \mathrm{Se}$, and Sb . The tailings water could also be elevated in sulphates (greater than $10 \mathrm{~g} / \mathrm{L}$ ), particularly due to the presence of magnesium, which increases solubility level of sulphate in solution.

[[%~%]]
## 1.15 Mineral Resource Estimate

The Mineral Resource estimate was prepared prior to the 2011 feasibility study and audited by Wood's QP. Three-dimensional solids for the geological model were constructed from polygons resulting from geologic interpretation of cross-section and level plans. Nine mineral and geological domains were assigned to the database. Geotechnical domain zone codes were input into the resource model, as required for the Lerchs-Grossmann (LG) pit optimization, using domain solids provided by BGC Engineering Inc (BGC) on 27 June 2008. A waste rock management category (WRMC) model was coded to identify overburden from the other WRMC codes.

Raw assay data were grouped by rock type, and capping values for gold were determined for each major rock type. Gold assays were capped according to lithology, as described in Section 14. Values for NP were also capped. Total sulphur, arsenic, mercury, and antimony assays were not capped.

Composites were created down each hole at 6 m intervals. The composites were not broken at intrusive or sedimentary rock contact boundaries. Indicator semi-variograms generated at $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ for the 6 m composites were fitted with a spherical model. Ranges of 30 m and 45 m were observed at $80 \%$ and $90 \%$ of the total sill variance.

A gold indicator model was used to estimate gold, arsenic, antimony, and mercury grades based on gold composite data. A separate sulphur indicator model was used to estimate sulphur.

Gold grades were estimated into the block model using an inverse distance to the third power methodology for two populations:

- Internal to the mineralized envelope, defined as blocks with indicator values greater than or equal to $50 \%$.
- External to the mineralized envelope, defined as blocks with indicator values less than $50 \%$.

Interpolation of grade into the blocks was broken into five passes based upon increasing search distances, out to a maximum of 125 m . Gold grades were estimated separately for intrusive rocks, shales, and greywackes, and further sub-divided based upon whether blocks were internal or external to the mineralized envelope.

Sulphur grades were estimated using the same methods and parameters as for the gold grade estimation. Arsenic, mercury, and antimony grades were estimated using methods and parameters similar to those for the gold grade estimation. Values for $\mathrm{CO}_{2}$, calcium, andmagnesium were estimated into the block model based on an ordinary kriging method within nine estimation domains. NP was estimated into the block model for use in the classification of waste rock.

The block model grades were validated visually against drill holes and composites in section and plan view. A nearest-neighbour block model was also generated. Grade profile plots were generated for the $6 \mathrm{~m} \times 6 \mathrm{~m} \times 6 \mathrm{~m}$ Measured and Indicated resource model as a further validation check. No estimation biases were noted from the validation reviews.

The extent of the classified material that might have reasonable expectation for economic extraction was assessed by applying a LG pit outline using Whittle ${ }^{\circledR}$ software to the Mineral Resources. A block value (BV) per tonne was then coded into each block of the resource model. For those blocks with a resource classification of Measured, Indicated, or Inferred, the BV per tonne was calculated with the following equations:

General:

$$
\begin{aligned}
& B V=\text { [Au grade] } * \text { [Recovery] } * \text { [Price of Gold less Refining and Royalty Costs] }-[\text { Processing } \\
& \text { Costs+ General and Administrative Costs + Rehandling Costs] \$/tonne }
\end{aligned}
$$

For Mineral Resources, the figures were:

$$
\begin{aligned}
& B V=[\text { Au grade }] *[\text { Recovery }] *[\$ 1,200-(1.85+((\$ 1200-1.85) * 0.045))]-[(10.65+ \\
& (2.1874 * S \%))+2.29+0.20] \$ / \text { tonne }
\end{aligned}
$$

The BV cut-off for Mineral Resource reporting purposes was $\$ 0.001 / \mathrm{t}$ processed, which represents the BV marginal cut-off strategy.

Mineral Resources take into account geologic, mining, processing and economic constraints, and have been confined within appropriate LG pit shells, and therefore are classified in accordance with the May 19, 2014 Canadian Institute of Mining, Metallurgy, and Petroleum (CIM) Definition Standards for Mineral Resources and Mineral Reserves (2014 CIM Definition Standards) and November 29, 2019 CIM Estimation of Mineral Resources and Mineral Reserves Best Practice Guidelines (CIM 2019). The QP for the Mineral Resource estimate is Henry Kim, P.Geo. an employee of Wood. Mineral Resources are reported in Table 1-1 at a commodity price of $\$ 1,200 /$ oz gold, have an effective date of 11 July 2011, and are reported inclusive of Mineral Reserves. A detailed review of the Mineral Resources using all available information determined that the Mineral Resources remain current and are suitable to be used in the Report. Subsection 14.15 shows there would be no material change to the Mineral Resources if the gold price is updated to $\$ 1,500 /$ oz and other economic parameters are updated to the 2020 parameters used in the Mineral Reserve estimate. A detailed review of the MineralResources using all available information determined that the Mineral Resources remain current and are suitable to be used in the Report

Table 1-1: Mineral Resources Summary Table, (Inclusive of Mineral Reserves) Effective Date 11 July 2011, Henry Kim, P.Geo

| Category | Tonnage <br> $(\mathbf{k t})$ | Au <br> $(\mathbf{g} / \mathbf{t})$ | Contained Au <br> $(\mathbf{k o z})$ | S <br> $(\%)$ |
| :-- | :--: | :--: | :--: | :--: |
| Measured | 7,731 | 2.52 | 626 | 1.15 |
| Indicated | 533,607 | 2.24 | 38,380 | 1.08 |
| Total Measured and Indicated | 541,337 | 2.24 | 39,007 | 1.08 |
| Inferred | 92,216 | 2.02 | 5,993 | 1.08 |

Note: ${ }^{1}$ Mineral Resources are inclusive of Mineral Reserves. Mineral Resources that are not Mineral Reserves do not have demonstrated economic viability.
${ }^{2}$ The cut-off date for the sample database used in the resource estimate is 1 November 2009. However, more recent drilling data was used to validate the resource model as remaining current.
${ }^{3}$ Mineral Resources are constrained within a conceptual Measured, Indicated and Inferred optimized pit shell using the following assumptions: gold price of $\$ 1,200 /$ oz; variable process cost based on $2.1874^{*}$ (sulphur grade) + 10.65; administration cost of $\$ 2.29 / \mathrm{t}$; refining, freight \& marketing (selling costs) of US $\$ 1.85 /$ oz recovered; stockpile rehandle costs of $\$ 0.20 / \mathrm{t}$ processed assuming that $45 \%$ of mill feed is rehandled; variable royalty rate, based on royalty of $4.5 \%$ * (Au price - selling cost), and a variable metallurgical recovery depending on the host rock type ranging from 86 to $94 \%$. Assuming an average recovery of $89.5 \%$ and average $\$ \%$ grade of 1.07 , the marginal gold cut-off grade is $0.47 \mathrm{~g} / \mathrm{t}$. These economic parameters are those that were used in the Donlin 2011 Technical Report. Based on the QP's review of the estimate, there would be no material change to the Mineral Resources if the gold price were updated to $\$ 1,500 /$ oz and other economic parameters were updated to the 2020 parameters used in the Mineral Reserve estimate. Therefore the 2011 Mineral Resource statement is considered current and is presented unchanged.
${ }^{4}$ Rounding may result in apparent summation differences between tonnes, grade and contained metal content.
5 Tonnage and grade measurements are in metric units. Contained gold ounces are reported as troy ounces.Factors which may affect the Mineral Resource estimate include the commodity price; changes to the assumptions used to generate the BV cut-off; changes to the $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ threshold used to define the indicator mineralized domains, changes in interpretations of fault geometry; changes to the search orientations used for grade estimation, results of a review of the Measured classification criteria; and changes to the assumptions used to generate the LG pit constraining the estimate, in particular slope design assumptions.

[[%~%]]
## 1.16 Mineral Reserve Estimate

Mineral Reserves were optimized for all Measured and Indicated blocks assuming a gold selling price of $\$ 1,200 /$ oz.

The ore considered for processing in the optimization was based on a marginal cut-off grade. Material considered to be ore if the revenue of the block exceeded the processing and General and Administrative (G\&A) cost. The revenue was based on net gold price after refining charges and royalties had been deducted.

Dilution was considered for bulk mineable ( 12 m bench height) and selective mineable ( 6 m bench height) scenarios. All blocks classified as Inferred were set to waste. Therefore, the combined grades of all blocks are derived from the Measured or Indicated metal grades only.

Pit shell generation was constrained in the northwestern part of the ACMA mining area to prevent it from encroaching on Crooked Creek, which is a salmon-bearing stream, but was not constrained by any infrastructure considerations.

Geotechnical domains, design sectors, slope angles, and associated assumptions were provided by BGC. Mine design has incorporated geotechnical and hydrogeological considerations.

The base mining cost (before incremental mining cost with depth) is $\$ 2.16 / \mathrm{t}$, the average processing cost, including sustaining capital, is $\$ 15.32 / \mathrm{t}$, and the G\&A cost is $\$ 3.66 / \mathrm{t}$. These costs are considered reasonable.

Recoveries for non-oxide ores are quoted as a constant for each rock type, whereas recoveries for oxide ores vary with sulphur grade. Recoveries range from $88.6 \%$ in shale to $94.2 \%$ in the Akivik zone.

Mineral Reserves have been modified from Mineral Resources by taking into account geologic, mining, processing, and economic parameters and therefore are classified in accordance with the 2014 CIM Definition Standards. The QP for the Mineral Reserve estimate is Kirk Hanson,P.E., a Wood employee. Mineral Reserves are reported at a gold price of \$1,200/oz gold and have an effective date of 27 April 2021.

Mineral Reserves are summarized in Table 1-2.
Factors which may affect assumptions used in estimating Mineral Reserves include the commodity price; unrecognized structural complications in areas with relatively low drill hole density that could introduce unfavourable pit slope stability conditions; changes in interpretation of the fault orientations, in particular the Vortex and Lo Faults; changes in orientations of the bedding or ash layer orientations which may necessitate flatter slope angles than currently assumed; in-pit and pit wall water management if water inflows are higher than predicted; and conditions that may be required around granting of the required permits and social licenses to construct the natural gas pipeline and to construct and operate the planned mine.

Table 1-2: Proven and Probable Mineral Reserves, Effective Date 27 April 2021, K. Hanson, P.E.

| Category | Tonnage <br> $(\mathbf{k t})$ | Au <br> $(\mathbf{g} / \mathbf{t})$ | Contained Au <br> $(\mathbf{k o z})$ | S <br> $(\%)$ |
| :-- | :--: | :--: | :--: | :--: |
| Proven | 7,683 | 2.32 | 573 | 1.12 |
| Probable | 497,128 | 2.08 | 33,276 | 1.06 |
| Total Proven and Probable | $\mathbf{5 0 4 , 8 1 1}$ | $\mathbf{2 . 0 9}$ | $\mathbf{3 3 , 8 4 9}$ | $\mathbf{1 . 0 6}$ |

Note: ${ }^{1}$ Mineral Reserves are reported within the feasibility pit designs, and supported by a mine schedule, featuring variable throughput rates, stockpiling and cut-off optimization. The pit designs are contained within an optimized pit shell based on the following economic and technical parameters: Metal price for gold of $\$ 1200 /$ oz; reference mining cost of $\$ 2.16 / \mathrm{t}$ incremented $\$ 0.0033 / \mathrm{t} / \mathrm{m}$ with depth from the 220 m elevation (equates to an average mining cost of $\$ 2.64 / \mathrm{t}$ ), fixed processing cost of $\$ 13.78 / \mathrm{t}$ processed; sustaining capital of $\$ 1.54 / \mathrm{t}$ processed; general and administrative cost of $\$ 3.66 / \mathrm{t}$ processed; stockpile rehandle costs of $\$ 0.24 / \mathrm{t}$ processed assuming that $45 \%$ of mill feed is rehandled; variable metallurgical recoveries by rock type, ranging from $86.7 \%$ in shale to $94.2 \%$ in intrusive rocks in the Akivik domain; refining and freight charges of $\$ 1.21 /$ oz gold; royalty considerations of $4.5 \%$ net smelter return (NSR) and $\$ 0.50 /$ t processed; and variable pit slope angles, ranging from $23^{\circ}$ to $43^{\circ}$.
${ }^{2}$ Mineral Reserves are reported using an optimized BV based on the following equation: BV = Au grade * Recovery - royalties \& refining costs - process operating costs - G\&A cost reported in $\$ / \mathrm{t}$. Assuming an average recovery of $89.5 \%$ the marginal gold cut-off grade would be approximately $0.57 \mathrm{~g} / \mathrm{t}$, or the gold grade that would equate to a $\$ 0.001 \mathrm{BV}$ cut-off at these same values.
${ }^{3}$ The LOM strip ratio is $5.48: 1$. The assumed LOM throughput rate is $53,500 \mathrm{t} / \mathrm{d}$.
${ }^{4}$ Rounding may result in apparent summation differences between tonnes, grade and contained metal content.
5 Tonnage and grade measurements are in metric units. Contained gold ounces are reported as troy ounces.

[[%~%]]
## 1.17 Proposed Mine Plan

The preferred development is for a $53,500 \mathrm{t} / \mathrm{d}$ process facility with on-site power; and a mine capacity of $440 \mathrm{kt} / \mathrm{d}$ with an elevated cut-off policy applied in the initial part of the mine life.

The ACMA ultimate pit has been divided into nine phases, the Lewis pit into six phases. The initial phases of the two pits are independent, but they partially merge later in the mine life, forming a final single pit. The mine design, complete with haulage access, includes 504.8 Mt of ore containing 33.8 Moz of in-situ gold and has a strip ratio of 5.48:1. The mine design is considered appropriate to the quantity of Measured and Indicated Mineral Resources estimated for the Project. Wood notes that the engineered pit design includes approximately $5 \%$ less ore tonnage and $7 \%$ fewer Au ounces than the pit optimization shell it was based on. This is at the upper end of the generally accepted limit of a $10 \%$ reduction in tonnes. As such, there is a risk that the engineered pit design contains less ore than optimum.

Mineable pit phases were designed based on optimized nested pit shell guidance, gold grade, strip ratio, access, and backfilling of the ACMA phases. Ramps in final walls have a design width of 40 m and a gradient of $10 \%$. A nominal minimum mining width of 150 m was used for phase design.

Dates in this Report are relative to the start of process production. Preproduction has been defined as starting in early Year -1 and finishing at the end of Year -1, when the main orebody is exposed. Process production starts in mid Year 1. The operating mine life is estimated to be 25 years based on a nominal processing rate of $53,500 \mathrm{t} / \mathrm{d}$. The schedule incorporates longterm and short-term ore stockpiles. The long-term stockpile will hold all ore produced at the mine in excess of plant feed, separated into three sections according to sulphur grade for blending purposes.

The maximum long-term stockpile is 104.3 Mt at the end of Year 13. This includes 18.5 Mt of high sulphur-grade material, 31.9 Mt of medium sulphur-grade material, and 53.9 Mt of low sulphur-grade material.

The short-term stockpile was established to cope with daily variations in plant capacity and to accommodate fluctuations in the average daily mill feed; this stockpile was assumed to have an average $45 \%$ annual re-handle.

After plant ramp-up, mill feed averages $52,700 \mathrm{t} / \mathrm{d}$ and reaches a maximum of $54,400 \mathrm{t} / \mathrm{d}$ in Year 12. Gold production averages approximately 1.1 Moz per year over the LOM, while gold production averages 1.5 Moz per year for the first full five years, with a maximum of 1.7 Moz in Year 6.In the opinion of the Wood QPs, the proposed plant feed supports that the amount of sulphur in the feed can be controlled through a blending strategy combining ore feed directly from the mine and from stockpiles.

A total of 2,232 Mt of waste will be stored in a single ex-pit waste rock facility, in the American Creek Valley, east of the pit area. Another 425 Mt of waste rock will be stored in the ACMA backfill dump and 17 Mt of overburden in the overburden stockpiles for reclamation use. The remaining 91 Mt is used as construction material, of which 89 Mt is for tailings dam wall construction. Backfilling will commence in Year 18 and continue until the end of mine life.

Surface ditches, a contact water dam (CWD) immediately upstream of the pit, plus diversion systems further upstream, will control surface waters in the pit and waste dump areas. Dewatering systems consisting of perimeter and in-pit vertical dewatering wells, horizontal drains, and in-pit sump pumps will be required to manage groundwater.

[[%~%]]
## 1.18 Process Design

ROM ore at 53,500 t/d from the Donlin deposits will be crushed in a gyratory crusher followed by a SAG mill and two-stage ball milling, addition of chemicals, and a flotation circuit. The primary ball milling circuit will produce a $\mathrm{P}_{80}$ particle size of 120 to $150 \mu \mathrm{~m}$ as feed to the primary rougher flotation section. The secondary ball milling circuit will produce a $\mathrm{P}_{80}$ particle size of $50 \mu \mathrm{~m}$ as feed to the secondary rougher flotation section.

Gold-bearing sulphides, recovered by flotation, generate a concentrate containing 7\% sulphur. The concentrate is refractory and will be treated in a POX circuit prior to cyanidation. Overall gold recovery from flotation, POX and cyanidation is estimated to be in the order of $89.8 \%$. Excess acid from the autoclave circuit will be neutralized with flotation tailings and slaked lime. Tailings from the process will be impounded in a TSF; water reclaimed from the TSF will be reused in the process plant.

Mineralogical studies have shown that the gold is not visible. Testwork analysis indicates a high level of association of gold with arsenopyrite. Other sulphides such as pyrite and marcasite are also present, with reduced tenors of gold. Organic carbon, a potential preg-robber, is present in the sedimentary ore. It is also present at lower levels in the intrusive ores, believed to be in the form of well-ordered graphite. This form of organic carbon is possibly less likely to preg-rob.

The average Bond work index for the ore is in the range of $15 \mathrm{kWh} / \mathrm{t}$. Flotation work has shown that kinetics was initially rapid, but to achieve high recoveries, a combined primary and secondary rougher residence time over 100 minutes, together with a high reagent loading inthe system, is required. Clay-like minerals will affect slurry viscosity and settling. Slurry density in the underflow will be less than $50 \%$ solids for the concentrate thickeners.

Partially geologically oxidized (altered) ore in the deposit, up to $7 \%$ of the process feed, is the key non-performing ore type in the flotation circuit.

POX has been shown to be successful in releasing the valuable constituents, under certain conditions. To optimize oxidation conditions, the water systems design has been modified to use the highest-quality water in the oxidation circuit. The autoclave design incorporates variable level control to provide better control over operating residence time.

The oxidation circuit discharge will be washed to reduce lime load in CIL; the washed solution will be neutralized by using high-carbonate flotation tails to further reduce plant lime consumption prior to tailings disposal.

Gold recovery by CIL has proven successful in treating Donlin ores and is estimated to be $96.6 \%$. Rheological investigation and CIL testing results have determined that a relatively low CIL feed density of $35 \%$ solids should be adopted. In addition, to control lime usage, the CIL circuit will be operated at a pH of approximately 11.0.

Given the plan to use stockpiles to manage the ore blend into the process from the perspective of gold, sulphur, carbonate, and hardness, allowances were made for ore aging or stockpile degradation for the LOM feed. Ore oxidized through weathering will have a slower flotation response than fresh rock. In general, ore at Donlin does not contain highly reactive sulphide species, and testwork has shown no statistical deviation over a one-year period. While data from a longer timeframe are not presently available, the testwork results for oxidized material show some degradation. Consequently, there is no effect on flotation recovery for material stockpiled for less than one year (sulphide "fresh" material), and a flotation recovery deduction of $5 \%$ has been applied to gold and sulphur recoveries for sulphide material stockpiled for longer than one year.

Alternative flowsheets to flotation-POX-CIL were considered, including whole ore pressure oxidation, roasting a flotation concentrate, and bio-oxidation (BIOX). None of these proved to be a viable economic alternative to the flotation-POX-CIL route.

[[%~%]]
## 1.19 Planned Project Infrastructure

The Project will require construction of significant infrastructure to support the planned producing facilities. Key infrastructure will include:

- Access road, 44 km long, from the mine site to the planned Kuskokwim River Port site at Jungjuk
- Airstrip to support DHC Dash 8 and the Hercules C-130 aircraft
- Barge cargo and fuel terminal at Jungjuk
- Marine cargo terminal at Bethel
- Two open pit mines
- Process plant site on the north ridge bounding Anaconda Creek valley
- Primary crusher area on a ridge on the south side of American Creek
- Fuel storage compound adjacent the process plant site
- Mining and road fleet truckshops in association with the primary crusher area
- CWD and a freshwater storage reservoir
- Water management pumping systems
- Power plant located adjacent the process plant
- TSF in the Anaconda Creek valley
- Waste rock storage facility (WRF) in the American Creek valley
- Natural gas pipeline
- Construction (2,560 people) and permanent accommodation (maximum 638 people) camps.

In general, the design and construction of the mine site infrastructure will be relatively straightforward, although the scope of the work is extensive, especially in terms of the water systems. In addition, the Project involves several development sites considerable distances apart, incurring high infrastructure costs to provide interconnecting roads, pipelines, services, and utilities. The decision to use material from the plant site excavation as a borrow source for constructing the initial tailings dam is an effective way to reduce the site preparation costs.

The construction schedule for the initial phase of the TSF and the Lower CWD is aggressive, with a great deal of work to be completed in a short duration. Weather delays could affect completion on schedule.

[[%~%]]
## 1.20 Markets

NOVAGOLD will be able to market its share of gold produced from the Project. Sales contracts that could be negotiated would be expected to be within industry norms. However, most of production would be expected to be spot marketed.

[[%~%]]
## 1.21 Capital Costs

The capital cost estimate is based on updated, first quarter 2020 pricing applied to the engineering designs and material take-offs from the 2011 feasibility study. Except the following two design changes, no changes to engineering or material take offs (MTOs) were made:

- The operations WTP was changed from a High Density Sludge (HDS) plant to a Reverse Osmosis (RO) plant.
- The natural gas pipeline was updated for an increase in pipe diameter from 12" to 14" (305 to 356 mm ) and for modifications made to the route (i.e., the North Route Alignment) between mile post (MP) 85 and 112.

Wood was responsible for updating the initial and sustaining capital estimates for all areas except the autoclave, autoclave support facilities, and oxygen plant (estimated by Hatch Ltd.) and the indirect costs associated with those areas. Closure and reclamation costs were prepared by SRK Consulting Limited and checked by Wood. Warehouse inventory is excluded from the capital cost estimate but is included in the Project's economic model.

Following the updates, the total initial capital cost estimate is $\$ 7,402$ million, increasing by $\$ 723$ million, a $10.8 \%$ increase, compared to the 2011 initial capital estimate (see Table 1-3). Likewise, the total sustaining capital is $\$ 1,723$ million, increasing by $\$ 219$ million, a $14.6 \%$ increase, compared to the 2011 sustaining capital estimate (see Table 1-4).

The level of accuracy for the estimate is $\pm 25 \%$ of estimated final costs, per Association for the Advancement of Cost Engineering (AACE) Class 3 definition. A 17.7\% contingency was applied to the initial capital estimate.Table 1-3: Initial Capital Estimate

| Area | Description | Estimate <br> (\$M) |
| :-- | :-- | :--: |
| 1000 | Mining | 422.1 |
| 2000 | Site Preparation and Roads | 268.4 |
| 3000 | Process Facilities | $1,435.7$ |
| 4000 | Tailings Management and Reclaim Systems | 140.4 |
| 5000 | Utilities | $1,473.4$ |
| 6000 | Ancillary Buildings and Facilities | 351.3 |
| 7000 | Off Site Facilities | 278.7 |
|  | Estimated Total Direct Cost | $4,370.2$ |
| 9000 | Estimated Total Indirect Cost | $1,566.9$ |
| 8000 | Total Owner's Cost | 353.6 |
| 9900 | Contingency | $1,111.4$ |
|  | Total Capital Cost | $\mathbf{7 , 4 0 2 . 0}$ |

Table 1-4: Sustaining Capital Estimate

| Area | Description | Estimate <br> (\$M) |
| :-- | :-- | --: |
| 1000 | Mining | 742.9 |
| 2000 | Site Preparation and Roads | 3.2 |
| 3000 | Process Facilities (Not Applicable) | 0.0 |
| 4000 | Tailings Storage Facility and Reclaim Systems | 723.5 |
| 5000 | Utilities (Not Applicable) | 0.0 |
| 6000 | Ancillary Buildings and Facilities | 96.1 |
| 7000 | Off Site Facilities | 20.1 |
|  | Total Direct Cost | $1,585.8$ |
| 9000 | Total Indirect Cost | 137.7 |
| 8000 | Total Owner's Cost | 0.0 |
| 9900 | Contingency | 0.0 |
|  | Total Capital Cost | $\mathbf{1 , 7 2 3 . 5}$ |

[[%~%]]
## 1.22 Operating Costs

Wood updated the 2011 feasibility study operating costs to bring them current to 2020 by updating key cost drivers like energy, labour, consumables, and freight. No changes to designs, schedules, or productivities were made, consequently the manning schedules and consumables remain unchanged.

Compared to 2011, the 2020 operating costs excluding royalties have decreased by 3.0\% primarily due to lower energy and process consumable prices.

The updated estimated LOM operating costs are $\$ 5.90 / \mathrm{t}$ mined or $\$ 38.21 / \mathrm{t}$ processed, or \$635/oz sold (see Table 1-5).

The level of accuracy for the estimate is $\pm 25 \%$ of estimated final costs, per AACE Class 3 definition.

Table 1-5: LOM Operating Costs

| Area | Total LOM <br> (\$M) | $\$ / t$ Processed | $\$ / t$ Mined | $\$ / o z$ |
| :-- | :--: | :--: | :--: | :--: |
| Mine Operations | 8,430 | 16.70 | 2.58 | 278 |
| Processing Operations | 6,916 | 13.70 | 2.12 | 228 |
| Administration | 1,762 | 3.49 | 0.54 | 58 |
| Land \& Royalty Payments | 2,182 | 4.32 | 0.67 | 72 |
| Total | $\mathbf{1 9 , 2 8 9}$ | $\mathbf{3 8 . 2 1}$ | $\mathbf{5 . 9 0}$ | $\mathbf{6 3 5}$ |

[[%~%]]
## 1.23 Economic Analysis

The results of the economic analysis represent forward-looking information that are subject to a number of known and unknown risks, uncertainties, and other factors that may cause actual results to differ materially from those presented here. Forward-looking information includes Mineral Resource and Mineral Reserve estimates, commodity prices and exchange rates, the proposed mine production plan, projected recovery rates, estimated capital and operating costs, and completion schedule for the proposed Project infrastructure, in particular assumptions regarding permits and governmental approvals.

The overall economic viability of the Project has been assessed using both undiscounted and discounted cash flow techniques. Undiscounted techniques include total net cash flow and payback period (measured from start of production). Discounted cash flow techniques includenet present value (NPV) and internal rate of return (IRR). Discounted values are calculated using a $5 \%$ discount rate and a discrete end-of-year convention relative to year -6 , the start of basic and detailed engineering.

The economic evaluation of the Project is based on:

- \$1,500/oz gold price
- Current royalty agreements for Calista and TKC, and the Lyman family land access payments and use
- Operating and initial and sustaining capital costs updated to first quarter 2020
- Tax payments in accordance with the Tax Cuts and Jobs Act ("TCJA") enacted in December 2017 and effective 1 January 2018
- $\$ 292$ million LOM contributions for reclamation, closure, and financial assurance
- Financing has been assumed on a 100\%, all equity, stand-alone basis
- Escalation/inflation has been excluded
- No salvage is assumed at the end of operations.

Based on the economic evaluation, the Project generates positive before and after tax economic results. After tax $\mathrm{NPV}_{5}$ is $\$ 3,040$ million and the after tax IRR is $9.2 \%$. After tax payback is achieved 7.3 years following the start of production. Key evaluation metrics is summarized in Table 1-6.

Sensitivity analyses have been performed on the Project on a range of $-30 \%$ to $+30 \%$ on gold price, gold grade, operating costs, and capital costs. Based on the sensitivity analysis, the Project is particularly sensitive to changes in the gold price. The Project requires a gold price of approximately $\$ 930 /$ oz to break even on an undiscounted cash flow basis and a gold price of approximately $\$ 1,180 /$ oz to break even on a $5 \%$ discounted basis.Table 1-6: Summary of Key Evaluation Metrics

| Item | Unit | Value |
| :--: | :--: | :--: |
| Total Mined | Mt | 3,270 |
| Ore Treated | Mt | 505 |
| Strip Ratio | W/O | 5.5:1 |
| Gold Recovered | Moz | 30.4 |
| Gold Recovery | \% | 89.8 |
| Gold Price (economic analysis) | \$/oz | 1,500 |
| Total After Tax Cash Flow | \$M | 13,145 |
| Total After Tax NPV ${ }_{5}$ | \$M | 3,040 |
| After Tax IRR | \% | 9.2 |
| Payback Period | years | 7.3 |
| Operation Life | years | 27 |
| Operating Costs | \$M | 19,289 |
|  | \$/oz | 635 |
| Closure Costs (Trust fund / assurance) | \$M | 292 |
|  | \$/oz | 10 |
| Initial Capital | \$M | 7,402 |
| Sustaining Capital | \$M | 1,723 |
| Total LOM Capital | \$M | 9,125 |
|  | \$/oz | 300 |
| Total operating, closure, and capital costs | \$M | 28,707 |
|  | \$/oz | 945 |

[[%~%]]
## 1.24 Conclusions

Wood's QPs consider that the scientific and technical information available on the Project can support proceeding with additional data collection, trade-off and engineering work and preparation of more detailed studies. However, the decision to proceed with a mining operation on the Project is at the discretion of Donlin Gold LLC, NOVAGOLD and Barrick.

[[%~%]]
## 1.25 Recommendations

Wood's QPs recommend:

- Completion of additional confirmation and extension drilling for 2021 to expand upon 2020 drill results into the continuity and structural controls of the higher-grade mineralization.- Completing a final feasibility study to incorporate all recent data acquisition from the targeted drill programs in 2017 and 2020 and current planned 2021 program, such as geologic and geotechnical information.
- Obtain final permits required for construction and operation, major permits still required and in progress include Dam Safety Certificates for seven planned dams and water diversion structures, and water rights.

[[@~@]]
# 2.0 Introduction

NOVAGOLD requested Wood to update necessary content to prepare a current summary on the results of the 2011 feasibility study in the form of a current National Instrument (NI) 43-101 technical report (the Report) for the Donlin Gold project (the Project) in Alaska, USA (Figure 2-1 and Figure 2-2).

The Project is a 50:50 joint venture between NOVAGOLD Resources Alaska, Inc, (a wholly-owned subsidiary of NOVAGOLD) and Barrick Gold U.S. Inc, (a wholly-owned subsidiary of Barrick). The partners use an operating company, Donlin Gold LLC to manage the Project. For the purposes of this Report, "Donlin Gold LLC" is used as a synonym for the joint venture. Prior to July 2011, Donlin Gold LLC was known as Donlin Creek LLC (DCLLC).

NOVAGOLD is filing this Report on System for Electronic Document Analysis and Retrieval (SEDAR) to update the scientific and technical information on the Property and to support NOVAGOLD's disclosure on the Project.

The Report has an effective date of 1 June 2021 and is current as of the date of filing.

[[%~%]]
## 2.1 Terms Of Reference

The feasibility study that is summarized in this Report was completed in October 2011, and was a compendium of different studies by a number of companies, as indicated in Table 2-1.

Wood used the information completed by these contributors, as well as more recent data and information available on the Project to support and make current information in this Report. Wood's QPs performed or supervised subject matter experts within Wood to conduct independent due diligence reviews on the information supplied by Donlin Gold LLC and made adjustments to the results of the 2011 feasibility study based on the outcome of those reviews.

The Report uses Canadian English. Unless otherwise specified in the text, monetary amounts are in US dollars and units are metric.# NOVAGOLD 

Figure 2-1: Regional Project Setting
![img-0.jpeg](img-0.jpeg)

Note: Figure courtesy Donlin Gold LLC, 2021
Figure 2-2: Local Project Setting
![img-1.jpeg](img-1.jpeg)

Note: Figure courtesy Donlin Gold LLC, 2021Table 2-1: Consulting Firms or Entities Contributing to Content in the Technical Report

| Consulting Firm or Entity | Area of Responsibility in Feasibility Study Report Document |
| :--: | :--: |
| Wood | Overall study compilation, design of port and process facilities (excluding the autoclave and autoclave ancillary facilities), flowsheet, development of logistics program; 2020 equipment pricing, excluding equipment associated with the autoclave and oxygen plant, quantity estimation for major civil and structural components, capital cost estimates for off-site facilities, on-site facilities, and process facilities, autoclave, autoclave support facilities, and oxygen plant, operating cost updates for mining, process, transport, natural gas pipeline and administration, development of Project plan and schedule. 2020 cost estimate updates for all study content except the autoclave and autoclave ancillary facilities. |
| Donlin Gold LLC and Barrick | Geologic modelling; Mineral Resource and Mineral Reserve estimation, specification and management of metallurgical testwork program; bench and pilot testing facilities for pressure oxidation and neutralization; specification and management of environmental and socio-economic baseline studies, including impact analysis; permitting requirements; reclamation planning; baseline environmental data; process and mining engineering; economic evaluation; mine planning; 2011 capital cost estimates for the mine; 2011 operating cost estimates for the mine; 2011 sustaining capital cost estimates for the mine. |
| BGC Engineering Inc. | Geotechnical engineering to support the mine pits, waste rock facility, plant site, and tailings storage facility; site water management; mine waste rock management; design of the tailings storage facility and waste rock facility foundations; pit dewatering plans for the mine. |
| CH2MHill | Routing and geotechnical studies for the originally selected alignment of the natural gas pipeline; pipeline design and engineering; construction execution planning and scheduling; 2011 capital and operating cost estimates for the natural gas pipeline. |
| Hatch Ltd. | Flowsheet development of autoclave process; design of autoclave and autoclave ancillary facilities; equipment pricing for autoclave and autoclave ancillary facilities; quantity estimation for autoclave and autoclave ancillary facilities; capital cost estimate for autoclave and autoclave ancillary facilities; operating cost estimate for autoclave and autoclave ancillary facilities; logistics plan for delivery of autoclave. 2020 cost updates for autoclave and autoclave ancillary facilities. |
| Lorax Environmental Services Ltd. | Water quality modelling for the mine pit lake |
| Michael Baker International | Natural gas pipeline execution plan and design basis |
| SRK Consulting Limited | Acid rock drainage (ARD) and metal leaching (ML) assessment; closure cost estimate; water management plan |
| Rowland Engineering Consultants | Geotechnical investigations to support port site, airstrip, and material borrow sources; geotechnical engineering for access roads between port site, airstrip, and plant site. |

Note: Wood QPs take responsibility for all sections of the Report as detailed in their individual Certificates of Qualified Persons. Contributions by non-Wood entities were reviewed by Wood experts for suitability for inclusion in this Report. Details of the data verification performed by Wood QPs are presented in Section 12 Data Verification. Wood QPs have relied on other experts for legal and tax matters as described in Section 3 Reliance on Other Experts.

[[%~%]]
## 2.2 Qualified Persons

The following individuals are the Qualified Persons (QPs) as defined in National Instrument 43-101 Standards of Disclosure for Mineral Projects (NI 43-101), are the co-authors of this Report:

- Henry Kim, P.Geo., Senior Resource Geologist, Wood Canada Limited
- Mike Woloschuk, P.Eng., VP Global Business Development \& Consulting, Wood Group USA, Inc.
- Kirk Hanson, MBA, P.E., Technical Director, Open Pit Mining, Wood Group USA, Inc.


[[%~%]]
## 2.3 Site Visits And Scope Of Personal Inspections

The QPs conducted site visits to the Project as shown in Table 2-2.
Mike Woloschuk completed a personal inspection of the Donlin property on 15 September 2010 to view the site topography for process plant and infrastructure facilities layout.

Henry Kim completed a personal inspection of the Donlin property on 18 to 21 September 2020. The independent consulting geologist who prepared the DC9 geological and resource model in 2009, was available to join the team for the site visit to discuss the model and activities at the site. During the visit, core logs were compared to the core, lithologies in the resource model were compared to the lithologies in the surface outcrops, core logging and sampling protocols were reviewed, available 2020 core logs were compared to the DC9 geological model, and handling of the core and sample preparation were observed. Drilling procedures could not be observed directly as no drilling was being performed during the site visit.

Kirk Hanson initially visited the site on 1 October 2008 and undertook a high-level review of the Project geology, inspected drill core, viewed the Project topography, inspected proposed pit and waste dump locations, and the locations of existing and proposed infrastructure, including road cuts and borrow pits.

During 18 to 21 September 2020, Kirk Hanson completed a second, 4-day, personal inspection of the Donlin property. The focus of the site visit was to inspect proposed mining areas and proposed locations for project infrastructure including:

- ACMA and Lewis pit and WRF locations
- TSF, plant site, and water retention facilities
- Jungjuk Road, port, access road including borrow sources- Permanent camp and airstrip
- RO operations water treatment plant and discharge location at Crooked Creek
- First 25 miles of natural gas pipeline route starting at Donlin Gold property.

In addition to these visits, other Wood personnel have visited site during preparation of the feasibility study, and have provided input to study content used in this Report.

Table 2-2: QPs, Areas of Report Responsibility, and Site Visits

| Qualified Person | Site Visits | Report Sections of Responsibility <br> (or Shared Responsibility) |
| :-- | :-- | :-- |
| Mike Woloschuk | 15 September 2010 | Sections 1.14, 1.18, 2.3, 11.2, 12.4, 12.6.3, 13, 17, 18.2, 21, <br> $25.4,25.7,26$, and 27 |
| Henry Kim | 18-21 September 2020 | Sections 1.4-1.6, 1.8-1.13, 1.15, 2.3, 3, 4, 5, 6, 7, 8, 9, 10, 11, <br> $12.1,12.2,12.6 .1,14,23,24,25.1-25.3,25.5,26$, and 27 |
| Kirk Hanson | 1 October 2008 \& <br> 18-21 September 2020 | Sections 1.1-1.3, 1.7, 1.16-1.17, 1.19-1.25, 2, 3, 12.3, 12.5, <br> $12.6 .2,12.6 .4,15,16,18,19,20,21,22,25.6,25.8-25.12,26$, <br> and 27 |

[[%~%]]
## 2.4 Effective Dates

The Report has a number of effective dates, as follows:

- Technical Report: 1 June 2021
- Effective date of the Mineral Resources: 11 July 2011
- Effective date of the Mineral Reserves: 27 April 2021

Based on the QPs' review of latest information available, there has been no material change to the scientific and technical information on the Project between the effective date of the Report, and the signature date of their Certificates of Qualified Persons.

[[%~%]]
## 2.5 Previous Technical Reports

NOVAGOLD previously filed the following technical reports on the Project:

- Lipiec, T., Seibel, G., and Hanson, K., 2012: Donlin Creek Gold Project Alaska, USA, NI 43-101 Technical Report on Second Updated Feasibility Study, effective date 18 November 2011, amended 20 January 2012 (Donlin 2011 Technical Report)- Francis, K., 2008: Donlin Creek Project, NI 43-101 Technical Report, Southwest Alaska, U.S.: technical report prepared for NOVAGOLD Resources Inc., effective date 5 February 2008
- Dodd, S., Francis, K. and Doerksen, G., 2006: Preliminary Assessment Donlin Creek Gold Project Alaska, USA, NI 43-101F1 Technical Report to NOVAGOLD Resources Inc. by SRK Consulting (US), Inc., effective date 22 August 2006
- Dodd, S., 2006: Donlin Creek Project 43-101 Technical Report, NI 43-101F1 Technical Report to NOVAGOLD Resources Inc. by NOVAGOLD Resources Inc., effective date 20 January 2006
- Juras, S. and Hodgson, S., 2002: Technical Report, Preliminary Assessment, Donlin Creek Project, Alaska, NI 43-101F1 Technical Report to NOVAGOLD Resources Inc. by MRDI, report date March 2002
- Juras, S., 2002: Technical Report, Donlin Creek Project, Alaska, NI 43-101F1 Technical Report to NOVAGOLD Resources Inc. by MRDI, effective date 24 January 2002


[[%~%]]
## 2.6 Information Sources And References

The primary data sources for this Report are the following:

- AMEC Americas Ltd., 2011: Donlin Creek Gold Project, Alaska, Feasibility Study Update 2, Effective Date 7 October 2011: feasibility study update prepared by AMEC for Donlin Creek LLC, dated 9 October 2011.
- Reports and documents listed in the Section 3 Reliance on Other Experts and Section 27 References, were also used to support preparation of the Report.

[[@~@]]
# 3.0 Reliance On Other Experts

The QPs have relied upon the following other experts, who provided information regarding mineral rights, surface rights, agreements, and tax content of this Report as noted below.

[[%~%]]
## 3.1 Mineral Tenure, Surface Rights, Agreements, And Royalties

The QPs have not reviewed the mineral tenure, nor independently verified the legal status, ownership of the Project area, underlying property agreements or permits. The QPs have fully relied upon, and disclaim responsibility for, information derived from Donlin Gold LLC experts and experts retained by Donlin Gold LLC for this information through the following documents:

- NOVAGOLD RESOURCES INC. Email with attachment of the content for inclusion as Section 4 in the NI 43-101 Technical Report on the Donlin Gold Project, Alaska, USA with an effective date of $1^{\text {st }}$ June 2021. Email from Cliff Krall, Manager, Mine Engineering, NOVAGOLD RESOURCES INC. to Kirk Hanson, Technical Director, Open Pit Mining, Wood Group USA, Inc., dated 16 July 2021.
- Manzer, D.S., 2020: Donlin Gold Project, Updated Abstract of Record Title, Effective September 11, 2020: title search prepared by Alaska Land Status Inc. for Perkins Coie LLP and addressed to Robert Maynard of Perkins Coie LLP, dated 16 October 2020
- Maynard, R.M., 2020: Update of October 10, 2011 Title Report Letter for Donlin Creek Project Real Property Interests: confidential legal opinion prepared by Perkins Coie LLP for Donlin Gold LLC, and addressed to Dan Graham, General Manager for Donlin Gold LLC, dated 26 October 2020.

This information is used in Section 4 and Section 19 of the Report and was also used to support considerations of reasonable prospects of economic extraction and declaration of Mineral Resources in Section 14, and for consideration of appropriate modifying factors for declaration of Mineral Reserves in Section 15.

[[%~%]]
## 3.2 Taxation

The QPs have not reviewed the taxation information. The QPs have fully relied upon, and disclaim responsibility for, information supplied by NOVAGOLD for information related to taxation contained in the following document:

Reliance on Other Expert for Tax Information: Taxation: letter prepared by NOVAGOLD for Wood Canada Limited, dated 27 April 2021, 3 pages. Title: Re: Taxation information and tax inputs to the financial model used in the NI 43-101 Technical Report on the Donlin Gold Project, Alaska, USA prepared by Wood Canada Limited ("Wood") for NOVAGOLD RESOURCES INC. ("NOVAGOLD").

This information is used to summarize the tax information and in support of the after-tax economic analysis in Section 22, which demonstrates economic viability of the Project in support of the Mineral Reserve estimation in Section 15.

[[@~@]]
# 4.0 Property Description And Location

[[%~%]]
## 4.1 Location

The Donlin deposits are situated approximately 450 km west of Anchorage and 250 km northeast of Bethel up the Kuskokwim River. The closest village is the community of Crooked Creek, approximately 20 km to the south, on the Kuskokwim River.

The resource areas are within T. 23 N., R. 49. W., Seward Meridian, Kuskokwim and Mt. McKinley Recording Districts, Crooked Creek Mining District, Iditarod A-5 USGS 1:63,360 topography map. The mineralization is centred on approximately 540222.50 east and 6878534.36 north, using the NAD 83 datum.

These areas consist of the ACMA and 400 Zone, Aurora and Akivik mineralized areas (grouped as ACMA) and the Lewis, South Lewis, Vortex, Rochelieu and Queen mineralized areas (grouped as Lewis). The proposed project configuration, including the pit outline for the combined ACMA and Lewis areas, in relation to the Calista Lease Boundary and The Kuskokwim Corporation Surface Use Agreement boundary (refer to Section 4.3) is shown as Figure 4-1.

[[%~%]]
## 4.2 Property Ownership History

Calista Corporation (Calista), an Alaska Native Corporation, has held the mineral rights to the Project mine site lands since 1974.

Placer Dome Inc. acquired a 20-year lease from Calista effective 1 May 1995. As further described in Section 4.3, the lease has been subsequently amended and restated as a Restated Exploration and Lode Mining Lease between Donlin Gold LLC and Calista (the "Calista Lease"), with a term extending to 30 April 2031, and continuing thereafter as long as mining or processing operations continue in good faith or specified payments are made each year.

On 13 November 2002, NOVAGOLD Resources Alaska, Inc., a wholly-owned subsidiary of NOVAGOLD, earned a 70\% interest in the Property by expending $\$ 10$ million on exploration and development of the Project. Placer Dome Inc. retained an option to buy back into the Property.Figure 4-1: Donlin Gold Property Land Status Map
![img-2.jpeg](img-2.jpeg)On 11 February 2003, Placer Dome Inc. exercised its back-in right and assumed management of the continued development of the Property. In January 2006, Barrick acquired Placer Dome Inc. and assumed Placer Dome Inc.'s joint venture responsibilities for exploration and development activities on the Property.

On 1 December 2007, NOVAGOLD entered into a limited liability company agreement with Barrick (the Donlin LLC Agreement) that provided for the conversion of the Project into a new limited liability company, the Donlin Creek LLC (DCLLC), which is jointly owned by NOVAGOLD and Barrick on a 50/50 basis. In July 2011, the Board of Donlin Creek LLC voted to change the name of the company to Donlin Gold LLC.

Lyman Resources in Alaska, Inc. (Lyman Resources) has an existing placer mining lease covering approximately 10.4 square km (partially covering six sections) within the Calista Lease area. The Lyman family also has title to approximately 5.7 hectares of surface estate within the Snow Gulch area. This lease area lies immediately to the north of the Project open pit shell outline. The Calista Lease grants priority to extraction of the lode mineralization in the event of a conflict of use between lode and placer mining operations, provided that a two-year notice period is provided to Lyman Resources. Lyman Resources, the Lyman family, and Donlin Gold LLC executed a Surface Lease and Assignment of Mining Lease effective 9 May 2012 leasing the Lyman surface estate and assigning the Lyman placer lease within the Calista Lease area to Donlin Gold LLC for mining use (the "Lyman Lease").

[[%~%]]
## 4.3 Lease Rights

The Calista Lease currently includes a total of 72 complete sections in the vicinity of the Donlin deposits, and additional partial sections associated with the Project infrastructure, leased from Calista, an Alaska Native Corporation that holds the subsurface (mineral) estate for Native-owned lands in the region. Title to approximately 19,988 hectares of the leased lands has been conveyed to Calista by the Federal Government. Calista owns the surface estate on a portion of these lands.

In March 2010, DCLLC renegotiated its lease with Calista. Amendments to the renegotiated lease provide for:

- The lease of certain additional lands that may be required for the development of the property.
- An extension of the term of the lease to 30 April 2031 and year to year thereafter, so long as either mining or processing operations continue, or Donlin Gold LLC makes specified payments to Calista.# NOVAGOLD 

In February 2011, Calista and DCLLC executed a Restated Exploration and Lode Mining Lease to reflect all Calista lease amendments and assignments up to and including 11 February 2011.

A separate Surface Use Agreement (SUA) with The Kuskokwim Corporation (TKC), an Alaska Native Village Corporation that owns the majority of the private surface estate in the area, grants non-exclusive surface use rights to Donlin Gold LLC on at least 64 sections overlying or in the vicinity of the Donlin deposits, with provisions allowing for adjusting that area in conjunction with adjustments to the subsurface included in the Calista Lease. The SUA was revised and restated and executed by Donlin Gold LLC and TKC to expand the TKC surface lands included in the SUA and update other provisions, effective 6 June 2014. The term of the SUA runs through 30 April 2031, with provisions to continue beyond that time so long as the Calista Lease remains in effect. Calista and Donlin Gold LLC executed an agreement making limited further amendments to the Calista Lease, effective 6 June 2014, in conjunction with the revision of the SUA between Donlin Gold LLC and TKC. The SUA provides Donlin Gold LLC with rights to approximately 16,923 hectares.

The Lyman Lease described above provides Donlin Gold LLC rights on the Lyman family small private surface parcel (approximately 5.7 hectares) in the vicinity of the Donlin deposits and placer mining lease with Calista that covers approximately 10.4 square km .

[[%~%]]
## 4.4 Mineral Tenure

Most of the Property rights (surface and subsurface) are governed by conditions defined by the Alaska Native Claims Settlement Act (ANCSA). Section 12(a) of ANCSA entitled each village corporation to select surface estate land from an area proximal to the village in an amount established by its population size. In accordance with ANCSA, Calista, as a regional corporation, receives conveyance of the subsurface estate and the surface estate in those lands is conveyed to the village corporation. Section 12(b) of ANCSA also allocated a smaller entitlement to the regional corporations with the requirement they reallocate it to their villages as they choose. Calista reallocated its Section 12(b) entitlement in 1999, based on an original village corporation enrollment formula.

The Calista Lease currently includes lands leased from Calista, which holds the subsurface (mineral) estate for Native-owned lands in the region. The leased land is believed to contain approximately 19,988 hectares. Title to all lands has been conveyed to Calista by the Federal Government. Calista owns the surface estate on a portion of these lands.A separate Surface Use Agreement (SUA) with TKC, which owns the surface estate of the remaining lands, grants non-exclusive surface use rights to Donlin Gold. All these lands have been conveyed to TKC by the Federal Government.

In addition to the approximately 19,988 hectares leased from Calista, Donlin Gold LLC holds 493 Alaska State mining claims comprising approximately 29,008 hectares, on State and Stateselected lands in the vicinity of the leased lands in the Kuskokwim and Mount McKinley recording districts, bringing the total mineral land package to approximately 48,996 hectares.

Of these claims:

- 84 are on State-selected lands
- A total of 409 are located on lands that have either been patented to the State of Alaska or Tentatively Approved to Patent from the United States pending survey.

None of the claims held by Donlin Gold LLC have been surveyed.
All claims are either 64.8 ha or 16.2 ha in size.

[[%~%]]
## 4.5 Surface Rights

Donlin Gold LLC, through the Calista Lease, TKC SUA, and Lyman Lease, holds most of the surface rights that will be required to support mining operations in the proposed mining area.

Other lands required for off-site infrastructure, such as the natural gas pipeline, upriver port site, and mine site access road, are categorized as Native, State of Alaska conveyed, or Federal BLM lands.

[[%~%]]
## 4.6 Royalties And Encumbrances

The terms for the Calista Lease and TKC SUA include various royalty and other payment provisions and considerations such as shareholder employment and contracting opportunities. The Lyman Lease provides for rent and certain other payments. Royalty Terms of the Calista Lease include:

- Annual advance minimum royalty (variable) to 2030
- All advance minimum payments are recoverable as a credit against the net smelter return royalty and net proceeds payment- Net smelter return of $1.5 \%$ for the earlier of the first five years following commencement of commercial production or until initial capital payback
- Conversion to $4.5 \%$ net smelter return after the earlier of five years or initial capital payback
- Net proceeds royalty of $8 \%$ of the net proceeds realized by Donlin Gold LLC commencing with the first quarter in which net proceeds are first realized.

Payment Terms of the TKC SUA include:

- Annual advance minimum payment (variable per milestones)
- All advance minimum payments are recoverable as a credit against the milled tonnage fee and net proceeds payment
- Milled tonnage fee of $\$ 0.40$ per tonne processed for the first 10 years of production
- Conversion of the milled tonnage fee to $\$ 0.50$ per tonne processed for all production after 10 years
- Net proceeds payment of $3 \%$ of the net proceeds realized by Donlin Gold LLC commencing with the first quarter in which net proceeds are first realized.

Additional estimated costs associated with various landowner and lease agreements, not already covered in initial capital or G\&A operating costs, average approximate $\$ 8.6$ million per year during the six pre-production years and $\$ 2.5$ million per year during the 27 operating years.

Annual rent, labour expenditures and filings are required to maintain Alaska State mining claims on State land.

Mining license tax payments may also apply.

[[%~%]]
## 4.7 Permits

Permits required to support Project development are discussed in Section 20 of the Report.

[[%~%]]
## 4.8 Environmental Liabilities

Environmental studies, closure plans and costs, and environmental liabilities and risk issues are discussed in Section 20 of the Report.

[[%~%]]
## 4.9 Social License

The potential social and community impact assessments of the Project are discussed in Section 20 of the Report.

[[%~%]]
## 4.10 Significant Risk Factors

The relatively isolated location of the Property in Alaska makes the Project subject to the risk of delays to mine development and increased costs caused by difficult terrain and harsh seasonal weather conditions. Risks posed by these conditions are discussed in Section 18 of the Report.

[[%~%]]
## 4.11 Comments On Section 4

In the opinion of the QPs, the following conclusions are appropriate:

- Information from Donlin Gold LLC and legal experts support that the mineral tenure is valid and is sufficient to support declaration of Mineral Resources and Mineral Reserves. Mineral tenures have not been surveyed. State mining claims held by Donlin Gold LLC show as active on Alaska Department of Natural Resources online records, indicating that appropriate claim payments and required expenditure commitments are current.
- Information from Donlin Gold LLC indicates that most surface rights are held by either TKC or Calista. The expert information supports that Donlin Gold LLC has agreements with both parties. Calista owns the surface estate on 27 of the 72 complete sections that make up the area covering the Project. TKC has granted Donlin Gold LLC non-exclusive surface use rights to at least 64 complete sections overlying the Donlin deposits and on additional lands for access and infrastructure in the vicinity of the Project site, with provisions allowing for adjusting that area in conjunction with adjustments to the subsurface included in the Calista Lease. The Lyman family owns a small (approximate 5.7 hectare) private parcel in the vicinity of the Donlin deposits and holds a placer mining lease from Calista that covers approximately 10.4 square km (partially covering six sections), currently leased and assigned, respectively, to Donlin Gold LLC. The currently identified resource and the bulk of the proposed primary mine infrastructure (process and waste rock facilities) are located on the leased lands. Additional lands required for the Jungjuk port site, access road from the port site to the mine site, natural gas pipeline, and tailings storage facility in Anaconda Creek are located on a combination of Native, State of Alaska conveyed, and Federal (BLM) lands. Rights-of-way, leases, and easements have been issued by the State for the access road where it crosses State lands. The BLM has authorized the natural gas pipeline right-of-way for those portions on federal lands. Theremaining land authorization required for the portions of the natural gas pipeline on State lands is currently in process.

- Exploration to date has been conducted in accordance with Alaskan regulatory requirements.
- Additional permits will be required for Project development.

[[@~@]]
# 5.0 Accessibility, Climate, Local Resources, Infrastructure, And Physiography

[[%~%]]
## 5.1 Accessibility

The Project site is approximately 450 km west of Anchorage and 250 km northeast of Bethel up the Kuskokwim River. The closest village is the community of Crooked Creek, approximately 20 km to the south, on the Kuskokwim River. Bethel, approximately 30 km upstream from the mouth of the Kuskokwim River, is the regional centre for the Yukon-Kuskokwim Delta area of Southwest Alaska. The town of Aniak, also on the Kuskokwim River and about 80 km southwest of the Project site, is the regional centre for the Upper Kuskokwim Valley.

There is no road or rail access to the site. The nearest roads are in the Anchorage area. Access to Bethel and Aniak, the regional centres, is limited to river travel by boat or barge in the summer and air travel year-round. The Kuskokwim River is a regional transportation route and is serviced by commercial barge lines.

All current access to the Project site for personnel and supplies is by air. The Project has an all-season, soft-sided camp sufficient to support recent field activities. An adjacent 1,500 m long airstrip is capable of handling aircraft as large as C-130 Hercules $19,050 \mathrm{~kg}$, allowing efficient shipment of personnel, some heavy equipment, and supplies. The Project can be serviced directly by charter air facilities out of both Anchorage and Aniak.

[[%~%]]
## 5.2 Climate

The area has a relatively dry interior continental climate with typically about 500 mm of total annual precipitation. Summer temperatures are relatively warm and may exceed $30^{\circ} \mathrm{C}$. Minimum temperatures may fall to well below $-42^{\circ} \mathrm{C}$ during the cold winter months.

Exploration is possible year-round, though snow levels in winter and wet conditions in late autumn and in spring can make travel within the Project area difficult. It is expected that mining operations will be able to be conducted year-round.

[[%~%]]
## 5.3 Local Resources And Infrastructure

Local resources necessary for the exploration and possible future development and operation of the Project are in Bethel and the Yukon-Kuskokwim region. Some resources would likely have to be brought in from the Anchorage area or other parts of Alaska.Alaska and the adjacent Canadian Province of British Columbia have a long mining history and a large resource of equipment and skilled personnel.

The Property is currently isolated from power and other public infrastructure. The exploration camp has capacity for exploration and other on-site field work. Power is provided by on-site diesel generators.

Infrastructure assumptions and the proposed infrastructure layout for the Project are discussed in Section 18 of the Report.

[[%~%]]
## 5.4 Physiography

The Project area is one of low topographic relief on the western flank of the Kuskokwim Mountains. Elevations range from 150 to 640 m . Ridges are well rounded and easily accessible by all-terrain vehicle.

Hillsides are forested with black spruce, tamarack, alder, birch, and larch. Soft muskeg and discontinuous permafrost are common in poorly drained areas at lower elevations and along north-facing slopes.

[[%~%]]
## 5.5 Sufficiency Of Surface Rights

Regarding future mining operations, sufficient space is available to site the various facilities, including personnel housing, stockpiles, tailing storage facility, waste rock storage facilities and processing plants.

[[%~%]]
## 5.6 Comments On Section 5

In the opinion of the QPs:

- The existing and planned infrastructure, availability of staff, the existing power, water, and communications facilities, the design and budget for such facilities, and the methods whereby goods could be transported to any proposed mine, and any planned modifications or supporting studies are reasonably well-established, or the requirements to establish such, are reasonably well understood by NOVAGOLD, and can support the declaration of Mineral Resources and Mineral Reserves.
- There is sufficient area within the Project to host an open pit mining operation, including the proposed open pits, mine and plant infrastructure, waste rock and tailings storage facilities.- It is a reasonable expectation that any additional surface rights to support Project development and operations can be obtained.
- It is expected that any future mining operations will be able to be conducted year-round.

[[@~@]]
# 6.0 History

Placer gold was first discovered at Snow Gulch, a tributary of Donlin Creek, in 1909. Intermittent small-scale placer gold production continued through 2014. Resource Associates of Alaska (RAA) carried out a regional evaluation for Calista, an Alaska Native regional corporation, in 1974 to 1975. This work included a soil grid and three bulldozer trenches in the Snow area immediately north of the current resource area. Calista followed up with prospecting activities between 1984 and 1986, and completed minor auger drilling in 1987.

The first substantial exploration drill program was carried out by WestGold in 1988 and 1989. WestGold completed geological mapping, trenching, rock and soil sampling, an airborne magnetic and VLF survey, and ground magnetic surveys. WestGold also tested biogeochemical sampling and ground penetrating radar with positive results. Based on this information, WestGold performed an initial Mineral Resource estimate.

Teck carried out a limited trenching and soil sampling program in the Lewis area in late 1993, and updated the Mineral Resource estimate.

Placer Dome Inc. explored the Property from 1995 to 2000. Placer Dome Inc. constructed an exploration camp and airstrip, undertook reconnaissance and geological mapping, aerial photography, completed rock chip and soil sampling, trenching, max-min (EM) geophysical surveys, airborne geophysical surveys, RC and core drilling, carried out detailed metallurgical test work, and prepared a series of Mineral Resource estimates and initial mining and engineering studies.

Placer Dome Inc. formed the Donlin Creek joint venture (DCJV) with NOVAGOLD as operator in 2001. During the period of the DCJV, NOVAGOLD undertook trenching, core and geotechnical drilling, updated Mineral Resource estimates, and completed a Preliminary Assessment.

Placer Dome Inc, reassumed management of the Property as operator in late 2002. From 2002 to 2005, work comprised additional core drilling, condemnation, geotechnical, and water drilling, geotechnical and hydrogeological studies, geological mapping and sampling of prospective calcium carbonate source areas, exploration and auger drilling program for sand and gravel resources, and updated Mineral Resource estimates.

Barrick acquired Placer Dome Inc.'s interest in the DCJV through a merger with Placer Dome Inc. in early 2006. Work completed in the period 2006-2007 included core drilling for resource infill, geotechnical, engineering, condemnation, waste rock, calcium carbonate exploration and metallurgical purposes, and updated Mineral Resource estimates.The DCJV partners formed Donlin Creek LLC in late 2007, with the subsequent name change to Donlin Gold LLC occurring in 2011.

Work on the Property included soil and stream sediment sampling, core drilling for resource infill, geotechnical, engineering, condemnation, waste rock, and metallurgical purposes, and estimation of Mineral Resources and Mineral Reserves.

An initial feasibility study was completed on the Project in 2007, and updated in 2009, and then updated again in 2011.

Between 2011 and 2020, the following types of activities have been completed on the Property: resource infill and extension drilling, trenching, geotechnical work, metallurgical testing, monitoring to support permitting, advancement of permits and certificates for the project, consultation with local communities, community support activities and sponsorships, and infrastructure design work.

A summary of the exploration programs completed on the Property is summarized in Table 6-1.Table 6-1: Exploration Work History Summary for Donlin Gold Property
![img-3.jpeg](img-3.jpeg)| Year | Company | Work Performed | Results |
| :--: | :--: | :--: | :--: |
| 1993 | Teck | D-9 bulldozer trenching ( $1,400 \mathrm{~m}$ ) and two ( 500 m ) soil lines in Lewis area. Petrographic, fluid inclusion, and metallurgical work. | Identified new mineralized areas and expanded property, completed updated resource estimate. Metallurgical tests not favourable, property dropped. |
| $\begin{aligned} & 1995 \text { to } \\ & 2000 \end{aligned}$ | Placer Dome Inc | $87,383 \mathrm{~m}$ of core, $11,909 \mathrm{~m}$ of RC drilling, and $8,493 \mathrm{~m}$ of trenching. | Drilled the American Creek magnetic anomaly (ACMA), discovered the ACMA deposit. Numerous mineral resource calculations. |
| $\begin{aligned} & 2001, \\ & 2002 \end{aligned}$ | DCIV (Placer Dome Inc. / NOVAGOLD) | $46,495 \mathrm{~m}$ of core, $11,589 \mathrm{~m}$ of RC drilling, 89.5 m of geotechnical drilling, and 268 m of water monitoring holes. Mineral Resource estimate. | Expanded the ACMA resource. |
| $\begin{aligned} & 2003 \text { to } \\ & 2005 \end{aligned}$ | DCIV (Placer Dome Inc. / NOVAGOLD) | $25,448 \mathrm{~m}$ of core and $5,979 \mathrm{~m}$ of RC drilling. Calcium carbonate exploration drilling; IP lines for facility condemnation studies. | Infill drilled throughout the resource area demonstrated continuity. Discovered a calcium carbonate resource. Poor quality IP data not useful for facility studies. |
| 2006 | DCIV <br> (Barrick / NOVAGOLD) | $92,804 \mathrm{~m}$ of core drilling for resource conversion, slope stability, metallurgy, waste rock, carbonate exploration, facilities, and port road studies. | Geological model and internal resource updates. |
| 2007 | DCIV | Core drilling totalled $75,257 \mathrm{~m}$ and included resource delineation, geotechnical and engineering, and carbonate exploration. 13 RC holes for monitor wells and pit pump tests totalled 1,043 m. Updated Mineral Resource estimate. | Improved pit slope parameters, positive hydrogeological results, exploration for carbonate mineral source was negative. || Year | Company | Work Performed | Results |
| :--: | :--: | :--: | :--: |
| 2008 | DCLLC | 108 core holes totalling $33,425 \mathrm{~m}$ for exploration and facility related geotechnical and condemnation studies. Metallurgical test work: flotation variability and CN leach. 54 test pits and 37 auger holes completed for overburden characterization. | - Resource expansion indicated for East ACMA. CN leach resource potential indicated for the main resource area, Snow, and Dome prospects. Facility sites successfully condemned. <br> - Updated resource estimates utilizing applicable data through 2007. |
| 2009 | DGLLC (name change) | 19 geotechnical core holes totalling 950 m in facility sites and to address hydrology. Mineral Reserve and Mineral Resource estimate update. | - |
| 2010 | DGLLC | - Six geotechnical core holes totaling 2,090 m to evaluate slope stability of expanded pit. Also drilled 90 auger holes totaling 585 m and dug 59 test pits to further evaluate overburden conditions and gravel supplies within TSF area. <br> - Mineral Reserve and Mineral Resource estimate update. | Pit slope stability of new pit design remained acceptable. Evaluation of construction suitability of surficial materials in TSF is ongoing. |
| 2017 | DGLLC | 16 HQ core holes totaling 7,040 m drilled within the resource area. Acoustic interviewer surveys were completed on 12 holes. Five of the holes were also logged by geotechnical engineering consultants for pit slope geotechnical data collection. Metallurgical sample collection was also conducted. | Geologic, geotechnical, and assay data were incorporated into the project database for internal geologic modeling and optimization updates. Metallurgical samples were tested in 2018, primarily for flotation optimization. |
| 2019 | DGLLC | 30 geotechnical core holes totaling 1,060 m were drilled as part of a site investigation program in support of detailed dam design. | Geotechnical data were incorporated into a site investigation dataset, to be utilized for detailed dam design and permitting once the field program is complete. |
| 2020 | DGLLC | - 85 holes and 23,361 metres core drilling (HQ) in ACMA and Lewis resource area. Objectives on this program has been to validate and increase the confidence in recent geologic | - Available geologic and assay data were incorporated into the project database for || Year | Company | Work Performed | Results |
| :--: | :--: | :--: | :--: |
|  |  | modeling concepts and support future resource updates. <br> Acoustic and optical interviewer surveying were completed on most of the holes. <br> - Geotechnical logging was performed on core from 10 holes | internal geologic modeling and optimization updates. <br> - R2020 drilling geological logs generally agrees with the DC9 geological model while suggesting local adjustments. |

[[@~@]]
# 7.0 Geological Setting And Mineralization

[[%~%]]
## 7.1 Regional Geology

The Donlin deposits lie in the central Kuskokwim basin of southwestern Alaska, and the basin is northeast-trending which subsided between a series of amalgamated terranes. Rocktypes within the basin include Mesozoic marine volcanic rocks, Palaeozoic clastic and carbonate rocks, and Proterozoic metamorphic rocks.

The Kuskokwim basin is predominately underlain by the Upper Cretaceous Kuskokwim Group, a back-arc continental margin basin fill assemblage that formed in response to a change in the angle of convergence between the Kula oceanic plate and the Cretaceous North American continental margin. Sediments primarily consist of a coarse- to fine-grained turbidite comprising sandstone, siltstone, and shale with minor conglomerate.

Late Cretaceous and Early Tertiary volcano-plutonic complexes intrude and overlie the Kuskokwim Group sedimentary rocks. Volcanic components of these complexes consist of intermediate tuffs and flows. Subaerial volcanic tuffs, flows, and domes are regionally extensive and dominantly andesitic, locally include dacite, rhyolite, and basalt. Associated plutons are calc-alkaline in composition, ranging from monzonite to granodiorite. Felsic to intermediate hypabyssal granite to granodiorite porphyry dikes, sills, and plugs are also widely distributed and often intruded into northeast-striking extensional faults. Volumetrically minor Upper Cretaceous intermediate to mafic intrusive bodies are also common.

The center of the Kuskokwim basin lies between two continental-scale, dextral slip-fault zones: the Denali-Farewell Fault system to the south and the Iditarod-Nixon Fork Fault system to the north. Fold-and-thrust-style deformation formed the earliest structures in response to subduction-related compression shortly after deposition of the Kuskokwim sediments. Eastward-trending folds and thrust faults are common in the central Kuskokwim basin, including the Donlin Gold project area. Younger north-northeast-trending folds are dominant near the Iditarod-Nixon Fork Fault and Denali-Farewell Fault but also formed throughout the region in response to basin-scale dextral movement. Most of the folds predate emplacement of the volcano-plutonic complexes. Pre-, syn-, and post-(?) intrusion, northeast-striking normal and oblique slip faults formed during subsequent late compressional and extensional events and focused intrusive igneous rocks and hydrothermal systems across the basin.

A regional geological plan is included as Figure 7-1.# NOVAGOLD 

Figure 7-1: Regional Geology of Central Kuskokwim Area
![img-4.jpeg](img-4.jpeg)

Source: Figure courtesy Donlin Gold LLC, 2020

[[%~%]]
## 7.2 Project Geology

Because outcrop is limited and of generally poor quality, property-scale geology is largely interpreted from trenches, drill holes, aeromagnetic surveys, and soil geochemistry.

The Project area is underlain by a 5 mile ( 8.5 km ) long x 1.5 mile ( 2.5 km ) wide granitic porphyry dike and sill swarm hosted by lithic sandstone, siltstone, and shale of the Kuskokwim Group.

[[%~%]]
### 7.2.1 Lithologies

The oldest igneous rocks at the Property are intermediate to mafic dikes and sills. They are not abundant but occur widely throughout the Property as generally thin and discontinuous bodies. The younger and much more voluminous granite porphyry intrusive rocks vary from about a meter to 60 m wide and occur as west-northwest-trending sills in the southern resource area and north-northeast-trending dikes farther north. The granite porphyry dikes and sills all have similar mineralogy, and the porphyry texture indicates relatively shallow emplacement. Although these rocks belong to the regionally important granite porphyry igneous event,geologists working on the Property classify them into five textural varieties of rhyodacite. These units are chemically similar, temporally and spatially related, and probably reflect textural variations of related intrusive events.

Figure 7-2 illustrates the interpreted property-scale distribution of igneous rocks, including the mineral resource area between the Queen deposit area on the northeast and the airstrip on the southwest.

Figure 7-2: Interpreted Property-Scale Igneous Rocks
![img-5.jpeg](img-5.jpeg)

Note: RDA = Aphanitic Porphyry; RDX = Crowded Porphyry; RDXL = Lath-Rich Porphyry; and RDXB = Blue Porphyry. Figure courtesy Donlin Gold LLC, 2011

[[%~%]]
### 7.2.2 Structure

The Project is located in a structurally complex area about 15 miles ( 25 km ) southeast of the Iditarod-Nixon Fault (refer to Figure 7-1). Sedimentary bedding generally strikes northwest and dips $10^{\circ}$ to $50^{\circ}$ to the southwest. Overall, sedimentary structure in the northern resource area is monoclinal, while sedimentary rocks in the southern resource area display open eastward-trending folds. East-southeast-trending and plunging folds or monoclinal warps are the oldest recognized structures and are associated with north-vergent thrust faults. Thrust faults are generally southwest-dipping, parallel to the bedding plane, and account for imbrication of the sedimentary rocks and locally moderate to steep southwest and northeast dips. Younger, low-amplitude north-northeast-trending folds crop out in the airstrip exposures along American Creek and are recorded on historic trench geology maps. Lack of cleavage or other evidence of dynamic recrystallization suggests that folds and thrust faults formed at relatively shallow depths.

[[%~%]]
## 7.3 Deposit Setting

Within the ACMA-Lewis area, a northeast, elongated, roughly 1.5 km wide x 3 km long cluster of gold deposits has an aggregate vertical range that exceeds 945 m . The deposits are hosted primarily in igneous rocks, and are associated with an extensive Upper Cretaceous gold-arsenic-antimony-mercury hydrothermal system. Gold occurs primarily in sulphide and quartz-carbonate-sulphide vein networks in igneous rocks and, to a much lesser extent, in sedimentary rocks. Broad disseminated sulphide zones formed in igneous rocks where vein zones are closely spaced. Sub-microscopic gold, contained primarily in arsenopyrite and secondarily in pyrite and marcasite, is associated with illite-kaolinite-carbonate-graphitealtered host rocks.

[[%~%]]
## 7.4 Paragenesis

Fluid inclusion studies and field and drill hole observations define three distinct styles of gold mineralization that are locally telescoped and cross-cut one another. The earliest is a porphyrystyle stockwork vein system at the Dome prospect.

Dome is located within the same dike-and-sill swarm that hosts the ACMA-Lewis resource, but the Kuskokwim sedimentary rocks are thermally metamorphosed to a siliceous hornfels. Quartz veins have a $\mathrm{Au}-\mathrm{Ag}-\mathrm{Cu}-\mathrm{Zn}-\mathrm{Bi} \pm$ Te trace metal signature (Ebert et al., 2003c; Drexler, 2010) with up to $3 \%$ arsenopyrite-pyrite-chalcopyrite-pyrrhotite $\pm$ Fe-rich sphalerite and trace amounts of electrum, native bismuth, and bismuth tellurides and selenides. Veins cut both the hornfels and porphyry dikes.

ACMA-Lewis-style mineralization post-dates the Dome veins and consists of sparse Au-Ag-As$\mathrm{Sb}-\mathrm{Hg} \pm \mathrm{W}$ (Ebert et al., 2003c; Drexler, 2010), trace metal-bearing quartz-Fe-dolomite veins with $<3 \%$ auriferous arsenopyrite-pyrite $\pm$ stibnite $\pm$ late realgar, native arsenic, and graphite. Veins and related disseminated sulphide zones are primarily hosted in illite-carbonate-kaolinite-altered rhyodacite dikes and sills but also occur in Kuskokwim Group sedimentary rocks near igneous contacts.

Variations between Dome and ACMA-Lewis vein habits, vein mineralogy, wall rock alteration, geochemical signatures, stable isotope variations (Drexler, 2010), and fluid inclusion chemistry (Ebert et al., 2003c) indicate that hydrothermal fluids were sourced at depth northeast of the Dome prospect, precipitated the base metal assemblage at Dome from metals sequestered in the vapor phase, and then migrated southwestward to the more distal ACMA-Lewis environment, where gold-bearing minerals were precipitated due to mixing with meteoric waters and boiling.

The last event consists of gold-bearing quartz-stibnite veins up to 1 m thick with variable carbonate, pyrite, and arsenopyrite found mainly around the margins of Dome and partially overlapping ACMA-Lewis. Quartz-stibnite veins also contain anomalous $\mathrm{Au}-\mathrm{As}-\mathrm{Cu}-\mathrm{Zn}-\mathrm{Bi}$ and have fluid chemistry and temperatures intermediate between Dome and ACMA-Lewis (Ebert et al., 2003). In the opinion of Donlin Gold LLC geologists, these veins do not contain significant gold mineralization.

[[%~%]]
## 7.5 Deposit Geology

Most of the detailed trench, road cut, and outcrop maps have not yet been compiled into a geological "fact map" in the resource area. The surface geology illustration in Figure 7-3 is a projection of the 3D geological model of intrusive rock units and faults shown in a perspective view of an orthophoto-draped digital elevation model (DEM) image.

[[%~%]]
### 7.5.1 Sedimentary Rocks

Informal sedimentary stratigraphy in the immediate deposit area is shown in Table 7-1. The approximate thicknesses of each unit are from the southern, or ACMA, resource area.

The stratigraphy in the deposit area consists of basin margin clastic rocks (MacNeil, 2009) dominated by greywacke (lithic sandstone) units with complex transition zones of interbedded siltstone, shale, and greywacke. Marker beds are not yet recognized, so absolute stratigraphic breaks are difficult to identify. Greywacke is dominant in the northern part of the resource area (Lewis, Queen, Rochelieu, Akivik), whereas shale-siltstone-rich units are common in the southern part (South Lewis, ACMA).# NOVAGOLD 

Figure 7-3: Interpreted Surface Geology of Resource Area
![img-6.jpeg](img-6.jpeg)

Note: Oblique view looking northeastward showing igneous rock units, faults, drill holes, and Mineral Reserve (DC9) pit outline. Figure courtesy Donlin Gold, 2020

Table 7-1: Donlin Gold Project Stratigraphy

| Assigned Nomenclature | Principal Rock Type | Apparent Thickness <br> $(\mathrm{m})$ |
| :-- | :--: | :--: |
| Upper Greywacke | greywacke | $100+$ |
| Upper Siltstone | siltstone/shale | 50 |
| Main Greywacke | greywacke | 80 |
| Main Shale | shale/siltstone | up to 140 (with sills) |
| Basal Greywacke | greywacke | $200+$ |

Note: After Piekenbrock and Petsel (2003)

[[%~%]]
### 7.5.2 Igneous Rocks

The mafic igneous rocks and the five textural varieties of rhyodacite recognized in the Donlin deposits were also shown in Figure 7-3. Table 7-2 lists the intrusive rocks, also from oldest to youngest.Table 7-2: Donlin Gold Project Intrusive Rocks

| Name | Code | Age | Rock Types |
| :--: | :--: | :--: | :--: |
| Mafic <br> Dikes/Sills | MD | oldest | Intermediate to mafic dikes and sills; locally host high-grade gold; generally less than 3 m thick. In the transition area between Akivik and ACMA, mafic sills are extremely abundant within the Lower Greywacke, immediately below the Main Shale. |
| Fine- <br> Grained <br> Porphyry | RDF | - | Earliest rhyodacite intrusions recognized. Grey, typically fine-grained, felsic porphyries. RDF intrusives occur as two main northeast-striking, 5 to 10 m wide dikes in the Lewis zone and possible discontinuous bodies in early eastwardtrending compressional faults, e.g., the Lo Fault. |
| Crowded <br> Porphyry | RDX | - | Volumetrically the most significant intrusive phase. Grey, characterized by a uniformly crowded feldspar porphyry texture. Present as two 50 to 100 m wide dike zones in the eastern edge of the north to north-northeast mineralized trend of Lewis/South Lewis. RDX is also found as sills throughout ACMA near the basal part of the sill sequence. |
| Lath-Rich <br> Porphyry | RDXL | - | Characterized by sparse, elongate plagioclase laths; significant coarser-grained biotite. occurs as two important dikes in the Akivik area that strike south into the center of the ACMA deposit. In Akivik and ACMA, RDXL occurs as a significant sill immediately below the RDX sill. The RDXL sill continues to the west but pinches out to the east. RDXL dikes are also present within the main Lewis area RDX dike trend, but here they are volumetrically insignificant. |
| Aphanitic <br> Porphyry | RDA | - | Rhyodacite rock with a salt-and-pepper texture of fine biotite phenocrysts and variable quartz and potassium feldspar phenocrysts. Numerous (up to eight) RDA dikes strike south from the Vortex / Rochelieu (Lewis) area into the East ACMA/ACMA area. The dikes are typically found west of the Vortex Fault but are also present between the Lo and Vortex faults and below the Lo Fault. An extensive sill package of RDA lies immediately above the RDX sills in the ACMA area. In West ACMA, the RDA sills are buttressed against, and locally cross-cut, RDX sills. Another package of RDA sills is found south of the AC Fault, in the Aurora domain. |
| Blue <br> Porphyry | RDXB | youngest | Final intrusive event; coarsely porphyritic with large blocky feldspars set in a graphite- and sulphide-rich matrix. locally hosts important high-grade disseminated sulphide material in addition to gold-bearing veins. RDXB occurs as two major dikes, the Lewis Blue Porphyry dike and the Vortex Blue Porphyry dike. Extensive thin RDXB sills are found in the uppermost part of the sill sequence in the South Lewis and ACMA areas, and RDXB sills are present as both distinct sills and co-mingled with RDA in the core of ACMA and in the Aurora domain. |

Note: After Piekenbrock and Petsel (2003)

[[%~%]]
### 7.5.3 Structure

The morphology of intrusive rocks in the deposit is largely governed by the rheology of sedimentary rocks and pre-intrusion faults and folds. Faults in the geological model (from earliest to youngest) are the American Creek (AC) Fault, Lo and Rochelieu faults, Vortex Fault, and ACMA Fault. Figure 7-4 shows a plan view of the faulting in the deposit area, and cross-sections through the ACMA and Lewis areas, respectively in Figure 7-5 and Figure 7-6.

Figure 7-4: 100 m Bench Level Geology
![img-7.jpeg](img-7.jpeg)

Note: Oblique view looking north-eastward of the 3D geological model projected on the 100 m pit bench level and the Mineral Reserves (DC9) pit outline. Figure courtesy Donlin Gold LLC, 2020Figure 7-5: Lewis Area Section
![img-8.jpeg](img-8.jpeg)

Note: Shows intrusive rocks, faults, drill holes, and Mineral Reserves (DC9) pit outline, looking northeast. Figure courtesy Donlin Gold LLC, 2020 (displays new drill holes, 2017 and 2020 in red).

Figure 7-6: ACMA Area Section
![img-9.jpeg](img-9.jpeg)

Note: Shows intrusive rocks, faults, drill holes, and Mineral Reserves (DC9) pit, looking southeast. Figure courtesy Donlin Gold LLC, 2020

[[%~%]]
## 7.6 Deposits

The Donlin deposits include eleven mineralized areas that exhibit slightly different geological settings but generally fall into two geologically similar deposit areas: ACMA and Lewis. ACMA, or the intrusive sill and shale-siltstone sedimentary setting, includes the Aurora, 400, Akivik, ACMA, and East ACMA mineralized zones. Lewis, or the massive greywacke-hosted intrusive dike setting, includes the South Lewis, Lewis, Vortex, Rochelieu, Queen, and North Akivik mineralized zones.

Veins in north-northeast-striking, east- or west-dipping faults and fracture zones are the primary control on gold distribution and are ubiquitous in all mineralized areas. Northwest- and northeast-striking veins occur locally but are relatively rare. Veins are narrow (typically $<1 \mathrm{~cm}$ wide), highly irregular, discontinuous, and generally sparsely distributed, although vein density can locally range up to 2 to 8 per meter in higher-grade zones. Vein zones vary from 2 to 35 m wide and 100 to 350 m long. Individual vein zones generally display limited lateral and vertical continuity; however, swarms of many anastomosing vein zones form larger mineralized corridors characterized by extensive lateral and depth continuity.

Vein corridors are more apparent in the north-northeast-trending dikes of Lewis than in the west-northwest-trending ACMA sill zone. The greater width of the sill-hosted ACMA mineralized zone makes discreet corridors less obvious (but still present). Mineralized zones follow steeply dipping dikes and sills beyond the depth limits of current drilling, or over a vertical range of at least 945 m .

Veins are best developed in relatively more brittle intrusive rocks and massive greywacke. Small, irregular, carbonate-altered mafic bodies often host very high-grade gold as sulphide dissemination, replacement, and breccia fill. Structural breccias in sedimentary rocks are also favorable sites for high-grade gold. Gold distribution in the deposit closely mimics the intrusive rocks, which contain about $75 \%$ of the resource. Structural zones in competent sedimentary units account for the remaining $25 \%$. The more steeply dipping sills in the ACMA sill sequence host the highest-grade and most continuous igneous-hosted mineralized zones, particularly where intersected by northeast-striking "feeder" dikes and faults. Gold grade is directly proportional to vein density and intensity of overlapping disseminated sulphide vein aureoles. The dike-dominant Lewis deposit areas consist of sheeted veins with limited disseminated sulphide in the wall rocks and are characterized by lower-grade and less continuous mineralized zones.

Gold distribution in the planned pit area is shown in Figure 7-7, as a bench plan.Figure 7-7: 100 m Bench Level Gold Distribution ( $>1 \mathrm{~g} / \mathrm{t}$ Au grade blocks)
![img-10.jpeg](img-10.jpeg)

Note: Figure courtesy Donlin Gold LLC, 2020

[[%~%]]
## 7.7 Mineralization

Gold-bearing zones are coincident with quartz-carbonate-sulphide veins and related disseminated sulphide aureoles in hydrothermally altered rhyodacite bodies and, to a lesser extent, in sedimentary rock near igneous contacts. Continuity and grade of mineralized material within the rhyodacite host rocks varies directly with vein spacing and the amount of vein and disseminated arsenopyrite, the principal gold-bearing mineral. Gold in sedimentary rocks and minor mafic igneous bodies is generally limited to small and discontinuous vein and breccia fill occurrences.

[[%~%]]
### 7.7.1 Vein And Disseminated Mineralization

Veins in the ACMA-Lewis area are subtle in appearance and vary from $<1 \mathrm{~mm}$ to 20 cm wide, averaging $<1 \mathrm{~cm}$. They formed in brittle fractures and are typical of open-spaced fillings with vugs, drusy quartz-lined cavities, vein wall-banded and cockscomb quartz, and bladed carbonate. Veins are composed of gray to clear quartz, white to tan carbonate, and as much as $3 \%$ sulphides. Table 7-3 contains a summary of the gold-bearing vein stages.Table 7-3: Vein Stages

| Vein | Description |
| :--: | :--: |
| V1 | Thin, irregular, and discontinuous sulphide ( $>50 \%$ ) veins with pyrite and trace arsenopyrite, little or no quartz ( $<30 \%$ ) or carbonate ( $<50 \%$ ). Broad disseminated selvage of pyrite and poorly crystalline illite and Fe -carbonate alteration. Barren or very low grade |
| V2 | Thin, discontinuous quartz ( $>30 \%$ ) sulphide veins contain variable pyrite and arsenopyrite. May have broad, often pervasive selvages of fine-grained, needle-like arsenopyrite. Broad pyrite aureole may surround the arsenopyrite selvage. Open-space vuggy textures common. Trace amounts stibnite. Have moderate gold grade and strong illite alteration aureoles with variable Fe-carbonate replacement of the host rock. |
| V3a | Higher-grade veins. Thicker, more planar and continuous, open-space quartz veins with Fe-dolomite, pyrite, arsenopyrite, native arsenic, and variable amounts of stibnite. Commonly show broad arsenopyrite-rich selvages with little to no Fe-carbonate as wall rock alteration |
| V3b | Thicker, more continuous, and planar quartz veins with open-space textures and complex mineralogy, including pyrite, arsenopyrite, stibnite, native arsenic, realgar, and trace other sulphides in intensely illite altered material. Gold grades are commonly much higher than the average grade of the deposit |
| V4 | Latest vein phase. Barren carbonate-quartz ( $>50 \%$ and $<50 \%$, respectively) vein sets that post-date mineralized veins. Primarily barren white and clear quartz veinlets and calcite $\pm$ ankerite veinlets with no sulphides. |

Mineralized zones are consistently oriented sub-parallel to the main $\delta 1$ axis (024) of the compressive structural regime (Piekenbrock and Petsel, 2003). Veins in the ACMA-Lewis resource evolved through a continuum (V1 through V3) of changing mineralogy and increasing gold grade while maintaining a generally consistent NNE strike and SE dip. The final carbonatequartz vein set (V4) has a broader range of orientation.

MacNeil (2009) found that the average vein orientation for all veins is 024/71 degrees. This orientation is generally consistent across all domains and vein types, which indicates that veins in the Donlin deposits formed during the same mineralizing event.

A comparison by host rock shows that veins in igneous rocks strike more easterly and dip more steeply than veins in sedimentary rocks, probably due to refraction across lithologic contacts.

Several quartz and carbonate phases have been recognized, including pre-gold-stage Mncalcite veins and wall rock replacement and cockscomb quartz veins; Fe-dolomite in main gold stage veins; and post-gold-stage clear quartz veins and ankerite stringer veins.Euhedral and porous replacement pyrite are the earliest sulphide phases, followed in order by marcasite, arsenopyrite, realgar, and native arsenic. Stibnite is most abundant in later veins. Most accessory sulphides are relatively early, while boulangerite is relatively late. Arsenopyrite occurs as both coarse (up to 1 cm ) crystals and very fine ( 0.1 to 0.2 mm ) euhedral grains. Fine-grained arsenopyrite contains five to 10 times more gold than the paragenetically earlier coarse-grained phase.

[[%~%]]
## 7.8 Alteration

Rhyodacite bodies are ubiquitously altered to an illite-carbonate-kaolinite-chlorite / smectite $\pm$ quartz $\pm$ graphite assemblage.

Mafic igneous rocks are strongly altered by carbonate $\pm$ fuchsite and contain locally high-grade gold with disseminated, massive replacement or breccia filling sulphide.

Altered sedimentary rocks consist of relict quartz grains in a matrix of illite, kaolinite, carbonate, hematite, and $<1 \%$ pyrite and trace sphalerite (Drexler, 2010).

Pyrite is widespread in all altered rocks ( $0.5 \%$ to $2 \%$ ) but is more abundant ( $1 \%$ to $4 \%$ ) in mineralized zones. Alteration is most intense near veins and is typically zoned outward from illite $\pm$ kaolinite to kaolinite $\pm$ illite and then to a distal zone of chlorite $\pm$ smectite $\pm$ quartz.

Silica is dominantly restricted to veins in the ACMA-Lewis area and is not generally expressed as pervasive silicification. Vein relationships show an increase in quartz content from early sulphide-dominant veins to late silica-dominant veins. Some increased silicification has been noted in the Queen area (Ebert et al., 2003b).

Short-wave infrared reflectance (SWIR) spectroscopy data, collected between 2007 and 2011, are interpreted by Donlin Gold LLC geologists to show that higher-grade gold is most strongly correlated with an alteration suite dominated by NH4-illite (ammonia-illite), whereas kaolinitebearing zones contain lower-grade gold.

[[%~%]]
## 7.9 Minor Elements

The most abundant minor elements associated with gold-bearing material are iron (Fe), arsenic (As), antimony (Sb), and sulphur (S). These are contained primarily in the mineral suite associated with hydrothermal deposition of gold, including pyrite $\left(\mathrm{FeS}_{2}\right)$, arsenopyrite (FeAsS), realgar (AsS), native arsenic (As), and stibnite ( $\mathrm{Sb}_{2} \mathrm{~S}_{3}$ ). Minor hydrothermal pyrrhotite (Fe1-xS) and marcasite $\left(\mathrm{FeS}_{2}\right)$, and syngenetic or sedimentary pyrite, also account for some of the Fe and S.Much less abundant elements such as copper $(\mathrm{Cu})$, lead $(\mathrm{Pb})$, and zinc $(\mathrm{Zn})$ are contained in relatively rare or accessory hydrothermal mineral species observed in the deposit, including chalcopyrite $\left(\mathrm{CuFeS}_{2}\right)$, chalcocite $\left(\mathrm{Cu}_{2} \mathrm{~S}\right)$, covellite $(\mathrm{CuS})$, tennantite $\left(\mathrm{Cu}_{12} \mathrm{As}_{4} \mathrm{~S}_{13}\right)$, tetrahedrite $\left(\mathrm{Cu}_{12} \mathrm{Sb}_{4} \mathrm{~S}_{13}\right)$, bornite $\left(\mathrm{Cu}_{5} \mathrm{FeS}_{4}\right)$, native copper $(\mathrm{Cu})$, galena $(\mathrm{PbS})$, sphalerite $(\mathrm{ZnS})$, and boulangerite $\left(\mathrm{Pb}_{55} \mathrm{~b}_{4} \mathrm{~S}_{11}\right)$. Small amounts of silver $(\mathrm{Ag})$ in the deposit are most likely accommodated within the crystal structures of tetrahedrite and galena, and to a lesser extent in some of the other sulphides. Molybdenum (Mo) occurs in rare molybdenite $\left(\mathrm{MoS}_{2}\right)$. Very minor nickel $(\mathrm{Ni})$ has been observed in the secondary sulphide mineral millerite ( NiS ) and minor cobalt (Co) in various secondary minerals in sedimentary rocks. The Ni and Co probably have a sedimentary origin.

Three elements of particular processing significance are mercury $(\mathrm{Hg})$, chlorine $(\mathrm{Cl})$, and fluorine (F). Graphitic carbon and carbonate minerals also have the potential to negatively affect the metallurgical process.

[[%~%]]
## 7.10 Comments On Section 7

In the opinion of the Wood QP:

- Knowledge of the deposit settings, lithologies, and structural and alteration controls on mineralization is sufficient to support Mineral Resource and Mineral Reserve estimation.

[[@~@]]
# 8.0 Deposit Types

According to Donlin Gold LLC geologists, the Donlin deposits share characteristics of several gold deposit genetic models. It has been classified as:

- Granite porphyry-hosted gold polymetallic (Bundtzen and Miller, 1997)
- Distal or high-level epizonal intrusion-related (Hart et al., 2002)
- Low-sulphidation epithermal (Ebert et al., 2003a)
- Orogenic- or intrusion-related (Goldfarb et al., 2004)
- Reduced porphyry to sub-epithermal Au-As-Sb-Hg (Ebert et al., 2003c; Hart, 2007).

Hart (2007) classifies the deposit as a high-level, reduced intrusion-related vein system to account for the reduced ilmenite series intrusions, near contemporaneous age of mineralization, and the apparent genetic relationship to the higher-temperature hydrothermal system at Dome (Drexler, 2010).

The ACMA-Lewis part of the district is clearly a low sulphidation, reduced intrusion related, epizonal system with both vein and disseminated mineral zones and conforms most closely to the Hart (2007) classification.

[[%~%]]
## 8.1 Comments On Section 8

In the opinion of the Wood QP:

- Deposit models used in the exploration programs have been appropriate to the style and setting of the mineralization.

[[@~@]]
# 9.0 Exploration

A summary of the exploration programs completed on the Property is summarized in Table 6-1.

[[%~%]]
## 9.1 Grids And Surveys

The Property uses Universal Transverse Mercator (UTM) Zone 4 (metres). The map datum is NAD83.

The topographic surface is based on a 2004 survey by Aero-metric. The survey has an accuracy of $\pm 2 \mathrm{~m}$ within all key Project areas.

[[%~%]]
## 9.2 Geological Mapping

Geological mapping was performed in 1988-1989 (WestGold), and during 1996, 1998, reconnaissance mapping was undertaken by Placer Dome Inc. This was followed in 1999 by Placer Dome Inc. completing a 1:10,000 geological mapping program over the entire Project area.

Mapping is generally limited by the poor quality and limited extent of outcrop. Information from the mapping programs was used to support more detailed data obtained from trenches and core drilling.

[[%~%]]
## 9.3 Geochemical Sampling

During the period 1988 to 1989, WestGold also collected over 15,000 soil, rock chip and auger samples. WestGold, in 1989, tested biogeochemical sampling, which returned positive results. Teck collected two lines of soil samples in 1993.

Barrick, during 2007, collected 600 soil samples in the ACMA and 400 areas, and an additional 646 soil samples and 92 rock samples were collected in 2008. During 2008, Barrick took 1,097 soil, 101 stream sediment, and 66 stream-concentrate geochemical samples.

Sampling was used as part of regional prospectivity evaluations.

[[%~%]]
## 9.4 Geophysics

WestGold performed an airborne magnetic and VLF survey and ground magnetic surveys during 1998 to 1999. The company also trialed ground-penetrating radar.During 1999, Placer Dome Inc. completed 25 line km of max-min EM geophysical survey in the ACMA, 400 and southern Lewis areas, and 1,800 line km of aeromagnetic survey was completed at 50 m line spacing and 50 m elevation over the property. In the same year, a total of 17.7 km of IP and resistivity lines were completed, and an additional 41.6 km of IP / resistivity lines were run in 2000. During 2003, IP surveys were undertaken in areas where infrastructure was planned, as part of condemnation evaluations.

Geophysical studies were used to support structural interpretations for geological modelling purposes, exploration targeting, and facilities condemnation drilling.

[[%~%]]
## 9.5 Pits And Trenches

During 1988 and 1989, a total of $13,525 \mathrm{~m}$ of D9 bulldozer trenching was completed by WestGold at all prospects.

The 1996 Placer Dome Inc. exploration program included 2,500 m of trenches for sampling and mapping purposes in southeast Lewis area; this was followed in 1997 by 4,222 m of trenches in the Lewis area, in 1998 by 2,054 m of trenching and geological mapping in the Lewis-Vortex and ACMA areas, and in 1999 by 2,237 m of trenching and geologic mapping (Dome, Queen, Far Side, and Vortex).

Teck completed 1,400 m of D-9 bulldozer trenching during 2003.
Pits to provide geotechnical data were excavated in 2005 (22 test pits), 2006 (40 test pits), 2007 (55 test pits), 2008 (54 test pits), and 2019 (18 test pits).

In 2020, Donlin Gold LLC completed the first phase of the Eastern Lewis Hill Test Pit, located on top of Lewis Hill. The objective was to excavate a 30 m long trench and study geological characterization and collect samples to compare mineralized features in various rock types.

[[%~%]]
## 9.6 Petrology, Mineralogy, And Research Studies

During 1993, Teck completed petrographic and fluid inclusion studies in support of understanding of the mineralization setting and host rock lithologies.

[[%~%]]
## 9.7 Geotechnical And Hydrological Studies

Geotechnical and hydrological studies have been undertaken in support of mine planning, mine design and environmental considerations.

[[%~%]]
## 9.8 Metallurgical Studies

Metallurgical testwork is primarily based on drill core. Please refer to Section 13 of the report.

[[%~%]]
## 9.9 Exploration Potential

Exploration potential in the vicinity of the Project open pit designs include extensions along strike to the East ACMA, Lewis, and Crooked Creek dike areas. Mineralization remains open at depth under the current pit limits. Mineralization also remains open to the north of the planned pit and has been tested by shallow trenching and soil sampling, with limited drilling undertaken to date.

The Property also retains exploration potential outside the areas that have been the subject of the Project mine design. Gold mineralization is associated with an overall north-northeasterlytrending high level dike / sill complex that has been outlined in the regional aero-magnetics as a subtle 50 nT magnetic low (Figure 9-1). The zone, approximately 8 km long, and 4 km wide, consists of a northern, dike-dominated area, and a southern, more sill-dominated area (refer to Figure 9-1 and Figure 4-1).

Figure 9-2 shows a gold-in-soils compilation plan of the area indicated by the magnetic low. The ACMA-Lewis area is the southern portion of this plan. No drilling has been performed in the northern portion since initial exploration activities, and some isolated drilling in the 1990s. Exploration targets identified by Donlin Gold LLC for additional work includes Far Side, Duqum, Snow, Quartz, Queen, Dome, and Ophir (refer to Figure 4-1). The following summaries of the exploration potential identified by Donlin Gold LLC are sourced from Buchanan (2009), Chamois (2009) and Francis (2011).

[[%~%]]
### 9.9.1 Far Side

The Far Side prospect has been tested by three Donlin Gold LLC core drill holes ( 735 m ) along 300 m of strike and 29 RC holes that were drilled by WestGold. Drill results for the core drilling are indicated in Table 10-3. The prospect is situated in an area where dikes of a generally easterly trend intersect the more dominant northeasterly trend.# NOVAGOLD 

Figure 9-1: Regional Magnetic Image Showing Magnetic Low Intensity Zone
![img-11.jpeg](img-11.jpeg)

Note: Figure courtesy Donlin Gold LLC, 2020# NOVAGOLD 

Figure 9-2: Gold-in-Soils Compilation Plan
![img-12.jpeg](img-12.jpeg)

Note: Figure courtesy Donlin Gold LLC, 2020

[[%~%]]
### 9.9.2 Duqum

The Duqum prospect is the site of the first recorded lode gold discovery in the Donlin deposit area. It is about 1 km long, and mineralization is associated with a narrow porphyry dike. Three core holes have been drilled ( $1,043 \mathrm{~m}$ ) by Donlin Gold LLC. Drill results are summarized in Table 10-4.

[[%~%]]
### 9.9.3 Snow / Quartz

The Snow and Quartz prospects are hosted in a dike-related, gold-bearing corridor that is about 1.5 km wide and approximately 4 km long. In the area of this dike swarm, the porphyry dikes# NOVAGOLD 

are 20 m to $>100 \mathrm{~m}$ wide, discontinuous bodies. Gold mineralization is associated closely with the dikes, and is hosted either within the dikes themselves or in the adjacent sedimentary rocks. Limited drilling has been completed. Better drill results are included in Table 10-5.

[[%~%]]
### 9.9.4 Dome

The Dome prospect is situated under a prominent, rounded hill about 5 km north of the planned ACMA-Lewis pits. Several mineralized felsic porphyries intrude into a greywacke unit and have hornfelsed the sedimentary rocks over wide intervals. Mineralization consists of stockworks of veinlets containing arsenopyrite, pyrite, pyrrhotite, and minor chalcopyrite. Preliminary metallurgical testwork indicates that mineralization may be less refractory than that encountered in the ACMA-Lewis area.

Fourteen widely-spaced drill holes have been completed over an area of approximately 500 m $\times 500 \mathrm{~m}$. Mineralization is open to the north, east, south and to depth, and may be open to the west at depth. Better drill results are included in Table 10-6.

[[%~%]]
### 9.9.5 Ophir

The Ophir Hill is the highest topographic feature in the Donlin district. Surface mapping over an area of about $1.5 \mathrm{~km} \times 750 \mathrm{~m}$ indicates Cretaceous sedimentary rocks have been intruded by felsic to intermediate intrusions, which may be dikes. Surface exposures are completely oxidized, but boxworks after sulphides indicate arsenopyrite, pyrite and other sulphides occur as disseminations and thin veinlets. Soil sampling has identified a strong gold-in-soil anomaly on the southwestern flanks of the hill. No drilling has been undertaken.

[[%~%]]
## 9.10 Comments On Section 9

In the opinion of the Wood QP:

- The exploration programs completed to date are appropriate to the style of the Donlin deposits and prospects within the Property.
- Additional exploration potential remains within the Property.

[[@~@]]
# 10.0 Drilling

Approximately 1,678 exploration and development drill holes totaling $367,886 \mathrm{~m}$, were completed from 1988 through 2007 in at least six separately managed campaigns (Table 10-1). Another 108 core holes totalling $33,425 \mathrm{~m}$ were added in 2008 to explore near-pit expansions and satellite deposits, and for facility-related condemnation and geotechnical studies. In 2010, six core holes totalling $2,090 \mathrm{~m}$ were drilled for additional pit slope geotechnical drilling. In 2017, sixteen core holes totalling $7,040 \mathrm{~m}$ were drilled, and in 2020, eighty-five core holes totalling $23,361 \mathrm{~m}$ were drilled.

A total of 1,396 core ( $89 \%$ ) and reverse circulation (RC) (11\%) holes totaling 339,733 m, as well as 282 trenches totalling $21,441 \mathrm{~m}$, were used for the resource model (DC9). Results from the 2017 and 2020 drilling were compared to the DC9 resource model as part of the Wood QP validation checks performed.

Drill summaries for the RC and core drill programs are included in Table 10-1. Drill location plans are provided in Figure 10-1 for the Property, and in Figure 10-2 for the area where Mineral Resources and Mineral Reserves were estimated.

[[%~%]]
## 10.1 Drill Methods

Core sizes used on the Property include: NQ3 ( 45.1 mm core diameter), NQ ( 47.6 mm ), HQ3 $(61.2 \mathrm{~mm}), \mathrm{HQ}(63.5 \mathrm{~mm})$, and $\mathrm{PQ}(85 \mathrm{~mm})$. Systematic records of core size were not maintained in the database; therefore, an accurate account of HQ and NQ core cannot be easily determined. It can be stated that most of the core drilled since 1995 was HQ size, since all holes were started with HQ tools and reduced to the smaller diameter NQ size as necessary. The relative amount of NQ size core likely increased in recent campaigns as drilling probed deeper in the deposit.

Depth limits for HQ size holes were 475 m for dry conditions and 545 m for fluid-filled holes. HQ depth was generally limited to 426 m for holes with no planned reduction.Table 10-1: RC and Core Drill Summary Table

| Year | Company | No. of Drill Holes | Hole <br> Type | Amount Drilled | Comment |
| :--: | :--: | :--: | :--: | :--: | :--: |
| 1988 | WestGold | 33 | Core | unknown | Shallow (average 25 m ), AX-diameter. Not used in the resource database |
|  |  | 50 | Auger | unknown | Shallow (average 8 m ). Not used in the resource database |
| 1989 | WestGold | 125 | RC | unknown | 31 holes in Far Side, 38 in Snow, 24 in Queen, 8 in Rochelieu, and 24 in Lewis. Not used in the resource database |
| 1995 | Placer Dome Inc | 32 | core |  | 30 in Lewis, 1 at Rochelieu Ridge, and 1 near the mouth of Queen Gulch |
| 1996 | Placer Dome Inc. | 28 | RC |  | Seventeen of the holes twinned earlier core holes. Four water wells (3 in camp, 1 in Lewis) were drilled with the RC drill, and 5 core holes in the 400 area were pre-collared through deep overburden. |
|  |  | 116 | core |  | All but 8 of the core holes were drilled in Lewis or Queen. The others were distributed north of the current resource area in the Dome, Far Side, and Snow prospects. |
| 1997 | Placer Dome Inc | 52 | RC |  | Lewis, Queen, Rochelieu, ACMA, 400 Area, Vortex, alongside the American Ridge runway, and Snow. Includes two water wells. |
|  |  | 66 | core |  | Lewis, Queen, 400 Area, ACMA, and north of the resource area at Quartz, Duqum, and Dome |
| 1998 | Placer Dome Inc. | 96 | core |  | The drilling was done in two phases: four holes in the ACMA-400 area in March and April, and 41 closely spaced holes in the Lewis area in June to October to test variography. Resource expansion drilling in the Lewis, Queen, and ACMA areas was also conducted from June to October. |
| 1999 | Placer Dome Inc. | 33 | core |  | Twenty-six of these, totaling $21,949 \mathrm{ft}(6,690 \mathrm{~m})$, were resource definition holes drilled in ACMA-400 |
| 2000 | Placer Dome Inc. | 7 | core |  | 5 at Dome and 2 at Quartz, for an evaluation of IP anomalies and potential for high-grade deposits |
| 2001 | Placer Dome Inc. | 42 | core |  | Evaluation of the potential for significant resource growth in the ACMA area || Year | Company | No. of Drill Holes | Hole <br> Type | Amount Drilled | Comment |
| :--: | :--: | :--: | :--: | :--: | :--: |
| 2002 | NOVAGOLD | 146 | RC | $11,589 \mathrm{~m}$ | 141 exploration and resource expansion holes in the ACMA, 400, Lewis, Akivik, Rochelieu, Vortex, and Far East prospects. Three water wells were drilled near the mouth of American Creek, and two were drilled in the Low Road on the south face of Lewis |
|  |  | 196 | core | $39,092 \mathrm{~m}$ | Two of the core holes are geotechnical holes in the Anaconda Creek valley. |
| 2003 | Placer Dome Inc. | 16 | RC |  | Water monitoring wells |
| 2004 | Placer Dome Inc. | 17 | RC | $2,335 \mathrm{~m}$ | Condemnation holes in the Anaconda Creek and upper American Creek valleys |
|  |  | 3 | core |  | Geotechnical core holes |
| 2005 | Placer Dome Inc. | 30 | RC | $3,644 \mathrm{~m}$ | - |
|  |  | 90 | core | $24,596 \mathrm{~m}$ | Infill in ACMA and Lewis |
| 2006 | DCJV | 327 | core | $92,804 \mathrm{~m}$ | Pit slope stability, metallurgy, waste rock studies, facilities condemnation, and engineering, and calcium carbonate resource bulk sampling, delineation, and exploration |
| 2007 | DCJV | 13 | RC | $1,043 \mathrm{~m}$ | Monitor wells and pit pump tests |
|  |  | 248 | core | $75,257 \mathrm{~m}$ | Pit resource infill, pit expansion, carbonate exploration, geotechnical, and engineering studies |
| 2008 | DCLLC | 108 | core | $33,425 \mathrm{~m}$ | Exploration, resource infill, condemnation, and geotechnical studies |
| 2009 | DCLLC | 19 | core | 950 m | Geotechnical and hydrological core holes |
| 2010 | DCLLC | 6 | core | $2,090 \mathrm{~m}$ | Geotechnical core holes |
| 2017 | DGLLC | 16 | core | 7040 m | Infill, geotechnical and geometallurgy tests. Used to validate the DC9 resource model, but not included in the DC9 resource model database (post-DC9). |
| 2019 | DGLLC | 30 | core | $1,060 \mathrm{~m}$ | Geotechnical core holes in planned tailings storage facility (TSF) and other planned water retention facilities in support of engineering and permitting of those facilities. |
| 2020 | DGLLC | 85 | core | $23,361 \mathrm{~m}$ | Infill to confirm recent geologic modeling concepts and test potential high-grade extensions. Not included in the DC9 resource model database (post-DC9). |# NOVAGOLD 

Figure 10-1: Property Drill Hole Location Plan
![img-13.jpeg](img-13.jpeg)

Note: Figure courtesy Donlin Gold LLC,2020

[[%~%]]
## 10.2 Geological Logging

Standard logging conventions were developed by Placer Dome Inc., and refined over the durations of the drilling programs.

Standard logging and sampling conventions were used to capture information from the drill core and, where applicable, RC chips. Types of data captured in separate tables including lithology, mineralization, alteration (visual), structural and geotechnical. Remarks by thelogging geologist were also recorded. Lithology was recorded in a two to four letter alpha code. The mineralization table recorded visual percent veining (by type) and sulphide (pyrite, arsenopyrite, stibnite and realgar). Specific alteration features including FeOx and carbonate alteration were also recorded using a qualitative scale. Structural data collected consisted of the type of structure, measurements relative to core axis and oriented core measurements, if applicable. The geotechnical table recorded percent recovery and RQD for the entire hole, and fracture intensity where warranted.

[[%~%]]
## 10.3 Recovery

A survey of nearly 200,000 core recovery records in the database revealed an overall lengthweighted average core recovery of $95 \%$. Average recovery increases from 80 to $95 \%$ from 0 to 40 m and then ranges from 95 to $100 \%$ below 40 m where overburden and surface weathering effects are generally absent.

[[%~%]]
## 10.4 Collar Surveys

Traditional survey methods were used to locate all 1995 to 1999 and 2001 drill collars and trenches. Modern GPS technology involving a base unit and up to two roving units was introduced in 2002. The roving instruments were operated in the field to collect stationary readings over the drill collars.

Based on surveys of control points, the approximate maximum horizontal and vertical variances of drill hole collar surveys under optimal conditions were considered to be 0.2 and 0.6 m , respectively.

In 2017, surveyors utilized Global Navigation Satellite System (GNSS) receivers and Real Time Kinematic (RTK) measurements. All drill holes, except DC17-1831, were surveyed with a horizontal and vertical accuracy within 8 cm .

In 2020, data were collected using GPS dual frequency receivers using RTK GPS methodology. No positions differed by more than 2 cm , horizontally or vertically.

[[%~%]]
## 10.5 Down-Hole Surveys

The Sperry Sun single-shot camera method was used through 2000 for directional surveys to determine down-hole deviation. Reflex EZ Shot instrumentation was introduced in 2001 and used until 2017. In 2020, the Boart Longyear TruShot tool was used.# NOVAGOLD 

Geotechnical and infill drilling programs include interviewer surveys in 2017 and 2020.

[[%~%]]
## 10.6 Geotechnical And Hydrological Drilling

Geotechnical and hydrological drilling is included in the drill totals in Table 10-1, and are included in the drill location plan in Figure 10-2.

[[%~%]]
## 10.7 Metallurgical Drilling

Specific drill holes were completed for metallurgical testwork. These holes, although not broken out by collar, are included in the drill location plan in Figure 10-2.

[[%~%]]
## 10.8 Condemnation Drilling

Condemnation drilling was performed to identify potential infrastructure sites.

Locations of the condemnation drill holes are included in Figure 10-2.

[[%~%]]
## 10.9 Twin Drilling

Core and RC holes were compared in 1996 when 17 core holes in the Lewis area were twinned with RC holes. This study found that, in most instances, composite assay intervals from the RC holes were thinner, less continuous, and lower in grade than in the twinned core holes (Szumigala, 1997).

[[%~%]]
## 10.10 Summary Of Drill Intercepts

A summary of a number of drill hole intercepts from each key area is shown in Table 10-2. Examples of the drill hole geometry, and drill hole intercepts are shown in Figure 10-3 and Figure 10-4 (ACMA) and Figure 10-5 and Figure 10-6 (Lewis), and demonstrate that the drilling was designed to intersect the mineralization as perpendicular as possible.

A summary of a number of drill hole intercepts from the areas that show exploration potential are shown in Table 10-3 to Table 10-6.# NOVAGOLD 

Figure 10-2: Resource Area Drill Holes
![img-14.jpeg](img-14.jpeg)

Note: Figure courtesy Donlin Gold LLC, 2020Table 10-2: Drill Hole Intercept Summary Table

| Hole ID | Northing | Easting | Elevation | Azimuth | Dip | Area | Drill Intercept <br> From <br> (m) | Drill Intercept <br> To <br> (m) | Drilled <br> Thickness <br> (m) | Gold Grade (g/t Au) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| DC06-1114 | 6878385.36 | 539899.82 | 127.97 | 294.85 | $-65.4$ | ACMA | 178.00 | 218.19 | 40.19 | 4.14 |
| DC06-1114 | 6878385.36 | 539899.82 | 127.97 | 294.85 | $-65.4$ | ACMA | 234.00 | 304.68 | 70.68 | 4.10 |
| DC06-1114 | 6878385.36 | 539899.82 | 127.97 | 294.85 | $-65.4$ | ACMA | 310.28 | 316.51 | 6.23 | 3.79 |
|  |  |  |  |  |  |  |  | Total / Average | 117.10 | 4.10 |
| DC06-1115 | 6878270 | 540117 | 133 | 288.55 | $-58.2$ | ACMA | 194.00 | 198.00 | 4.00 | 1.37 |
| DC06-1115 | 6878270 | 540117 | 133 | 288.55 | $-58.2$ | ACMA | 232.00 | 242.00 | 10.00 | 4.58 |
| DC06-1115 | 6878270 | 540117 | 133 | 288.55 | $-58.2$ | ACMA | 248.00 | 252.98 | 4.98 | 19.37 |
| DC06-1115 | 6878270 | 540117 | 133 | 288.55 | $-58.2$ | ACMA | 261.00 | 280.29 | 19.29 | 5.64 |
| DC06-1115 | 6878270 | 540117 | 133 | 288.55 | $-58.2$ | ACMA | 286.00 | 304.00 | 18.00 | 2.19 |
| DC06-1115 | 6878270 | 540117 | 133 | 288.55 | $-58.2$ | ACMA | 310.00 | 332.94 | 22.94 | 3.49 |
| DC06-1115 | 6878270 | 540117 | 133 | 288.55 | $-58.2$ | ACMA | 343.05 | 368.00 | 24.95 | 5.87 |
|  |  |  |  |  |  |  |  | Total / Average | 104.16 | 5.01 |
| DC06-1120 | 6878411.6 | 539846.32 | 127.22 | 295.85 | $-61.2$ | W. ACMA | 145.00 | 160.00 | 15.00 | 2.48 |
| DC06-1120 | 6878411.6 | 539846.32 | 127.22 | 295.85 | $-61.2$ | W. ACMA | 175.00 | 205.00 | 30.00 | 1.11 |
| DC06-1120 | 6878411.6 | 539846.32 | 127.22 | 295.85 | $-61.2$ | W. ACMA | 235.50 | 271.46 | 35.96 | 2.89 |
|  |  |  |  |  |  |  |  | Total / Average | 80.96 | 2.15 |
| DC06-1126 | 6878684.93 | 539605.65 | 123.7 | 299.05 | $-60.3$ | W. ACMA | 189.04 | 204.50 | 15.46 | 2.56 |
| DC06-1126 | 6878684.93 | 539605.65 | 123.7 | 299.05 | $-60.3$ | W. ACMA | 222.00 | 229.30 | 7.30 | 4.21 |
| DC06-1126 | 6878684.93 | 539605.65 | 123.7 | 299.05 | $-60.3$ | W. ACMA | 259.90 | 264.00 | 4.10 | 1.21 |
| DC06-1126 | 6878684.93 | 539605.65 | 123.7 | 299.05 | $-60.3$ | W. ACMA | 303.00 | 309.00 | 6.00 | 2.32 |
| DC06-1126 | 6878684.93 | 539605.65 | 123.7 | 299.05 | $-60.3$ | W. ACMA | 317.00 | 335.00 | 18.00 | 5.37 || Hole ID | Northing | Easting | Elevation | Azimuth | Dip | Area | Drill Intercept From (m) | Drill Intercept <br> To <br> (m) | Drilled <br> Thickness <br> (m) | Gold Grade (g/t Au) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| DC06-1126 | 6878684.93 | 539605.65 | 123.7 | 299.05 | $-60.3$ | W. ACMA | 345.00 | 365.00 | 20.00 | 3.27 |
| DC06-1126 | 6878684.93 | 539605.65 | 123.7 | 299.05 | $-60.3$ | W. ACMA | 374.00 | 382.00 | 8.00 | 2.40 |
|  |  |  |  |  |  |  |  | Total / Average | 78.86 | 3.43 |
| DC06-1134 | 6879104.23 | 539709.27 | 149.47 | 297.35 | $-61.3$ | Akivik | 17.00 | 27.00 | 10.00 | 1.64 |
| DC06-1134 | 6879104.23 | 539709.27 | 149.47 | 297.35 | $-61.3$ | Akivik | 35.00 | 43.00 | 8.00 | 4.22 |
| DC06-1134 | 6879104.23 | 539709.27 | 149.47 | 297.35 | $-61.3$ | Akivik | 187.00 | 201.00 | 14.00 | 5.54 |
|  |  |  |  |  |  |  |  | Total / Average | 32.00 | 3.99 |
| DC06-1136 | 6879210 | 539771.1 | 150.99 | 297.55 | $-59$ | Akivik | 33.00 | 47.00 | 14.00 | 2.90 |
| DC06-1136 | 6879210 | 539771.1 | 150.99 | 297.55 | $-59$ | Akivik | 61.00 | 69.00 | 8.00 | 2.79 |
|  |  |  |  |  |  |  |  | Total | 22.00 | 2.86 |
| DC06-1138 | 6878826.27 | 539729.18 | 136.51 | 298.35 | $-61.6$ | Aurora | 13.00 | 40.00 | 27.00 | 2.07 |
| DC06-1138 | 6878826.27 | 539729.18 | 136.51 | 298.35 | $-61.6$ | Aurora | 54.63 | 68.00 | 13.37 | 2.70 |
| DC06-1138 | 6878826.27 | 539729.18 | 136.51 | 298.35 | $-61.6$ | Aurora | 104.23 | 117.00 | 12.77 | 1.51 |
| DC06-1138 | 6878826.27 | 539729.18 | 136.51 | 298.35 | $-61.6$ | Aurora | 285.50 | 288.00 | 2.50 | 12.40 |
| DC06-1138 | 6878826.27 | 539729.18 | 136.51 | 298.35 | $-61.6$ | Aurora | 306.00 | 316.00 | 10.00 | 4.05 |
| DC06-1138 | 6878826.27 | 539729.18 | 136.51 | 298.35 | $-61.6$ | Aurora | 405.00 | 409.00 | 4.00 | 4.54 |
| DC06-1138 | 6878826.27 | 539729.18 | 136.51 | 298.35 | $-61.6$ | Aurora | 460.00 | 474.00 | 14.00 | 3.88 |
| DC06-1138 | 6878826.27 | 539729.18 | 136.51 | 298.35 | $-61.6$ | Aurora | 494.00 | 506.00 | 12.00 | 2.19 |
| DC06-1138 | 6878826.27 | 539729.18 | 136.51 | 298.35 | $-61.6$ | Aurora | 526.00 | 530.00 | 4.00 | 3.25 |
|  |  |  |  |  |  |  |  | Total / Average | 99.64 | 2.96 |
| DC06-1245 | 6878553.04 | 540311.42 | 170.41 | 301.65 | $-58.7$ | E. ACMA | 5.33 | 23.00 | 17.67 | 1.62 |
| DC06-1245 | 6878553.04 | 540311.42 | 170.41 | 301.65 | $-58.7$ | E. ACMA | 42.00 | 62.00 | 20.00 | 1.84 || Hole ID | Northing | Easting | Elevation | Azimuth | Dip | Area | Drill Intercept <br> From <br> (m) | Drill Intercept <br> To <br> (m) | Drilled <br> Thickness <br> (m) | Gold Grade (g/t Au) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| DC06-1245 | 6878553.04 | 540311.42 | 170.41 | 301.65 | $-58.7$ | E. ACMA | 94.00 | 106.00 | 12.00 | 5.53 |
| DC06-1245 | 6878553.04 | 540311.42 | 170.41 | 301.65 | $-58.7$ | E. ACMA | 112.00 | 126.00 | 14.00 | 2.33 |
| DC06-1245 | 6878553.04 | 540311.42 | 170.41 | 301.65 | $-58.7$ | E. ACMA | 128.00 | 148.97 | 20.97 | 2.85 |
| DC06-1245 | 6878553.04 | 540311.42 | 170.41 | 301.65 | $-58.7$ | E. ACMA | 166.00 | 178.00 | 12.00 | 1.21 |
| DC06-1245 | 6878553.04 | 540311.42 | 170.41 | 301.65 | $-58.7$ | E. ACMA | 187.00 | 193.65 | 6.65 | 2.33 |
| DC06-1245 | 6878553.04 | 540311.42 | 170.41 | 301.65 | $-58.7$ | E. ACMA | 210.00 | 245.50 | 35.50 | 8.35 |
| DC06-1245 | 6878553.04 | 540311.42 | 170.41 | 301.65 | $-58.7$ | E. ACMA | 254.00 | 276.00 | 22.00 | 1.89 |
|  |  |  |  |  |  |  |  | Total / Average | 160.79 | 3.68 |
| DC06-1252 | 6878663.18 | 541745.81 | 302.68 | 303.35 | $-59.6$ | Lewis | 45.21 | 53.21 | 8.00 | 3.98 |
| DC06-1252 | 6878663.18 | 541745.81 | 302.68 | 303.35 | $-59.6$ | Lewis | 104.49 | 108.49 | 4.00 | 1.78 |
| DC06-1252 | 6878663.18 | 541745.81 | 302.68 | 303.35 | $-59.6$ | Lewis | 209.10 | 215.10 | 6.00 | 3.07 |
| DC06-1252 | 6878663.18 | 541745.81 | 302.68 | 303.35 | $-59.6$ | Lewis | 240.90 | 259.00 | 18.10 | 2.56 |
| DC06-1252 | 6878663.18 | 541745.81 | 302.68 | 303.35 | $-59.6$ | Lewis | 265.00 | 281.00 | 16.00 | 4.80 |
| DC06-1252 | 6878663.18 | 541745.81 | 302.68 | 303.35 | $-59.6$ | Lewis | 297.00 | 309.00 | 12.00 | 2.73 |
|  |  |  |  |  |  |  |  | Total / Average | 64.10 | 3.39 |
| DC06-1253 | 6879030.63 | 541736.09 | 400.88 | 300.35 | $-58.9$ | Lewis | 9.00 | 14.33 | 5.33 | 3.00 |
| DC06-1253 | 6879030.63 | 541736.09 | 400.88 | 300.35 | $-58.9$ | Lewis | 26.00 | 32.50 | 6.50 | 1.84 |
| DC06-1253 | 6879030.63 | 541736.09 | 400.88 | 300.35 | $-58.9$ | Lewis | 39.69 | 42.50 | 2.81 | 3.39 |
| DC06-1253 | 6879030.63 | 541736.09 | 400.88 | 300.35 | $-58.9$ | Lewis | 74.50 | 85.70 | 11.20 | 1.17 |
| DC06-1253 | 6879030.63 | 541736.09 | 400.88 | 300.35 | $-58.9$ | Lewis | 90.00 | 120.00 | 30.00 | 1.60 |
| DC06-1253 | 6879030.63 | 541736.09 | 400.88 | 300.35 | $-58.9$ | Lewis | 293.00 | 305.00 | 12.00 | 1.26 |
| DC06-1253 | 6879030.63 | 541736.09 | 400.88 | 300.35 | $-58.9$ | Lewis | 311.00 | 340.50 | 29.50 | 3.29 || Hole ID | Northing | Easting | Elevation | Azimuth | Dip | Area | Drill Intercept From (m) | Drill Intercept <br> To <br> (m) | Drilled Thickness (m) | Gold Grade (g/t Au) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| DC06-1253 | 6879030.63 | 541736.09 | 400.88 | 300.35 | $-58.9$ | Lewis | 349.00 | 363.00 | 14.00 | 1.21 |
|  |  |  |  |  |  |  |  | Total / Average | 111.34 | 2.05 |
| DC06-1183 | 6879518.7 | 541253.71 | 240.06 | 299.65 | $-61.8$ | Rochelieu | 42.00 | 51.00 | 9.00 | 2.22 |
| DC06-1183 | 6879518.7 | 541253.71 | 240.06 | 299.65 | $-61.8$ | Rochelieu | 60.00 | 63.00 | 3.00 | 2.01 |
| DC06-1183 | 6879518.7 | 541253.71 | 240.06 | 299.65 | $-61.8$ | Rochelieu | 96.00 | 102.00 | 6.00 | 6.72 |
| DC06-1183 | 6879518.7 | 541253.71 | 240.06 | 299.65 | $-61.8$ | Rochelieu | 110.00 | 116.00 | 6.00 | 3.64 |
|  |  |  |  |  |  |  |  | Total / Average | 24.00 | 3.67 |
| DC06-1185 | 6879443.2 | 541416.5 | 288.87 | 295.35 | $-61.9$ | Rochelieu | 29.80 | 55.93 | 26.13 | 3.61 |
| DC06-1185 | 6879443.2 | 541416.5 | 288.87 | 295.35 | $-61.9$ | Rochelieu | 63.84 | 78.00 | 14.16 | 1.85 |
| DC06-1185 | 6879443.2 | 541416.5 | 288.87 | 295.35 | $-61.9$ | Rochelieu | 196.00 | 204.77 | 8.77 | 6.66 |
| DC06-1185 | 6879443.2 | 541416.5 | 288.87 | 295.35 | $-61.9$ | Rochelieu | 237.00 | 251.00 | 14.00 | 6.25 |
| DC06-1185 | 6879443.2 | 541416.5 | 288.87 | 295.35 | $-61.9$ | Rochelieu | 283.00 | 289.00 | 6.00 | 1.82 |
|  |  |  |  |  |  |  |  | Total / Average | 69.06 | 4.02 |
| DC06-1267 | 6879724.6 | 542229.44 | 374.72 | 299.05 | $-59.4$ | Queen | 131.67 | 135.09 | 3.42 | 1.54 |
| DC06-1267 | 6879724.6 | 542229.44 | 374.72 | 299.05 | $-59.4$ | Queen | 190.00 | 206.00 | 16.00 | 2.41 |
| DC06-1267 | 6879724.6 | 542229.44 | 374.72 | 299.05 | $-59.4$ | Queen | 212.00 | 216.00 | 4.00 | 4.27 |
| DC06-1267 | 6879724.6 | 542229.44 | 374.72 | 299.05 | $-59.4$ | Queen | 242.00 | 248.00 | 6.00 | 1.46 |
| DC06-1267 | 6879724.6 | 542229.44 | 374.72 | 299.05 | $-59.4$ | Queen | 266.00 | 272.00 | 6.00 | 2.27 |
| DC06-1267 | 6879724.6 | 542229.44 | 374.72 | 299.05 | $-59.4$ | Queen | 316.43 | 332.80 | 16.37 | 2.10 |
| DC06-1267 | 6879724.6 | 542229.44 | 374.72 | 299.05 | $-59.4$ | Queen | 362.00 | 377.04 | 15.04 | 1.47 |
|  |  |  |  |  |  |  |  | Total / Average | 66.83 | 2.09 |
| DC06-1268 | 6879663.53 | 542219.04 | 356.56 | 293.95 | $-58.2$ | Queen | 159.55 | 165.00 | 5.45 | 2.08 || Hole ID | Northing | Easting | Elevation | Azimuth | Dip | Area | Drill Intercept <br> From <br> (m) | Drill Intercept <br> To <br> (m) | Drilled <br> Thickness <br> (m) | Gold Grade <br> (g/t Au) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| DC06-1268 | 6879663.53 | 542219.04 | 356.56 | 293.95 | $-58.2$ | Queen | 234.00 | 243.00 | 9.00 | 8.06 |
| DC06-1268 | 6879663.53 | 542219.04 | 356.56 | 293.95 | $-58.2$ | Queen | 254.00 | 257.00 | 3.00 | 2.43 |
| DC06-1268 | 6879663.53 | 542219.04 | 356.56 | 293.95 | $-58.2$ | Queen | 288.00 | 292.34 | 4.34 | 2.54 |
|  |  |  |  |  |  |  |  | Total / Average | 21.79 | 4.69 |

Note: Northings, eastings and elevations are at the collar locations. Drilled thicknesses do not represent true thickness. Example drill sections in Figures 10-3 through 10-6 illustrate variable angles of drill holes to mineralized dikes and interpreted grade shells.Figure 10-3: Example Drill Cross-Section ACMA
![img-15.jpeg](img-15.jpeg)

Note: 2017 and 2020 drilling includedFigure 10-4: Vertical Cross Section through ACMA and Lewis Block Model, Looking 315*
![img-16.jpeg](img-16.jpeg)

Note: 2017 and 2020 drilling includedFigure 10-5: Example Drill Cross-Section, Lewis
![img-17.jpeg](img-17.jpeg)

Note: 2017 and 2020 drilling includedFigure 10-6: Vertical Cross Section through Lewis Block Model, Looking 45*
![img-18.jpeg](img-18.jpeg)

Note: 2017 and 2020 drilling included# NOVAGOLD 

N 43-101 Technical Report on the DonLIN Gold ProJect Alaska, USA

Table 10-3: Far Side

|  |  |  |  |  | Drill Intercept | Drilled |  |
| :-- | :-- | :-- | :-- | :-- | :-- | :-- | :-- |
| Hole ID | Northing | Easting | Elevation | Azimuth | Dip | From <br> $(\mathrm{m})$ | Thickness <br> $(\mathrm{m})$ | Gold Grade <br> $(\mathrm{g} / \mathrm{t} \mathrm{Au})$ |
| DC96-254 | $6,883,383$ | 542,914 | 179 | 320 | 65 | 23.2 | 16.8 | 4.60 |
| DC96-255 | $6,883,356$ | 542,960 | 182 | 320 | 65 | 122.0 | 14.0 | 3.00 |
| DC96-256 | $6,883,296$ | 542,888 | 175 | 320 | 65 | 130.0 | 15.6 | 5.86 |

Note: These are illustrative of better drill results, may not be representative of the deposit in general. Northings, eastings, and elevations are at the collar locations. Drilled thicknesses do not represent true thicknesses.

Table 10-4: Duqum

|  |  |  |  |  | Drill Intercept | Drilled |  |
| :-- | :-- | :-- | :-- | :-- | :-- | :-- | :-- |
| Hole ID | Northing | Easting | Elevation | Azimuth | Dip | From <br> $(\mathrm{m})$ | Thickness <br> $(\mathrm{m})$ | Gold Grade <br> $(\mathrm{g} / \mathrm{t} \mathrm{Au})$ |
| DC97-387 | $6,882,450$ | 543,692 | 274 | 310 | 55 | 338.0 | 16.0 | 2.39 |
| DC97-388 | $6,882,605$ | 543,070 | 221 | 310 | 55 | 210.0 | 12.0 | 5.03 |
| DC97-388 | $6,882,605$ | 543,070 | 221 | 310 | 55 | 236.0 | 10.0 | 2.29 |
| DC97-389 | $6,882,607$ | 543,074 | 221 | 40 | 55 | 90.0 | 10.0 | 3.86 |
| DC97-389 | $6,882,607$ | 543,074 | 221 | 40 | 55 | 202.0 | 10.0 | 2.79 |
| DC97-389 | $6,882,607$ | 543,074 | 221 | 40 | 55 | 320.0 | 16.0 | 3.79 |

Note: These are illustrative of better drill results, may not be representative of the deposit in general. Northings, eastings, and elevations are at the collar locations. Drilled thicknesses do not represent true thicknesses.

Table 10-5: Snow / Quartz

|  |  |  |  |  | Drill Intercept |  | Drilled |  |
| :-- | :-- | :-- | :-- | :-- | :-- | :-- | :-- | :-- |
| Hole ID | Northing | Easting | Elevation | Azimuth | Dip | From <br> $(\mathrm{m})$ | Thickness <br> $(\mathrm{m})$ | Gold Grade <br> $(\mathrm{g} / \mathrm{t} \mathrm{Au})$ |
| DC97-383 | $6,880,373$ | 541,449 | 230 | 295 | 50 | 16.0 | 23.0 | 2.77 |
| DC97-384 | $6,880,537$ | 541,563 | 194 | 295 | 50 | 52.0 | 10.0 | 3.34 |

Note: These are illustrative of better drill results, may not be representative of the deposit in general. Northings, eastings, and elevations are at the collar locations. Drilled thicknesses do not represent true thicknesses.Table 10-6: Dome

| Hole ID | Northing | Easting | Elevation | Azimuth | Dip | Drill Intercept <br> From <br> (m) | Drilled <br> Thickness <br> (m) | Gold Grade <br> (g/t Au) |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| DC08-1785 | $6,882,542$ | 544,056 | 342 | 110 | 70 | 139.0 | 10.0 | 2.19 |
| DC08-1785 | $6,882,542$ | 544,056 | 342 | 110 | 70 | 163.0 | 10.0 | 3.89 |
| DC08-1785 | $6,882,542$ | 544,056 | 342 | 110 | 70 | 211.0 | 22.6 | 3.29 |
| DC08-1785 | $6,882,542$ | 544,056 | 342 | 110 | 70 | 248.0 | 25.0 | 2.94 |
| DC97-392 | $6,882,486$ | 544,041 | 340 | 130 | 65 | 94.0 | 52.0 | 3.21 |
| DC97-392 | $6,882,486$ | 544,041 | 340 | 130 | 65 | 185.0 | 61.0 | 3.30 |
| DC97-392 | $6,882,486$ | 544,041 | 340 | 130 | 65 | 258.0 | 14.0 | 3.99 |

Note: These are illustrative of better drill results, may not be representative of the deposit in general. Northings, eastings, and elevations are at the collar locations. Drilled thicknesses do not represent true thicknesses.

[[%~%]]
## 10.11 Comments On Section 10

In the opinion of the Wood QP, the quantity and quality of the lithological, geotechnical, collar and downhole survey data collected in the exploration and infill drill programs completed by Placer Dome Inc., NOVAGOLD, Barrick, the DCJV, DCLLC and DGLLC are sufficient to support Mineral Resource and Mineral Reserve estimation based on:

- Core logging meeting industry standards for gold exploration.
- Collar surveys were performed using industry-standard instrumentation.
- Downhole surveys were performed using industry-standard instrumentation.
- Recovery data from core drill programs are acceptable.
- Geotechnical logging of drill core meets industry standards for planned open pit operations.
- Drill orientations are generally appropriate for the mineralization style, and have been drilled at orientations that are acceptable for mineralization in the bulk of the Project area.
- In the bottom of the ACMA pit, the preferred orientation of the drill holes and the trend of the mineralization are both northwest. Figure 10-4 illustrates that although the contacts of the mineralized intrusions are well defined at higher elevations, the location of the mineralized intrusions are subjective at the bottom of the pit. This "bottom of the pit" mineralization would be mined late in the mine plan and the interpretation and location of this deeper mineralization can be refined through ore control drilling as the pit progresses to those depths.

[[@~@]]
# 11.0 Sample Preparation, Analyses, And Security

[[%~%]]
## 11.1 Sampling Methods

Drill hole sampling protocols were developed by Placer Dome Inc., and refined over subsequent drill programs.

Holes are sampled from the top of bedrock to the end of the hole. Overburden, excluding the organic layer, is also sampled if core recovery was good and if the interval was abnormally thick and composed of abundant rock clasts. Prior to the 2017 drilling program, core sample intervals were typically based on rock type, rock type breaks, and presence of visible sulphide / arsenic minerals. The maximum sample length in zones consisting of intrusive rocks or that contain appreciable sulphide / arsenic minerals is typically 2 m , whereas sample lengths in sedimentary rock zones that lack appreciable sulphide / arsenic minerals can be 3 m . A minimum of three additional 2 m sample intervals were placed before and after each intrusive rock or mineralized zone. From 2017 onward, samples were typically taken at maximum of 2 m intervals unless there was a change in lithology type.

An aluminum tag inscribed with the sample number is stapled to the core box with a samenumbered paper tag at each sample break. A sampling cutting list is generated that also specifies the insertion points for control samples.

The core is then digitally photographed and split in half with an electric rock saw equipped with water-cooled diamond saw blades. Core cutters orient the core in the saw to ensure a representative split. One-half of the core is returned to the core box for storage at site, and the other half is bagged for sample processing. Occasionally, whole core has been transported off site for cutting and sampling, after which the remaining half-core is stored off site.

[[%~%]]
## 11.2 Metallurgical Sampling

Typically, metallurgical sampling consisted of taking half-core samples which were used in flotation and pressure oxidation tests. Whole core samples were only taken for drop weight and SAG mill comminution (SMC) tests.

[[%~%]]
## 11.3 Density / Specific Gravity Determinations

Historically, only two specific gravity (SG) values were used in tonnage calculations: 2.65 for the intrusive units and 2.71 for the sedimentary units. Additional SG measurements were collected in 2006 to provide better coverage of deposit rock units and geographic sub-regions. Statistical# NOVAGOLD 

evaluations of these SG values showed that they were similar to the historical intrusive and sedimentary rock SG values. Therefore, the historical values were used for the Mineral Resource estimate in Section 14.

The following methodology was used to determine SG:

- Samples of whole core approximately 5 to 10 cm in length were first weighed dry and then weighed in water. The dry weighing tray assembly was replaced with a wire basket and the sample was submerged in a five-gallon bucket of water. A small tare weight (to compensate for the removed weighing tray) was attached midway up the wire assembly to facilitate alternating wet and dry measurements.
- The formula for SG calculation was: Weight in Air/(Weight in Air - Weight in Water). The SGs were automatically computed in acQuire when the weights were entered into the database.
- Measurements were collected for all rock types at a minimum frequency of one sample from all logged rock type intervals and one sample every 15 to 20 m in the longer rock unit intervals. Mineralized rock takes precedence over unmineralized rock in a given rock type interval, but sufficient measurements of unmineralized material were also collected to document potential variability.

The weighted average of all SG data points was 2.69. Table 11-1 summarizes the average SG values by rock type. Data points clearly identified as outliers were removed before the average was determined.

It was noted that SG values were generally similar among the intrusive units (2.63 to 2.67); therefore, the SG measurements were re-evaluated for the three main rock groupsrhyodacite, greywacke, and shale. Because the grouped average SG values are similar enough to the historical values used in previous estimates, it was determined that the values used in Table 11-2 would be sufficient for tonnage estimation and that a block model of SG estimates was not warranted. In addition, the blocks contained within the overburden model were set with what is considered a reasonable SG value of 2.14. No new SG analysis was undertaken for the DC9 block model of 2009.Table 11-1: Specific Gravity Values by Rock Type

| Rock Code in <br> DH Database | Rock Types | No. of Samples | Specific Gravity |
| :-- | :-- | :--: | :--: |
| ARG | Argillite | 272 | 2.67 |
| CGL | Conglomerate | 9 | 2.71 |
| FTZ | Fault Zone | 25 | 2.75 |
| GWK | Greywacke | 2,368 | 2.71 |
| MD | Mafic Dyke | 473 | 2.73 |
| MZD | Monzodiorite | 2 | 2.70 |
| RDA | Rhyodacite Aphanitic Porphyry | 499 | 2.64 |
| RDF | Rhyodacite Fine-Grained Porphyry | 315 | 2.67 |
| RDX | Rhyodacite Coarse-Grained Porphyry | 1,339 | 2.66 |
| RDXB | Rhyodacite Coarse-Grained Blue Porphyry | 520 | 2.63 |
| RDXL | Rhyodacite Lath-Rich Porphyry | 216 | 2.64 |
| SLT | Siltstone | 838 | 2.72 |
| SHL | Shale | 387 | 2.70 |
| All Rock Types / Average |  | $\mathbf{7 , 3 7 0}$ | $\mathbf{2 . 6 9}$ |

Table 11-2: Specific Gravity Values by Grouped Rock Type

| Grouped Rock Type | Individual Rock Types | No of Samples | Specific Gravity |
| :-- | :-- | :--: | :--: |
| Intrusive Rocks | RDA, RDX, RDXB, RDXL \& RDF | 2,889 | 2.65 |
| Greywacke | GWK \& CGL | 2,377 | 2.71 |
| Shale | SHL, SLT \& ARG | 1,497 | 2.70 |
| All Rock Types / Average |  | $\mathbf{6 , 7 6 3}$ | $\mathbf{2 . 6 8}$ |

[[%~%]]
## 11.4 Analytical And Test Laboratories

The primary laboratory for all assaying has been ALS in Vancouver, BC. Other ALS laboratory locations have also been utilized. During the exploration programs, ALS held accreditations typical for the time.

Metallurgical test facilities have included AuTec, Barrick Technology Center (BTC), SGS-Lakefield Research (SGS-Lakefield), Hazen Research (Hazen), and G\&T Metallurgical Services (G\&T), who are independent, recognized metallurgical testing laboratories. Work has also been performedby test facilities operated by Placer Dome Inc. and Barrick. Metallurgical test facilities are not typically accredited.

[[%~%]]
## 11.5 Sample Preparation And Analysis

Most core samples from 2005 through 2010 were split and crushed at the Donlin camp sample preparation facility and pulverized at the ALS Vancouver laboratory facility. Samples of 2006 core that were split in Anchorage were shipped to an ALS preparation laboratory for crushing and pulverizing. In 2017, whole core was shipped off-site, split and sampled in Fairbanks, Alaska by a contractor independent of ALS. Sampled half-core was then crushed, pulverized, and split at ALS' facility in Fairbanks, and pulps were shipped to and analysed primarily at the ALS Vancouver laboratory. In 2020, drill core was split at the Donlin camp facility, shipped primarily to ALS in Fairbanks for sample preparation, and pulps were shipped and analysed at ALS in Vancouver, BC and Lima, Peru.

Typical sample preparation procedures are as follows:

- The entire bagged sample is dried in an oven heated to $90^{\circ}$ to $95^{\circ} \mathrm{C}$ for 12 hours.
- The sample and sample tag are placed into trays for processing.
- Blank samples (one of three QA/QC control samples) are inserted into the sample stream.
- The sample is crushed in a TM Terminator jaw crusher until the end product passes 70\% minus 10 mesh ( 2 mm ). Sieve analyses are performed daily to check crush quality, and the crusher jaws are adjusted as necessary. The crushers are cleaned with blank material four times per 12-hour shift and before a new hole is started. Cutting lists also specify special cleaning frequency when unusually sulphide-rich material is processed.
- Crushed sample is then passed through a riffle splitter four to six times to obtain a nominal 250 g split. This subsample is put into a numbered pulp bag, and the remainder, or coarse reject, is put back into the original sample bag. The splitter and sample pans are cleaned with compressed air.
- Two additional control samples-standard reference material (SRM) and a duplicate split of crushed sample-are inserted as specified on the cutting list prepared by the geologist. Two of each control sample type, including SRM, duplicates, and blanks, are included in every batch of 78. The blank is prepared by processing a sample from a bin of gravel-size crushed rock through the jaw crusher and riffle-splitting it to 200 g . When a duplicate is required, the crushed core sample is passed once through the riffle splitter, and each half is split repeatedly to obtain a 200 g sample.Final sample preparation and chemical analysis at various ALS facilities consisted of the following:

- Splits of crushed core were reduced to rock flour or "pulp" (better than $85 \%$ passing minus $75 \mu \mathrm{~m}$ in a ring-and-puck grinding mill.
- A 30 g subsample of the pulp was assayed by fire assay-atomic absorption spectroscopy (AAS). Before 2007, the primary gold assay method was Au-AA23, which had an analytical range of 0.005 to $10 \mathrm{~g} / \mathrm{t} \mathrm{Au}$. The Au-AA25 gold assay method was initiated in 2007 and had an analytical range of 0.01 to $100 \mathrm{~g} / \mathrm{t} \mathrm{Au}$. This switch was made to reduce the cost and time delay associated with re-assaying samples with values above the $10 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ analytical limit.
- Samples that exceeded the analytical limit for a given method were re-assayed by fire-assay and gravimetric finish or "ore grade" fire-assay AAS. ALS determined the sulphur content of each sample according to the Leco method. The Leco method was also used to analyse samples flagged for acid base accounting (ABA) for carbon content as well as to determine neutralization potential (NP) and acid potential (AP) according to the industry-standard ALS ABA procedure.
- Most trace and major element data for drill holes located within the resource model boundary were acquired prior to the 2005 program by various labs using industry-standard acid digestions followed by atomic absorption (AA) or inductively coupled plasma (ICP) instrumental determinations. Subsequent multi-element trace analyses were performed at ALS using aqua regia or four-acid digestions followed by ICP $\pm$ mass spectrometry.

On occasion, if ALS Vancouver was unable to complete the preparation, another ALS laboratory could be used.

[[%~%]]
## 11.6 Quality Assurance And Quality Control

[[%~%]]
### 11.6.1 1995-2002 Qa/Qc Protocol

Placer Dome Inc. initiated the first QA/QC protocol during the 1995 drilling campaign. Coarse reject duplicate splits from $10 \%$ of the drill hole samples were submitted to an outside lab (Bondar Clegg). SRM assay standards and blanks were added in 1996, and an outside lab (Chemex) performed check assays, presumably of coarse reject duplicates. Check assays by a secondary assay lab were apparently discontinued after 1996. A more structured assay QA/QC protocol, consisting of SRMs, blanks, and duplicates inserted in rotation every 15 m down-hole,was initiated in 1997. This protocol evolved to random and blind insertion of SRMs, blanks, and coarse reject duplicates through the 2002 NOVAGOLD program.

From 1996 to 2002, SRMs and coarse-reject duplicates were inserted at an average rate of one per 24 samples, and blanks were inserted at an average rate of one per 25 samples. After the 1995 - 2002 drilling campaign, almost all samples associated with SRM and blank control samples that returned values beyond acceptable tolerance limits were re-assayed until the control sample results were either acceptable or validated by duplication.

[[%~%]]
### 11.6.2 2005-2006 Qa/Qc Protocol

No resource delineation drilling was conducted in 2003 and 2004. Placer Dome Inc. implemented a slightly modified QA/QC protocol in 2005, which Barrick continued in 2006. Three QA/QC samples, consisting of one blank, one coarse reject duplicate, and one SRM, were randomly inserted into every block of 20 sample numbers. Thus, every block of 20 sample numbers contained 17 drill hole samples and 3 QA/QC control samples.

[[%~%]]
### 11.6.3 2007-2010 Qa/Qc Protocol

The batch size submitted to ALS was increased from 20 samples to 78 in 2007. To avoid sample mixing with products from other sources in the fusion process, the ALS protocol was based on a fusion batch size of 84 samples, where the lab added six internal control samples, leaving space for 78 client samples in a given batch.

Each batch of 78 samples shipped to ALS for sample preparation and analysis contained 9 control samples ( $12 \%$ ) consisting of 3 each of standards, blanks, and crushed duplicates. Spacing of the SRMs within the batch was left to the judgement of the geologist. Up to 5\% field duplicates (remaining half split of core) were added to the sample batch at the discretion of the geologists for geologic reasons.

[[%~%]]
### 11.6.4 2017 Qa/Qc Protocol

At least nine quality control samples (three blanks, three standards, and three field duplicates) were inserted into each batch of 69 samples, totaling 78 samples.

[[%~%]]
### 11.6.5 2020 Qa/Qc Protocol

Sample dispatches to the lab are comprised of 80 samples, including QA/QC samples. Each group of 80 samples has 14 QA/QC samples inserted into the sample sequence which includes4 of each of the following: a SRM, and a coarse granite blank (blank-granite); as well as two of each the following: a pulp blank, a prep (crush) duplicate, and a pulp duplicate.

[[%~%]]
### 11.6.6 Standard Reference Materials

There is no information available on SRMs used prior to the 2002 drilling campaign. Two standards, (Std-C and Std-D), were used during the 2002 drill campaign.

SRMs remaining from the 2002 campaign were used at the beginning of the 2005 season. Additional reference material was purchased from Analytical Solutions (OREAS 6Pb and OREAS 7Pb) and CDN Laboratories (CDN-GS-3) when these SRMs were depleted. After the 2005 season, two additional SRMs (Std-G and Std-H) were created from Donlin coarse reject material. These two new standards and CDN-GS-3 were used during the 2006 season.

Nine new "matrix matched" SRMs of varying gold grade were added in early 2007, and the older standards were eventually phased out. The new SRMs were created from coarse reject samples from throughout the deposit. Composites of this material were pulverized and homogenized at CDN Laboratories in Vancouver, BC. A Barrick geochemist certified the 2007 SRMs after industry-accepted round-robin assay and statistical analyses.

The final SRMs included four each from unoxidized igneous and sedimentary host rocks and one oxidized igneous rock SRM.

[[%~%]]
### 11.6.7 Blank Materials

Washed river gravel produced by Anchorage Sand and Gravel was used for blanks through early 2006 and then replaced by granite crushed material for all subsequent drill campaigns.

[[%~%]]
## 11.7 Databases

The work completed by Placer Dome Inc. and predecessors before 2001 was collected and compiled into a main Microsoft Access database. NOVAGOLD compiled the Placer Dome Inc. database into an updated Access database and added information from work completed in 2001 and 2002.

Placer Dome Inc. contracted ioDigital to convert the Access database to an MS SQL Server database in early 2005 using an acQuire Technology Solutions data model (acQuire). Data obtained after the conversion were imported directly into the acQuire database.

Barrick and Donlin Gold LLC subsequently used acQuire software to capture drill hole data.

[[%~%]]
## 11.8 Sample Security

For all drill programs following the initial involvement of Placer Dome Inc. in the Project, core samples are transported from the field and brought to the yard adjacent to the geology office and logging tents at the end of each drill shift.

Core storage is secure because the Property is remote and camp access is strictly controlled.
Unauthorized camp personnel have generally been excluded from the core cutting facility.
Splits of core, along with the control samples, are packed in a shipping bag, secured with a numbered security seal, and sealed in boxes for shipment. The coarse rejects and remaining split core are returned to a storage yard on site or to a secure storage facility near Anchorage.

The typical sample shipment procedure is as follows:

- Boxed samples are flown from the Donlin camp to ALS in Fairbanks, AK for sample preparation and forwarded to ALS in Vancouver, BC (or other ALS facility as required) for analysis.


[[%~%]]
## 11.9 Comments On Section 11

Sample collection, preparation, analysis and security for all Placer Dome Inc., NOVAGOLD, Barrick, the DCJV, DCLLC and DGLLC core drill programs are in line with industry-standard methods for gold deposits:

- Drill programs included insertion of blank, duplicate and SRM samples
- QA/QC program results do not indicate any problems with the analytical programs (refer to discussion in Section 12)
- Data is subject to validation, which includes checks on surveys, collar coordinates, lithology data, and assay data. The checks are appropriate, and consistent with industry standards (refer to discussion in Section 12).
- Independent data audits have been conducted and indicate that the sample collection and database entry procedures are acceptable.
- All core has been catalogued and stored in designated areas.

The Wood QP is of the opinion that the quality of the gold analytical data from the Placer Dome Inc., NOVAGOLD, Barrick, the DCJV, DCLLD and DGLLC drill programs are sufficiently reliable tosupport Mineral Resource and Mineral Reserve estimation without limitations on Mineral Resource and Mineral Reserve confidence categories.

[[@~@]]
# 12.0 Data Verification

[[%~%]]
## 12.1 Drill Hole Database

[[%~%]]
### 12.1.1 Wood (2002)

As a test of data integrity, the data used to estimate the January 2002 Donlin Creek Mineral Resources reported in the February and March 2002 Technical Reports (Juras, 2002, and Juras and Hodgson, 2002) were validated. Wood (formerly AMEC) resource estimation staff concluded that the assay and survey database used for the Donlin Mineral Resource estimation at that time was sufficiently free of error to be adequate for support of Mineral Resource estimation.

[[%~%]]
### 12.1.2 Novagold (2005)

NOVAGOLD conducted a 100\% check of 2005 drill hole gold assays within the 2005 resource area against electronic assay certificates. An error rate of less than $1.5 \%$ was noted.

NOVAGOLD also checked the collar and down-hole survey data. Electronic down-hole survey files were read for the drill holes and compared to those stored in the resource database.

As a result of the verification, NOVAGOLD in 2005 considered that the database at the time was adequate to support Mineral Resource estimation.

[[%~%]]
### 12.1.3 Novagold (2008)

In support of preparation of a technical report on the Property in early 2008, NOVAGOLD undertook a data review of the 2006 and 2007 drilling. Data reviewed included:

- Drill collar locations: The Ashtech output files and geologic logs were compared to 5\% of the electronic collar surveys. There was one unexplained $20-\mathrm{cm}$ discrepancy between the elevation file and the database. Although a number of errors were noted in the geological survey tables, and attributed to likely use of proposed, rather than final, collar coordinates, NOVAGOLD concluded that the collar surveys from the Ashtech data files were sufficiently error free to be used for support of Mineral Resource estimation.
- Down hole surveys: $10 \%$ of the drill holes were checked and an error rate of $4.4 \%$ was measured. NOVAGOLD recommended that DCLLC review their down-hole survey transcription protocols and complete a 100\% check of the down-hole survey database. Despite the high error rate, the magnitude of the errors was small; therefore, in NOVAGOLD's opinion the impact on the estimation of grade was likely to be minimal.- Assay data: For 2006 drilling, $70 \%$ of the assays were compared and an acceptable discrepancy rate of $0.4 \%$ was measured. For 2007, $99 \%$ of the assays were compared to the electronic assay certificates and a discrepancy rate of $1 \%$ was measured. NOVAGOLD recommended that the source of the discrepancies be identified. NOVAGOLD believed that the assay database was sufficiently error free to be used for Mineral Resource estimation.


[[%~%]]
### 12.1.4 Wood (2011)

Wood resource estimation staff reviewed the March 2008 through December 2010 QA/QC information for the drill hole data used to construct the DC9 model. Following are the outcomes of the review:

- Certified Reference Materials (CRM) Results: Wood resource staff reviewed the results for 691 CRMs from 2,078 samples and calculated that the relative bias for all CRMs is within the acceptable limits of $\pm 5 \%$ relative bias (mean/best value)/1).
- Blank Material Results: Wood resource staff reviewed the results for 694 blank samples submitted for analysis. There were 4 samples which returned higher than allowed gold assays which may be due in part to mislabelled samples. This is an infrequent occurrence and will not affect project assay results, thus Wood resource geologists consider that there was no significant risk to the resource estimate.
- Coarse Reject Duplicate Results: The absolute value of relative differences (AVRD = | pair difference |/pair mean) of the crush duplicate pairs that have pair means greater than 1 ppm Au show that $90 \%$ of these pairs agree within $15 \%$; this indicates acceptable precision is achieved with the current sample preparation procedure (crushing and pulverizing).


[[%~%]]
## 12.2 Geology And Resource Data

[[%~%]]
### 12.2.1 Wood (2021)

Henry Kim, the QP for the content related to geology and Mineral Resources performed the following data verification exercises to assess whether the data was adequate and suitable to be used:

- Reviewed the "Feasibility Study Update 2 (FSU2) for the Donlin Creek Gold Project in Alaska, 2011 Chapter 3. Geology and Resource Estimation"- Completed a project hand over with Gordon Seibel, QP of the Mineral Resources in the Donlin 2011 Technical Report including:
- Resource estimation procedures
- Geological and resource models
- Validation checks on the models
- Conducted a site visit to the project site. During the Donlin site visit, Henry Kim met with one of the Donlin Gold LLC team members who was involved in generating the DC9 model and others currently managing the Donlin drilling program, and reviewed:
- Geological modeling procedures, and compared the DC9 model to the 2020 drilling logs
- Resource estimation procedures
- 2020 and older drill core and drill core photographs
- Site visit: 18-21 September 2020:
- Visited accessible 2020 and older drill sites
- Inspected representative examples of 2020 and older drill core and drill core photographs; compared the core against the description of lithology, styles of mineralization, alteration types and structures
- Visited representative and accessible trenches and surface exposures
- Reviewed the DC9 geological model on screen with 2020 drilling logs that were available at the time of site visit
- Became familiarized with the location, terrain, topography, and overburden type and depth during the site visit
- 2020 Drill Results:
- Reviewed on screen all of the 2020 drilling results compared to the DC9 model as a validation check.


[[%~%]]
## 12.3 Mining And Infrastructures

To comply with NI 43-101 requirement for a personal inspection of the mineral property, Kirk Hanson, the Wood QP for mining, infrastructure, and economic analysis, completed a 4-day site visit at the Project site during September 2020. The focus of the site visit was to inspect proposed mining areas and proposed locations for project infrastructure including:

- ACMA and Lewis pits and WRF locations
- Tailings storage facility, plant site, and water retention facilities- Jungjuk Road and port, including borrow sources
- Permanent camp and airstrip
- RO operations water treatment plant and discharge location at Crooked Creek
- First 25 miles of natural gas pipeline route starting at the Donlin site.

Kirk Hanson had visited the site previously on 1 October 2008 in order to fulfill the NI 43-101 personal inspection requirements expected for the QP for the mining work in Section 15 and 16 of the Donlin 2011 Technical Report. The purpose of the current site visit was to not only become refreshed on the mining infrastructure and supporting data, including reviewing of core from new drilling, but to also become familiar with proposed locations of project infrastructure as part of the verification by K. Hanson to take responsibility as the QP for much of the project infrastructure summarized in this Report.

In addition to the site visit conducted by Kirk Hanson, subject matter experts within Wood's project team completed reviews and updates of key project infrastructure and documented their findings in technical memos for Kirk Hanson to rely on when determining whether the information was adequate for the purposes used in the Report.

[[%~%]]
### 12.3.1 Operations Water Treatment Plan

Wood specialists reviewed the new design documents and engineering studies for the Project Operations Water Treatment Plant (WTP) which were a change in concept from the 2011 WTP. Following the review, Wood:

- Compared scale, timing, and cost of the feasibility water treatment facilities to the permitted facilities.
- Scaled and updated cost estimates to reflect membrane-based water treatment system described in the documents submitted to Alaska Department of Natural Resources (ADNR).
- Wrote a technical memo describing the review and updated costs that Kirk Hanson used when determining whether this information was adequate for the purposes used in the Report.

The review was conducted by Bob Kimball, P.E., BCEE and Rangesh Srinivasa, Senior Process Engineer, and documented in a technical memo titled "Water Treatment Plant Review" and dated December 17, 2020.

[[%~%]]
### 12.3.2 Tsf, Wrf, Contact And Freshwater Dams, And Water Diversion Structures

Wood technical experts reviewed the design documents and engineering studies that are associated with the following planned infrastructure for the Project:

- Tailings Storage Facilities (TSF)
- Waste Rock Facility (WRF)
- Contact Water and Freshwater Dams
- Water Diversion Structures.

The designs were completed by BGC and have not been updated since 2011. The Wood review involved:

- Assessing the 2011 BGC designs for level of engineering and constructability
- Comparing the 2011 basis of design with current regulatory requirements
- Providing inputs to unit costs for the cost update used in this Report
- Writing a technical memo describing the review that Kirk Hanson used when determining the data was adequate for the purposes used in the Report.

The Wood review was conducted by Peter H. Yuan, PE (NV), PhD and documented in a technical memo titled "Phase II Donlin Gold NI 43-101 FS Technical Report Update - Donlin Gold Project: TSF, WRF, and Water Dam Review" and dated December 7, 2020.

[[%~%]]
### 12.3.3 Natural Gas Pipeline

Wood technical experts completed a high level, general technical review of the 2011 Donlin natural gas pipeline designed and costed by CH2M Hill Engineers, Inc., and the Donlin Gold Project Pipeline Construction Execution Plan and Design Basis Memorandum prepared by Michael Baker in November 2016 and April 2018, respectively. Wood also reviewed the prior natural gas pipeline capital cost estimates and revised the cost estimate to make it current by:

- Adjusting the size of the pipeline diameter from 12 inch to 14 inch and utilizing the pipeline re-routes as a result of permitting.
- Updating material pricing from 2020 quotes received from pipe and valve suppliers
- Updating the construction estimate based on an estimate prepared by personnel with prior experience in Alaska's North Slope and Kenai Peninsula. Other experts within Wood were also engaged to apply their experience working in remote, arctic conditions.- Writing a technical memo describing the results of the review that Kirk Hanson then used to determine the information on the natural gas pipeline was adequate for the purposes used in this Report.

The review was conducted by MJ Hwang P.E. and Greg Tuckwood of Wood's Oil \& Gas division and documented in a technical memo titled "Natural Gas Pipeline, 314 Miles x 14" Diameter" and dated November 12, 2020.

[[%~%]]
## 12.4 Metallurgy And Mineral Process

Wood reviewed the design documents and engineering studies that are associated with the pressure oxidation plant and oxygen plant as designed by Hatch Ltd. including:

- initial trade-offs for flowsheet selection
- updates to the engineering and designs that were included in the 2011 feasibility study, and additional metallurgical testing completed in 2018.

Wood also reviewed the updates prepared by Hatch Ltd for this Report including:

- Scaled and updated capital cost estimates to reflect 2020 vendor pricing
- Scaled and updated operating cost estimates to reflect 2020 reagent pricing, and related maintenance costs.

The Wood review was conducted by Nicole Brazier, Senior Wood Process Engineer, and documented in a technical memo titled "Review of Hatch Design and Updated Cost Estimates for the Autoclave and Oxygen Plant" and dated January 13, 2021 under the supervision of Mike Woloschuk, Wood's QP for the metallurgy and mineral processing sections of the Report, which supports the metallurgical data as being adequate for the purposes used in the Report.

[[%~%]]
## 12.5 Economic Analysis

NOVAGOLD's accounting firm completed a review of the tax assumptions used in calculating the U.S. income tax, Alaska State income tax and Alaska Mining tax for the financial model to determine if the assumptions are reasonable and are in accordance with current (2020) federal and state tax rules. NOVAGOLD's accounting firm completed the following scope of work:

- Reviewed the methodology used in the calculation of the tax depreciation on the deprecation tab to ensure it is in accordance with the existing depreciation tax rules(i.e., applicable depreciation methods, depreciable life, depreciation factors and convention).

- Reviewed reasonableness of tax depletion calculation used in the model.
- Sample tested 2 years of tax calculation to make sure that the tax calculations work as intended.

The outcome of the review found that the financial model tax assumptions were correct and reasonable with minor updates recommended for the depreciation calculations. NOVAGOLD subsequently updated the depreciation tax calculations and provided a final reliance letter titled "Reliance on Other Expert for Tax Information" dated April 27th, 2021 for Wood to rely on.

In addition to tax checks, Kirk Hanson completed an independent financial model which was used as a parallel model to:

- Check data inputs into the NOVAGOLD financial model
- Check financial outcomes of the NOVAGOLD financial model.

The outcome of the check model is that the after tax cash flows for both models are within $0.6 \%$. The differences are primarily due to the additional details included in the NOVAGOLD financial model to account for stockpile deferred costs and minor royalty agreements.

[[%~%]]
## 12.6 Comments On Section 12

[[%~%]]
### 12.6.1 Geology And Resources

Henry Kim, Wood's QP considers that the data supporting the Mineral Resources are reliable, reasonably error free and suitable for the purposes used in the Report.

[[%~%]]
### 12.6.2 Mining And Infrastructure

Kirk Hanson, Wood's QP considers that the data supporting the Mineral Reserves and Project infrastructure are reliable, reasonably error free and suitable for the purposes used in the Report.

[[%~%]]
### 12.6.3 Metallurgy And Mineral Process

Mike Woloschuk, Wood's QP considers that the data supporting the metallurgy and mineral processing are reliable, reasonably error free, and suitable for the purposes used in the Report.

[[%~%]]
### 12.6.4 Financial Model

Kirk Hanson, Wood's QP considers that the financial model calculations both before and after tax are reliable, reasonably error free, and suitable for the purposes used in the Report.

[[@~@]]
# 13.0 Mineral Processing And Metallurgical Testing

[[%~%]]
## 13.1 Metallurgical Testwork

[[%~%]]
### 13.1.1 Domains

## Lithological and Geological Domains

Mineralization at the Donlin deposits is temporally and spatially associated with rhyodacite dikes and sills intruded into sedimentary rocks of the mid-Cretaceous Kuskokwim Group. The sedimentary rocks are predominantly inter-bedded greywacke and shale. Six intrusive phases and two major sedimentary phases have been recognized. The lithological domains and their respective percentages within the Donlin deposits are summarized in Table 13-1. The listed intrusive lithologies are ranked in order of relative age.

Due to poor continuity and minor occurrence within the deposit, the Mafic Dike (MD) intrusive lithology is not separately defined within the geological model, and therefore its relative content within the ore is not accurately defined. Based upon lengths of ore intercepts within the exploration drilling, the content of MD in the ore is estimated to be $0.2 \%$ of the ore tonnes.

Two main pits have been identified within the current Donlin deposits, Lewis and ACMA, each subdivided into spatial zones typically separated by faults or other key geological structures.

The Lewis pit is dike dominated and contains more sedimentary rock hosted ore than ACMA. The ACMA pit is sill dominated and typically contains less sedimentary rock hosted ore and more intrusive rock hosted ore than Lewis. Regarding the intrusive rocks, the Lewis pit is dominated by RDX and RDXB compared to the ACMA pit area, which is dominated by the RDA, RDX, and RDXL intrusive lithologies.

For the purpose of defining discreet geological domains within the deposit, the Donlin Gold LLC geological team is using a multi-type separation of the deposit based on a combination of both lithology and spatial location. This is undertaken by independently recognizing the main pit spatial domains (Lewis, ACMA, Akivik, 400, Aurora, and Vortex) for the intrusive rocks, but separating out the sedimentary lithologies from every spatial area, and differentiating into the two sedimentary global domains, greywacke (GWK) and shale (SHL). However, for metallurgical interpretation all different types of domain categorization are considered, used, and applied as appropriate. Table 13-2 provides an estimate of the ore tonnes and gold ounces distribution on the basis of geological domain allocation.

Figure 13-1 is a graphical representation of the geological domains in the Donlin deposits.Table 13-1: Intrusive and Sedimentary Lithologies of the Donlin Gold Project

| Lithology Description | Abbreviations | Relative Intrusive Age | $\begin{gathered} \text { \% Ore Tonnes LOM } \\ (\%) \end{gathered}$ |
| :--: | :--: | :--: | :--: |
| Intrusive Phases |  |  |  |
| Blue Porphyry | RDXB | Youngest | 15.2 |
| Aphanitic Flow-banded Porphyry | RDA |  | 22.5 |
| Lathe-rich Porphyry | RDXL |  | 7.2 |
| Crystalline (Crowded) Porphyry | RDX |  | 27.6 |
| Fine-grained Porphyry | RDF |  | 1.4 |
| Mafic Dikes | MD | Oldest | $0.2^{*}$ |
| Sedimentary Phases |  |  |  |
| Greywacke | GWK |  | 20.4 |
| Shale | SHL |  | 5.4 |
| Total |  |  | 100.0 |

Note: MD component percentage is an estimate only - and is therefore not included within the total composition.

Table 13-2: Major Geological Domains Within the Mine Plan

| Description | $\begin{gathered} \text { \% O } \\ (\%) \end{gathered}$ | $\begin{gathered} \text { \% Ore Tonnes LOM } \\ (\%) \end{gathered}$ |
| :--: | :--: | :--: |
| Lewis Intrusive | 22.4 | 25.7 |
| ACMA Intrusive | 20.8 | 16.1 |
| Aurora Intrusive | 5.0 | 4.2 |
| Akivik Intrusive | 3.9 | 4.6 |
| Vortex Intrusive | 9.7 | 11.6 |
| 400 Intrusive | 6.1 | 5.6 |
| Oxide | 6.9 | 7.7 |
| Greywacke (GWK) | 19.9 | 19.2 |
| Shale (SHL) | 5.2 | 5.2 |
| Total | 100.0 | 100.0 |# NOVAGOLD 

Figure 13-1: Donlin Gold Project Geological Domains
![img-19.jpeg](img-19.jpeg)

## Gold Mineralization

There are four primary vein types in the deposit area with variable mineralization as summarized in Table 13-3.

Table 13-3: Vein Types

| Vein Type | Dominant Mineralogy | Grade <br> $\mathbf{( g / t ~ A u )}$ | Average Orientation <br> (degrees) | Relative Age |
| :-- | :-- | :--: | :--: | :--: |
| V1 | Sulphide | 2.7 | $020 / 67$ | Oldest |
| V2 | Qtz-Sulphide | 3.9 | $022 / 68$ |  |
| V3 | NA, St, Re | 7.4 | $028 / 72$ |  |
| V4 | Carbonate | 0.6 | $028 / 65$ | Youngest |

Note: NA is native arsenic; St is stibnite; Re is realgar

## Sulphide Mineralization

A number of mineralogical investigations were undertaken in 2004 to 2007, including work carried out by Amtel, Hazen, G\&T, and BTC, and in 2018 by FLSmidth, Dawson Metallurgical Laboratories, and AuTec. Typical sulphide mineralization presence based on these investigations is summarized in Table 13-4.# NOVAGOLD 

Psrite is the dominantly occurring sulphide within the deposit. Marcasite is also present, at an approximate ratio of 1:7 as marcasite to pyrite. Arsenopyrite is the main carrier of arsenic within the deposit. Stibnite is the main carrier of antimony.

Table 13-4: Typical Sulphide and Metals Mineralization in the Donlin Ores

| Typical Occurrence | Sulphides | Chemical Formula |
| :--: | :--: | :--: |
| Major to Minor | Pyrite | $\mathrm{FeS}_{2}$ |
|  | Marcasite | $\mathrm{FeS}_{2}$ |
|  | Arsenopyrite | FeAsS |
| Minor to Trace | Native Arsenic | As |
|  | Realgar | AsS |
|  | Stibnite | $\mathrm{Sb}_{2} \mathrm{~S}_{3}$ |
| Trace | Chalcopyrite | $\mathrm{CuFeS}_{2}$ |
|  | Sphalerite | $(\mathrm{Zn}, \mathrm{Fe}) \mathrm{S}$ |
|  | Tetrahedrite | $(\mathrm{Cu}, \mathrm{Fe})_{12} \mathrm{Sb}_{4} \mathrm{~S}_{13}$ |
|  | Galena | PbS |
|  | Pyrrhotite | FeS |
|  | Molybdenite | $\mathrm{MoS}_{2}$ |
|  | Bornite | $\mathrm{Cu}_{5} \mathrm{FeS}_{6}$ |
|  | Covellite | CuS |
|  | Mercury Sulphide | HgS in pyrite |
|  | Native Copper | Cu |

[[%~%]]
### 13.1.2 Gold Department

The primary host mineral of gold within the Donlin ores is arsenopyrite, which carries $80 \%$ to $90 \%$ of the gold as "solid solution" gold atomically distributed within the arsenopyrite crystal. Fine arsenopyrite is typically highest in gold grade at 500 to $1,500 \mathrm{~g} / \mathrm{t}$ (mineral gold content), compared to coarse arsenopyrite at $\sim 100$ to $500 \mathrm{~g} / \mathrm{t} \mathrm{Au}$. A proportion of the arsenopyrite (particularly coarser-grained arsenopyrite) has been shown to have a preferential concentration of gold around the rim of the crystal.

Pyrite is the second most important gold carrier, hosting $10 \%$ to $20 \%$ of the contained gold, also in "solid solution" form. Typical gold grades of pyrite are $1 \mathrm{~g} / \mathrm{t}$ to $50 \mathrm{~g} / \mathrm{t}$. Similarly, marcasite is also a gold carrier.Free gold is a minor source of gold (rare occurrence) within the deposit at less than $1 \%$ of the contained gold being free liberated particles less than $20 \mu \mathrm{~m}$ in diameter. Native arsenic is an insignificant carrier of gold in terms of both grade and quantity.

[[%~%]]
### 13.1.3 Mercury, Chlorine, Carbonates And Organic Carbon Department

The Donlin ore hosts mercury at a grade of $1 \mathrm{~g} / \mathrm{t}$ to $3 \mathrm{~g} / \mathrm{t}$. For occupational health and environmental considerations, mercury is an important species considered for the process plant design.

Detailed deportment of mercury was undertaken by Amtel in 2007, which indicated that, based upon the concentrate samples tested, pyrite is the principal carrier (66\%) of mercury as HgS in "solid solution" within the sulphide mineral matrix, followed by the sulphide marcasite (18\%). The Amtel study also indicated that fine-grained pyrite, marcasite, and stibnite are relatively enriched in mercury content. Arsenopyrite has relatively low mercury content and is an insignificant carrier. No specific mercury minerals have been found or identified in any of the samples examined by Amtel in the deportment work completed.

The Donlin ore contains chloride with an average concentration of approximately 22 ppm . Detailed testing of chloride deportment carried out by Amtel in 2007 indicated that the principal carrier of chloride in flotation concentrate was muscovite (white mica) as $\mathrm{KAl}_{2}\left(\mathrm{Si}_{9} \mathrm{Al}\right) \mathrm{O}_{10}(\mathrm{OH}, \mathrm{F}, \mathrm{Cl})_{2}$, followed by hydroxylapatite, $\mathrm{Ca}_{5}\left(\mathrm{PO}_{4}\right)_{3}(\mathrm{OH}, \mathrm{F}, \mathrm{Cl})$.

The form of carbonates within the Donlin ores is an important consideration - carbonate within the flotation tails stream is used to neutralize the acidic liquor coming from the autoclave. The three forms of carbonate identified by Amtel in 2007 were calcite $\left(\mathrm{CaCO}_{3}\right)$, siderite $\left(\mathrm{FeCO}_{3}\right)$, and dolomite $\left(\mathrm{CaMg}\left(\mathrm{CO}_{3}\right)_{2}\right)$. The predominant carbonate species remaining in flotation tails was dolomite, followed by ankerite. Calcite was only identified in two test samples and siderite in only one test sample. For the samples tested, the Aurora geological domain consistently contains calcite as the dominate carbonate.

The Donlin ores host organic carbon in both the intrusive and sedimentary lithologies. The sedimentary lithologies are relatively abundant in organic carbon. The RDF and RDXB intrusive lithologies are characteristically high in graphitic carbon content.

[[%~%]]
### 13.1.4 Samples

The samples used for the metallurgical testwork during 2006 to 2007 were obtained from a variety of sources. Samples for metallurgical testwork were selected to represent the various geological lithologies and geological domains.Additional samples were collected and tested in 2017 and 2018. The main objective of the 2017 Donlin drilling campaign was primarily to confirm resource modelling and improve geologic understanding. Some of the drill core from this campaign was made available and was utilized for metallurgical testing. The metallurgical test results from these samples were reviewed but did not change the process design used in this Report.

[[%~%]]
### 13.1.5 Comminution

Grinding testwork for the Donlin deposits have been conducted periodically since early resource evaluation. The initial grinding testwork was undertaken in the 1990s and very little specific information is available on this work. Subsequently, in 2002-2003 additional work was completed at Hazen managed by NOVAGOLD.

Placer Dome Inc. initiated some further work by SGS-Lakefield in 2004, which tested ACMA material. During this program, JK and Bond testwork were completed in conjunction with testing the applicability of high pressure grinding rolls (HPGRs) to the deposit. During 2006 Barrick initiated three major testwork programs at SGS-Lakefield:

- SGS-Lakefield 2006 HQ half-core testwork
- SGS-Lakefield 2006 PQ whole-core testwork
- SGS-Lakefield 2007 HQ half-core testwork.

The metallurgical testwork completed in 2007 for the feasibility level study indicated that grinding testwork should preferably be carried out on freshly drilled core that has been protected from freezing and thawing in the Alaskan weather. It is apparent that the physical hardness properties of the drill core are affected upon exposure to the Alaskan environment while in storage (i.e., reduced in competency, believed to be through a cryogenic weathering effect) and therefore could lead to biased low hardness test results.

Consequently, the test results from the core recovered from fresh exploration drilling undertaken in 2006 were used preferentially as the basis for the feasibility study design of the grinding circuit.

## Testwork Period 2002-2003

A summary of results of the testwork undertaken in 2002-2003 is shown in Table 13-5. The testwork summary indicates that the material tested at that time was moderately hard. These results align with more recent testwork.Table 13-5: Grinding Testwork Results from Hazen Research

| Pit | Locale | Ore Type | BWI <br> (kWh/t) |
| :-- | :--: | :--: | :--: |
| ACMA | - | Intrusive | 14.3 |
|  | - | Sedimentary | 13.0 |
| Lewis | Rochelieu | Intrusive | 14.1 |
|  | Rochelieu | Sedimentary | 13.3 |
| Lewis | North | Intrusive | 13.9 |
|  | North | Sedimentary | 13.1 |
| Lewis | South | Intrusive | 15.1 |
|  | South | Sedimentary | 12.1 |

# Testwork Period 2004-2005 

Placer Dome Inc. initiated a testing program at SGS-Lakefield in 2004. This work was performed on two large samples from the Donlin deposits with the objective of comparing the power efficiency of using HPGR as opposed to semi-autogenous grinding to prepare the ore ahead of ball milling. The results of the JK and Bond work are summarized in Table 13-6.

Table 13-6: Summary of Grindability Testing

| Sample Composite | CWI <br> $(\mathbf{k W h} / \mathbf{t})$ | $\mathbf{A} \times \mathbf{b}$ | ta | Ore Density <br> $\left(\mathbf{g} / \mathbf{c m}^{\mathbf{3}}\right)$ | RWI <br> $(\mathbf{k W h} / \mathbf{t})$ | BWI <br> $(\mathbf{k W h} / \mathbf{t})$ | Ai <br> $(\mathbf{g})$ |
| :-- | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| ACMA Sedimentary | 9.9 | 38.7 | 0.39 | 2.76 | 14.7 | 14.0 | 0.205 |
| ACMA Intrusive | 11.3 | 52.8 | 0.31 | 2.69 | 13.5 | 14.7 | 0.181 |

The following key items were identified from the testwork:

- The sedimentary rock sample was described as moderately hard with respect to resistance to impact, as measured by the impact work index (CWI) and drop-weight test (A x b).
- The intrusive rock sample measured as hard in terms of low-energy impact and medium in the drop-weight test.
- The sedimentary rock sample was moderately hard with respect to resistance to abrasion breakage (ta), while the intrusive sample was hard.- Both samples can be categorized as medium in terms of Bond rod mill (RWI) and ball mill work indices (BWI).
- Both samples were only mildly abrasive (Ai).

The two samples were also submitted to a series of bench-scale HPGR tests. The tests showed that the HPGR successively reduced the 13 mm material feed to ball mill feed size with an energy input of 2.07 and $1.94 \mathrm{kWh} / \mathrm{t}$ for the sedimentary and intrusive rock samples, respectively. The BWIs of the resultant samples were tested at $75 \mu \mathrm{~m}$ and produced values of 12.5 and $13.3 \mathrm{kWh} / \mathrm{t}$, respectively, indicating that a reduction (in the BWI) was attributable to the HPGR processing.

SGS-Lakefield recommended further HPGR work at Polysius with the REGRO unit accompanied by ATWAL abrasion testing. The testwork by Polysius judged that a specific energy input in a range of 1.5 to $2.0 \mathrm{kWh} / \mathrm{t}$ was the optimum for HPGR comminution of the provided test samples. A specific throughput rate of approximately $250 \mathrm{ts} / \mathrm{hm}^{3}$ was achieved with the grinding force selected.

The abrasion testwork indicated an ATWAL wear index of $8.3 \mathrm{~g} / \mathrm{t}$ for sedimentary rock material and $24.8 \mathrm{~g} / \mathrm{t}$ for intrusive rock material. This testwork was done at the standard feed moisture of $1 \%$. This wear is medium abrasive compared with Polysius' database at the time.

# SGS-Lakefield 2006 HQ Core Testwork 

In 2006, SGS-Lakefield conducted an extensive test program to determine grinding parameters for the Donlin ores. The samples used were HQ drill core taken from the 1999 and 2002 drilling campaigns, which had been stored at the exploration site. Parameters were obtained from the following tests:

- Minnovex SAG power index (SPI), crusher index (Ci), and modified Bond ball mill work index (Modified Bond test)
- SMC drop-weight index test (DWI)
- Bond low-energy impact (CWI), rod mill work index (RWI), ball mill work index (BWI), and abrasion index (Ai)
- High-pressure grinding roll energy test.# SGS-Lakefield 2006 Whole PQ Core Testwork 

HQ drill core was too small in diameter for full drop weight tests for JKSimMet modelling. Larger diameter PQ holes were drilled in a 2006 drilling campaign, targeting bulk mineralized areas of the deposit, and covering the full range of lithologies. The samples from these drill holes were processed to develop JK grinding parameters, in addition to conventional Bond ball mill and rod mill work index numbers. This information was important for use in checking the grinding parameters developed from the HQ testwork. It was seen by comparing work index properties within lithologies from the PQ core results and the 2006 HQ core results that the freshly drilled PQ core was consistently harder than the HQ core samples drilled in 1999 and 2001. At that point in the study, it was recommended that a second set of HQ samples be selected from freshly drilled core that became available during 2006.

## SGS-Lakefield 2007 HQ Core Testwork

With the availability of additional fresh HQ drill core from the 2006 exploration program, a second phase of variability testing was initiated in early 2007. A total of 149 additional samples were tested.

In parallel with this testwork AMEC (now Wood) undertook grinding circuit design trade-off studies in 2006, which indicated that a semi autogenous-ball mill-crushing circuit (SABC) circuit design was the preferred option. Therefore, the test program was designed to maximize generation of hardness properties relating to the required parameters for the SABC circuit. The parameters tested in the program were then restricted to:

- Minnovex SAG power index (SPI)
- Minnovex crusher index (Ci)
- Minnovex modified Bond ball mill work index
- Rod mill work index (RWI)
- Ball mill work index (BWI).

Once again, it became apparent that within lithology, the results from the 2007 test program indicated consistently harder comminution properties than the 2006 test program.

Therefore, it was recommended that comminution data obtained from core predating 2006 be normalized to fresh rock conditions for design calculations when it is known that the core has been exposed for an extended period to Alaskan climate. Such normalization was carried out on the 1999 and 2001 HQ core data.# NOVAGOLD 

## Comparison of 2006 Drilled and 1999-2001 Drilled Half HQ Core

Table 13-7 directly compares the average results by lithology between the two crushing and grinding hardness data from the 2006 (core drilled 1999/2001) and 2007 (core drilled 2006) testwork programs.

It should be noted that for the test JKTech parameters Axb and Crushing Index, ore hardness is inversely proportional to the test result (i.e., lower numerical result is physically harder to process, requiring more power).

Given that the 2007 program used the freshly drilled 2006 HQ core, these results were regarded as being a more reliable predictor of the hardness of the deposit. However, the 2006 test results were preserved to provide more test samples to augment the variance analysis and subsequent population of the geological model. Minnovex adjusted the 2006 variability results to match the hardness distribution of the later (harder) test results.

Table 13-7: Comparison of Average Results from 2006 and 2007 Test Programs

| Lithology | JKMRC, A x b |  | SPI, Minutes |  | Crushing Index |  | RWI, kWh/t |  | BWI, kWh/t |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | 2006 | 2007 | 2006 | 2007 | 2006 | 2007 | 2006 | 2007 | 2006 | 2007 |
| RDX | 46.0 | 42.7 | 47.6 | 90.5 | 17.2 | 14.9 | 13.3 | 15.1 | 14.6 | 15.6 |
| RDA | 41.0 | 41.1 | 53.8 | 90.1 | 17.3 | 14.6 | 14.0 | 15.0 | 12.4 | 13.8 |
| RDXL | 54.2 | 48.5 | 44.6 | 72.3 | 22.5 | 21.3 | 13.6 | 14.0 | 13.6 | 14.3 |
| RDXB | 50.0 | 49.4 | 53.7 | 91.9 | 18.8 | 15.3 | 13.7 | 15.5 | 14.6 | 16.4 |
| GWK | 41.8 | 34.4 | 55.9 | 94.7 | 16.6 | 12.5 | 14.5 | 15.2 | 13.3 | 14.7 |
| SHL | 50.2 | 42.2 | 48.4 | 58.1 | 21.7 | 16.0 | 13.4 | 16.7 | 13.5 | 14.4 |
| RDF | 37.0 | 30.1 | 61.9 | 100.8 | 18.3 | 14.2 | 13.9 | 14.8 | 15.1 | 15.3 |
| Average | 45.7 | 41.2 | 52.3 | 85.5 | 18.9 | 15.5 | 13.8 | 15.2 | 13.9 | 14.9 |

Table 13-8 is a summary of the adjustments for each lithology, derived by splitting the data into separate lithological groups, comparing the frequency distribution of the 2006 and 2007 sample data, and then determining a simple adjustment to move the 2006 data to fit the form of the 2007 distribution.

After the adjustment to each of the lithologies within the 2006 test data, the two 2006 and 2007 data sets ( $\mathrm{Ci}, \mathrm{SPI}, \mathrm{BWI}$ ) were combined and forwarded to Wood for geostatistical review and modelling, to provide a block-by-block mill feed hardness schedule for the parameters of $\mathrm{Ci}, \mathrm{SPI}$, and BWI. With these parameters, it is possible to use a Minnovex CEET (comminution economic evaluation tool) grinding model to predict the milling capacity and power requirements for each ore block in the designed Donlin circuit.Table 13-8: Adjustments Made to the 2006 Test Program Data

| Lithology | CI <br> 2006 Correction | SPI <br> 2006 Correction | BWI <br> 2006 Correction |
| :-- | :--: | :--: | :--: |
| RDA | $\mathrm{x} / 1.2$ | $1.8^{*} \mathrm{x}+6$ | $1.09^{*} \mathrm{x}$ |
| RDX | $\mathrm{x} / 1.1$ | $1.35^{*} \mathrm{x}+18$ | $1.07^{*} \mathrm{x}$ |
| RDXB | $\mathrm{x} / 1.1$ | $1.1^{*} \mathrm{x}+33$ | $1.17^{*} \mathrm{x}$ |
| RDXL | x | $1.2^{*} \mathrm{x}-18$ | $1.07^{*} \mathrm{x}$ |
| RDF | $\mathrm{x} / 1.3$ | $1.2^{*} \mathrm{x}+27$ | $1.05^{*} \mathrm{x}$ |
| GWK | $\mathrm{x} / 1.3$ | $1.8^{*} \mathrm{x}+2$ | $1.12^{*} \mathrm{x}$ |
| SHL | $\mathrm{x} / 1.5$ | $1.3^{*} \mathrm{x}$ | $1.07^{*} \mathrm{x}$ |
| MD | $\mathrm{x} / 1.8$ | $1.8^{*} \mathrm{x}$ | $1.09^{*} \mathrm{x}$ |

Note: where * = multiplier

# Effect of Grind Size on BWI 

The potential adoption of a MCF2 flowsheet would result in two different ball mill product size distributions. The products from the primary ball milling circuit would target $\mathrm{P}_{80} 120$ to $150 \mu \mathrm{~m}$, and the secondary ball mill would target $\mathrm{P}_{80} 50 \mu \mathrm{~m}$. From previous work by others, it is known that in some circumstances the measured BWI of a test sample will vary according to the target $P_{80}$ of the BWI test.

To determine if this is the case for Donlin ores, and to quantify that effect, additional BWI tests at different final product sizes were undertaken by SGS-Lakefield. For the feasibility grinding circuit modelling and design, an overall adjustment model was applied to the BWI number used, based on these results.

Using the blended pilot-plant feed sample, an additional set of BWI tests was undertaken at varying product sizes.

From the results obtained, it was seen that as the target product $\mathrm{P}_{80}$ size increased in fineness, the measured BWI of the test sample increases. On the blended pilot-plant sample a significant increase in BWI occurs between $\mathrm{P}_{80} 54 \mu \mathrm{~m}$ and $42 \mu \mathrm{~m}$. Figure 13-2 is a graphical representation of the pilot-plant blend feed sample results.# NOVAGOLD 

Figure 13-2: Test $P_{80}$ vs. Measured BWI Results on Blend Composite Sample
![img-20.jpeg](img-20.jpeg)

## Feasibility Comminution Circuit Selection

In 2006, Barrick contracted Orway Mineral Consultants (OMC), and SGS-Lakefield (Minnovex), both of which have specialist groups in grinding circuit modelling and design, to perform appraisals of the various comminution options. The consultants were asked to examine the testwork information and provide capital and operating cost alternatives for four options:

- Option 1 - autogenous milling with ball milling and crushing of pebble reject (ABC)
- Option 2 - semi-autogenous milling with ball milling and pebble crushing (SABC)
- Option 3 - coarse crushing followed by HPGR with ball milling
- Option 4 - fine crushing followed by ball milling.

Both consultants created grinding models based on their internal databases and calculated capital and operating costs.

Wood then performed a trade-off study based on the OMC recommendations to investigate the economics of various options as well as non-economic factors. Wood also performed a check analysis on the various models to ensure that these were reasonable in their execution. It should also be noted that since the OMC and SGS-Lakefield work was done, it has becomeapparent that the samples from the 1999 and 2002 drill campaigns may have weathered sufficiently to affect the primary mill grindability testing. Consequently, Wood also performed a separate analysis using only the results from the samples obtained in the 2006 drilling campaign.

The SABC circuit, Option 2, was selected as the comminution circuit for Donlin ores, for several reasons:

- Lowest capital cost
- Ability to cope with the clay fraction in the ore
- Ability to cope with the climatic conditions
- General ease of operation and maintenance
- Flexibility in throughput rates
- Widely applied technology in the mining industry
- Barrick's extensive experience in SABC circuit application.

Although the lower operating costs ascribed to Options 3 and 4 indicate a long-term economic advantage, these options are considered unwarranted in use because of uncertainty regarding their ability to achieve the operating costs and stated availabilities. In particular, the natural high clay content of the Donlin ores would hinder the performance of these two types of circuits, particularly as ore moisture increases.

# Geostatistical Assessment 

To better define the hardness characteristics of the scheduled mill feed, the compiled comminution data set for $\mathrm{Cl}, \mathrm{SPI}$, and BWI was provided to Wood to build a metallurgical model, which served as the basis for the geostatistical assessment. The purpose of the metallurgical model was to develop the supportable relationships that might exist between the ore sample hardness, rock lithology, spatial location, ore grades (Au, S, As, Mg, Sb), and rock quality designation (RQD), and to use these relationships to populate the geological block model with the ore hardness properties $\mathrm{Ci}, \mathrm{SPI}$, and BWI. The key results of the geotechnical assessment are summarized below.

No correlations could be determined between these three grinding hardness properties, and therefore each parameter had to be assessed individually.

- Variability of the crushing index data is quite high within and between lithologies and is dominated by lithology as indicated in Table 13-9.- The SPI results are dominated by lithology, with the differences between lithologies being significant. Based on analysis of the variance of the data, four separate categories were defined and used to populate the block model. These are summarized in Table 13-10.
- Lithology was determined to be the significant variable influencing ball work index (Table 13-11). Within a lithology, the variance in results was quite low, except the SHL and MD lithologies, due to a small number of test results.

Table 13-9: Orebody Estimation of Crushing Index (Ci)

| Domain | Ci Mean | Std. Dev. | Sample Count |
| :-- | :--: | :--: | :--: |
| RDXL | 21.9 | 8.2 | 33 |
| Non-RDXL West $(<541,000)$ | 14.2 | 6.7 | 158 |
| Non-RDXL East $(>541,000)$ | 14.8 | 6.9 | 81 |
| All | $\mathbf{1 5 . 3}$ | $\mathbf{7 . 4}$ | $\mathbf{2 7 2}$ |

Table 13-10: Orebody Estimation of SAG Power Index (SPI)

| Domain | SPI Mean | Std. Dev. | Sample Count |
| :-- | :--: | :--: | :--: |
| SHL | 58 | 17 | 9 |
| RDXL | 71 | 14 | 33 |
| RDX | 85 | 22 | 79 |
| Remaining Lithologies | 95 | 21 | 152 |
| All | $\mathbf{8 8}$ | $\mathbf{2 3}$ | $\mathbf{2 7 3}$ |

Table 13-11: Orebody Estimation of Bond Ball Work Index (BWI)

| Domain | BWI Mean | Std. Dev. | Sample Count |
| :-- | :--: | :--: | :--: |
| RDX + RDF + MD | 15.5 | 1.3 | 107 |
| GWK + SHL | 14.6 | 1.5 | 48 |
| RDA | 13.8 | 1.3 | 46 |
| RDXL | 14.4 | 1.1 | 33 |
| RDXB | 16.4 | 1.2 | 39 |
| All | $\mathbf{1 5 . 0}$ | $\mathbf{1 . 5}$ | $\mathbf{2 7 3}$ |# NONAGOLD 

## MCF2 Grinding Circuit Design Method and Capacity Definition

During the first quarter of 2007, pilot flotation testing was carried out at SGS-Lakefield to assess the potential of a MCF2-style flowsheet to improve confidence in the overall gold recovery and economic value of the ore (Figure 13-3). The MCF2 flowsheet incorporates two separate stages of grinding and flotation. An economic evaluation was completed, and it was decided to use the MCF2 flowsheet as the basis of the circuit design utilizing the SABC configuration as the primary grinding step.

In 2007, a throughput confirmation study carried out by the mining team, indicated that an optimum ore production rate was in the order of $45,000 \mathrm{t} / \mathrm{d}$. In 2008, an updated resource model based on additional drilling was completed and the mill throughput was increased to $53,500 \mathrm{t} / \mathrm{d}$.

Mineralogical assessment, flotation bench-scale, and flotation pilot-scale testwork have indicated that the primary rougher feed particle $80 \%$ passing size distribution $\left(P_{80}\right)$ should be in the range 120 to $150 \mu \mathrm{~m}$, and that the secondary rougher feed $P_{80}$ should be in the range 50 to $60 \mu \mathrm{~m}$, to achieve high flotation gold recoveries. These assumptions were applied to the grinding circuit modelling and design.

Figure 13-3: Illustration of MCF2 Generic Flowsheet
![img-21.jpeg](img-21.jpeg)# NOVAGOLD 

Based on a common hardness data set and the conventional SABC circuit, three different grinding circuit modelling techniques were used (JKSimMet, CEET, and a power-based model referred to as DJB) to "calibrate" a CEET model to represent an agreed design model set-up.

At the 2008 target throughput of $53,500 \mathrm{t} / \mathrm{d}$, the design parameters collated in the steps above suggested that large mills and power input would be required. The mill size was approaching the production capacity limitations of the largest existing and operating SAG mill ( 40 ft diameter) and ball mill (18 MW).

Based on the adjusted CEET grinding model and using the "calibration" dataset, a single 38 ft SAG mill ( 20 MW ) followed by a single 18 MW ball mill could process $53,500 \mathrm{t} / \mathrm{d}$ to produce a primary flotation feed $\mathrm{P}_{80}$ of 120 to $150 \mu \mathrm{~m}$. This could then be followed by another 18 MW ball mill to produce the required secondary rougher flotation feed of $\mathrm{P}_{80}$ of $50 \mu \mathrm{~m}$.

In the design moving forward, therefore, a smaller 38 ft diameter SAG mill with a corresponding motor size of 20 MW was adopted, while still retaining two 18 MW ball mills.

## Plant Ramp-Up

The Project ramp-up schedule was defined based on operating data available to Barrick from other sites. The sites used for the comparison were selected on the basis being large SABC circuits with some additional downstream process sections, and where reasonable ramp-up data were available.

This ramp-up schedule provides an additional constraint to the CEET model for capacity scheduling. Figure 13-4 and Figure 13-5 show the assumed feasibility ramp-up schedules for the plant utilization and throughput, as a percentage of design.Figure 13-4: Plant Utilization Ramp-up Schedule for Donlin Feasibility Compared to Other Available Commissioned Sites
![img-22.jpeg](img-22.jpeg)

Figure 13-5: Plant Throughput Ramp-up Schedule for Donlin Feasibility Study Compared to Other Available Sites
![img-23.jpeg](img-23.jpeg)# NOVAGOLD 

## Downstream Autoclave Productivity Limits

Given that the milling circuit provides feed to flotation, and that the flotation concentrate generated is then processed through a site-based POX unit, CEET must consider downstream constraints to production. The POX facility has a design capacity of $648 \mathrm{t} / \mathrm{d}$ of sulphur.

Therefore, for example, during periods of high-grade sulphur content in the mill feed, the POX units limit the upstream (grinding circuit) plant throughput. Sixty days of downtime for complete autoclave re-lining have been incorporated into the LOM schedule every six to seven years.

## Mill Feed Schedule Definition

With the CEET model set up with the recommended grinding equipment sizes, the sulphur productivity limits, and the ramp-up schedule, it is then possible to model the mill feed schedule from mining on a block-by-block basis to determine the operating capacity of the milling circuit to process the ore on a period-by-period basis, taking into account all the plant constraints.

## Continuous Improvement Assumptions

Nominal continuous improvement targets have been defined over the LOM to account for anticipated productivity gains earned through operating experience and promoting a continuous improvement culture at the mine. These increases are not significant in size and are considered within the existing plant design limitations. The fixed constraints of the designed and installed grinding circuit power and oxygen plant capacity are not exceeded within any given period regardless of these improvements.

Table 13-12 summarizes the productivity improvement assumptions used for the scheduling of ore to the process facility.

Table 13-12: Productivity Improvement Assumptions for the Feasibility Study

| Production Period | Component | Assumption <br> (\% of Design) |
| :-- | :-- | :--: |
| Year 3 \& Onwards | Milling Circuit Capacity | 100.0 |
| Year 6 \& Onwards | Milling Circuit Utilization | 101.5 |
| Year 6 \& Onwards | Autoclave Sulphur Treatment Rate | 101.5 |
| Year 6 \& Onwards | Autoclave Circuit Utilization | 100.0 |

[[%~%]]
### 13.1.6 Flotation

## Introduction

Extensive bench and pilot flotation testwork had been carried out on samples of the Donlin ores from 1995 through to mid-2007.

The objective for the flotation circuit within the flowsheet is to provide high gold recovery $(+90 \%)$ to a high-grade sulphur concentrate (greater than $6.5 \%$ total sulphur content) for POX feed. Once the feed contains sufficient grade of sulphide sulphur as fuel to generate heat and achieve the required operating temperatures within the autoclave, there is little overall net benefit in increasing the sulphur grade of the concentrate any further. This is advantageous for the Project because the mineralogy of the ores produces a gold recovery in flotation concentrate increases significantly as concentrate grade is reduced.

For the Project, a general target of 7\% sulphur grade has been selected for the final flotation concentrate, noting that the autogenous grade is determined to be approximately $6.5 \%$ sulphur, varying slightly with changes in the solids / liquid ratio, the carbon, and arsenic grade of the autoclave feed; the gap between $6.5 \%$ autogenous grade and the target $7 \%$ grade is provided to allow for variability in feed and to minimize any requirement to add external heating to the autoclaves.

## Wood Review of Testwork from 1995 to 2006

The key conclusions and comments from the Wood review of the 1995 to 2006 flotation testwork are as follows:

## Bench Testing

- The testwork results indicated that producing a bulk concentrate was the optimum route to maximize gold recovery.
- A variety of reagent schemes were attempted. The best reagent system was using plant acid, copper sulphate, xanthate, and dispersant.
- Nitrogen-based flotation technology was tested extensively but provided no overall benefit.
- Adequate retention time was found to be very important. To achieve maximum recovery, a long flotation retention time, of 114 minutes, was found to be necessary.- The required particle grind size reflects the presence of the two different ore types in the feed. While the intrusive ores can tolerate coarser sizes in the range of 75 to $110 \mu \mathrm{~m}$, the sedimentary ores perform best in the range of 60 to $80 \mu \mathrm{~m}$ for the conventional flotation flowsheet.
- Mass pull from the rougher and scavenger circuits was dictated by entrainment of clays during the long residence time of the flotation. With the use of dispersants, lower flotation feed pulp densities and cleaning, the overall mass pull to final concentrate could be decreased to approximately $15 \%$.
- The process development testwork indicated that froth recovery was a critical factor. Froth recovery can be enhanced by using crowding cones in the flotation machine and through launder design.
- Because of the different flotation response of the ores, testwork was performed to assess the outcome of blending the two main ore types. Given adequate reagent dosages and residence times, it proved possible to produce high flotation recoveries with the LOM test blends provided for the testwork.


# Flotation Pilot-Plant Testing 

- Extensive testwork was performed in 2004 and 2006 leading to the demonstration that a recovery of $91 \%$ to $92 \%$ on a LOM lithology blend was possible, confirming the performance of the conventional rougher / scavenger flowsheet under continuous operation.


## Mineralogy Summary

In summary, the various mineralogy studies undertaken on many different flotation test samples by a number of different investigators present a relatively consistent themes concerning the aim to achieve high gold recovery ( $+90 \%$ ) to concentrate:

- Fine arsenopyrite must be recovered to final concentrate.
- Many ores (particularly Lewis ores) must be ground finer than $\mathrm{P}_{80}$ of $75 \mu \mathrm{~m}$ to improve the liberation characteristics.
- Pyrite hosts a significant portion of the gold as solid solution gold within the crystal matrix, and therefore must also be recovered to concentrate.
- Over-grinding of the liberated sulphides to less than $10 \mu \mathrm{~m}$ diameter particles would be detrimental to flotation recovery.- The liberation properties of the sulphides within the Donlin ores are somewhat variable.
- The expected concentrate sulphur grade from a Donlin flotation circuit producing high gold recovery ( $+90 \%$ ) is going to be relatively low, less than $10 \%$ sulphur content, because of the presence of low-grade composite particles of sulphide with gangue, floatable gangue (such as carbon and carbon/clay binaries), and non-floatable gangue as entrainment.


# Pilot-Plant Testing (G\&T Third Quarter 2006) 

Testwork was performed at G\&T in third quarter, 2006 to confirm process parameters on a blend (50\% Lewis Intrusive, 25\% ACMA Intrusive, and 25\% Sedimentary). This pilot flotation testing did not produce flotation gold recoveries (at required grade) that were comparable to those achieved from a bench test undertaken on the same sample. Pilot results showed gold recoveries in the range of $83 \%$ to $85 \%$ in the blended sample, compared to the bench flotation test at $91 \%$ to $93 \%$.

Subsequent testing was undertaken to explain this discrepancy through exhaustive re-testing of both the bench and pilot-plant flotation cells under different operating and test conditions. This work led to the conclusion that the froth conditions generated by the G\&T pilot plant were hindering recovery of sulphide composite particles to the concentrate. As a consequence, the importance of froth recovery was emphasized in design.

## Pilot-Plant Testing (SGS-Lakefield December 2006)

The SGS-Lakefield pilot run in December 2006 was initiated after the G\&T work was completed in 2006, when it was reasonably understood which key items were affecting gold recovery under pilot conditions.

The purpose of this pilot run was to demonstrate the ability of closing the gap between bench and pilot performance and to understand the performance of the new proposed flowsheet. This pilot-plant testwork was performed on available material and later followed up by another pilot run using freshly drilled core to eliminate any issues related to sample weathering.

It should be noted that the generally poorer flotation results were attributed to partially geologically oxidized ore in some of the upper areas of the deposit, as evident from the 2007 variability testing. This was not understood at that time, and therefore the December 2006 composite sample included material that was geologically oxidized.From the pilot-plant run approximately $91 \%$ gold recovery to a $7 \%$ sulphur concentrate was achieved compared to a bench test result of $93 \%$ recovery on a LOM lithology blend. This was a significant improvement from the earlier pilot work in 2006.

At this point in the study, to further improve the overall performance of the flotation circuit design, an alternative MCF2 flotation configuration (Figure 13-6) was considered, and some comparative bench testing of this option commenced.

Figure 13-6: Comparison of SGS-Lakefield Dec 2006 Key Bench and Pilot-Plant Results
![img-24.jpeg](img-24.jpeg)

# Bench Testing of MCF2 Alternative Flowsheet 

In early 2007, a series of bench flotation tests were initiated to explore the potential benefit of the MCF2 circuit configuration.

Initial tests were conducted by SGS-Lakefield at a nominal grind of $\mathrm{P}_{80} 40 \mu \mathrm{~m}$ for the second stage product and with varying primary stage grind sizes. The results showed that the alternative MCF2 grind / flotation configuration was realizing a measurable improvement in gold recovery of approximately $2 \%$ at the same final concentrate grade as the conventional grind / float configuration.These tests also suggested that the primary grind size selection was not a key parameter and that there could be some flexibility in the final size selection for the stage of grinding.

Subsequent bench tests were then undertaken to attempt to quantify the effect of the secondary grind size on gold recovery. The results did not clearly define an optimal secondary grind target but a nominal $50 \mu \mathrm{~m}\left(\mathrm{P}_{80}\right)$ was selected for the subsequent MCF2 pilot run based on trends identified through previous mineralogical work.

# Pilot-Plant Testing, (SGS-Lakefield February 2007) 

A second SGS-Lakefield pilot-plant campaign was undertaken February to March 2007, with the primary aim to confirm pilot-plant recovery of the conventional flotation circuit on a LOM lithological blend of freshly-drilled core.

The pilot runs produced on average $92.8 \%$ recovery to a $7 \%$ sulphur concentrate grade compared to the bench tests, which indicated $\sim 94.0 \%$ recovery. The second series of pilot runs was undertaken and confirmed that a mild steel primary mill with high chrome media could be used in lieu of the original stainless steel mill with high chrome media. A third series of pilot tests was undertaken where the scavenger concentrate was reground before cleaning. A slight improvement in the grade / recovery profile was evident. A fourth series of pilot tests was conducted to evaluate the MCF2 configuration. A clear trend of improved recovery is evident. At a concentrate of $7 \%$ sulphur grade, the recovery difference between MCF2 and conventional flotation is $\sim 1.8 \%$. This compares reasonably well to the $\sim 2 \%$ recovery improvement indicated by the initial MCF2 screening bench test results.

Based on the Phase 2 piloting at SGS-Lakefield, it was recommended that the MCF2 option be selected evaluated as a potential base case for the Donlin feasibility grinding / flotation circuit design.

## Variability Testing (SGS-Lakefield, Second Quarter, 2007)

The flotation variability testwork program consisted of a total of 149 flotation tests using 102 different test samples selected to cover a range of different lithologies and geological domains from core drilled throughout 2006. The number of samples selected for each lithology was based on the proportion of the orebody represented by that lithology.

Of the 102 samples, 22 were characterized as having some form of partial geological oxidation, and the remaining 80 were considered unoxidized fresh rock. Two types of variability bench-scale flotation tests were carried out, a modified Minnovex Flotation Test (MFT), and a conventional bench flotation test (CFT).Analysis of test data indicated:

- RDX, RDA, RDXL, and MD lithological domains appear to behave similarly in terms of average and standard deviation, and together have an average flotation recovery of $\sim 96 \%$.
- GWK and SHL recoveries are, on average, lower ( $91.5 \%$ and $89.8 \%$, respectively), with a relatively large variation in performance.
- RDXB lithology is the worst-performing intrusive, with an average recovery of $94.8 \%$. This is characteristic for RDXB, which has relatively high graphitic carbon content compared to the other intrusive rocks.
- RDF is the best-performing intrusive rock, with an average gold recovery of $97.7 \%$ and relatively low variance in performance.
- The GWK domain dataset does exhibit a weak correlation of flotation recovery with both arsenic and gold grade, noting that there is a natural strong relationship between gold and arsenic head grades. Given the relatively poor correlation with the GWK dataset this type of relationship is not recommended to predict recovery for the GWK ores. Instead, a non-weighted average of the test data should be used.
- For the SHL test results, no obvious correlations are evident to improve recovery predictions, and a non-weighted recovery average should be used here as well.

Another methodology for characterizing the test samples is via geological domain, which is mainly based on physical location rather than rock type.

Examining the statistical representation of recovery data based on geological domain suggests:

- Samples from 400, ACMA, Akivik, and Aurora behave very similar, with an overall average gold recovery of $\sim 96.5 \%$.
- GWK and SHL gold recoveries are, on average, lower ( $91.5 \%, 89.8 \%$, respectively), with a relatively large variation in performance.
- Lewis is the worst-performing intrusive, with an average gold recovery of $94.3 \%$.
- Vortex is the medium-performing intrusive, with an average gold recovery of $95.2 \%$.

The Vortex geological domain is adjacent the Lewis domain; the Lewis geological domain has a high content of RDXB intrusive, and conversely, RDXB is concentrated mainly in the Lewis area of the deposit.# Effect of Geological Oxidation on Flotation Performance 

The upper portion of the Donlin orebody contains ore that shows some sign of geological oxidation or weathering. To quantify the potential impact of this oxidation on flotation, a series of 22 samples were selected. Results indicated that presence of some form of geological oxidation significantly affects the flotation performance. The average gold recovery is $72 \%$, with a relatively high standard deviation of $22 \%$ recovery.

Where there was insufficient sulphur content in the test sample to generate a $7 \%$ concentrate, gold recovery was determined at the $15 \%$ mass-to-concentrate point instead.

## Flotation Circuit Scale-up and Modelling for Feasibility Design

The conventional approach to designing flotation circuits focuses on the use of scale-up factors from bench-scale testwork to determine the residence time required for a full-scale plant. For Donlin ore, a modelling approach was adopted.

Two flotation simulators were tested. One is JKSimFloat developed by the AMIRA P9 Project and the second is FLEET (Flotation Economic Evaluation Tool) developed by Minnovex (now SGSLakefield).

JKSimFloat was the simulator used for Donlin flotation circuit design because of its robustness based on rigorous validation at various operations, including those with refractory and platinum group metal ore types relevant to Donlin ore. The JKSimFloat simulations predicted the Donlin pilot-plant results fairly accurately, especially with the addition of a cleaning circuit in the secondary rougher circuit.

Simulated results for a $53,500 \mathrm{t} / \mathrm{d}$ flotation circuit using the floatability parameters suggested a gold recovery of about $94 \%$ at a concentrate grade of $7.2 \% \mathrm{~S}$ for a two-row circuit configuration treating a throughput with head grade of $1.12 \% \mathrm{~S}$ and $2.37 \mathrm{~g} / \mathrm{t}$ of gold. Flotation cell sizes of $300 \mathrm{~m}^{3}$ were selected based on lip loading data.

[[%~%]]
### 13.1.7 Pressure Oxidation (Pox)

## Chemistry of POX and Hot Cure

POX in gold processing generally refers to the oxidation of gold-bearing sulphide minerals to metal sulphates using a combination of heat (typically $200^{\circ} \mathrm{C}$ to $230^{\circ} \mathrm{C}$ ), acid, and oxygen sparging in a specifically designed pressure vessel. The breakdown of the sulphide particleseffectively releases the gold locked within the mineral matrix, rendering it amenable to leaching by cyanidation.

# Batch Autoclave Testing (Dynatec 2004) 

During 2004, Dynatec carried out bench-scale autoclave testing of four composite samples, ACMA Intrusive, ACMA Sediment, Lewis Intrusive, and Lewis Sediment. The scope of the test program included kinetic and locked-cycle mass balance POX tests on the concentrates, followed by neutralization tests on the POX discharge liquors and carbon-in-leach (CIL) cyanidation tests.

The concentrates were relatively fine, with $\mathrm{P}_{80}$ levels of 33 to $41 \mu \mathrm{~m}$ ( $82 \%$ to $89 \%$ minus $44 \mu \mathrm{~m}$ ), and were tested without further size reduction for comparison purposes. Direct CIL cyanide leaching of the unoxidized feeds yielded gold extractions between 3\% (ACMA Sedimentary rock) and $11 \%$ (Lewis Intrusive rock).

Higher autoclave oxidation kinetics were observed at $210^{\circ} \mathrm{C}$ and $220^{\circ} \mathrm{C}$ than at $200^{\circ} \mathrm{C}$. Gold extractions were highest from the solids oxidized at $220^{\circ} \mathrm{C}$. All subsequent POX testwork on all four concentrates were, therefore, conducted at $220^{\circ} \mathrm{C}$.

As shown in Figure 13-7, the sulphide sulphur oxidation kinetics was rapid, with more than $98 \%$ oxidation achieved within 30 minutes.

Gold extractions from the oxidized concentrates, as shown in Figure 13-8, were correspondingly high after 30 minutes of POX and improved marginally to their maximum values of between 95.1\% (ACMA Sedimentary rock) and 98.5\% (ACMA Intrusive rock) after 45 minutes of oxidation. With extended POX time, however, the gold extractions declined, most markedly for the sedimentary rock concentrates, which had relatively high organic carbon content.

A retention time of 45 minutes was selected for the POX in the subsequent material balance and locked-cycle testwork.

In the locked-cycle testwork, the POX tests were conducted at pulp densities approaching those anticipated for the discharge slurries in commercial autoclave operation. The extents of sulphide sulphur oxidation with the 45 minute POX retention time at $220^{\circ} \mathrm{C}$ exceeded $98 \%$, with more than half over $99 \%$. There was no systematic change in the oxidation extent with increasing cycle number, indicating that the recycled solution did not affect the sulphide oxidation.# NOVAGOLD 

Figure 13-7: Sulphide Oxidation Pressure Oxidation Kinetics at $220^{\circ} \mathrm{C}$
![img-25.jpeg](img-25.jpeg)

Figure 13-8: Gold Recovery Profiles from Pressure Oxidation at $220^{\circ} \mathrm{C}$
![img-26.jpeg](img-26.jpeg)

Analysis of selected solution samples for gold and silver indicated that these were below their respective detection limits of $0.2 \mathrm{mg} / \mathrm{L}$ and $1 \mathrm{mg} / \mathrm{L}$ in the POX discharge solutions.

Stirred tank CIL cyanide leach gold extractions varied from $90.3 \%$ to $98.8 \%$ for the four oxidized concentrates, with median extractions of $93.5 \%$ to $97.4 \%$.

Subsequent testing has indicated that oxidation rates and performance of the batch tests are strongly affected by the decision to pre-acidify the concentrate sample charge, or not, both at pilot scale and bench scale.# Batch Autoclave Testing (BTC 2006) 

A summary of the various tests undertaken on composite samples in 2006, indicating the key conclusions, is provided in the following subsections. This discussion is mainly limited to gold recovery performance.

## Baseline Tests

A series of batch tests was conducted to understand the potential impact of autoclave temperature, oxidation time, pre-acidification, oxygen concentration, and thiocyanate (SCN) concentration on autoclave performance.

The bench autoclave tests (BTAC) for the various concentrate samples were run at a temperature of $220^{\circ} \mathrm{C}$. Recoveries in the order of $\sim 95 \%$ to $99 \%$ were achieved at the 45 minute POX retention time for all ores tested.

The results indicate that oxidation rate increases with POX temperature and that of the temperatures tested, the optimum in terms of gold recovery profile is $230^{\circ} \mathrm{C}$, being marginally better in performance than at $220^{\circ} \mathrm{C}$. No definitive explanation can be provided to explain the unusual decrease in performance of the $240^{\circ} \mathrm{C}$ test result.

In conclusion, autoclave temperatures of more than $192^{\circ} \mathrm{C}$ are required to achieve $>92 \%$ gold recovery within a nominal 1 hour autoclave residence time, and temperatures of $220^{\circ} \mathrm{C}$ to $230^{\circ} \mathrm{C}$ provide maximum recovery values.

Some preliminary BTAC tests were undertaken to evaluate the potential impact of SCN dosed into the feed slurry on the CIL gold recovery of the autoclave products. No detrimental impact on recovery was indicated

From the autoclave test data, it was noted that gold recovery improved with increasing POX residence time. Therefore, experiments were undertaken to test the potential application of higher-temperature POX $\left(230^{\circ} \mathrm{C}\right.$ to $\left.240^{\circ} \mathrm{C}\right)$. It was seen that gold recovery does improve with extended autoclave time and that this improvement is indeed accelerated at $240^{\circ} \mathrm{C}$.

## BTAC Testing on 2007 Phase 1 Composite Concentrate Sample

During January 2007, the BTC carried out a series of BTAC tests on a sub-sample of the concentrate generated from the SGS-Lakefield December 2006 pilot flotation test program. The test program aimed to investigate the POX characteristics of the new composite concentratesample against previous testwork, and to investigate the effect of autoclave parameters on POX performance. The best result was at $220^{\circ} \mathrm{C}$ with 45 minutes of residence time.

# Pilot-Plant Testing (BTC 2006) 

Four phases of autoclaving pilot tests were carried out during the latter half of 2006. In discussing the gold recovery aspects of the pilot-plant results, all testwork phases undertaken in 2006 are considered as one, for clarity.

## Pilot Campaigns at $220^{\circ} \mathrm{C}$ and $225^{\circ} \mathrm{C}$

A series of $220^{\circ} \mathrm{C}$ and one $225^{\circ} \mathrm{C}$ pilot campaigns were also carried out during the latter part of 2006. The three tests undertaken that generated final CIL gold recoveries of less than $95 \%$ were due to oxidation rate performance issues. Based on earlier results, a final run was attempted at $225^{\circ} \mathrm{C}$, incorporating pre-acidification of the concentrate feed, with an extended residence time. The purpose was to determine under pilot conditions what recovery could be achieved at more complete oxidation levels. This run successfully demonstrated that the CIL gold recoveries of the autoclave residue in excess of $96 \%$ were possible.

## Pilot Campaigns at $240^{\circ} \mathrm{C}$

Previous batch tests carried out at $240^{\circ} \mathrm{C}$ indicated the potential for operating at this temperature and achieving high gold recovery. As for the $240^{\circ} \mathrm{C}$ test runs, high gold recoveries were achieved quickly, albeit with faster oxidation kinetics than at $220^{\circ} \mathrm{C}$. An improvement in recovery is evident, but the level of improvement is insufficient to achieve high gold recoveries under practical design constraints.

## Pilot-Plant Testing (2007 Phase 1)

During February 2007, an additional autoclave pilot campaign was undertaken at the BTC to verify the autoclave design parameters and potential gold recovery results for the 2007 FS. This pilot run attempted to explore the three different operating temperatures, $200^{\circ} \mathrm{C}, 210^{\circ} \mathrm{C}$, and $220^{\circ} \mathrm{C}$. Based on previous successes with pre-acidification in 2006, it was decided to utilize pre-acidification of the concentrate for each of these planned runs.

The selected residence times for unit operation were purposely set to be higher than design to try to achieve more fully oxidized conditions at the discharge than had been realized in previous campaigns, and to provide a set of data covering a large range of operating residence times.This coverage of residence time is possible by sampling each of the pilot-plant compartments and undertaking CIL tests on each sample.

A maximum gold recovery of $\sim 96.9 \%$ was reached in compartments 3 and 4 for the $225^{\circ} \mathrm{C}$ test run, representing a residence time of 50 to 55 minutes. For the $220^{\circ} \mathrm{C}$ run, a maximum recovery of $95 \%$ to $96 \%$ was achieved in compartment 5 at a residence time of $\sim 55$ minutes. It can be seen that CIL gold recovery drops significantly towards the discharge of the autoclave, after peaking at $96.0 \%$ to $96.4 \%$ near compartments 3 and 4 . As the operating temperature of the autoclave is lowered; the required residence time for reaching maximum gold recovery increases.

# Pilot vs. BTAC Testing 

It is well known that the BTAC test has inherent limitations in its ability to replicate a continuous autoclave operation. The continuous introduction of fresh feed into a continuously operating facility, the continuous transfer of new feed to each stage (residence time distribution), and the need to provide the BTAC unit with acid solution in the feed to allow the oxidation reaction to "kick-start" all result in some important differences in the chemistry, and the timing of that chemistry occurring, between a BTAC test and a pilot test.

Pilot testing is considered the more appropriate test method to replicate the chemistry and kinetics of a production-scale autoclave and is regarded as best practice for definitive autoclave testing.

## Summary

The main results from 2007 Phase 1 pilot testing indicated that:

- CIL gold recovery achieved from the pilot autoclave is sensitive to the autoclave residence time where recovery is lower than optimum when autoclave residence time is either too short or too long.
- Autoclave operating temperatures of $220^{\circ} \mathrm{C}$ and $225^{\circ} \mathrm{C}$ provided the highest gold recoveries with the lowest autoclave residence times, with optimum residence time of around 40 to 55 minutes.

Considering the target gold recoveries were demonstrated only on autoclave compartmental samples, not actual pilot autoclave discharge samples, it was decided to continue the pilot autoclave testing program into Phase 2.# Pilot-Plant Testing (2007 Phase 2) 

During June 2007, Phase 2 pilot autoclave testing was carried out at the BTC. The aim of the Phase 2 testwork was several-fold:

- To operate the pilot unit more closely to the design optimum autoclave residence time as determined from Phase 1
- To demonstrate that target CIL gold recoveries can be achieved on final products from the autoclave, not just on compartmental sub-samples
- To confirm potential downstream CIL gold recoveries
- To confirm the selected design criteria for the POX circuit for the 2007 FS
- To provide more autoclave profile data for oxidation rates and gold recoveries.

The concentrate feed sample was obtained from material generated from the SGS-Lakefield pilot flotation test program undertaken in January 2007.

## Pre-Acidification

Concentrate pre-acidification reduced the carbonate content (inorganic carbon) of the concentrate from $0.35 \%$ to $0.05 \%$, representing approximate $86 \%$ dissolution of the contained carbonates.

## Sulphide Oxidation Performance

The pilot run investigated two different operating temperatures, $220^{\circ} \mathrm{C}$ and $225^{\circ} \mathrm{C}$.
For test runs W and X , the oxidation rates were reasonably fast and consistent, and that measurable sulphide oxidation was essentially completed by 37 to 42 minutes' residence time.

## Autoclave Discharge Gold Recovery Performance

Before the first set of discharge samples was collected, the autoclave was operated for approximately two hours, or approximately 2.5 turnovers, to allow it to come to near steady-state before sampling commenced. The autoclave then continued to operate for another 4 to 5 hours, with regular sampling.

The pilot autoclave operated at periods of high gold recovery, $96.1 \%$ to $97.3 \%$, at times, but then shifted and operated at $93 \%$ to $94 \%$, seemingly moving from one "recovery regime" to theother very quickly. It was found that if the autoclave residence time is permitted to exceed 50 minutes, then CIL gold recovery of the autoclave discharge drops to $93 \%$ to $94 \%$. Similarly, if autoclave residence time is too short, then recovery is also lower than optimum at $96 \%$ to $97 \%$. Optimum gold recovery, exceeding $97 \%$, is recorded at around 45 to 49 minutes.

# Autoclave Profiles Recovery Performance 

During the operation of pilot campaign runs W and X , four profile samples were collected through the autoclave, approximately every 30 minutes. The same trend of the effect of residence time on CIL gold recovery as seen for the discharge samples is clearly evident. Based on the results from these samples, the optimum operating residence time is confirmed in the range 37 to 47 minutes. Optimum gold recovery from the autoclave appears to correspond with the "just completed" extent of sulphide sulphur oxidation. Excess oxidation after that point is detrimental to gold recovery.

## Carbon Dissolution in Autoclave

Test results showed the organic carbon content (by assay) had decreased from $0.78 \%$ to an average of $0.57 \%$, meaning that $\sim 25 \%$ of the organic carbon has oxidized within the autoclave. Further, the graphitic carbon (by assay) showed negligible reduction in assay grade in the autoclave. Inorganic carbon in the feed was reduced to below assay detection limits by the pre-acidification process ahead of the autoclave, and so no apparent trends were discernible.

## Autoclave Vent Gas Sampling

During the Phase 2 pilot autoclave run, standard gas testing was performed on the main vent gases from the autoclave, ahead of the water scrubber, with the purpose of quantifying the oxygen, carbon dioxide $\left(\mathrm{CO}_{2}\right)$, carbon monoxide (CO), and total hydrocarbon (THC) generation rates from the autoclave that would be fed to the gas scrubbing system.

## Hot Cure

An additional testwork series on hot curing optimization was undertaken on the Phase 2 pilot autoclave products to confirm the proposed hot cure section design and to provide the latest information for future optimization.

The analyses of the hot cured solids and liquor components show that sulphur in the solids is indeed dissolving, with a corresponding decrease in solids mass and liquor sulphuric acid concentration and a consequential increase in liquor iron content. A decrease in lime# NOVAGOLD 

consumption is required for pH adjustment to 11 and that CIL gold recovery improves slightly at the six-hour residence time point. The hot cure circuit was designed with a residence time of six hours. Lime consumption of well-washed hot cure solids to pH 9 was relatively constant at around 3 to $4 \mathrm{~kg} / \mathrm{t}$ of hydrated lime.

## Hot Cured Product Counter-Current Decant Washing

A large sample of autoclave hot-cured product was collected from the Phase 2 pilot run and subjected to a series of washing tests followed by neutralization to $\mathrm{pH} 7,9$, and 11. Significant reductions in lime consumption occur up to $98 \%$ washing efficiency, the feasibility design target, and the addition of magnesium sulphate substantially increases lime consumption from 8 to $22 \mathrm{~kg} / \mathrm{t}$ when adjusting pH to 11 but does not greatly affect lime consumption for adjustment to $\mathrm{pH} \sim 8.8$ to 9.0 ; in this case, lime consumption increases from $\sim 5.7$ to $6.5 \mathrm{~kg} / \mathrm{t}$. Note that lime consumption is specified as kilograms of $\mathrm{Ca}(\mathrm{OH})_{2}$.

The benefit of operating a CIL circuit at $\mathrm{pH} \sim 9$, in terms of lime consumption, is also demonstrated from this work.

## Summary

The main results of the 2007 phase 2 pilot autoclave testing program were as follows:

- Product CIL gold recoveries of $96.6 \%$ can readily be achieved and recoveries of $97 \%$ are possible under optimum operating conditions, as indicated by the tests on the discharge samples as well as the autoclave profile samples.
- CIL gold recovery from the pilot autoclave is sensitive to the autoclave residence time. Gold recovery is slightly lower than optimum when autoclave residence time is too short because of incomplete sulphide sulphur oxidation. Recovery can also be lower than optimum if autoclave residence time is too long and oxidation is excessive.
- Autoclave operating temperatures of $220^{\circ} \mathrm{C}$ and $225^{\circ} \mathrm{C}$ provided good results with optimum residence times of 45 to 49 minutes for CIL gold recovery, based on the autoclave discharge samples.
- Measurable sulphide sulphur oxidation is essentially completed by 37 to 42 minutes residence time, as indicated by analysis of the autoclave profile samples.
- The selected hot curing time of six hours as per the feasibility design provides good lime consumption results and CIL gold recovery performance, but dissolution of arsenic is evident, subsequently requiring precipitation in the following neutralization stage.# Autoclave Mercury Emission Testwork 

During a pilot run, two gas streams were sampled for mercury content in the flash pot vent stream and the autoclave vent stream.

The amounts of mercury vented through the flash system and the autoclave vent were $0.21 \%$ and $0.026 \%$, respectively, of the calculated mercury head in the concentrate.

The results from a second series of emissions testing indicated the presence of very little mercury emission in the combined gas streams ( $0.003 \%$ of feed mercury content), with the gas and scrubber mercury contents being close to assay detection limit.

Despite the low measurements, a mercury abatement system has been designed to comply with the December 2010 US EPA National Emissions Standard for Hazardous Air Pollutants for gold ore processing and production facilities.

[[%~%]]
### 13.1.8 Neutralization

## Introduction

The oxidation of pyrite and other naturally occurring sulphides generates sulphuric acid and other metal sulphates within the autoclave and hot curing circuits. These species need to be neutralized and precipitated into a stable form to ensure that the final tails from the plant have a low soluble metals content, and is also at approximately neutral pH .

Typically, limestone (calcium carbonate) and hydrated lime (calcium hydroxide) are utilized for this neutralization duty. Limestone is used for the first part of the pH adjustment while the final pH adjustment to 7 (for acidic liquor neutralization) and 9-11 (for CIL feed) is carried out with hydrated lime as $\mathrm{Ca}(\mathrm{OH})_{2}$, which is a more reactive neutralizing reagent.

Metallurgical studies were undertaken to determine the potential neutralization capacity of the flotation tails stream and also of an identified local natural source of low-grade carbonates known as calcareous sandstone (CSS). This local material was composed of ferroan dolomite, ankerite, calcite and siderite in decreasing levels.

The orebody itself has a relatively high carbonate content of $2.33 \%$ reported as $\mathrm{CO}_{2}$ (or $3.18 \%$ reported as $\mathrm{CO}_{3}$ ) over the LOM compared to a sulphur content of $1.13 \% \mathrm{~S}$. This represents a stoichiometric ratio of carbonate to sulphur of 1.49. Therefore, there is sufficient, or rather, excess alkali in the ore available to neutralize the sulphates generated from the oxidation of allthe contained sulphur. However, this requires effective utilization (reactivity) of the measured neutralization content of the ore for the excess to be valid.

It has been shown through the testwork carried out, that with the provision of sufficient neutralization residence time, and the elevation of the slurry temperature in neutralization, good utilization of the contained carbonates in the ore is possible, resulting in the minimal amounts of lime needing to be consumed by the plant.

Further, it has been determined that the use of CSS is not required for neutralization of the acidic autoclave acid, due to effective use of the ore itself, as flotation tails, and at high pH (>5.0), CSS does not compete economically with imported lime. The local CSS resource instead serves as a back-up alkali source for the Project if, and as, required.

# Dynatec - November 2004 

During 2004 Dynatec tested the neutralization properties of the acidic liquors generated from bench autoclave tests, using flotation tails, limestone, and lime. The neutralization tests conducted with limestone and lime performed well, and at pH 8.0 all metals, except Mn and Mg , precipitated virtually completely from solution at generally below detection limit grade. The results however were not favourable from a lime consumption perspective.

## Placer Dome Technical Services 2005

During late 2005 and into 2006, Placer Dome Technical Services (PDTS) investigated the neutralization capacities of CSS and flotation tails. The results show that CSS with high $\mathrm{CaO} / \mathrm{MgO}$ ratios provided higher carbonate utilization compared to low ratio composites. The grind size did not have a large effect on the neutralization capacity of the CSS composites.

Testwork on flotation tailings showed higher carbonate usage from the intrusive materials compared to the sedimentary materials. Overall, the utilization of the carbonate within the tailings was very low.

## Preliminary Batch Neutralization Testing, 2006

A limited batch neutralization testwork program was initiated in mid-2006, aiming to improve quantification of the neutralization options for the project. The results indicated that the flotation tails / lime neutralization option, with extended neutralization residence time, was the most economic with the lowest total cost.# Pilot Neutralization 2006 

During October 2006 a pilot neutralization testwork program was undertaken. The acid solution used for the pilot test was produced during the POX pilot run conducted on 26 September 2006, with the autoclave operating at $220^{\circ} \mathrm{C}$ followed by hot curing of the slurry for at least 12 hours at $95^{\circ} \mathrm{C}$.

Flotation tailings were used as produced from G\&T being blended in the ratio of $25 \%$ ACMA Intrusive, 50\% Lewis Intrusive and 25\% Sedimentary.

Profile samples were routinely collected from the pilot-plant run, and then lime added to achieve a final pH of 7.0. At the given ratio of flotation tailings to concentrate ( 5.135 kg tailings per kg concentrate), neutralization of the dilute acidic POX solution using flotation tailings with a carbonate grade of about $1.8 \% \mathrm{CO}_{2}$ reached a pH of 4.0 to 4.5 after 12 hours. There was no significant increase in pH at longer retention times. Under the conditions tested, lime consumption after flotation tailings neutralization was approximately 4.5 g quicklime per litre of dilute acid solution, or 24 g of quicklime per kilogram of concentrate. It was also possible to use CSS at the rate of 1.6 kg of CSS per kg of concentrate.

## Neutralization Phase 1 Bench Testing, 2007

The acidic solution used for this testwork was generated from concentrate during the continuous POX pilot run on 6 February 2007. The concentrate was pre-acidified to pH of about two with sulphuric acid prior to the oxidation process. The campaign run was at $225^{\circ} \mathrm{C}$ with a 70 minutes retention time. The discharge slurry was then hot cured for about 24 h immediately following the POX process.

The hot cure slurry was washed with gypsum saturated water in a pilot counter-current decant (CCD) circuit at a ratio of 2:1. The overflow acidic filtrate was collected and used for batch and continuous tests. Initially, the pH of the diluted POX solution was approximately 1.0.

The flotation tailings used was a blend from a flotation piloting campaign in December 2006 obtained from SGS-Lakefield. The flotation tails used had a carbonate grade of $2.0 \% \mathrm{CO}_{3}$ and was sourced from the same pilot float feed sample that provided the concentrate used to generate the acidic liquor, via the pilot autoclave.

Bench tests at varying temperatures were undertaken to determine the effect of temperature on neutralization rate and utilization. Significant improvement in performance occurs as temperature increases. Temperatures of $55^{\circ} \mathrm{C}$ or greater allowed a pH of 6.0 to 6.5 to bereached, consequently resulting in the reduction of lime consumption to about 1 to $2 \mathrm{~g} / \mathrm{L}$ of diluted acidic liquor.

# Neutralization Phase 1 Pilot Testing, 2007 

Based on the bench tests, a pilot neutralization campaign was initiated in early 2007, using $70^{\circ} \mathrm{C}$ and two residence time selections of eight and 12 hours, and using the same acidic liquor and flotation tails as used for the bench testing.

The average pH profiles of both the eight and 12 hour residence time test campaigns are shown in Figure 13-9. Final pH levels of greater than 6.0 were reached with the flotation tails, for both the eight hour and 12 hour runs.

Figure 13-10 shows that lime consumption tests of profile samples taken from the pilot-plant runs. Required lime addition is less than $1 \mathrm{~g} / \mathrm{L}$ of diluted acidic liquor, at the end of the neutralization circuit.

Figure 13-9: 2007 Phase 1 Neutralization Pilot pH Profiles
![img-27.jpeg](img-27.jpeg)# NOVAGOLD 

Figure 13-10: Lime Demand Test Results of 2007 Phase 1 Pilot Samples, Plotted against Initial pH
![img-28.jpeg](img-28.jpeg)

## Neutralization Phase 2 Pilot Testing, 2007

With the undertaking of the Phase 2 pilot autoclave test program in June 2007, an opportunity arose to confirm the expected performance from the final feasibility neutralization circuit using a suitably designed pilot-plant set-up. In addition, this provided an opportunity to test the neutralization performance of the MCF2 pilot flotation tails. The design of the neutralization pilot circuit closely followed that of the actual feasibility circuit design, with the following key parameters:

- Four float tails neutralization tanks
- One lime neutralization tank
- Six hours' residence time $\sim$ optimization based on testwork
- Operating temperature of $55^{\circ} \mathrm{C} \sim$ based on heat balance
- Addition of CIL tails into tank one
- Mixing ratios of diluted acidic liquor and flotation as per the feasibility mass balance.

In addition to the six-hour residence time run, a second three-hour residence time campaign was undertaken to investigate the potential to reduce the size of the circuit for the detailed design phase.The source of the dilute acidic liquor was the overflow stream from the operation of the pilot CCD plant, washing Run W hot cured product. To be conservative, no calcium carbonate was added to this acidic liquor to correct for the pre-acidification process.

The source of the flotation tails was SGS-Lakefield flotation pilot PP-11, which incorporated the MCF2 grinding / flotation flowsheet. The sample used for the pilot test had a carbonate grade of $1.65 \%$ (as $\mathrm{CO}_{2}$ ), compared to the LOM predicted carbonate grade of $2.33 \%$ (as $\mathrm{CO}_{2}$ ).

The average pH profiles for the two test campaigns are shown in Figure 13-11. With the six-hour test campaign (i.e., matching the feasibility circuit design), a final pH of 6.75 was reached prior to the lime addition step. With the reduction to three hours' residence time, the final pH was 6.50 .

Figure 13-11: 2007 Phase 2 Neutralization Pilot pH Profiles
![img-29.jpeg](img-29.jpeg)

Figure 13-12 shows the results of the lime demand tests undertaken on profiles from the pilot plant. Lime consumption at the end of the neutralization circuit is less than $0.2 \mathrm{~g} / \mathrm{L}$ of diluted autoclave acid solution, noting that wash water flows have been increased in the feasibility design (more dilution of the acidic liquor) to improve washing efficiency of the autoclave discharge hot cure product.The results of the three-hour test campaign are encouraging, suggesting the potential to decrease the size of the neutralization circuit further. However, for the purposes of managing the potential variability of carbonate content in the ore, and also to provide time for the operations personnel to respond to unplanned grinding or flotation circuit shutdowns, the longer six-hour residence time circuit continues to be the recommended design.

Figure 13-12: Lime Demand Test Results of 2007 Phase 2 Pilot Samples, Plotted against Initial pH
![img-30.jpeg](img-30.jpeg)

# Neutralization Variability Testing 

During July to September 2007, a variability neutralization testwork program was initiated at SGS-Lakefield. The program had the dual aim of confirming the potential differences in neutralization performance of the varying lithologies and of developing a confident relationship between lime consumption (for final pH trim to 7) and the feed samples carbonate grade.

SGS-Lakefield generated a synthetic dilute autoclave acid based on the prediction of key species content from the near-final MetSim model's prediction of that stream. Flotation tails samples from the recently completed flotation variability program were used as the source of neutralizing solids.

Figure 13-13 is a summary chart of the results of the tests completed.Prediction of lime consumption for acidic liquor neutralization for the operating cost estimate is based upon the relationship between lime demand and flotation feed carbonate grade developed from this test data.

Figure 13-13: Plot of Neutralization Variability Testing Lime Demand Results at 6 Hours' Residence Time
![img-31.jpeg](img-31.jpeg)

[[%~%]]
### 13.1.9 Carbon-In-Leach (Cil)

The following subsections summarize the processes of cyanidation and carbon adsorption, and then describe the results of the various testwork programs completed on the Donlin ores.

## Testwork Introduction

Extensive cyanidation testing has been undertaken on samples of Donlin ores, at various points in the flowsheet, since 1995.

Cyanidation of unoxidized Donlin ores, with or without the presence of activated carbon, consistently yields very low gold recoveries of $5 \%$ to $30 \%$, either as flotation feed, flotation tails, or concentrate. This is characteristic of an ore where gold is predominantly associated with arsenopyrite or pyrite in solid solution form, like Donlin ore.The bulk of the cyanidation tests carried out to date have largely been on autoclave compartmental and discharge samples, where large numbers of relatively small samples are leached with high concentrations of carbon and cyanide. This is a diagnostic tool that enables the performance of various autoclave tests to be established without the added complication of the constraints that could be imposed by attempting to optimize leaching kinetics.

CIL gold recovery has generally shown to be more sensitive to the autoclave operating conditions (residence time, temperature) than to the operating conditions and methods applied in the CIL circuit. The target of the metallurgical design of the CIL circuit is rather to ensure that good CIL recovery performance is achieved on the material presented to it from the autoclave, with optimum reagent (lime and cyanide) usage.

# Key Metallurgical Aspects of Planned CIL Circuit 

The key metallurgical aspects of the final selected CIL circuit design are summarized as an introduction to the detailed discussions of the specific testwork results presented subsequently. The aim of the testwork programs was to define the operating characteristics and circuit design of the CIL circuit for treatment of CCD-washed autoclave product.

## Leach Circuit pH

The MetSim modelling and metallurgical testing have shown that the CIL circuit could operate well at a relatively low pH of 9 .

Increasing CIL pH above 9 in the CIL circuit will consume additional lime through the precipitation of magnesium sulphate in solution to magnesium hydroxide. The lime then re-dissolves back into solution when mixed back into the tailings and returns to the plant through tailings water recycle. To achieve the traditional CIL circuit pH levels of 10 to 11, all magnesium in the feed solution would need to precipitate completely. Reclaim water used in CIL is treated to remove magnesium and enable operation at conventional pH in CIL.

Assuming a CIL pH of $\sim 9$, lime addition is estimated to be in the order of 5 to $7 \mathrm{~kg} / \mathrm{t}$ of concentrate. The key component affecting both is the washing efficiency of the autoclave product CCD wash circuit. To maximize washing efficiency, a four-stage CCD circuit with a high wash ratio of $4: 1$ is used.# N0VAGOLD 

## CIL of Flotation Tails

During late 2006, BTC undertook CIL tests on the flotation tails from the G\&T pilot-plant campaigns. Table 13-13 summarizes the results. Based on the low head grade and low gold recovery, it is not economically viable to leach the flotation tails.

Table 13-13: CIL Results from Pilot Flotation Tails

| Ore Type | Head Grade <br> $(\mathbf{A u} \mathbf{g} / \mathbf{t})$ | NaCN Consumption <br> $(\mathbf{k g} / \mathbf{t})$ | Lime Consumption <br> $(\mathbf{k g} / \mathbf{t})$ | Float Tails Gold Recovery <br> $(\mathbf{( \% )}$ |
| :-- | :--: | :--: | :--: | :--: |
| Sedimentary | 0.75 | 0.88 | 0.7 | 16.0 |
| Lewis Intrusive | 0.51 | 0.56 | 0.6 | 33.3 |
| ACMA Intrusive | 0.47 | 0.61 | 0.7 | 27.7 |
| Blend | 0.59 | 0.79 | 0.7 | 30.5 |

## CIL Optimization Testwork - 2006

A composite of autoclave discharge material from the 2006 autoclave pilot test program was collected and leached under varying conditions. The gold recoveries achieved from this work were limited due to the nature of the product from the particular pilot run. The following conclusions are drawn from the CIL optimization work undertaken on the pilot autoclave product:

- Cyanidation in the absence of carbon is detrimental to final leach gold recovery.
- Using higher carbon loadings (pre-loaded with gold) does not adversely affect CIL gold recovery.
- Leaching at pH 9.2 does not negatively affect CIL gold recovery.
- Increasing the wash efficiency of the CIL feed slurry can significantly reduce reagents consumption rates.
- Leaching at too high a slurry density can negatively affect CIL gold recovery through unsuitable rheological properties of the slurry.

Samples of the detoxified CIL products were sent to the University of British Columbia for rheological testing, where it was seen that the slurry solids content (\% solids) had a significant impact on the viscosity of the slurry. Densities above $35 \%$ are considered potentially problematic.# CIL Pilot-Plant Testing 2007 

In early 2007, the BTC carried out a pilot CIL test run using CCD-washed pilot autoclave product from the 2007 Phase 1 autoclave pilot testwork program.

## Gold and Silver Recoveries

The carbon in the pilot CIL circuit was successfully loaded up to $4,000 \mathrm{~g} / \mathrm{t}$ gold, and two carbon transfers were undertaken.

A gold balance for the period of the pilot-plant run returned a calculated gold recovery of $93.6 \%$ with a tailings grade of $1.39 \mathrm{~g} / \mathrm{t}$. At the tank 5 position, ahead of the adverse influence of the higher carbon loadings in tanks 6 and 7, the solids assay was lower, at 1.2 to $1.3 \mathrm{~g} / \mathrm{t}$, representing a gold recovery of $\sim 94.0 \%$ to $94.5 \%$.

A bottle roll test of the CIL feed conducted at pH 11 yielded a comparative gold recovery of $93.9 \%$, indicating that the pilot operation provides equivalent recovery performance to that achieved in a batch bottle roll test, even with the pilot plant operating at a relatively low pH of 9 and using profile-loaded carbon.

Silver recovery from the pilot plant was low, at $29.7 \%$, which is typical of the leaching characteristics of silver from autoclave solids product due to its dissolution and subsequent precipitation as cyanide insoluble Ag -jarosite within the autoclave.

Leaching residence time of 20 to 24 hours over six tanks is an appropriate design for the continuous CIL circuit.

## Cyanide Consumption and Addition

The Donlin CIL feed is relatively free of cyanide consumers. This is characteristic of concentrate that has been subject to POX, where sulphur is oxidized completely to sulphate and base metals are dissolved into solution, and then CCD washing, which removes the dissolved metals from the autoclave product ahead of CIL.

Cyanide addition to the pilot circuit was 1.5 to $1.6 \mathrm{~kg} / \mathrm{t}$, with a consumption of 1.1 to $1.3 \mathrm{~kg} / \mathrm{t}$. Most of the consumption is likely to be from losses through HCN from the pilot CIL circuit, rather than consumption by species within the ore. HCN losses of this magnitude will not be experienced at full scale, and the HCN that evolves will be recovered via the ventilation and scrubbing system and returned to the CIL circuit feed. Cyanide addition to the pH 11 bottle roll tests on the pilot-plant feed was $1.2 \mathrm{~kg} / \mathrm{t}$, with a consumption of $0.05 \mathrm{~kg} / \mathrm{t}$.Assuming a CIL pH of $\sim 9$, cyanide addition of 0.7 to $0.9 \mathrm{~kg} / \mathrm{t}$ of concentrate is estimated. Consumption of cyanide will be lower at a higher CIL pH of 11.

# CIL Optimization Testwork - 2007 

A series of bench-scale tests was undertaken on products from the 2007 Phase 2 Pilot autoclave test program to attempt to optimize the CIL process.

## Cyanide Addition Optimization

A series of 24-hour bottle roll CIL tests were conducted at varying cyanide concentrations to determine the relationship between cyanide addition rate and gold recovery. Due to the limitations associated with undertaking low pH CIL tests at laboratory scale, a higher pH of 11 was used. CIL gold recovery was found to be not significantly affected at low cyanide concentration, and that the process is more economically favourable at low CIL cyanide concentration levels.

## Rheology

Additional rheology testing was undertaken on a detoxified CIL product from the 2007 Phase 2 pilot-plant work. Beyond a level of $35 \%$ solids the viscosity of the material was found to climb rapidly.

## Cyanide Detoxification Testwork

## Introduction

The $\mathrm{SO}_{2} /$ Air (sulphur dioxide cyanide destruction) process will be used for cyanide detoxification of the CIL tailings before this stream is transferred into the neutralization circuit.

## Testwork Summary - 2006

Cyanide detoxification testwork has been completed on CIL tails slurry generated from the 2006 pilot autoclave test program. Three types of cyanide detoxification methods were tested and found effective:

- Prussian blue (iron sulphate precipitation) - consists of adding autoclave discharge acid to detoxify the cyanide complexes- AVR (Acidification, Volatilization, Recycle) - consists of acid addition to drive the cyanide off as HCN and capturing the HCN for reuse in the circuit
- $\mathrm{SO}_{2} /$ Air testing - uses a combination of $\mathrm{SO}_{2}$ and air to detoxify the cyanide.

All three test methods were successful in reducing the cyanide levels to expected permit requirements. The $\mathrm{SO}_{2} /$ Air method was selected over the Prussian blue and AVR methods for cyanide detoxification.

For the $\mathrm{SO}_{2} /$ Air testing, the CIL tailings slurry was effectively treated in a single stage operating with approximately 60 minutes of retention and an $\mathrm{SO}_{2}$ dosage of $4 \mathrm{~g} / \mathrm{g}$ CNWAD. A pH of 8.5 was used for all tests since acid addition was required to lower pH levels. The addition of $\mathrm{CuSO}_{4}$ at $10 \mathrm{mg} / \mathrm{L} \mathrm{Cu}^{2+}$ was required for effective removal of cyanide that was present in the feed.

It was found that the content of arsenic in the liquor phase increased after $\mathrm{SO}_{2} /$ Air cyanide detoxification. This solubilized arsenic will be re-precipitated upon mixing the CIL tails into the neutralization circuit as a result of the presence of high levels of dissolved iron in this circuit.

[[%~%]]
### 13.1.10 Thickening And Counter-Current Decantation (Ccd) Washing

## Introduction

The feasibility flowsheet includes the following thickening / solids settling operations:

- Concentrate thickening after flotation
- CCD washing of pre-acidified concentrate with fresh water to provide optimal oxidation conditions
- CCD washing of hot cured autoclave product slurry with process water to reduce lime consumption ahead of CIL cyanide leaching
- Clarification of the portion of hot cure CCD overflow not reporting to pre-acidification to recover entrained gold values
- Thickening of flotation tailing prior to neutralization, to minimize dilution during neutralization and reclaim of process water.

Earlier flowsheets presented for Donlin ore also included a final tailings thickener to dewater the combined CIL tailing and neutralization residue prior to discharge to the TSF. This thickener was removed from the feasibility study flowsheet.The flotation tailings, which are a combination of the secondary rougher and the cleaner scavenger tailings, are de-watered before being directed to the POX to provide cooling.

[[%~%]]
### 13.1.11 Environmental Testwork

To provide samples that are reasonably representative of both the complete metallurgical processes, and also the ore, the testing of combined pilot-plant tailings was selected as the preferred testing method.

The final tailings consist of a blend of detoxified CIL tails (cyanide leached autoclave and hot cure product) and neutralized autoclave acidic liquor using the flotation tails stream.

The metallurgical process adopted for the project is favourable for the establishment of tailings that are not acid producing as a result of near-complete sulphide sulphur oxidation.

The average mill feed grade is $\sim 1.12 \%$ sulphur, with no significant sulphate sulphur present. The mill feed averages $2.51 \%$ carbonate as $\mathrm{CO}_{2}$, which is a molar excess of $37 \%$ to the contained sulphur in the mill feed after Year 2, meaning that the ore has excess carbonate content to sulphur content.

Mineralogy undertaken by SGS-Lakefield indicates that up to 23\% of the sulphate sulphur in the 2006 pilot final tails sample is in the form of jarosite, with $7 \%$ in the 2007 Phase 1 pilot-plant final tails and $8 \%$ in the 2007 Phase 2 pilot-plant final tails. Modifying the calculated ABA parameters, assuming that jarosite is an acid-forming component of the sulphate, indicates that the tailings will still contain an excess of neutralization capacity.

POX of arsenopyrite in the presence of excess iron is generally considered a best-practice process for generation of stable arsenic precipitates, in forms such as scorodite, for disposal into a TSF. Promoting the formation of stable precipitates is particularly favoured when molecular ratio of iron to arsenic ratio in the applicable process solutions exceeds 4:1. Within the plant feed, there is sufficient iron to provide the recommended molar ratio of 4:1 of iron to arsenic. It should be noted that the actual assay grade of iron typically is double the iron content that is accounted for by arsenopyrite and pyrite alone and is more typically at grades of 15,000 to $40,000 \mathrm{ppm}$.

The cyanide within the CIL circuit dissolves a portion of the mercury in the solids feed to the circuit. A portion of this dissolved mercury in the CIL circuit is adsorbed onto the circuit carbon and is then recovered from the carbon via stripping and carbon regeneration. However, the capacity of the circuit carbon to completely adsorb the mercury is limited and therefore a component of the soluble mercury remains in the CIL tails solution. This remaining solublemercury is then blended with the detoxified CIL tails into the neutralization circuit, which then reports to the TSF.

Reductions in soluble mercury content in recirculating plant waters can be achieved by addition of mercury precipitation reagents, which convert soluble mercury to a stable mercury sulphide $(\mathrm{HgS})$ product. This is currently practiced using the Cherokee Chemical UNR 829 reagent suite at operating mine sites in the U.S.

Based on the testwork completed, it is recommended that the process plant design includes a dosage facility for Cherokee reagent UNR 829 to permit addition to a recirculating water stream for precipitation of mercury in solution into a stable HgS solid. Doing so will eliminate potential build-up of mercury in the process water circuit.

Addition of UNR 829 was included as part of the feasibility study summarized in this 2020 update of the technical report.

[[%~%]]
## 13.2 Recovery Estimates

There are two components to defining the final recovery of gold to bullion from the proposed Donlin processing facility:

- Gold recovered from the flotation circuit to the flotation concentrate
- Gold recovered through leaching / adsorption (CIL) of the pressure oxidized (Autoclaved) flotation concentrate.

Due to the refractory nature of the Donlin ores and the relatively low grade of the flotation tails stream, it is not economically viable to recover gold from the flotation tails stream. Therefore, gold not recovered to the flotation concentrate is directed to plant tails and represents a final gold loss, along with the CIL tail residue post cyanide destruction.

The following sections will discuss both these aspects of the definition of final gold recovery from the proposed Donlin processing facility.

Please note for the purposes of this document the terminology MCF2 and MF2 are interchangeable as they pertain to the key equipment within the Donlin flowsheet.

[[%~%]]
### 13.2.1 Flotation

The MCF2 flowsheet is assumed to be the basis of the flotation circuit design and for all recovery figures referenced in this section, both as bench testing and pilot testing.In late 2006, sections of the Donlin deposits were identified as being geologically weathered (altered). While the extent of the geological oxidation is relatively low, there is still potential for significant effects on flotation recovery. Good flotation performance relies on the existence of un-oxidized sulphide surfaces for flotation collector adherence. Minor surface oxidation of sulphide particles can strongly affect recovery of gold to flotation concentrate performance. This is particularly the case for Donlin, where the fine nature of the arsenopyrite mineralization means that there is a potentially greater exposure of the sulphides to minor particle surface oxidation.

In anticipation of this potential issue, flotation pilot and variability testwork was undertaken separately on fresh ores or oxidized (partially) ores. The pilot flotation testing was undertaken exclusively on non-oxidized ores, as this represents the majority of the Donlin orebody (93\%). All partially oxidized ores were excluded from the pilot composite sample.

Variability bench flotation testing was then used to define the relative performance of the (partially) oxidized ores so that the overall deposit flotation recovery could be corrected to account for this smaller oxidized component of the orebody.

# Sulphide Ore MCF2 Pilot-Plant Results 

The MCF2 pilot-plant testwork campaign is recommended as the basis for selecting the overall recovery for flotation. The MCF2 pilot flotation test program simulates the entire MCF2 flotation flowsheet, incorporating the cleaning circuit, cleaner scavenger, and recirculation of the cleaner scavenger tails back to the secondary mill. This scope exceeds the work done in the batch flotation variability tests, which for practicality consist of roughing stages only.

The design of the flotation circuit is directly scaled from, and based upon, the pilot-plant flowsheet, incorporating an identical cleaner and cleaner-scavenger recycle circuit configuration.

The sample selected for the MCF2 pilot campaign was sourced from newly recovered HQ core drilled in 2006 and was compiled as a blend to represent the known LOM composition at the time of compositing based on rock lithology. Notably the sample compositing was not based on geological domain categorization, and known geologically oxidized affected core samples were purposely excluded from this composite sample.

The establishment of gold recovery from the MCF2 pilot program is achieved by means of fitting a linear regression line through all the MCF2 pilot survey results.No MCF2 test results are excluded from the data set used for the linear regression fit (Figure 13-14), and the gold recovery survey calculations incorporate both the primary rougher concentrate and the secondary rougher cleaner concentrate. Cleaner scavenger concentrate was recirculated to the feed of the secondary rougher.

At the design concentrate target of 7\% (total) sulphur, based upon linear regression fit to the MCF2 pilot-plant results, gold recovery of the blended composite sample tested is $94.64 \%$. This recovery forms the basis of the flotation gold recovery estimate but must be adjusted to account for effects of geological domain and alteration (oxidation extent).

Figure 13-14: MCF2 Pilot-Plant Campaign Survey Results
![img-32.jpeg](img-32.jpeg)

# Variability Testing - Non-oxidized Ores 

Two different methods of compiling and assessing the non-oxidized / intrusive ore variability flotation recoveries are discussed in this section, being based upon either lithology or geological domain. It is recommended that the intrusive variability samples be grouped based on geological domain, for the following reasons:

- Statistical variance of the variability test flotation recovery results grouped by geological domain is lower than sets of results grouped by lithology. Average statistical variance by geological domain is $2.48 \%$ R, compared to lithology groupings at $2.64 \%$ R.
- Geological domain assignment is spatially based, so that sample grouping by geological domain would better correct the orebody recovery predictions on a spatial basis toovercome any potential bias through variability sample selection being higher in density in better performing areas of the deposit (i.e., the AMCA deposit area).

- Calculation of overall flotation recovery by geological domain results in a more conservative estimate of the orebody average recovery compared to that based on lithological grouping.

The recommended recoveries per geological domain are summarized in Table 13-14.

Table 13-14: Summary of Average Flotation Recovery in Variability Testwork Program, by Geological Domain

| Geological Domain | \% Tonnes in Orebody <br> (\%) | Average Variability Flotation Recovery <br> (\%) |
| :-- | :--: | :--: |
| AKIVIK Intrusive | 4.6 | 97.61 |
| 400 Intrusive | 5.6 | 96.97 |
| ACMA Intrusive | 16.1 | 96.45 |
| AURORA Intrusive | 4.2 | 96.22 |
| VORTEX Intrusive | 11.6 | 95.19 |
| LEWIS Intrusive | 25.7 | 94.87 |
| GWK | 19.2 | 91.45 |
| SHL | 5.2 | 89.99 |
| OXIDE | 7.7 | 81.45 |
| Overall | $\mathbf{1 0 0 . 0 0}$ | $\mathbf{9 3 . 6 5}$ |

Adjusting the MCF2 pilot-plant recovery based on the geological domain variability flotation performance results in a minor upward adjustment of $0.16 \%$ for the unaltered ore types. The gold and sulphur head grades of the MCF2 pilot-plant composite are very close to the orebody average.

# Variability Testing - Oxidized Ores 

There is a large variation in flotation test results (i.e., gold recoveries to target concentrate grades) of the ores affected by oxidation. Therefore, to improve the accuracy of the application of the test data to the deposit characteristics, it is recommended that the relationship between sulphur grade and flotation recovery be used as the basis of recovery estimation.

Oxidation Wireframe Model and Mine Block Model
To better clarify the tonnes and grades of oxidation-affected ores within the deposit, a geological wireframe was developed by the Donlin Gold LLC geological team. They then usedthis model to categorize each mining block as either oxidized-affected ore or non-oxidized ore. This was undertaken on the $6 \mathrm{~m} \times 6 \mathrm{~m} \times 6 \mathrm{~m}$ block size, where a block was flagged as oxidized if $50 \%$ of the block or greater was located within the oxidation wireframe model.

With the mine blocks defined as such, it was then possible to allocate tonnes and grade of oxidized ore into a mill feed schedule. The oxidized-affected tonnage portion of the deposit is estimated by wireframe modelling to be $7.7 \%$.

# Mine Model and Stockpile Oxidation Allowance 

Ores will be stockpiled and subsequently reclaimed for mill feed during the course of the mine life. A sulphur degradation and flotation recovery factor of $-5 \%$ was applied to reclaimed material that was stockpiled for longer than one year.

## Final Flotation Recovery Model Definition

As discussed previously, Wood recommends that the adjusted MCF2 pilot-plant performance results be used for the un-altered (un-oxidized) areas of the deposit. The performance of the altered oxides is not changed. Because the pilot-plant sample was originally composited based on lithological domain, rather than geological domain, the results have been adjusted slightly to account for the variation in content between the pilot-plant sample and the latest estimate for the orebody.

The results from the variability testwork program can be used to assign different geological domains within the mine plan to improve the estimation of time-based cash flow from the mine. However, a slight adjustment is again required to match the MCF2 pilot result.

The proportionally adjusted flotation recoveries by geological domain are summarized in Table 13-15; these numbers have been adjusted slightly to reflect the ore release sequence in the feasibility study mine plan. Wood recommends that these recovery values be used within the mine plan where the geological domains are separately defined on a period-by-period basis.

No clear relationships between gold, arsenic, or sulphur head grades in flotation recovery were identified in the variability testwork.Table 13-15: Summary of Flotation Recovery in Variability Testwork Program by Geological Domain and Adjusted to MCF2 Pilot Result

| Geological Domain | \% Tonnes in Orebody <br> (\%) | Adjusted Recovery to MCF2 Pilot Result <br> (\%) |
| :-- | :--: | :--: |
| AKIVIK Intrusive | 4.6 | 97.77 |
| 400 Intrusive | 5.6 | 97.13 |
| ACMA Intrusive | 16.1 | 96.61 |
| AURORA Intrusive | 4.2 | 96.38 |
| VORTEX Intrusive | 11.6 | 95.34 |
| LEWIS Intrusive | 25.7 | 95.03 |
| GWK | 19.2 | 91.61 |
| SHL | 5.2 | 89.99 |
| OXIDE | 7.7 | 81.45 |
| Overall | $\mathbf{1 0 0 . 0}$ | $\mathbf{9 3 . 8 1}$ |

Considering the flotation recoveries of non-oxidized ores by geological domain, of the separately defined oxidized ores, and the impact of stockpiling, the entire flotation circuit can be determined. The overall LOM flotation gold recovery, based on the ore feed delivery schedule also taking into account feed grade, is calculated to be $93.81 \%$.

The production plan has been optimized to maximize the feed grade and cash flow in the early years of processing. This has been accomplished through using sequential mining of both the Lewis and ACMA pits along with the use of stockpiles and associated ore rehandling,

Figure 13-15 shows the flotation recovery trend across the mine life. Recovery drops in Year 25 due to an increase in oxide content in addition to the Lewis intrusive component in the mill feed. Recoveries steadily improve from Year 1 through to Year 9 due to decreasing oxide content in the mill feed. Flotation recoveries trend downwards from Year 10 to the end of the mine life in Year 27 due to increased content of oxide and Lewis intrusive material and a decrease in ACMA intrusive content. In Year 4 a dip in flotation recovery occurs due to a significant increase in processing of oxidized stockpiled material.# NOVAGOLD 

Figure 13-15: Flotation Recovery Trend throughout Mine Life
![img-33.jpeg](img-33.jpeg)

[[%~%]]
### 13.2.2 Pressure Oxidation (Pox)

## Introduction

Considering the varying nature of test results from the different test methodologies (bench, semi-continuous, or continuous), Wood recommends that the continuous testing method be used as the basis of estimating gold recovery performances from the Donlin ores. Continuous pilot testing is considered to best represent a real continuous autoclave operation and is the basis that Hatch Ltd has used for evaluating the expected gold recovery from the POX / CIL circuit. The Hatch Ltd evaluation predicts that an overall $96.6 \%$ recovery of concentrate can be achieved from the POX / CIL circuit under the testwork conditions.

To undertake variability testing on individual ore types, a test method that consumes less sample, such as bench-scale autoclave testing (BTAC) or semi-continuous autoclave testing (SCAC), must be used.

It is the degree of oxidation, the residence time required to achieve full oxidation, and the ability to control the autoclave oxidation level that influence the chemistry in the test autoclave vessel and therefore the final gold recovery.# Pilot-Plant Testing and Design Considerations 

Hatch Ltd. has reviewed the pilot autoclave testwork completed to date on the Project and has concluded that, based upon the proposed plant design, an overall gold recovery of $96.6 \%$ of concentrate can be achieved through the POX / CIL circuits on a continuous and long-term basis. This evaluation assumes that the concentrate sample used for piloting during the 2007 Phase 2 test program is representative of the overall orebody composition and that the conditions of the testwork are maintained in the final design. The result of this review has been used in the feasibility study summarized in this Report.

The deleterious components in the feed to POX, based on the historical BTAC testwork, are the sedimentary rock hosted ores themselves (shale and greywacke lithologies).

The proposed autoclave design for the Project incorporates a level control system on the slurry content of the pressure vessel to permit direct control of operating residence time in the autoclave. Therefore, based on the pilot testwork and the flowsheet design, Hatch Ltd. recommends that an overall POX and CIL recovery of target of $96.6 \%$ of concentrate be adopted and be applied equally to all ore types fed to the autoclave.

The nature of the orebody within the deposit is such that sedimentary ores will always be blended into the mill feed. The actual lithologies of the intrusive rocks present within the blend may change on a macroscopic basis, but the sedimentary rock content from greywacke and shale will remain an ongoing part of the blend. The inventory within concentrate storage tanks ahead of the autoclave feed tank will provide a mechanism to smooth short-term variability of sedimentary rock content.

[[%~%]]
### 13.2.3 Overall Plant Gold Recovery

To determine the overall plant recovery, both POX/CIL and flotation need to be considered together. The overall plant recovery averages $89.8 \%$ over the LOM.

[[%~%]]
## 13.3 Metallurgical Variability

Variability testing undertaken for the Project is discussed in Sections 13.1 and 13.2 under the various testwork programs.

[[%~%]]
## 13.4 Deleterious Elements

The likely deleterious elements identified in the metallurgical testwork programs are discussed in Sections 13.1 and 13.2 under the various testwork program headings.

[[%~%]]
## 13.5 Comments On Section 13

In the opinion of the Wood QP, the following conclusions are appropriate:

- The metallurgical test results and process design described in this report are essentially the same as those presented in the Donlin 2011 Technical Report.
- Metallurgical testwork and associated analytical procedures were performed by recognized testing facilities, and the tests performed were appropriate to the mineralization type.
- Samples selected for testing were representative of the various types and styles of mineralization in the Donlin deposits. Samples were selected from a range of depths within the deposit. Sufficient samples were taken so that tests were performed on sufficient sample mass.
- Mineralogical studies have shown that the gold is not visible. Testwork analysis indicates a high level of association of gold with arsenopyrite. Other sulphides such as pyrite and marcasite are also present, with reduced tenors of gold.
- Organic carbon, a potential preg-robber, is present in the sedimentary rock hosted ore. It is also present at lower levels in the intrusive rock hosted ores, believed to be in the form of well-ordered graphite. This form of organic carbon is possibly less likely to preg-rob.
- Testwork completed by SGS-Lakefield, Hazen, and G\&T under Barrick's supervision has shown that the Donlin ore requires pre-treatment prior to cyanidation to recover the gold. Process development work has determined that POX is the preferred method of pretreatment. Extensive testwork on composites has shown that acceptable gold recoveries can be produced through a combination of flotation pre-concentration, POX, and CIL cyanidation.
- Alternative flowsheets to flotation-POX-CIL were considered, including whole ore POX, roasting a flotation concentrate, and BIOX. None of these proved to be a viable economic alternative to the flotation-POX-CIL route.
- Additional metallurgical testwork was completed since 2011 including the programs in 2017 and 2018 at AuTec, FLSmidth, and TOMRA. Results show opportunity for plant optimization and potential reductions to process operating and capital costs. However,the recommendations from the testwork include the need for further testing, locked-cycle testing and continuous pilot plant, and more detailed economic evaluation of impacts of any new design parameters. Therefore, the results of the 2017 and 2018 testwork programs are not yet definitive and were not incorporated into the feasibility study summarized into this Report.

- Testing at TOMRA involved a First Inspection on a series of samples that confirmed ore sorting was not able to clearly distinguish between waste and ore. Ore sorting was eliminated from further analysis.
- The average Bond work index for the ore is in the range of $15 \mathrm{kWh} / \mathrm{t}$. Flotation work has shown that kinetics was initially rapid, but to achieve high recoveries, a combined primary and secondary rougher residence time over 100 minutes, together with a high reagent loading in the system, is required. Clay-like minerals will affect slurry viscosity and settling. Slurry density in the underflow will be less than $50 \%$ solids for the concentrate thickeners.
- Partially geologically oxidized (altered) ore in the deposit, up to $7 \%$ of the mill feed, is the key non-performing ore type in the flotation circuit. Degradation of the sulphide ore via oxidation in the stockpile will also affect the flotation recovery, applied as $5 \%$ recovery loss within flotation on all ores stockpiled for longer than one year.
- POX) has been shown to be successful in releasing the valuable constituents, under certain conditions. To optimize oxidation conditions, the water systems design has been modified to use the highest-quality water in the oxidation circuit. The autoclave design incorporates variable level control to provide better control over operating residence time.
- Areas of design modification during previous studies include detailing the mercury abatement systems in the gold cyanidation, elution, and refining circuits, and also the treatment of off-gases from the POX process to meet more stringent air emissions legislation. The current design includes dosing Cherokee reagent UNR 829 to recirculating water streams for precipitation of mercury in solution into a stable HgS solid.
- Metal production and recoveries from the flotation process have been adjusted upward slightly to account for changes in the new mine plan related to ore-type sequencing, and the Prussian blue process has been removed as a backup system to the $\mathrm{SO}_{2} /$ Air method for cyanide detoxification.
- Air flotation using the MCF2 flowsheet provides an estimated LOM average of $93.0 \% \mathrm{Au}$ recovery, with CIL recoveries after POX at approximately $96.6 \%$ for an estimated combined plant total gold recovery of $89.8 \%$. The concentrate pull will vary from $15 \%$ to $17 \%$ and that will result in a concentrate grade of 13.0 to $12.7 \mathrm{~g} / \mathrm{t} \mathrm{Au}$.

[[@~@]]
# 14.0 Mineral Resource Estimates

[[%~%]]
## 14.1 Key Assumptions / Basis Of Estimate

The geological model and resource model (DC9) are based on all drilling through the 2009 drilling campaign. The cut-off date for the DC9 model was 1 November 2009. As part of the September 2020 site visit and as a desktop study, Wood's QP reviewed the available results from the 2017 and 2020 drilling for consistency with the geological model and as part of the DC9 resource model validation.

The Mineral Resource estimate was prepared by Barrick and audited by Wood. Composites and 3D solid models were constructed utilizing Vulcan ${ }^{\circledR}$ commercial mine modelling software. The models extend a total of $4,020 \mathrm{~m}$ in the north-south direction, $4,020 \mathrm{~m}$ in the east-west direction and a total of 960 m in the vertical direction. The block model was created with a constant block size of $6 \mathrm{~m} \times 6 \mathrm{~m} \times 6 \mathrm{~m}$.

The coordinate system used for resource modelling is NAD83. Resource estimation uses a topographic surface derived from a 2004 survey by Aero-metric. The survey has an accuracy of $\pm 2 \mathrm{~m}$.

The Mineral Resource estimate has been reviewed by Wood as being current and is in accordance with the definitions in 2014 CIM Definition Standards and with the estimation best practices described in CIM 2019.

In the 2011 feasibility study, Mineral Resources were constrained within a LG optimized pit shell that considered all Measured, Indicated, and Inferred blocks assuming a gold selling price of \$1,200/oz and other assumptions stated in Table 14-4.

In 2020, this exercise was repeated using current assumptions shown in Table 14-5, including a \$1,500/oz gold selling price. This updated Mineral Resource optimization resulted in tonnes and contained gold in each Mineral Resource category within $1.5 \%$ of the 2011 tabulation as shown in Table 14-7, so the 2011 Mineral Resource values are considered valid and current as previously stated. This verification of the estimates is described in further detail in Section 14.13.

[[%~%]]
## 14.2 Geological Models

Three-dimensional solids for the geological model were constructed from polygons resulting from geologic interpretation of cross-section and level plans. Tools available in Vulcan ${ }^{\circledR}$ commercial mine design software were used to create the polygons representing the geometry# NOVAGOLD 

of the intrusive sills and dikes. These were digitized directly on a computer screen snapping to drill holes in section.

Once digitized, the polygons were used to develop 3D wireframe solids to incorporate geologic control into the grade model for the intrusive rocks. The solids were validated and checked for crossing errors, consistency, and closure prior to use. The solids were used to assign the corresponding geological code to the 3D block model.

To limit the size of the model, blocks were assigned a default code of greywacke (ROCK = 93) and were then overprinted with rock values according to the established priorities. Rocks assigned a greywacke code had the lowest priority value.

Rock codes are held as three variable types in the block model. The "ROCK" variable is assigned with values that include codes for lithology, overburden, and air. The "ROCK_EST" variable, although similar to "ROCK" does not include overburden and topography in order to allow unrestricted estimation of blocks at or near the topographic surface. The "ROCK_MINE" variable holds a simplified rock code nomenclature.

Nine mineral and geological domains were assigned to the database as shown in Figure 14-1.
Figure 14-1: Donlin Geology Domains
![img-34.jpeg](img-34.jpeg)

Note: Figure courtesy Donlin Gold LLC, 2011The geotechnical domain zone codes were input into the resource model, as required for the LG pit optimization, using domain solids provided by BGC on 27 June 2008.

A waste rock management category (WRMC) model was coded to identify overburden from the other WRMC codes.

[[%~%]]
## 14.3 Exploratory Data Analysis

The assay database contains over 187,000 samples of generally 2 m length. The geological model wireframes were used to define exploratory data analysis (EDA) envelope.

The raw gold assay statistics table shows that the average grade within the intrusive units is higher than the sedimentary units. Within the sedimentary units, the greywacke unit shows higher average gold grade than the shale or silt units.

Gold estimation domains are defined by three major geological units defined by the geological wireframes: intrusive units, greywacke unit and combined silt and shale units. Each gold estimation unit is further constrained by a grade shell generated by a gold probability model using a gold grade threshold of $0.25 \mathrm{~g} / \mathrm{t}$.

Wood's QP reviewed the EDA analysis and agrees with the findings.
The Donlin deposits have been divided into nine geological domains. The individual domains are described below; and the plan locations are shown in Figure 14-1.

- Domain 1, ACMA: The ACMA domain is dominated by a wide and compact sill sequence within a synclinal shale unit. Domain 1 is limited to the north by the Lo Fault and to the west by the ACMA Fault. The eastern and southern margins correspond to the edge of the Lower Vortex domain.
- Domain 2, Lower Vortex: The Lower Vortex domain is dominated by the lower extension of the RDA dikes and the far eastern extension of the ACMA RDX and RDA sills. It is limited to the north by the Lo Fault. Arbitrary lateral boundaries were digitized on either side of the dike system to separate it from the Lewis domain on the south and east, and from the ACMA domain on the west.
- Domain 3, Lewis: The Lewis domain is dominated by a series of wide dikes that intersected the shale sequence and produced wide masses of sills. Domain 3 is limited to the west by the Lower Vortex and Vortex domains.- Domain 4, Vortex: The Vortex domain corresponds to the upper portion of the Vortex RDA dikes. It is limited to the south by the Lo Fault. Arbitrary lateral boundaries were digitized on either side of the dike system to separate it from the Akivik and Lewis domains.
- Domain 5, Akivik: The Akivik domain is the upper faulted extension of the ACMA sill sequence and includes the RDXL dike. Domain 5 is limited to the south by the Lo Fault and to the west by the ACMA Fault. The eastern margin corresponds to the edge of the Vortex domain.
- Domain 6, Tortured Block: The Tortured Block domain is dominated by the ACMA sills that have been faulted into an indistinguishable mass of intrusive. It is limited to the north by the extension of the Lo Fault beyond the ACMA Fault (currently named the Hello Fault), to the west by the American Creek Fault, to the south by the Upper-Lo fault, and to the east by the ACMA Fault.
- Domain 7, Wedge Block: Wedge Block domain is dominated by the eastern extension of the ACMA domain RDA and RDXB sills. It is immediately south of the Tortured block below the Upper-Lo Fault. It is bound to the west by the American Creek Fault and to the east by the ACMA Fault.
- Domain 8, 400: 400 domain is characterized by a series of sub-parallel sills that are the western extension of the ACMA/Tortured domains. Domain 8 is located above the Lo Fault between the ACMA Fault and American Creek Fault.
- Domain 9, Aurora: Aurora domain is characterized by a series of sub-parallel sills that are the western extension of the ACMA/Tortured domains. Domain 9 is located below the Lo Fault and west of the ACMA and American Creek faults.


[[%~%]]
## 14.4 Density Assignment

As discussed in Section 11.3, three specific gravity values were used:

- Intrusive Rocks: 2.65
- Greywacke and shale: 2.71
- Overburden: 2.14

[[%~%]]
## 14.5 Grade Capping / Outlier Restrictions

[[%~%]]
### 14.5.1 Gold, Sulphur, Arsenic, Mercury, And Antimony Grade Caps

Raw assays in the database were examined for the presence of local high-grade outliers, and overall grade distributions were used to establish capping values. The raw assay data were grouped by rock type, and capping values for gold were determined for each major rock type. Total sulphur, arsenic, mercury, and antimony assays were not capped.

Assay capping values were selected from cumulative frequency plots for each major rock type. The distribution for all gold assays shows a well-defined lognormal population with no obvious breaks in the higher-grade trend. However, the grade-frequency trend becomes erratic above $30 \mathrm{~g} / \mathrm{t} \mathrm{Au}$, deviating from the lognormal approximation line. This is therefore the position at which the raw assay would be capped and represents a metal loss of $1.8 \%$.

Individual frequency distribution plots were generated to determine the appropriate grade cap for each rock type. The grade caps were applied to all raw assays prior to compositing. Capping grades used for each rock type are summarized in Table 14-1. Values represent all assays greater than $0.1 \mathrm{~g} / \mathrm{t} \mathrm{Au}$.

Table 14-1: Summary of Capping Grades for Major Rock Types

| Rock Type | Capping Grade <br> $(\mathrm{g} / \mathrm{t} \mathrm{Au})$ | Percentile <br> $(\%)$ | No. of Samples <br> Capped <br> $(\#)$ | Metal Loss <br> $(\%)$ |
| :-- | :--: | :--: | :--: | :--: |
| GWK | 25 | 99.07 | 127 | 3.61 |
| SHL/ARG | 30 | 99.58 | 15 | 6.97 |
| SLT | 20 | 99.14 | 17 | 10.04 |
| MD | 30 | 98.04 | 26 | 13.05 |
| RDA | 20 | 99.50 | 51 | 1.23 |
| RDF | 16 | 98.91 | 26 | 3.35 |
| RDX | 30 | 99.84 | 34 | 1.22 |
| RDXB | 28 | 99.71 | 22 | 0.99 |
| RDXL | 10 | 98.87 | 40 | 2.07 |

[[%~%]]
### 14.5.2 Neutralization Potential Grade Caps

Values for neutralization potential (NP) were also capped, as indicated in Table 14-2. Raw assays in the database were examined for the presence of local high-grade outliers, and overall grade distributions were used to establish capping values. The raw assay data were grouped by the domains established in the estimation of calcium, and capping values for NP weredetermined for each domain. High NP populations were noticed in the sedimentary rock domains and determined to be from the mafic dikes unit. Because the block model geology does not break out this unit, it was decided to cap the NP value in the sedimentary rock domain values below the mafic dikes population to prevent smearing of high NP values.

Table 14-2: Summary of Capping Values for Neutralization Potential, with COV and GT Lost

| Ca_RKTYP Domain Code | Description | Capping Grade <br> NP | COV <br> Uncapped | COV <br> Capped | GT Lost <br> (\%) |
| :-- | :-- | :--: | :--: | :--: | :--: |
| 1 | RDX, Other, RDF | 235.0 | 0.68 | 0.68 | 0.00 |
| 2 | RDA | 103.0 | 0.77 | 0.77 | 0.00 |
| 3 | RDXB | 130.0 | 0.73 | 0.59 | 2.36 |
| 4 | RDXL | 75.0 | 0.97 | 0.75 | 6.20 |
| 5 | SHL-NW, SW, SE | 125.0 | 1.03 | 0.56 | 11.66 |
| 6 | GWK-NW, SW, SE | 225.0 | 0.89 | 0.72 | 3.92 |
| 7 | SHL-NE | 250.0 | 0.59 | 0.55 | 1.20 |
| 8 | GWK-NE | $2,400.0$ | 0.59 | 0.52 | 2.47 |
| 9 | OVB | 1.5 | 0.20 | 0.85 | 85.29 |
| All Rock Types |  | $\mathbf{4 0 0 . 0}$ | $\mathbf{0 . 8 1}$ | $\mathbf{0 . 8}$ | $\mathbf{0 . 1 1}$ |

Note: COV = coefficient of variation, GT lost = grade-thickness removed

[[%~%]]
## 14.6 Composites

[[%~%]]
### 14.6.1 Gold, Sulphur, Arsenic, Mercury, And Antimony Composites

Composites were created down each hole at 6 m intervals. The composites were not broken at intrusive or sedimentary rock contact boundaries.

A composite database was generated for gold values where non-assayed (missing) intervals are set to zero. The non-assayed (missing) intervals include primarily trench data, RC data outside the resource area, or tops of holes within overburden. These account for approximately 1\% (1,958 out of a total of 193,237 Au assay intervals) of the entire assay database.

Two additional composite databases were generated; one for sulphur; one for arsenic, antimony, and mercury (multi-elements).

[[%~%]]
### 14.6.2 Neutralization Potential Composites

A separate composite database was generated for magnesium, calcium, $\mathrm{CO}_{2}$, and NP. Composites were also created down each hole at 6 m intervals. The composites were not broken at intrusive or sedimentary rock contact boundaries.

[[%~%]]
## 14.7 Gold And Sulphur Indicator Models

A gold indicator model was used to estimate gold, arsenic, antimony, and mercury grades based on gold composite data. A separate sulphur (S) indicator model was used to estimate sulphur. An indicator value of 0 or 1 was assigned to each 6 m composite interval based on nominal cutoff grades of $0.25 \mathrm{~g} / \mathrm{t}$ for Au and $0.50 \%$ for S .

Intrusive and sedimentary (shale and greywacke) rocks were modelled separately. All 6 m gold composites with an assigned rock code between 1 and 89 (all intrusive rocks) that were below $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ were assigned an intrusive indicator value of 0 . Data with an assigned rock code between 1 and 89 and an assay grade equal to or greater than $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ were assigned an intrusive indicator value of 1 .

All data with an assigned rock code of 92 (shale) or 93 (greywacke) and a grade below $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ were assigned a sedimentary indicator value of 0 .

Data with an assigned rock code of 92 or 93 and an assay grade equal to or greater than $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ were assigned a sedimentary indicator value of 1 .

Similarly, indicator values were assigned to the 6 m composite database for sulphur such that all data with an assigned rock code between 1 and 89 that were below $0.50 \% \mathrm{~S}$ were assigned an intrusive indicator value of 0 . Data with an assigned rock code between 1 and 89 and an assay of greater than or equal to $0.50 \% \mathrm{~S}$ were assigned an intrusive indicator value of 1 . All data with an assigned rock code of 92 (shale) or 93 (greywacke) and a grade below $0.50 \% \mathrm{~S}$ were assigned a sedimentary rock indicator value of 0 . Data with an assigned rock code of 92 or 93 and an assay grade equal to or greater than $0.50 \% \mathrm{~S}$ were assigned a sedimentary rock indicator value of 1 .

A block discriminator model was then developed by interpolating the assigned indicator values in the composite database in two passes for each major rock type (intrusive, shale, and greywacke) into the block model. The search distances for all passes were 175 m (Major axis z), 175 m (Semi-major axis $-y$ ), and 100 m (Minor axis $-x$ ). The orientation of the search ellipse was set to $024^{\circ}$ in $X, 0^{\circ}$ in $Y$, and $-68^{\circ}$ in $Z$. The inverse power of distance method (power = 2) was utilized for block indicator assignment.

In the first pass, a relatively large number of samples and drill holes were used to estimate the block probabilities. At least three drill holes were required to create an indicator value for each block based on the following sample selection criteria: a minimum number of six composites per estimate, a maximum of 13 composites per estimate, and a maximum of two composites per drill hole.As a result of the restriction on sample selection, some areas in the indicator model in each of the major rock types did not receive an indicator value in the first pass. A second indicator pass was performed with the same search and selection criteria as in the first pass, except that the minimum number composites required was reduced to four. This change required two drill holes per estimate instead of three to allow estimation of blocks that did not receive an indicator value in the first pass.

The resulting block estimates are values between 0 and 1, which are best considered as the probability that the given block contains grades above the threshold indicator value. For the gold indicator values, a 50\% threshold was used to separate blocks that have a high confidence of containing grades greater than the threshold value of $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ and those that do not. An indicator block value of 0.5 equates to a 50\% probability of a block having a gold grade equal to or greater than $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$.

The same search parameters and sample constraints used for the gold indicator were used to create the sulphur indicator model.

[[%~%]]
### 14.7.1 Overburden

The gold grade values in blocks that were coded as overburden were removed. This procedure was completed to prevent overburden blocks from having inappropriate gold values, or at least gold values that will not be recovered. Eliminating gold values in overburden prevents not only erroneous block valuations in the LG pit optimization, but also inconsistent volumetric resource reports.

[[%~%]]
## 14.8 Variography Performed In Support Of Probability Assisted Grade Model

The 6 m composites were used to develop indicator, correlogram, and relative pairwise variograms. The variograms were generated for all sample data and by domain using orientations along the average strike and dip of the mineralized zones identified both geologically and through stereonet analysis of oriented vein data. The analysis defines a plane striking $024^{\circ}$ and dipping $68^{\circ}$ to the southeast and forms the basis for search orientation during block estimation.

Indicator semi-variograms generated at $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ for the 6 m composites were fitted with a spherical model. Ranges of 30 m and 45 m were observed at $80 \%$ and $90 \%$ of the total sill variance.

[[%~%]]
## 14.9 Estimation / Interpolation Methods

[[%~%]]
### 14.9.1 Gold

Gold grades were estimated into the block model using an inverse distance to the third power methodology for the two populations:

- Internal to the mineralized envelope, defined as blocks with indicator values greater than or equal to $50 \%$
- External to the mineralized envelope, defined as blocks with indicator values less than $50 \%$.

Composites in the gold composite database were flagged as being either inside the $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ indicator threshold (i.e., passing through blocks with an estimated probability of at least 50\%) or outside the threshold. Intrusive indicator values were back flagged to the appropriate intrusive variable in the composite database. Indicator values in the sedimentary units were back flagged to the sedimentary rock variable in the composite database.

Interpolation of grade into the blocks was broken into five passes based upon increasing search distances. Gold grades were estimated separately for intrusive rocks, shales, and greywackes, and further sub-divided based upon whether blocks were internal or external to the mineralized envelope.

The initial grade estimation pass used a "box search" with a search range having the same dimensions as a single block. The range was increased for each successive estimation pass, out to a maximum of 125 m using an elliptical search. Search ellipse distances and sample weights were adjusted based on an anisotropic model. Once estimated, blocks could not be overwritten by subsequent estimation passes.

[[%~%]]
### 14.9.2 Sulphur

Sulphur grades were estimated using the same methods and parameters as for the gold grade estimation. A series of five passes was used for blocks inside and outside the $0.50 \%$ sulphur grade indicator populations. Separate estimation runs were generated for intrusive rocks, shale, and greywacke using search parameters with the same extent, orientation, and constraints as those for gold.

Sulphur data are less extensive than gold data; therefore, sulphur was not estimated for a number of blocks during the inverse distance estimation runs due to a lack of support. Regression curves were derived from the relationship between gold and sulphur for each of themajor rock types. The regression formulae were then used to assign sulphur values to non-estimated blocks based on the estimated gold grade. Where gold grade was not estimated, a value of $0.001 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ was assumed for the calculation.

[[%~%]]
### 14.9.3 Arsenic, Mercury, And Antimony

Arsenic (As), mercury $(\mathrm{Hg})$, and antimony ( Sb ) grades were estimated using methods and parameters similar to those for the gold grade estimation. Multi-element, 6 m long composites were flagged as being either inside the $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ indicator threshold (i.e., blocks with an estimated probability of at least $50 \%$ for intrusive rocks and $50 \%$ for shale and greywacke) or outside the threshold. A series of five passes was made to estimate blocks inside and outside the $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ grade indicator populations. Separate estimation runs were generated for intrusive rocks, shale, and greywacke.

Data available for $\mathrm{As}, \mathrm{Hg}$, and Sb are much less extensive than the data availability for Au and S . Regression curves were derived from the relationship between gold and each of these elements for each of the major rock types. The regression formulae were then used to assign $\mathrm{As}, \mathrm{Hg}$, and Sb values to non-estimated blocks based on the estimated gold grade. Where gold grade was not estimated, a value of $0.001 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ was assumed for the calculation.

[[%~%]]
### 14.9.4 Calcium, Magnesium And Carbon Dioxide

Values for Carbon Dioxide $\left(\mathrm{CO}_{2}\right)$, calcium, and magnesium were estimated into the block model based on an ordinary kriging method within nine estimation domains. The domains consisted of the four major intrusive rock types, two domains of shale, two domains of greywacke, and one domain of overburden. The $\mathrm{CO}_{2}$ and calcium estimates were used for waste rock management and environmental assessment and the magnesium estimate for metallurgical models.

Data for these elements are limited; therefore, blocks that could not be estimated were assigned the average value within each of the estimation domains.

[[%~%]]
### 14.9.5 Neutralization Potential

NP was estimated into the block model for use in the classification of WRMC. The NP database consists of 3,571 ABA samples within the block model limits. These sample intervals were composited into 6 m sample lengths prior to grade estimation. The block geology was backflagged into the database from the block model to assign geology to each interval.Estimates were generated using ordinary kriging methodology in eight passes for each of the identified domains. No new variogram models were generated; rather, the same models used in the calcium estimation were used for NP estimation. Block discretization was undertaken with a $4 \mathrm{~m} \times 4 \mathrm{~m} \times 2 \mathrm{~m}$ pattern. A minimum of two and maximum of six composites were used for the estimation. The search parameters are identical to those used for calcium estimation.

Blocks that could not be estimated were assigned a value based on regression analysis of NP against calcium. Regression curves were derived from the relationship between NP and calcium for each of the identified domains. The regression formulae were then used to assign NP values to non-estimated blocks based on the estimated calcium grade in each block.

[[%~%]]
### 14.9.6 Classification Of Waste Rock Management Categories

Several variables were included in the block model to aid with the geochemical classification of waste rock, based on ongoing waste rock characterization studies.

Acid Potential (AP) was calculated from the estimated total sulphur concentration $\left(\mathrm{S}_{\mathrm{T}}\right)$ where:

Acid Potential $=31.25 \times$ Estimated $S_{T}(\%)$
Neutralization Potential from carbonate minerals $\left(\mathrm{NPCO}_{3}\right)$ was estimated from:

$$
N P_{\mathrm{CO}_{3}}=0.85 \times N P+3.4
$$

To avoid a slight bias at low NP below $22.7 \mathrm{~kg} \mathrm{CaCO}_{3} / \mathrm{t}$ resulting from the regression equation, the calculated $\mathrm{NP}_{\mathrm{CO}_{3}}$ should not exceed analytical NP when NP is below $22.7 \mathrm{~kg} \mathrm{CaCO}_{3} / \mathrm{t}$. Therefore, the following rules were applied to the calculation:

$$
\begin{array}{ll}
\text { If } N P \leq 22.7 \mathrm{~kg} \mathrm{CaCO}_{3} / \mathrm{t}: & \mathrm{NPCO}_{3}=N P \\
\text { If } N P>22.7 \mathrm{~kg} \mathrm{CaCO}_{3} / \mathrm{t}: & \mathrm{NPCO}_{3}=0.85 \times N P+3.4
\end{array}
$$

The variables $\mathrm{NPCO}_{3}$ and AP were estimated for each block separately and were then used to calculate Acid Rock Drainage potential (ARD). ARD was modelled using the ratio $\mathrm{NPCO}_{3} / \mathrm{AP}$. Recommended ARD categories were assigned to each block according to calculated ARD potential.

The block model estimates for arsenic and sulphur values were used to calculate the ratio of arsenic to sulphur ( $\mathrm{As} / \mathrm{S}$ ) for each block. During the process, arsenic leaching was recognized as being ubiquitous throughout the deposit.# NOVAGOLD 

Blocks were classified into seven WRMC subdivided into potentially acid generating (PAG) and non-acid generating (NAG) groups, based on ARD potential.

[[%~%]]
## 14.10 Dilution

The DC9 model is undiluted. Grade dilution will be an operational consideration given the nature of the narrow, steeply dipping mineralized zones that characterize the gold system. Because of these narrow zones, the deposit was initially modelled with relatively small blocks to ensure that sufficient resolution was available to better characterize the deposit. Dilution and selectivity of mineralized material during Mineral Reserve estimation were determined using a Barrick in-house program referred to as SMUman. Dilution is discussed in detail in Section 15.2.

[[%~%]]
## 14.11 Classification Of Mineral Resources

The resource model was classified using distance to nearest composite as stored in the model blocks during the nearest-neighbour grade estimate. Classification distances are based on the $80 \%$ and $90 \%$ of variance from the omni-directional indicator variogram model. The classification methodology is summarized in Table 14-3.

Table 14-3: Donlin Project Mineral Resource Classification Methodology

| Category | Minimum Distance to Nearest Drill Hole (m) | Maximum Distance to Nearest Drill Hole (m) | Minimum <br> No. of Drill Holes | Intrusive Indicator Block Condition Criteria | Sediment \& Greywacke Indicator Block Criteria |
| :--: | :--: | :--: | :--: | :--: | :--: |
| Measured | - | 3 | Block pierced by drill hole | $\geq 0.0$ | $\geq 0.0$ |
| Indicated | - | 30 | $\geq 2$ | $\geq 0.0$ | $\geq 0.0$ |
| Indicated | 30 | 45 | $\geq 2$ | $\geq 0.5$ | $\geq 0.7$ |
| Inferred | 30 | 45 | $\geq 2$ | $\geq 0.0 \&<0.5$ | $\geq 0.0 \&<0.7$ |
| Inferred | 45 | 60 | $\geq 2$ | $\geq 0.5$ | $\geq 0.7$ |

[[%~%]]
## 14.12 Reasonable Prospects Of Eventual Economic Extraction

The extent of the 2011 classified material that might have reasonable prospects for eventual economic extraction was assessed by applying a LG pit outline using Whittle software to the Mineral Resources. This 2011 conceptual pit used the economic parameters summarized in Table 14-4 plus an average mining cost of $\$ 2.14 / \mathrm{t}$.The economic parameters shown in Table 14-5, plus an average mining cost of $\$ 2.64 / \mathrm{t}$, was used by Wood's QP in 2020 to validate the 2011 Mineral Resource estimate as current.

Process recoveries vary by rock type, domain, and degree of oxidation. Recoveries used for calculation of block values are summarized in Table 14-6.

Table 14-4: Assumptions used for Calculation of Block Value for Mineral Resources (Using 2011 Economic Parameters)

| Economic Parameters | Assumptions |
| :-- | :-- |
| Au selling price (resources) | $\$ 1,200 / o z$ |
| Grams per troy ounce | 31.10348 |
| Average process recovery | $89.5 \%$ (see Table 14-6 for variable recoveries) |
| Process cost | $\$ 2.1874$ * (sulphur grade) + 10.6485/t |
| Rehandle cost | $\$ 0.20 / t$ |
| G\&A cost | $\$ 2.29 / t$ |
| Refining, freight \& marketing (selling costs) | $\$ 1.85 / o z$ recovered |
| NSR Royalty | $4.5 \%$ * (Au price - Selling cost) |

Table 14-5: Assumptions used for Calculation of Block Value for Mineral Resources (Using 2020 Economic Parameters)

| Economic Parameters | Assumptions |
| :-- | :-- |
| Au selling price (resources) | $\$ 1,500 / o z$ |
| Grams per troy ounce | 31.10348 |
| Process cost | $\$ 13.78 / t$ |
| Sustaining Capital | $\$ 1.54 / t$ |
| G\&A | $\$ 3.66 / t$ |
| Rehandle Cost | $\$ 0.24 / t$ |
| Refining, freight \& marketing (selling costs) | $\$ 1.21 / o z$ recovered |
| NSR Royalty | $4.5 \%$ * (Au price - Selling cost) |
| Production Royalty | $\$ 0.50 / t$ processed |
| Average Process Recovery | $89.5 \%$ (see Table 14-6 for variable recoveries) |Table 14-6: Process Recoveries used in Calculation of Block Value for Mineral Resources

| Rock Type and Domain | Au Recovery <br> (\%) |
| :-- | :--: |
| Intrusive rocks - Akivik | 94.17 |
| Intrusive rocks - 400 | 93.55 |
| Intrusive rocks - ACMA | 93.05 |
| Intrusive rocks - Aurora | 93.61 |
| Intrusive rocks - Vortex | 91.82 |
| Intrusive rocks - Lewis | 91.52 |
| Greywacke (all domains) | 88.22 |
| Shale (all domains) | 86.66 |
| Oxide / weathered rocks - S grade $>1.8 \%$ | 87.90 |
| Oxide / weathered rocks - S grade $\leq 1.8 \%$ | $\left((8.7361 * 53-49.806 * 52+95.233 * 5+30.004\right) \times 0.966)$ |

[[%~%]]
### 14.12.1 Block Value Calculations For Marginal Cut-Off Application

The block value per tonne was then coded into each block of the resource model. This provides a variable marginal cut-off value based on processing costs, selling costs, and royalties, rather than gold grade alone. Measured, Indicated, and Inferred blocks were treated as potential process feed, while unclassified blocks were treated as waste. The processing cost is variable and is proportional to the sulphur content of the material being processed. To calculate a block value into each block of the resource model, a Vulcan script was written and used.

For those blocks with a resource classification of Measured, Indicated, and Inferred, the block value per tonne was calculated with the following equations:

```
General: Block Value = [Au grade] * [Recovery] * [Au Price less Refining and Royalty
Costs] - [Processing Costs + General and Administrative Costs + Rehandling Costs]
$/tonne
For Mineral Resources: Block Value = [Au grade] * [Recovery] * [\$1200-(1.85 + (\$1200
-1.85)*0.045)]} - [(10.65+(2.1874**5%)]+2.29+0.20] $/$ tonne
```

Therefore, for Mineral Resource reporting, the block value for the purposes of evaluation of reasonable prospects is the gross revenue, consisting of the total revenue minus production costs. For Donlin, any material that had a positive block value and was inside the LG pit shell was treated as having potential for reasonable prospects of economic extraction as a Mineral Resource. The applied cut-off was $\$ 0.001 / \mathrm{t}$ processed, which represents the marginal cut off strategy where the decision is made at the pit rim that revenue generated by processing a resource block exceeds the cost of processing.

[[%~%]]
## 14.13 Wood Qp Review

The gold block model grades were validated visually against drill holes and composites used in the estimation in section and plan view. A nearest-neighbour block model was also generated using 6 m composites to compare estimated grades in the $6 \mathrm{~m} \times 6 \mathrm{~m} \times 6 \mathrm{~m}$ block model.

Grade profile plots were generated for the $6 \mathrm{~m} \times 6 \mathrm{~m} \times 6 \mathrm{~m}$ Measured and Indicated resource model as a further validation check.

No estimation biases were noted from the validation reviews.

Gold, arsenic, antimony, mercury and sulphur grades were estimated using a combination of lithologic and indicator domains. Wood's QP considers the estimation procedure to be appropriate with the following comments:

- The block size of 6 m is good balance between the blocks being small enough to reflect the geometry of the lithologic domains, but large enough to be make construction of the model manageable. The 6 m block size is also a subunit of the selective mining unit (SMU) size used in the mine plan.
- Using intrusive, shale and greywacke domains is a key factor in the design of the modelling methodology, and appropriate as these domains match the different styles of mineralization. The intrusive units are more brittle, fracture more easily, and create openings for the mineralization. The sedimentary units tend to be more ductile during structural deformation, and the mineralization tends to be more confined with the competent greywacke a more favourable host than the shale.
- Using a discriminator or indicator model to separate mineralized from unmineralized material is appropriate as this design prevents higher-grade assays inside the mineralized domains from smearing into unmineralized domains, and restricts the lower-grade assays in the unmineralized domains from diluting the grades in the mineralized zones.
- The selection of the $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ discriminator between mineralized and non-mineralized material is lower than the cut-off grade, which adds an unquantified amount of dilution into the mineralized domains.
- Search orientations were the same for all estimations (strike $=024^{\circ}$ and dipping $68^{\circ}$ to the southeast) based on average orientation of the mineralized zones identified both geologically and through stereonet analysis of oriented vein data. Wood's QP recommends that the search orientations be reviewed for any localized variances and in areas where mineralization may be more disseminated, especially in the ACMA region.# NOVAGOLD 

Wood's QP reviewed the correlation, regressions, and implementation of the values and found the procedure to be reasonable given the strong non-linear correlations between the elements:

- The power regressions used to estimate sulphur, arsenic, mercury, and antimony where the data is too sparse to estimate directly is reasonable if the populations approximate a log normal distribution, and there is a good correlation between the elements and gold. However, using non-linear regression equation can cause biased estimation of these minor element grades. Wood's QP recommends using the latest drill results (2017 and 2020) to validate these minor elements non-linear based grade estimates to determine if there is any bias.

The resource model was classified using the distance to the nearest composite as stored in the block model during the nearest-neighbour grade estimation. Blocks were classified as Measured only if they were pierced by a drill hole. Indicated and Inferred classifications were based on a combination of distance to the nearest drill hole, the number of drill holes used to estimate a block, and the indicator values. Distance thresholds were based on the lag distances at $80 \%(30 \mathrm{~m})$ and $90 \%(45 \mathrm{~m})$ of the variance from an omni-directional gold indicator correlogram model generated using 6 m composites and a $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ discriminator.

Wood's QP reviewed the classification methodology and found the classification to be acceptable with the following observations:

- Wood's QP calculated gold grade correlograms in different direction and geologic domains, and compared the lag distances at $80 \%$ and $90 \%$ sill in the gold correlograms to the distances used for classification. Although there is considerable variability in the lag distances with the different directions, overall the average lag distances are similar to the lag distances used for classification. Wood's QP recommends to update the Indicated and Inferred Mineral Resource classification based on a gold grade variogram ranges at $80 \%$ and $90 \%$ of the sill which is a fairly common industry practice.
- Using the criteria that a block must be pierced by a drill hole to be classified as Measured is an outdated classification method and should be revised. Classification is designed to reflect the continuity of the mineralization, and establishing continuity requires at least two points of observation. Visual inspection of the blocks classified as Measured shows that the Measured material consists of isolated cylinders around single drill holes which does not convey any information about the lateral continuity of the mineralized trends.
- Wood's QP recommends to consider updating the Mineral Resource classifications following common industry accepted practice of requiring more than one drill hole to support Measured Mineral Resources rather than having cylinders of Measured surrounding and supported by one drill hole only. This is considered a minor practice issuesince Measured Classification represents less than $1.5 \%$ of the Measured plus Indicated materials.

Histograms of estimated gold and sulphur show artificially generated valley effect at around $0.25 \mathrm{~g} / \mathrm{t}$ for gold and $0.5 \%$ for sulphur. This is due to hard boundary conditions used for the gold and sulphur estimations. Wood's QP recommends using firm boundary between the lowand high-grade shells for Au and S to reduce the artificial valley effect in the block model.

Donlin Gold LLC geologists estimated grades using an inverse distance cubed method, with an increasing five-pass stepped search selection. This creates a model with very little smoothing that is not appropriate for mine planning without post processing or the addition of planned dilution. The bullet points below explain what occurs during post-processing of the resource model by using the SMUman for mine planning and Mineral Reserve estimation which compensates for this:

- Wood's QP checked the smoothness of the resource model inside the intrusive units within the high-grade Au shell using the discrete Gaussian model change-of-support (Herco). This change-of-support method accounts for in-situ dilution, that is, mixing of higher and lower grade within the same domain. The Herco analysis shows that the unreblocked $6 \mathrm{~m} \times 6 \mathrm{~m} \times 6 \mathrm{~m}$ resource model is under smoothed at the $1.0 \mathrm{~g} / \mathrm{t}$ cut-off grade. If no adjustments are made to the resource model, in the area anticipated to be mined on 6 m benches ( $12 \mathrm{~m} \times 12 \mathrm{~m} \times 6 \mathrm{~m}$ SMU size), the resource model underestimates the tonnage by approximately $7 \%$ and overestimates the gold grade by approximately $5 \%$ compared to the theoretical HERCO GT curves. In the area anticipated to be mined on 12 m benches ( $12 \mathrm{~m} \times 12 \mathrm{~m} \times 12 \mathrm{~m}$ SMU size), the resource model underestimates tonnage by approximately $13 \%$ while overestimates the gold grade by $9 \%$.
- The resource model, however, was post-processed for mine planning and Mineral Reserve estimation using Barrick's in-house software program (referred to as SMUman) which accounts for a mix of in-situ and contact dilution, mineralization loss, and helps identify areas where selective mining on 6 m bench ( $12 \mathrm{~m} \times 12 \mathrm{~m} \times 6 \mathrm{~m}$ SMU size) using the smaller SMU size has a positive economic benefit. Results from SMUman optimization which include a mixture of both $12 \mathrm{~m} \times 12 \mathrm{~m} \times 6 \mathrm{~m}$, and $12 \mathrm{~m} \times 12 \mathrm{~m} \times 12 \mathrm{~m}$ SMUs resulted in the addition of $7.1 \%$ waste tonnes which is in reasonable agreement with the Herco change-of-support analyzes.

Overall, the data and documentation are well organized and in good order. Estimation parameter files were checked for errors by Wood's QP and found to be created as intended.

[[%~%]]
## 14.14 Mineral Resource Currency Check

As part of the September 2020 site visit and as a desktop study, Wood's QP reviewed the results from the 2017 and 2020 drilling for consistency with the geological model and as part of the DC9 resource model validation. Drill sections with the results of the 2017 and 2020 drilling were compared on screen to what was predicted by the DC9 model. The new drilling results were consistent with the model such that no material change in the tonnes or grade of the Mineral Resource statement would be expected when these latest drill holes are incorporated into an updated resource model.

As part of the validation checks, Wood's QP reran the constraining pit shell using current economic parameters. A comparison of the tabulated resources using the 2020 economic parameters to the 2011 Mineral Resource showed very minor differences (Table 14-7). Therefore the 2011 Mineral Resource estimate still has an effective date of 11 July 2011 (cutoff date for the technical and economic parameters used to establish reasonable prospects of eventual economic extraction), but is considered current since latest technical and economic information, if included in the estimate would not materially change the estimate.

The overall differences indicated in Table 14-7 are small and well within the expected measuring errors, and would not be considered to have a material impact. The Mineral Resource statement would not materially change if the 2020 economic parameters were used. Therefore the 2011 Mineral Resource statement is considered as current as stated in this Report.

Table 14-7: Mineral Resource Assessment Variance Check from 2011 to 2020 Economic Parameters

| Category | Tonnage <br> $(\mathbf{k t})$ | Au <br> $(\mathbf{g} / \mathbf{t})$ | Contained Au <br> $(\mathbf{k o z})$ | S <br> $(\%)$ |
| :-- | :--: | :--: | :--: | :--: |
| Measured | $-1.1 \%$ | $1.1 \%$ | $0.0 \%$ | 1.7 |
| Indicated | $-0.5 \%$ | $0.6 \%$ | $0.2 \%$ | 1.5 |
| Total Measured and Indicated | $-0.5 \%$ | $0.8 \%$ | $0.2 \%$ | 1.6 |
| Inferred | $0.3 \%$ | $1.1 \%$ | $1.4 \%$ | 1.2 |

[[%~%]]
## 14.15 Mineral Resource Statement

Mineral Resources take into account geologic, mining, processing and economic constraints, and have been constrained within appropriate LG pit shells, and therefore are classified in accordance with the definitions in 2014 CIM Definition Standards.The QP for the Mineral Resource estimate is Henry Kim, P.Geo., an employee of Wood.
Mineral Resources are reported at a commodity price of $\$ 1,200 /$ oz gold, and have an effective date of 11 July 2011. Mineral Resources are stated in Table 14-8 using a block value cut-off of $\$ 0.001 / \mathrm{t}$. Mineral Resources are reported inclusive of those Mineral Resources that were converted to Mineral Reserves.

Table 14-8: Mineral Resources Summary Table, (Inclusive of Mineral Reserves) Effective Date 11 July 2011, Henry Kim, P.Geo.

| Category | Tonnage <br> $(\mathbf{k t})$ | Au <br> $(\mathbf{g} / \mathbf{t})$ | Contained Au <br> $(\mathbf{k o z})$ | $\mathbf{S}$ <br> $(\%)$ |
| :-- | :--: | :--: | :--: | :--: |
| Measured | 7,731 | 2.52 | 626 | 1.15 |
| Indicated | 533,607 | 2.24 | 38,380 | 1.08 |
| Total Measured and Indicated | 541,337 | 2.24 | 39,007 | 1.08 |
| Inferred | 92,216 | 2.02 | 5,993 | 1.08 |

Note: ${ }^{1}$ Mineral Resources are inclusive of Mineral Reserves. Mineral Resources that are not Mineral Reserves and do not have demonstrated economic viability.
${ }^{2}$ The cut-off date for the sample database used in the resource estimate is 1 November 2009. However, more recent drilling data was used to validate the resource model as remaining current.
${ }^{3}$ Mineral Resources are constrained within a conceptual Measured, Indicated and Inferred optimized pit shell using the following assumptions: gold price of $\$ 1,200 /$ oz; variable process cost based on $2.1874^{*}$ (sulphur grade) + 10.65; administration cost of $\$ 2.29 / t$; refining, freight \& marketing (selling costs) of $\$ 1.85 /$ oz recovered; stockpile rehandle costs of $\$ 0.20 /$ t processed assuming that $45 \%$ of mill feed is rehandled; variable royalty rate, based on royalty of $4.5 \%$ * (Au price - selling cost), and a variable metallurgical recovery depending on the host rock type ranging from 86 to $94 \%$. Assuming an average recovery of $89.5 \%$ and average $5 \%$ grade of 1.07 , the marginal gold cut-off grade is $0.47 \mathrm{~g} / \mathrm{t}$. These technical and economic parameters are those that were used in the Donlin 2011 Technical Report to establish reasonable prospects of eventual economic extraction (effective 11 July 2011). Based on the QP's review of the estimate, there would be no material change to the Mineral Resources if the gold price were updated to $\$ 1,500 /$ oz and other economic parameters were updated to the 2020 parameters used in the Mineral Reserve estimate. Therefore the 2011 Mineral Resource statement is considered current and is presented unchanged.
${ }^{4}$ Rounding may result in apparent summation differences between tonnes, grade and contained metal content.
${ }^{5}$ Tonnage and grade measurements are in metric units. Contained gold ounces are reported as troy ounces.

[[%~%]]
## 14.16 Comments On Section 14

The QP is of the opinion that the Mineral Resources for the Project, which have been estimated using drill data, have been prepared in accordance with best practices under CIM 2019 and 2014 CIM Definition Standards. Validation checks on the Mineral Resource estimates using latest technical and economic inputs have determined the estimates remain current and are suitable to support Mineral Reserve estimation in the feasibility study summarized in this Report.

Factors which may affect the Mineral Resource estimates include:

- Gold price
- Pit slope angles
- Changes to the assumptions used to generate the block value cut-off
- Changes to the $0.25 \mathrm{~g} / \mathrm{t}$ threshold for defining the indicator mineralized shells
- Changes in interpretations of fault geometry, in particular the Vortex and Lo faults
- Changes to the search orientations used for grade estimation
- Changes to the geological model; in general, all geological models are a simplified presentation of what occurs in nature. With more data, the geological models reflect more of the actual complexity of the deposit
- Changes to the Mineral Resource Classification criteria.

[[@~@]]
# 15.0 Mineral Reserve Estimates

[[%~%]]
## 15.1 Key Assumptions / Basis Of Estimate

Pit shell generation was not constrained by infrastructure because the only existing features are an aircraft landing strip, exploration camp, and drilling access roads. All the major infrastructure facilities planned for the Project—stockpiles, waste rock storage facility, offices, maintenance and truck shops, fuel storage, permanent camp, power-generating facilities, mineral processing facilities, tailings storage facility, water diversion and storage structures-will be external to the ultimate pit design and its area of influence. The pit shell generation is constrained in the northwestern part of the ACMA mining area to prevent it from encroaching on Crooked Creek, which is a salmon-bearing stream.

Mineral Reserves were optimized for all Measured and Indicated blocks assuming a gold selling price of $\$ 1,200 /$ oz. The reserves included dilution based on the block model, which identified blocks amenable to bulk mining ( 12 m high benches) and selective mining ( 6 m high benches). Block value (BV) assumptions for Mineral Reserves are summarized in Table 15-1.

The ore considered for processing in the optimization was based on a marginal BV cut-off. Material was considered to be ore if the revenue of the block exceeded the total of the process operating cost, ore rehandle cost, G\&A operating cost, and a sub-set of sustaining capital costs (marginal BV). The revenue was based on net gold price after refining and freight charges and royalties had been deducted. Neither a minimum cut-off grade nor raised cut-off gold grade was applied.

Table 15-1: Assumptions used for Calculation of BVs for Mineral Reserves

| Economic Parameters | Assumptions |
| :-- | :-- |
| Au selling price (reserves) | $\$ 1,200 /$ oz |
| Process Recovery | Based on values in Table 15-6 |
| Grams per troy ounce | 31.10348 |
| Process cost | $\$ 13.78 / \mathrm{t}$ |
| Sustaining Capital | $\$ 1.54 / \mathrm{t}$ |
| G\&A | $\$ 3.66 / \mathrm{t}$ |
| Rehandle cost | $\$ 0.24 / \mathrm{t}$ |
| Refining, freight \& marketing (selling costs) | $\$ 1.21 /$ oz Au recovered |
| NSR Royalty | $4.5 \%$ * (Au price - Selling cost) |
| Production Royalty | $\$ 0.50 / \mathrm{t}$ processed |

[[%~%]]
## 15.2 Dilution And Mining Losses

For this Report the approach used in the 2011 feasibility study to determine dilution and ore losses remains unchanged. During the feasibility study, a software application referred to as SMUman was developed collaboratively between NCL Ingenieria Y Construccion S.A (NCL) and Barrick staff. The objective of the software was to assist in the identification of areas within the Donlin resource where selective mining would be economically beneficial. The economic analysis incorporates mining dilution and ore losses associated with the assumed level of mining selectivity. The software calculates the BV of each block assuming it is mined on a 6 m bench and as part of a 12 m bench. Element grades for a 12 m bench block are derived by calculating a tonnage-based weighted average of the upper and lower 6 m blocks.

The SMUman software replicates the block BV calculation detailed in Section 14.13.1. In addition, a mining penalty is applied to the selective mining scenario. This is a differential unit mining cost to reflect the additional costs associated with selective mining on a 6 m bench versus on a 12 m bench. This cost would include allowances for additional drilling and blasting, reduced loader productivity, and greater requirements for ancillary equipment. A typical example of the differential cost calculation was obtained from Kalgoorlie Consolidated Gold Mines (KCGM). A total additional selective mining cost penalty of $\$ 0.52 / \mathrm{t}$ was applied to the SMUman study.

Using the BV of each block, the SMUman software identifies which blocks are "ore" for both the 6 m and 12 m mining scenarios. Ore loss and dilution are then simulated for each scenario based on the assumed degree of mining selectivity.

The feasibility study assumes that the minimum SMU size for calculation of ore loss and dilution is approximately 5,000 tonnes when mining a full 12 m bench. This figure was based on operating experience at the KCGM joint venture in Western Australia, which uses an equipment fleet similar to the one proposed for Donlin. As applied to the raw $6 \times 6 \times 6 \mathrm{~m}$ resource model:

- On a 6 m mining bench, a minimum SMU size of four contiguous $6 \times 6 \times 6 \mathrm{~m}$ blocks (in plan view) was required to form an ore pod. Note that this can include diluting waste as long as the overall pod grade is above cut-off. This equates to a minimum mining unit size of approximately 2,330 tonnes.
- On a 12 m mining bench, a minimum SMU size of four contiguous $6 \times 6 \times 12 \mathrm{~m}$ blocks (in plan view) was required to form an ore pod. Note that this can include diluting waste as long as the overall pod grade is above cut-off. This equates to a minimum mining unit size of approximately 4,660 tonnes.- Conversely, for both 6 m and 12 m scenarios, a minimum of four contiguous waste blocks (in plan view) was required to be successfully separated from adjacent ore. Any less than four blocks is assumed to be diluting waste.
- Polygons representing potential selective mining areas were digitized into SMUman on a 12 m bench-by-bench basis. The software reports the overall BV of the polygon assuming selective mining on two 6 m benches versus bulk mining on a single 12 m bench. The selective mining unit cost penalty was deducted from the BV $\$ / \mathrm{t}$ for the selective mining scenario. A visual comparison of the results was used as a guide for identifying areas to be selectively mined.

The approach was somewhat subjective. Selective mining of ore pods (using the assumed selective mining penalty of $\$ 0.52 / \mathrm{t}$ mined) generally resulted in all ore pods benefiting from selective mining. This was considered impractical given the large ( $+400,000 \mathrm{t} / \mathrm{d}$ ) scale of the operation, and because the selective mining penalty does not fully reflect additional (intangible) operational complexities associated with split-bench mining. An alternative approach was adopted, whereby practical mining areas were designated for selective mining if they demonstrated a significant BV benefit over bulk mining. This significant benefit threshold was chosen as being approximately $5 \%$.

In general, this benefit occurred in the ACMA deposit, which includes flatter-dipping areas and is less contiguous than the Lewis deposit.

The mine plan is based on Measured and Indicated resources. All selective mining areas (on 6 m benches) based on the $6 \times 6 \times 6 \mathrm{~m}$ block treat Inferred material as waste.

In bulk mining areas, however, SMUman provided options for the treatment of Inferred material. The grades of a 12 m block are calculated from the weighted average of the upper and lower 6 m blocks. A question arises when assigning a confidence category to a 12 m block when one of the constituent 6 m blocks is Inferred (e.g., an Inferred 6 m block below an Indicated 6 m block). The conservative approach would be to assign the lowest confidence category. For instance, if one of the 6 m blocks is Inferred, then the entire 12 m block is treated as Inferred.

For the feasibility study, the Wood QP and the Barrick mining teams agreed that a pragmatic approach would be taken, such that the 12 m block was assigned the higher confidence category, for example:

- If one of the 6 m blocks was Inferred and one was Indicated, then the entire 12 m block was treated as Indicated. However, the grade of all Inferred blocks was set to zero at thestart of the process (waste dilution). Therefore, the combined grade of the 12 m block is derived from the Measured or Indicated metal grades only.

The following net adjustments were applied to the resource model for pit optimization:

- A loss of $1.26 \%$ of tonnes above cut-off ( $0.76 \%$ loss of gold ounces) due to the removal of pods smaller than the minimum four-block SMU size.
- Added diluting waste of $7.1 \%$ of tonnes ( $1.0 \%$ gain of gold ounces) because of the inclusion of waste pods smaller than the minimum four-block SMU size when surrounded by blocks above cut-off.
- A net adjustment of $5.8 \%$ additional rock tonnes ( $0.24 \%$ of additional gold ounces).

As a result of the chosen method of treating Inferred material during the 12 m re-blocking process, $2.6 \%$ of the total ore tonnage ( $0 \%$ of the gold ounces) is Inferred blocks included as waste dilution that have been included in, and reclassified as, either Measured or Indicated (Table 15-2).

Table 15-2: Net Model Adjustments (within pit design)

| Item | Mill Material <br> $(\mathbf{k t})$ | Au <br> $(\mathbf{g} / \mathbf{t})$ | S <br> $(\%)$ | Au <br> $(\mathbf{k o z})$ |
| :-- | :--: | :--: | :--: | :--: |
| Undiluted mill material | 477,083 | 2.20 | 1.07 | 33,767 |
| Net adjustments (dilution) | 27,728 | 0.09 | 0.88 | 82 |
| Total M\&I with adjustments | 504,811 | 2.09 | 1.06 | 33,849 |
| Adjustments |  |  |  |  |
| $\quad$ Isolated ore blocks | $-6,016$ | 1.33 | 0.91 | -257 |
| Planned diluting material ${ }^{1}$ | 33,745 | 0.31 | 0.88 | 339 |
| Sum of adjustments | 27,728 | 0.09 | 0.88 | 82 |
| Ore loss (\%) | -1.26 | - | - | -0.76 |
| Dilution (\%) | 7.07 | - | - | 1.01 |
| Net (\%) | 5.81 | - | - | 0.24 |
| Inferred included (waste) | 13,193 | - | 0.89 | - |
| Inferred (\%) | 2.6 | - | - | - |

Note: ${ }^{1}$ Inferred Resources were included at zero grade (waste), while Measured and Indicated Resources below cut-off were included at their grade (dilution).

[[%~%]]
## 15.3 Conversion Factors From Mineral Resources To Mineral Reserves

[[%~%]]
### 15.3.1 Mining Costs

Mining costs utilized in the Mineral Reserve LG pit shell generation were based on first-principle calculations performed in the 2011 feasibility study that were escalated to 2020 to bring them current. Donlin Gold LLC provided a current (2020) price of \$65/barrel of oil, which corresponds to a delivered to site diesel price of $\$ 0.69 / \mathrm{L}$. Other costs were escalated using cost indexes published in CostMine's costing indexes from their MCSO2 - Cost Indexes and Metal Prices March 2020. Overall, the mining costs increased by $5.7 \%$ primarily due to increases in labor and maintenance costs (Table 15-3). Excluding rehandle, the adjusted mine cost is $\$ 2.64 / \mathrm{t}$ mined. The rehandle cost is $\$ 0.24 / \mathrm{t}$ which has been escalated by $5.8 \%$ from the 2011 rehandle cost of $\$ 0.22 / t$.

Table 15-3: Escalated Mining Costs

| Cost Area | Percentage in <br> Total Cost <br> (\%) | 2011 <br> \$/t mined | Adjustment <br> Percentage <br> (\%) | 2020 <br> \$/t mined |
| :-- | :--: | :--: | :--: | :--: |
| Labour | 23.4 | 0.59 | 14.6 | 0.68 |
| Diesel Fuel | 25.2 | 0.64 | -13.7 | 0.55 |
| Electricity | 2.2 | 0.06 | -15.8 | 0.05 |
| Drilling Consumables | 1.1 | 0.03 | -16.2 | 0.02 |
| GETs | 1.2 | 0.03 | -16.2 | 0.02 |
| Blasting Consumables | 12.2 | 0.31 | 14.9 | 0.35 |
| Tires | 8.3 | 0.21 | -1.2 | 0.21 |
| Other Consumables | 1.2 | 0.03 | -4.1 | 0.03 |
| Maintenance Parts \& Supplies | 21.4 | 0.54 | 19.8 | 0.64 |
| External Services | 3.3 | 0.08 | 14.6 | 0.10 |
| Cost Overheads | 0.5 | 0.01 | 14.6 | 0.01 |
| Total | $\mathbf{1 0 0 . 0}$ | $\mathbf{2 . 5 2}$ | $\mathbf{5 . 7}$ | $\mathbf{2 . 6 6 ^ { 1 }}$ |

Note: ${ }^{1}$ Includes rehandle costs which account for $\$ 0.02 / t$
Based on the adjusted mining costs, the reference mining cost used in the pit shell generation was $\$ 2.16 / \mathrm{t}$ of material mined. Ore and waste mining costs were assumed to be equal. An incremental increase in cost with depth of $\$ 0.0033 / \mathrm{t} / \mathrm{m}$ was applied to blocks below a reference elevation of 220 m to represent increased haulage cost with pit depth.

[[%~%]]
### 15.3.2 Processing Costs

Processing costs were based on first-principle calculations performed in the 2011 feasibility study that were updated to 2020 to bring them current. Overall, the processing costs reduced by $12.2 \%$ primarily due to reductions in energy and consumable costs (Table 15-4).

Table 15-4: Escalated Processing Costs

| Cost Area | Percentage in <br> Total Cost <br> $(\%)$ | 2011 <br> $\$ /$ t processed | Adjustment <br> Percentage <br> $(\%)$ | 2020 <br> $\$ / t$ processed |
| :-- | :--: | :--: | :--: | :--: |
| Labour | 8 | 1.22 | 14.6 | 1.40 |
| Electricity | 45 | 6.93 | -15.8 | 5.83 |
| Grinding Consumables | 10 | 1.53 | -16.2 | 1.29 |
| Consumables | 23 | 3.59 | -26.6 | 2.64 |
| Maintenance Parts \& Supplies | 14 | 2.20 | 19.8 | 2.63 |
| Total | $\mathbf{1 0 0}$ | $\mathbf{1 5 . 4 7}$ | $\mathbf{- 1 2 . 2}$ | $\mathbf{1 3 . 7 8}$ |

In 2011, the processing costs calculated within the optimization were variable based on sulphur grade; however, Wood's QP reviewed the formula used for the 2011 optimization work and the process cost estimates from 2011 and determined that the sulphide in mill feed is relatively flat across the range of operating costs in the feasibility study. As a result, Wood's QP used a fixed process cost of $\$ 13.78 / t$ processed, in the pit optimization work.

A sustaining capital of $\$ 1.54 / t$ was added to the processing cost to account for tailings storage and miscellaneous process capital.

[[%~%]]
### 15.3.3 General And Administrative (G\&A) Cost

The 2011 feasibility study G\&A operating cost estimate of $\$ 3.22 / t$ processed was brought current by applying a $13.6 \%$ increase. Following the increase, the G\&A cost, inclusive of aviation, catering, camps, clinic, health and safety, and logistics, is $\$ 3.66 /$ of material processed and were added to the processing cost in the LG analysis, as is typically assumed for cases limited by processing rate (Table 15-5).Table 15-5: Escalated G\&A Cost

|  | Percentage in <br> Total Cost <br> (\%) | 2011 <br> \$/t processed | Adjustment <br> Percentage <br> (\%) | 2020 <br> \$/t processed |
| :-- | :--: | :--: | :--: | :--: |
| Cost Area | 71 | 2.30 | 14.6 | 2.63 |
| Labour | 7 | 0.22 | -15.8 | 0.19 |
| Electricity | 6 | 0.21 | 19.0 | 0.25 |
| Logistics | 15 | 0.49 | 19.8 | 0.59 |
| Equipment | 100 | $\mathbf{3 . 2 2}$ | $\mathbf{1 3 . 6}$ | $\mathbf{3 . 6 6}$ |
| Total |  |  |  |  |

[[%~%]]
### 15.3.4 Metallurgical Recovery

Gold recovery values were based on work completed for the Project. Metallurgical recoveries for non-oxide ores are quoted as a constant for each rock type, whereas recoveries for oxide ores vary with sulphur grade. The recoveries applied in pit optimization are listed in Table 15-6.

Table 15-6: Pit Optimization Process Recoveries

| Deposit Area | Recovery <br> $(\%)$ |
| :-- | :--: |
| Non-Oxide Ores |  |
| Akivik intrusive | 94.17 |
| 400 intrusive | 93.55 |
| ACMA intrusive | 93.05 |
| Aurora intrusive | 93.61 |
| Vortex intrusive | 91.82 |
| Lewis intrusive | 91.52 |
| Greywacke | 88.22 |
| Shale | 86.66 |
| Oxide/Weathered Ores |  |
| Sulphur grade (S) $>1.8 \%$ | 87.90 |
| Otherwise | $=\left(8.7361^{*}(\mathrm{~S})^{\wedge} 3-49.806^{*}(\mathrm{~S})^{\wedge} 2+95.233^{*}(\mathrm{~S})+30.004\right)^{*} 0.966$ |
|  |  |

[[%~%]]
### 15.3.5 Refining, Freight, And Royalties

The 2011 feasibility study refining and freight cost of $\$ 1.02 /$ oz Au was increased by $19.0 \%$ to \$1.21/oz Au based on InfoMine's Freight Cost Index.

An average royalty charge of $4.5 \%$ of the net gold value was added after the refining and freight cost had been applied. The $4.5 \%$ royalty was applied through-out the life of the Project based on an assumed 25 -year mine life. Additionally, a production royalty of $\$ 0.50 / \mathrm{t}$ processed was applied to the processed material.

The refining, freight, and royalty costs were applied to the selling cost per ounce in the LG pit optimization using the following equation:

Selling Cost $=1.21+((1200-1.21) \times 0.045)+\$ 0.50 / t$ processed

[[%~%]]
### 15.3.6 Metal Prices

A gold price of $\$ 1,200 /$ oz was used for pit optimization.

[[%~%]]
### 15.3.7 Pit Slopes

Geotechnical domains, design sectors, slope angles, and associated assumptions were provided by BGC Engineering Inc. (BGC), an applied earth sciences company. BGC's inter-ramp slope angles were reduced for each design sector in each of the geotechnical domains to flatten the generated pit shell; this allowed for the haulage ramps that would be included in the mine design. Slope angle reductions were based on the haulage ramp width, the number of times a haulage ramp traversed a design sector, and the overall slope height of the sector.

Certain slope angles were further adjusted to smooth the transition to an adjacent design sector. This enabled the LG software to generate structural arcs in cases where the slope angles contrasted sharply in "narrow" design sectors. The slope angles were either increased or decreased to enable the generation of arcs while attempting to preserve slope steepness. The slope angles used in the pit optimizations are shown in Table 15-7.Table 15-7: Pit Optimization Slopes

| Domain | BGC Design Sector | Whittle ${ }^{\text {TM }}$ <br> Bearing | Slope <br> Angle | No. of <br> Ramps | Reduction | Reduced <br> Slope Angle | Whittle ${ }^{\text {TM }}$ Transition <br> Adjusted |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| 1 | 219 | 039 | 038 | 001 | 2.3 | 035.0 | 035.0 |
| 1 | 263 | 083 | 032 | 003 | 6.2 | 026.0 | 026.0 |
| 1 | 314 | 134 | 042 | 001 | 4.7 | 037.0 | 036.0 |
| 1 | 329 | 149 | 046 | 002 | 9.8 | 036.0 | 036.0 |
| 1 | 015 | 195 | 038 | 001 | 3.1 | 034.0 | 034.0 |
| 1 | 068 | 248 | 042 | 001 | 2.7 | 039.0 | 039.0 |
| 1 | 110 | 290 | 035 | 001 | 1.8 | 033.0 | 033.0 |
| 1 | 171 | 351 | 033 | 002 | 4.7 | 028.0 | 028.0 |
| 2 | 194 | 014 | 030 | 003 | 3.6 | 026.0 | 027.0 |
| 2 | 217 | 037 | 034 | 003 | 4.5 | 030.0 | 027.0 |
| 2 | 232 | 052 | 030 | 003 | 3.6 | 026.0 | 027.0 |
| 2 | 265 | 085 | 027 | 003 | 3.0 | 024.0 | 024.0 |
| 2 | 299 | 119 | 028 | 003 | 3.2 | 025.0 | 025.0 |
| 2 | 344 | 164 | 026 | 003 | 2.8 | 023.0 | 023.0 |
| 2 | 36 | 216 | 036 | 003 | 5.0 | 031.0 | 031.0 |
| 2 | 115 | 295 | 027 | 003 | 3.0 | 024.0 | 024.0 |
| 3 | 199 | 019 | 031 | 001 | 1.5 | 030.0 | 030.0 |
| 3 | 254 | 074 | 028 | 001 | 1.3 | 027.0 | 027.0 |
| 3 | 308 | 128 | 032 | 001 | 1.6 | 030.0 | 032.0 |
| 3 | 330 | 150 | 037 | 001 | 2.1 | 035.0 | 033.0 |
| 3 | 12 | 192 | 046 | 003 | 7.7 | 038.0 | 038.0 |
| 3 | 60 | 240 | 038 | 003 | 5.7 | 032.0 | 032.0 |
| 3 | 105 | 285 | 034 | 003 | 4.7 | 029.0 | 029.0 |
| 3 | 156 | 336 | 037 | 001 | 2.1 | 034.0 | 034.0 |
| 4 | 190 | 010 | 031 | 001 | 1.5 | 029.0 | 029.0 |
| 4 | 246 | 066 | 036 | 001 | 2.0 | 034.0 | 035.0 |
| 4 | 272 | 092 | 045 | 001 | 2.9 | 042.0 | 037.0 |
| 4 | 341 | 161 | 045 | 001 | 2.9 | 042.0 | 042.0 |
| 4 | 55 | 235 | 045 | 001 | 2.9 | 042.0 | 042.0 |
| 4 | 85 | 265 | 044 | 001 | 2.8 | 041.0 | 040.5 |
| 4 | 118 | 298 | 040 | 001 | 2.4 | 038.0 | 036.0 |
| 4 | 140 | 320 | 036 | 001 | 2.0 | 034.0 | 034.0 |

[[%~%]]
### 15.3.8 Sensitivity Of Optimized Pit

A sensitivity study was performed on the pit optimization to assess the sensitivity of the Measured and Indicated Mineral Resources to changes in gold price, metallurgical recovery, and operating costs. Factors that favourably affected the revenue stream and cut-off BV resulted in larger pits with higher recovered ounces at lower average grades. The process recovery and gold price had more influence on the ore tonnes and recovered ounces than did the process and G\&A costs and mining costs. However, the mining cost had more influence on the total size of the pit than did the process and G\&A costs.

[[%~%]]
## 15.4 Mineral Reserves Statement

Mineral Reserves have been modified from Mineral Resources by taking into account geologic, mining, processing, and economic parameters and therefore are classified in accordance with the 2014 CIM Definition Standards.

The Q P for the Mineral Reserve estimate is Kirk Hanson, P.E., a Wood employee.
Mineral Reserves are reported at a gold price of \$1,200/oz gold and have an effective date of 27 April 2021.

Mineral Reserves are summarized in Table 15-8.Table 15-8: Proven and Probable Mineral Reserves, Effective Date 27 April 2021, K. Hanson, P.E.

| Category | Tonnage <br> $(\mathbf{k t})$ | Au <br> $(\mathbf{g} / \mathbf{t})$ | Contained Au <br> $(\mathbf{k o z})$ | $\mathbf{S}$ <br> $(\%)$ |
| :-- | :--: | :--: | :--: | :--: |
| Proven | 7,683 | 2.32 | 573 | 1.12 |
| Probable | 497,128 | 2.08 | 33,276 | 1.06 |
| Total Proven and Probable | $\mathbf{5 0 4 , 8 1 1}$ | $\mathbf{2 . 0 9}$ | $\mathbf{3 3 , 8 4 9}$ | $\mathbf{1 . 0 6}$ |

Note: ${ }^{1}$ Mineral Reserves are reported within the feasibility pit designs, and supported by a mine schedule, featuring variable throughput rates, stockpiling and cut-off optimization. The pit designs are contained within an optimized pit shell based on the following economic and technical parameters: Metal price for gold of $\$ 1200 /$ oz; reference mining cost of $\$ 2.16 / \mathrm{t}$ incremented $\$ 0.0033 / \mathrm{t} / \mathrm{m}$ with depth from the 220 m elevation (equates to an average mining cost of $\$ 2.64 / \mathrm{t}$ ), fixed processing cost of $\$ 13.78 / \mathrm{t}$ processed; sustaining capital of $\$ 1.54 / \mathrm{t}$ processed; general and administrative cost of $\$ 3.66 / \mathrm{t}$ processed; stockpile rehandle costs of $\$ 0.24 / \mathrm{t}$ processed assuming that $45 \%$ of mill feed is rehandled; variable metallurgical recoveries by rocktype, ranging from $86.7 \%$ in shale to $94.2 \%$ in intrusive rocks in the Akivik domain; refining and freight charges of $\$ 1.21 /$ oz Au; royalty considerations of $4.5 \%$ NSR and $\$ 0.50 / \mathrm{t}$ processed; and variable pit slope angles, ranging from $23^{\circ}$ to $43^{\circ}$
${ }^{2}$ Mineral Reserves are reported using an optimized block value (BV) based on the following equation: BV = Au grade * Recovery - royalties \& refining costs - process operating costs - G\&A cost reported in $\$ / \mathrm{t}$. Assuming an average gold recovery of $89.5 \%$ the marginal gold cut-off grade would be approximately 0.57 $\mathrm{g} / \mathrm{t}$, or the gold grade that would equate to a $\$ 0.001 \mathrm{BV}$ cut-off at these same values.
${ }^{3}$ The LOM strip ratio is $5.48: 1$. The assumed LOM throughput rate is $53,500 \mathrm{t} / \mathrm{d}$.
${ }^{4}$ Rounding may result in apparent summation differences between tonnes, grade and contained metal content.
${ }^{5}$ Tonnage and grade measurements are in metric units. Contained gold ounces are reported as troy ounces.

[[%~%]]
## 15.5 Comments On Section 15

The Wood QP is of the opinion that the Mineral Reserves for the Project appropriately consider modifying factors, and have been estimated using industry best practices in CIM 2019, and are in accordance with 2014 CIM Definition Standards.

Factors which may affect the Mineral Reserve estimates include: effectiveness of the dilution model, gold price, metallurgical recoveries, geotechnical characteristics of the rock mass, ability of the mining operation to meet the planned annual throughput rate assumptions for the process plant, capital and operating cost estimates, effectiveness of surface and ground water management, and likelihood of obtaining required permits and social licenses. Wood's QP is of the opinion that these potential modifying factors have been adequately accounted for using the assumptions in this Report, at this feasibility level of study.Risk factors which may affect the assumptions in this Report include:

- Unrecognized structural complications in areas with relatively low drill hole density could introduce unfavourable pit slope stability conditions.
- The stability of the south walls of the ultimate ACMA and Lewis pits is sensitive to the interpreted orientations of the Vortex and Lo faults, respectively. The current overall slope designs of these two walls may need to be modified if the interpretations of these faults change.
- Given the natural variations in the bedding dips, parts of footwall slopes may need to be excavated with flatter bench face angles than estimated for the feasibility design. This could potentially decrease the overall slope angle for the footwall slope(s) and increase the strip ratio.
- The residual friction angles of the ash beds are estimated to be $14^{\circ}$. If these low-strength layers are identified within footwall slopes, then, combined with bedding thicknesses of less than 2 m , artificial support may be required for the footwall bench faces.
- Trench and other surface exposures show complex intrusive rock contacts on an ore polygon scale that cannot be accounted for in wireframe interpretations. The ore control plan, which includes angled drill hole delineation of ore zones, should mitigate these uncertainties.
- If the mining rate results in the pit walls encountering the water table, producing extensive seepage into the pit, then additional horizontal drains and pumping wells will be required. Similarly, if the bulk bedrock hydraulic conductivity is lower in some areas of the pit than assumed for the base case, then the density of vertical wells / horizontal drains will need to be increased.
- An estimation of the likely duration required to obtain the permits and social licenses to construct the natural gas pipeline and operate the planned mine is incorporated in this study; any changes to that timeframe may impact the assumptions used in the economic analysis, and therefore the declaration of Mineral Reserves.

[[@~@]]
# 16.0 Mining Methods

[[%~%]]
## 16.1 Throughput Considerations

The project processing rate is $53,500 \mathrm{t} / \mathrm{d}$, which takes into account processing design constraints and rationalization of the proposed POX circuit.

[[%~%]]
## 16.2 Pit Design

Parameters considered in the pit optimization process are discussed in Section 15. The pit design was originally guided by an optimized pit shell generated using a $\$ 975 /$ oz gold price and 2011 cost inputs. In this update, a revised optimized shell (2020 optimized shell) was generated using a $\$ 1,200 /$ oz gold price and current cost inputs. The pit design conforms reasonably well with the 2020 optimized shell and has not been changed. Compared to the 2020 optimized shell, the pit design adds approximately 2 Mt of ore and 194 Mt of waste. This represents $0.4 \%$ and $7.5 \%$ additions, respectively. Although high, the increase in waste is considered acceptable; consequently the 2020 optimization work supports the feasibility pit design summarized in the Donlin 2011 Technical Report, and the 2011 pit designs are considered current for use in this report.

[[%~%]]
## 16.3 Geotechnical Considerations

BGC provided feasibility-level slope design criteria for the proposed Donlin open pit. The design incorporates data collected and evaluations conducted by BGC from 2004 to 2007. BGC collected additional data in 2010 to confirm that the feasibility study slope design parameters remained applicable to the expanded feasibility study open pit. The pit shell developed for the feasibility study conforms to the feasibility-level geotechnical slope design parameters. Final slope parameters are those indicated in Table 15-7.

[[%~%]]
### 16.3.1 Rock Mass Model

The rock mass model is divided into geotechnical units, which for Donlin pit slope design are equivalent to the rock units as defined by the geological model. The sedimentary rocks of the mine-scale geology model are locally divided into eight units. The complex inter-bedding of the sedimentary rocks makes it impractical to delineate geotechnical units comprised entirely of shale, siltstone, or greywacke. The five intrusive rock types of the mine-scale geological model were combined into a single geotechnical unit (INT) for the feasibility slope design. Based on testing and logging completed through 2010, variations in the texture and mineralogy of these five units are expected to have a minor effect on their geotechnical behaviour.The dominant structural fabric is bedding and bedding parallel discontinuities. Joints forming the minor structural fabric are best developed in the greywacke beds and intrusive units. Faults within the mine-scale geological model that have no in-fill have an estimated residual friction angle of $26.5^{\circ}$. Fault in-fill dominated by silt / clay gouge has an estimated residual friction angle of $26^{\circ}$; in-fill dominated by disintegrated/decomposed rock has an estimated residual friction angle of $29^{\circ}$. The feasibility-level slope design assumes a design friction angle of $26^{\circ}$ for all faults and shears in the mine-scale geological model. Based on the BGC geotechnical database through 2010, this represents the most likely fault character to be encountered.

[[%~%]]
### 16.3.2 Open Pit Slope Design

For the Donlin feasibility design summarized in this Report, the inter-ramp scale slope kinematic analyses were completed first to determine achievable slope angles and define the design sectors for the pit design. Conventional deterministic analyses were undertaken for the inter-ramp slopes assuming that designs satisfy a minimum static factor of safety of 1.2.

The open pit design was completed by Barrick using the slope design parameters provided by BGC. BGC checked selected cross-sections of the final pit design to confirm that the pit wall angles met the slope design criteria developed for the feasibility study. Overall slope stability analyses for depressurized conditions predicted by the 3D numerical groundwater modelling and for fully saturated groundwater conditions were completed for nine cross-sections developed from the feasibility-level pit slopes and the feasibility geotechnical model. Two critical areas of the proposed pit were highlighted during the slope design process:

## Lewis Pit - Northeast Wall (Design Sector I-219)

Given the monoclinal dip of the sedimentary rocks in this area of the pit, where the bedding dips at an average of $43^{\circ}$, a standard $65^{\circ}$ to $70^{\circ}$ bench face would undercut bedding and likely result in instability. As a result, a footwall mining configuration has been recommended and will achieve the maximum slope angle in this area.

Stability analyses to assess standard potential footwall instability modes indicate that a 48 m high unbenched slope will be stable against buckling, bi-linear slab, and ploughing failures. To practically dewater this area and maintain adequate protection against rock and ice fall, a rockfall catchment berm should be placed every 48 m vertically. The berm will need to be a minimum of 8 m wide, increasing to 13 m wide at every second bench to accommodate water wells, horizontal drain hole collection systems, a rockfall catchment ditch / net, and a roadway with a 5 m wide running surface for service vehicles. This results in a $38^{\circ}$ inter-ramp slope angle for this wall.# ACMA Pit - South Wall (Design Sector IV-340) 

Stability analyses suggest that kinematically possible inter-ramp failures in this part of the wall are unlikely and consequently that relatively steep inter-ramp slopes (up to $50^{\circ}$ ) are possible in the south and southwest wall. The wall angles are currently limited by the 24 m maximum bench height being used for the assessments.

However, rock mass failure analyses of the south wall (dip direction towards $360^{\circ}$ ) indicate that this area of the pit will have to be dewatered and the overall slope angle cannot exceed $45^{\circ}$. The presence of a flat ( $20^{\circ}$ dip) fault set dipping to the north could also play a significant role in the stability of this wall. The full extent and continuity of the flat set cannot be established from the drilling conducted through 2010; however, it may be prudent to avoid pit wall orientations that the flat-dipping faults would affect.

[[%~%]]
### 16.3.3 Recommended Design Parameters

The general design parameters used in the detailed pit design are as follows:

- Bench height, single-bench mining ............................................ 6 and 12 m
- Height between catch benches .................................................. 24 or 48 m
- Bench face angle........................................................ 43º to 65º (variable)
- Berm width (variable) .................................................................. 8 to 38 m
- Total width allowance, temporary roads ............................................ 45 m
- Total width allowance, final roads ........................................................ 40 m
- Running surface on final two-way roads.............................................. 29 m
- Minimum road inside radius on corners .............................................. 20m
- Berms and ditches .......................................................................... 4 to 6 m
- Maximum grade uphill loaded .............................................................. 10\%
- Maximum grade downhill loaded............................................................ 8\%


[[%~%]]
## 16.4 Pit Phases

The ACMA ultimate pit has been divided into nine phases based on optimized nested pit shell guidance, gold grade, strip ratio, the ability to access the pit, and locations for waste backfill. The planned ACMA pit has a top elevation of 268 m above sea level (asl) and a bottom elevation of 344 m below sea level (bsl). The nine phases are delineated in Figure 16-1.# NOVAGOLD 

The Lewis pit will be on a hill directly above and to the northeast of the ACMA pit, at an elevation ranging from 436 m asl to 68 m bsl. The Lewis ultimate pit has been divided into six phases based on optimized pit shell guidance, gold grade, and ramp access. The six phases are delineated in Figure 16-2.

Figure 16-1: ACMA Phases in Plan at 94 m Elevation
![img-35.jpeg](img-35.jpeg)# NOVAGOLD 

Figure 16-2: Lewis Phases in Plan at 178 m Elevation
![img-36.jpeg](img-36.jpeg)

[[%~%]]
## 16.5 Haul Roads

Haul roads are required between the pit phases and the ore crusher, waste dumps, overburden stockpiles, construction areas, and truckshop. The roads have generally been laid out with a cut-and-fill balance. Roads within the ultimate waste dump are all fill construction. The road design is based on the following design parameters:

- Total width allowance temporary roads ............................................. 45 m
- Total width allowance on final two-way roads .................................... 40 m
- Running surface on final two-way roads............................................. 29 m
- Minimum road inside radius on corners ............................................. 20 m
- Berms and ditches ...................................................................... 9 to 11 m
- Maximum grade in pit, uphill loaded .................................................... 10\%
- Maximum grade ex pit, uphill loaded..................................................... 8\%
- Maximum grade downhill loaded............................................................ 8\%

The initial phases of the two pits are independent, but they partially merge later in the mine life. The final overall pit layout plan is included as Figure 16-3.# NOVAGOLD 

Figure 16-3: End-of Mine Plan Layout of Open Pit and WRF ${ }^{1}$
![img-37.jpeg](img-37.jpeg)

Note: ${ }^{1} 1 \mathrm{~km}$ grid shown in drawing

[[%~%]]
## 16.6 Production Schedule

[[%~%]]
### 16.6.1 Planned Production Schedule

Preproduction mining has been defined as starting in April of Year -1 and finishing in December of Year -1, when the main orebody is exposed. Process production starts in July of Year 1. The operating mine life is estimated at 25 years based on a nominal processing rate of $53,500 \mathrm{t} / \mathrm{d}$.

In accordance with the convention, the Year -1 (preproduction) was scheduled on a quarterly basis, while schedules for the first year of production, Year 1, were developed by month. Years 2 and 3 are scheduled quarterly, and all remaining periods are scheduled annually.

Given the geometry of the orebody and the distribution of the ore, almost all of the waste material, and those ore zones that can be mined without significant loss or dilution, will be mined on 12 m benches. There are select ore zones that are planned for mining on 6 m benches.The schedule incorporates long-term and short-term ore stockpiles. The long-term stockpile will hold all ore produced at the mine in excess of process feed, separated into three sections according to sulphur grade for blending purposes, as follows:

- High S grade (HS) S $\geq 1.4 \%$
- Medium S grade (MS). S $\geq 0.9 \%$ and $S<1.4 \%$
- Low S grade (LS). S $<0.9 \%$

Long-term reclaim is based only on sulphur category at the average Au grade of the stockpile; however, the first 21 Mt (higher grade) of ore is stored separately in front of the Lower contact water dam. Other high-grade stockpiles (of ore to be processed during mine life) can be made in the AMCA 8/9 area to further separate preferential process feed. Opportunities to apply value segregation and reclaim higher grades first may become evident in further studies. The short-term stockpile was established to accommodate fluctuations in the average daily process feed as a result of plant capacity.

[[%~%]]
### 16.6.2 Pit-Phase Mining Rates

The key features of the planned mine schedule are as follows:

- The production plan is developed on a quarterly basis for the first four years from Year -1 to Year 3 and annually thereafter, except for Year 1, where a monthly schedule was completed.
- The mine will operate $355 \mathrm{~d} / \mathrm{a}$, with 10 days allowed for delays due to winter conditions.
- The plant is scheduled to operate $365 \mathrm{~d} / \mathrm{a}$.
- The average productivity of the main loading units (hydraulic shovel) is 46 to $53,000 \mathrm{t} / \mathrm{d}$ for ore and 54 to $63,000 \mathrm{t} / \mathrm{d}$ for waste material.
- Pre-stripping from inside the pits totals 20 Mt .
- The mine can sustain maximum material movement of $437,000 \mathrm{t} / \mathrm{d}$ based on $355 \mathrm{~d} / \mathrm{a}$.
- ACMA phase 8 is completed at the beginning of Year 15 allowing in-pit waste dumping to begin.
- ACMA phase 9 is mined out in Year 21 providing most of the space for the in-pit waste dump.
- ACMA phases 1, 2, and 3 and Lewis phases 0, 1, and 2 are essentially one-year ore production phases. Accelerated and simultaneous mining is driven by the requirements for ore blending.- The highest rate of annual vertical advance is 96 m in Lewis phase 3 in Year 12 and Year 13. During this period, approximately $95 \%$ of material is mined on 12 m benches.
- Pit floor elevations (and therefore vertical advance rates) show the rate at which the mine must be dewatered to allow pit development.
- The initial phases are generally mined at a lower rate with the intent of keeping as many alternative areas open as possible in each phase.
- In the production years, three to four phases will be active in any given period, with four active phases per year from Years 1 to 15. This is driven by the requirements for ore blending and to make ACMA available for the pit waste dump.
- The maximum mining rate of $437,000 \mathrm{t} / \mathrm{d}$ is achieved in Year 6. The average rate increases progressively from $350,000 \mathrm{t} / \mathrm{d}$ in Years 1 to 3 to $417,000 \mathrm{t} / \mathrm{d}$ in Years 4 to 11.
- The phase mining rate peaks at approximately 206,000 t/d in ACMA phase 2 in Year 1 and at more than $203,000 \mathrm{t} / \mathrm{d}$ in two periods of ACMA phase 5 (Years 7 and 8). The permanent double-access strategy and wider phases allow for high mining rates.

Table 16-1 summarizes the proposed LOM production schedule. Figure 16-4 graphically summarizes the planned mining rate per pit phase and Figure 16-5 provides the breakdown between ore and waste on an annual basis.

[[%~%]]
### 16.6.3 Process Feed Plan

The process feed will constitute ore transported directly from the mine plus ore reclaimed from five stockpiles. The following issues are considered:

- Variable metallurgical recovery by metallurgical domain
- Variable mill throughput by rock type
- Ore degradation applied to metallurgical gold recovery and sulphur grade by guidance of Barrick metallurgical staff. When ore is stockpiled for more than one year:
- Au recovery drops by 5\% (RMAU = RMAU - 5\%)
- S grade drops by 5\% (5\% = Sulphur\% *0.95)

After plant ramp-up, process feed averages $52,700 \mathrm{t} / \mathrm{d}$ and reaches a maximum of $54,400 \mathrm{t} / \mathrm{d}$ in Year 12. Contained gold in the process feed averages approximately 1.3 Moz per year over the LOM, while gold production averages 1.5 Moz per year for the first five years, with a maximum of 1.73 Moz in Year 6.Table 16-1: Summary Projected Mine Production Plan by Year

| Period | Total Ore |  |  | Waste NAG <br> (kt) | Waste PAG 5 <br> (kt) | Waste PAG 6 <br> (kt) | Waste PAG 7 <br> (kt) | Waste OVB <br> (kt) | Total Rock (kt) |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | Tonnes (kt) | $\begin{gathered} \text { Au } \\ (\mathrm{g} / \mathrm{t}) \end{gathered}$ | $\begin{gathered} \text { S } \\ \text { (\%) } \end{gathered}$ |  |  |  |  |  |  |
| -1 | 1,724 | 1.97 | 0.98 | 12,022 | 463 | 1,485 | 172 | 4,133 | 20,000 |
| 1 | 16,202 | 2.18 | 0.95 | 66,814 | 3,591 | 8,722 | 224 | 4,020 | 99,574 |
| 2 | 21,064 | 2.46 | 1.10 | 80,766 | 3,625 | 8,069 | 104 | 6,372 | 120,000 |
| 3 | 26,757 | 2.28 | 1.09 | 83,267 | 4,674 | 8,473 | 334 | 245 | 123,750 |
| 4 | 33,119 | 2.03 | 0.94 | 79,933 | 3,555 | 7,390 | 753 | 7,750 | 132,500 |
| 5 | 32,596 | 2.10 | 0.99 | 93,621 | 3,289 | 5,801 | 181 | 7,013 | 142,500 |
| 6 | 30,508 | 2.07 | 1.09 | 112,976 | 3,661 | 4,698 | 55 | 602 | 152,500 |
| 7 | 36,217 | 2.06 | 1.12 | 109,241 | 3,612 | 5,587 | 17 | 325 | 155,000 |
| 8 | 23,321 | 2.02 | 1.02 | 115,684 | 3,900 | 7,124 | 91 | 1,131 | 151,250 |
| 9 | 21,522 | 2.26 | 1.01 | 119,776 | 3,080 | 5,345 | 39 | 237 | 150,000 |
| 10 | 28,193 | 2.24 | 1.09 | 113,272 | 3,211 | 4,422 | 25 | 876 | 150,000 |
| 11 | 25,996 | 1.91 | 1.08 | 111,763 | 4,487 | 5,540 | 6 | 2,208 | 150,000 |
| 12 | 26,251 | 2.15 | 1.08 | 111,446 | 4,202 | 6,433 | 15 | 1,652 | 150,000 |
| 13 | 19,971 | 1.96 | 1.01 | 119,363 | 4,599 | 5,314 | 25 | 729 | 150,000 |
| 14 | 15,351 | 1.85 | 1.02 | 128,263 | 2,952 | 2,889 | - | 545 | 150,000 |
| 15 | 14,188 | 1.83 | 0.99 | 129,078 | 2,458 | 3,519 | 169 | 590 | 150,000 |
| 16 | 11,848 | 1.97 | 1.06 | 129,060 | 3,267 | 5,415 | 9 | 401 | 150,000 |
| 17 | 15,063 | 1.90 | 1.00 | 127,844 | 2,303 | 4,172 | 9 | 609 | 150,000 |
| 18 | 11,619 | 1.84 | 1.02 | 113,314 | 2,447 | 4,265 | 7 | 1,348 | 133,000 |
| 19 | 14,559 | 1.81 | 0.98 | 104,059 | 2,279 | 3,776 | 32 | 1,294 | 126,000 |
| 20 | 15,475 | 2.31 | 1.02 | 127,479 | 3,025 | 3,956 | 46 | 20 | 150,000 |
| 21 | 18,407 | 2.56 | 1.20 | 124,831 | 3,159 | 3,578 | 4 | 21 | 150,000 |
| 22 | 15,489 | 2.10 | 1.36 | 98,742 | 3,145 | 2,123 | - | - | 119,500 |
| 23 | 8,725 | 1.78 | 1.11 | 63,562 | 1,221 | 740 | - | - | 74,247 |
| 24 | 16,336 | 1.92 | 1.10 | 35,727 | 2,105 | 2,832 | 1 | - | 57,000 |
| 25 | 4,308 | 1.70 | 1.15 | 7,096 | 717 | 863 | 2 | - | 12,986 |
| Total | 504,811 | 2.09 | 1.06 | 2,518,999 | 79,028 | 122,529 | 2,318 | 42,122 | 3,269,807 |Figure 16-4: Proposed Mining Rate per Pit Phase
![img-38.jpeg](img-38.jpeg)

Figure 16-5: Projected Ore and Waste Production Schedule
![img-39.jpeg](img-39.jpeg)Details of the process schedule, gold recoveries, and projected ounce production on an annualized basis are included in Section 17.6.

The proposed process feed is based on the amount of sulphur in the feed being controlled through a blending strategy that combines ore feed directly from the mine with ore from stockpiles.

[[%~%]]
## 16.7 Ore Stockpiles

The maximum long-term stockpile volume is 104.3 Mt at the end of Year 13. This includes 18.5 Mt of high sulphur grade material, 31.9 Mt of medium sulphur grade material, and 53.9 Mt of low sulphur grade material.

A short-term stockpile was assumed with an average $45 \%$ annual rehandle.
Locations and planned usages for the stockpiles are included as Figure 16-6 and Figure 16-7 respectively.

Figure 16-6: Proposed Locations, Ore Stockpiles
![img-40.jpeg](img-40.jpeg)Figure 16-7: Donlin Ore Stockpile Projected Capacity by Year
![img-41.jpeg](img-41.jpeg)

[[%~%]]
## 16.8 Waste Rock Scheduling And Nag/Pag Management

Waste material will consist of overburden, NAG rock, and PAG rock. The waste will be stored in several dump areas (Figure 16-8).

NAG and most PAG rock from the ACMA and Lewis pits will be routed to the external waste dump (waste rock facility, WRF) during the first part of the mine life. Later, as mining is completed in the ACMA pit, the remaining waste rock will be routed there. In certain periods, suitable material will be sent to the tailings dam location where it will be used for dam lift construction.

A total of 2,232 Mt of waste will be stored in a single ex-pit waste rock facility, in the American Creek Valley, east of the pit area. Another 425 Mt of waste rock will be stored in the ACMA backfill dump and 17 Mt of overburden in the overburden stockpiles for reclamation use. The remaining 91 Mt is used as construction material, of which 89 Mt is for tailings dam wall construction. Backfilling will commence in Year 18 and continue until the end of mine life.Figure 16-8: Waste Dump Locations
![img-42.jpeg](img-42.jpeg)

Diversion dam construction is based on WRF construction sequencing; the estimated lifespan of the American Creek Freshwater Diversion Dam (AFWDD) is approximately three years, from Year -2 to Year 2.

The disposal of PAG waste rock will depend on its reactivity category: PAG rock WRMC 7, or PAG7, will potentially start producing acid in less than a few years, PAG6 in less than a decade, and PAG5 after several decades.

PAG5 rock will be blended with NAG rock when placed in the WRF; the NAG rock has enough neutralizing potential to prevent the PAG5 waste from producing acid. PAG6 waste will initially be placed in encapsulated cells in the Rob's Gulch and Unnamed Gulch sections of the WRF. Water infiltration into this cell will be minimized by a cover of compacted colluvium or terrace gravel.

The PAG-7 waste rock will either be sent to the process or temporarily stockpiled and then placed back into the open pit where it will eventually be submerged.

[[%~%]]
### 16.8.1 Overburden Scheduling And Concurrent Reclamation

Overburden must be pre-stripped from within the pit before production mining begins. The initial stripped materials will be stockpiled for construction and reclamation purposes or placed into the WRF. Materials stripped during the mine production period will continue to be stockpiled or placed into the WRF, but some will also be used directly for construction or reclamation.

[[%~%]]
## 16.9 Water Management And Treatment

Water management will play an important role in mine development. The ACMA pit area is bisected by American Creek, and the west wall of the ultimate pit will be close to Crooked Creek. Surface ditches, a contact water pond immediately upstream of the pit and downstream of the WRF, plus diversion systems further upstream, will control surface waters in the pit and WRF areas. Dewatering systems consisting of vertical dewatering wells, horizontal drains, and in-pit sump pumps will be needed to manage groundwater.

The Operations WTP will be required to treat dewatering and other process water flows that are not expected to meet Alaska Water Quality Standards (AWQS) for discharge to Crooked Creek without treatment. The operations WTP is expected to operate for approximately 29 years ( 2 years during pre-production followed by 27 years during mine operation). The operations WTP will be constructed and placed into operation prior to construction of the process facilities because the dewatering wells need to be placed in service upon commencement of the mine pit development (pre-production).

[[%~%]]
## 16.10 Ore Control

The mining approach chosen for Donlin will require the ability to accurately distinguish the selective mining areas from the bulk mining areas and to accurately predict the actual waste to mineralized material contact. The Ore Control group will be responsible for:

- Managing the RC drilling program
- Sampling and geologic mapping of blastholes and logging of RC drill holes
- Merging assay data with drill holes and blasthole coordinates
- Generating short-range planning block models
- Performing ore and waste delineation, including mine-to-mill reconciliations and quality control.The Ore Control group will fall under the direction of the Geology Department. Ore Control staffing will include 24 -hour coverage by geologists and sampling technicians to assist mine operations with ore-waste decisions. Ore control will rely heavily on digital methods such as high-precision GPS and virtual dig maps because the ore zones are not visually discernable by field personnel. Dark and snowy conditions for much of the year will also add to the reliance on digital techniques.

RC drilling will be the primary method of identifying ore-bearing areas for routing material to the ore stockpiles and crusher. RC drilling has been used extensively in Australia, Africa, and to a lesser extent in other parts of the world to make ore-waste determinations for orebodies that are narrow and steeply dipping. The RC holes at Donlin will be 140 mm diameter inclined at $60^{\circ}$ to intersect the mineralized structures and drilled to a hole length of 42 m . This is within the maximum hole length quoted by the manufacturer of the selected drill rig. Holes inclined at $60^{\circ}$ will provide RC information for three 12 m benches ( 36 m vertically).

[[%~%]]
## 16.11 Blasting And Explosives

A blend of $70 \%$ emulsion phase / 30\% ammonium nitrate/fuel oil (ANFO) will be used for blasting, based on anticipated groundwater conditions.

An explosives supplier will be contracted to provide a "'down-the-hole" blasting service. The supplier will provide the ammonium nitrate (AN), emulsion phase components, and blasting accessories. The supplier will also supply the emulsion plant, explosives magazines, mixing equipment, and delivery trucks. The Donlin operator will provide fuel oil and accommodation. Supplier personnel will charge the holes, place the detonators and boosters, and tie in the patterns.

[[%~%]]
## 16.12 Mining Equipment

The Donlin equipment operating cost, capital cost, performance, and specifications were provided by a number of equipment manufacturers. Based on the manufacturer provided information, a total cost of ownership (TCO) analysis was completed to select the mining equipment to support the study. Note that the initial quotes were budgetary only and the final equipment selections will be made via a competitive selection process.

To determine the number of equipment units required for each major fleet, productivities were calculated based on estimated annual operating hours and mechanical availability. Annual operating hours varied by fleet due to associated availabilities. A value of 50 net operating minutes per gross operating hour (GOH) was applied to all equipment to account for time spenton non-primary production tasks. The vendor-estimated mechanical availability of the equipment decreases with hours worked. An average mechanical availability based on the life of the fleet was assigned to replicate the availability for a fleet containing units of mixed ages.

[[%~%]]
### 16.12.1 Drilling

Donlin will undertake five different types of drilling:

- RC drilling to provide samples for geological modelling
- Blast pattern drilling to fragment the rock for mining
- Frost drilling to deal with previously blasted material that has become frozen
- Horizontal drain hole drilling to prevent water pressure from building up behind the pit walls. The horizontal drain hole drilling is a specialized activity and will be performed by a contractor.
- Vertical dewatering wells. The vertical dewatering well development is a specialized activity and will be performed by a contractor.

To accomplish the five types of drilling, three different types of drill will be used: a rotary drill for bulk waste with 251 mm diameter holes for 12 m benches; a rotary drill with 200 mm diameter holes for ore and waste in 12 m benches; and a hammer drill with 140 mm diameter holes for ore and waste in the 6 m benches and for pre-split and RC drilling.

[[%~%]]
### 16.12.2 Loading

Primary loading will be performed by electric-hydraulic shovels with a $37 \mathrm{~m}^{3}$ bucket. One $40 \mathrm{~m}^{3}$ front-end loader (FEL) will be used for secondary production, and another for backup production, cleanup, and stockpile rehandling.

[[%~%]]
### 16.12.3 Hauling

Large 360 t payload haul trucks will be used for primary mine production. A maximum of sixtynine 360 t payload trucks are required.

[[%~%]]
### 16.12.4 Secondary Fleet

A second fleet of mining equipment will be required for overburden management, concurrent reclamation, snow removal, road maintenance, and special projects. This fleet will consist of smaller, more agile $25 \mathrm{yd}^{3}\left(18.1 \mathrm{~m}^{3}\right)$ FELs and 135 t trucks and will allow the primary fleet to focus on production ore and waste mining.

[[%~%]]
### 16.12.5 Support Equipment

The major tasks to be completed by the support equipment include the following:

- Bench and road maintenance
- Reclamation support
- Stockpile construction
- General maintenance
- Ditch preparation and maintenance
- Tailings dam support
- Shovel Support / cleanup.

Additional auxiliary equipment will serve and support the mine operations and maintenance groups. Equipment selection by function is included in Table 16-3 (drilling equipment), Table 16-3 (shovel fleet), Table 16-4 (mine support equipment), and Table 16-5 (auxiliary equipment). Mine equipment requirements over the LOM are included as Table 16-6.

[[%~%]]
### 16.12.6 Maintenance Considerations

For the first two years, all mobile fleets will be maintained by contractors under Maintenance and Repair Contract (MARC) agreements. It is anticipated that each fleet will have cost and availability guarantees as well as associated warranties. Donlin will be able to minimize risk of maintenance cost increases due to either equipment reliability or labour shortages.

After 15 months, the Donlin will assume more risk but will reduce costs by phasing out the MARC contracts and taking responsibility for all mobile equipment maintenance.

Maintenance on the large drills and excavators will be performed in the field, whereas equipment that can be easily driven or towed will be serviced in the truckshop. The truckshop will be near the long-term ore stockpile, fuel station, and haul road to provide easy access for haul truck maintenance and refuelling.

[[%~%]]
### 16.12.7 Communications Considerations

The mining department at Donlin will use GPS machine guidance and a fleet management system to guide and control the mining operation on a near real-time basis. Fleet management is the assignment of equipment to mining tasks, while GPS machine guidance assists the operator with respect to spatial positioning of the ground-engaging tools.Table 16-2: Annual Required Drill Fleet

| Year | Rotary Drill 9/5" | Rotary Drill 7/5" | Hammer Drill 5/5" |
| :--: | :--: | :--: | :--: |
|  | Fleet Size \# | Fleet Size \# | Fleet Size \# |
| $-1$ | 1 | 2 | 2 |
| 1 | 4 | 11 | 10 |
| 2 | 4 | 11 | 10 |
| 3 | 4 | 11 | 10 |
| 4 | 4 | 12 | 10 |
| 5 | 4 | 12 | 10 |
| 6 | 4 | 12 | 10 |
| 7 | 4 | 13 | 10 |
| 8 | 4 | 13 | 10 |
| 9 | 4 | 13 | 10 |
| 10 | 4 | 13 | 7 |
| 11 | 4 | 14 | 6 |
| 12 | 4 | 14 | 5 |
| 13 | 4 | 15 | 5 |
| 14 | 5 | 14 | 5 |
| 15 | 6 | 14 | 5 |
| 16 | 7 | 14 | 5 |
| 17 | 7 | 14 | 5 |
| 18 | 7 | 14 | 5 |
| 19 | 5 | 14 | 5 |
| 20 | 5 | 14 | 5 |
| 21 | 5 | 14 | 5 |
| 22 | 4 | 11 | 5 |
| 23 | 3 | 7 | 3 |
| 24 | 1 | 7 | 3 |
| 25 | 1 | 2 | 1 |

Table 16-3: Annual Shovel Fleet Required

| Year | Shovel Electric <br> $\left(50 \mathrm{yd}^{3}\right)$ | Shovel Diesel <br> $\left(50 \mathrm{yd}^{3}\right)$ | Front-End <br> Loader $\left(53 \mathrm{yd}^{3}\right)$ | Front-End <br> Loader (25 yd ${ }^{3}$ ) |
| :--: | :--: | :--: | :--: | :--: |
|  | Fleet Size \# | Fleet Size \# | Fleet Size \# | Fleet Size \# |
| $-1$ | 0 | 1 | 1 | 1 |
| 1 | 4 | 1 | 2 | 1 |
| 2 | 4 | 1 | 2 | 1 |
| 3 | 5 | 1 | 2 | 1 |
| 4 | 5 | 1 | 2 | 1 |
| 5 | 5 | 1 | 2 | 1 |
| 6 | 6 | 1 | 2 | 1 |
| 7 | 6 | 1 | 2 | 1 |
| 8 | 6 | 1 | 2 | 1 |
| 9 | 6 | 1 | 2 | 1 |
| 10 | 6 | 1 | 2 | 1 |
| 11 | 6 | 1 | 2 | 1 |
| 12 | 6 | 1 | 2 | 1 |
| 13 | 6 | 1 | 2 | 1 |
| 14 | 6 | 1 | 2 | 1 |
| 15 | 6 | 1 | 2 | 1 |
| 16 | 6 | 1 | 2 | 1 |
| 17 | 6 | 1 | 2 | 1 |
| 18 | 6 | 1 | 2 | 1 |
| 19 | 6 | 1 | 2 | 1 |
| 20 | 6 | 1 | 2 | 1 |
| 21 | 6 | 1 | 2 | 1 |
| 22 | 5 | 1 | 2 | 1 |
| 23 | 3 | 1 | 2 | 1 |
| 24 | 2 | 1 | 2 | 1 |
| 25 | 1 | 0 | 2 | 1 |
| 26 | 0 | 0 | 2 | 0 |
| 27 | 0 | 0 | 1 | 0 |Table 16-4: Mine Support Equipment

| Equipment Unit | Size <br> hp (kW) | Number |
| :-- | :--: | :--: |
| Track Dozer | $850(633.8)$ | 6 |
| Track Dozer | $580(432.5)$ | 4 |
| Wheel Dozer | $800(596.6)$ | 6 |
| Grader | $533(397.5)$ | 3 |
| Grader | $297(221.5)$ | 7 |
| Hydraulic Excavator (5 m² $^{2}$ Bucket) | $513(382.5)$ | 2 |
| Water Truck | $1,450(1,081)$ | 4 |
| Excavator 16 yd | $956(713)$ | 2 |

Table 16-5: Mine Auxiliary Equipment

| Equipment Unit | Number |
| :-- | :--: |
| Horizontal Drain Hole Drill | 1 |
| Excavator with Hydraulic Hammer | 1 |
| 220 Ton (200 tonne) Class Crane | 1 |
| 165 Ton (150 tonne) Class Crane | 1 |
| 66 Ton (60 tonne) Class Crane | 1 |
| 26 Ton (23.5 tonne) Forklift | 1 |
| 18 Ton (16.3 tonne) Forklift | 1 |
| 5 Ton (4.5 tonne) Telehandler | 1 |
| 5 Ton (4.5 tonne) Forklift | 1 |
| Fuel / Lube Truck | 3 |
| Medium Mech Truck | 4 |
| Large Mech Truck | 1 |
| Tire Handler | 2 |
| SVE Lift Truck | 1 |
| Loader | 1 |
| Lowboy / Tow | 1 |
| Operations Field Truck | 1 |
| Soil Compactor | 1 |
| Backhoe Loader | 1 |
| Light Plant | 20 |
| Skid Steer Trailer | 3 |
| Light Vehicle | 35 |
| Crew Bus | 5 |
| Cable Reeler | 1 |
| Shovel Motivator | 1 |
| Excavator 16 yd3 | 2 |Table 16-6: Mine Equipment Requirements

|  | LOM | P-P | Prod. | $-1$ | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 15 | 16 | 17 | 18 | 19 | 20 |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Installed Fleet |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shovel Electric ( $50 \mathrm{yd}^{4}$ ) | 6 |  | 6 |  | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 |
| Shovel Diesel ( $50 \mathrm{yd}^{4}$ ) | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| Front-End Loader (53 yd3) | 2 | 1 | 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 |
| Front-End Loader (25 yd3) | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| Haul Truck (400 st) | 69 | 9 | 69 | 9 | 28 | 34 | 35 | 35 | 40 | 45 | 47 | 55 | 60 | 60 | 60 | 60 | 60 | 66 | 69 | 69 | 69 | 69 | 69 |
| Haul Truck (150 st) | 10 | 10 | 10 | 10 | 10 | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 8 |
| Rotary Drill $97 / 8^{\circ}$ | 7 | 1 | 7 | 1 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 6 | 7 | 7 | 7 | 5 | 5 |
| Rotary Drill $77 / 8^{\circ}$ | 15 | 2 | 15 | 2 | 11 | 11 | 11 | 12 | 12 | 12 | 13 | 13 | 13 | 13 | 14 | 14 | 15 | 14 | 14 | 14 | 14 | 14 | 14 |
| Top Hammer Drill $51 / 2^{\circ}$ | 10 | 2 | 10 | 2 | 10 | 10 | 10 | 10 | 10 | 10 | 10 | 10 | 10 | 7 | 6 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 |
| Track Dozer (850 hp) | 6 | 4 | 6 | 4 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 |
| Track Dozer (580 hp) | 4 | 3 | 4 | 3 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 |
| Wheel Dozer (800 hp) | 6 | 4 | 6 | 4 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 |
| Grader (533 hp) | 3 | 1 | 3 | 1 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 3 | 3 |
| Grader (297 hp) | 7 | 3 | 7 | 3 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 6 | 6 | 6 | 6 | 6 | 6 | 7 | 7 | 7 | 7 | 7 | 7 |
| Water Truck | 4 | 1 | 4 | 1 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 |
| Excavator (6.5 yd ${ }^{4}$ ) | 2 | 1 | 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| Excavator ( $16 \mathrm{yd}^{4}$ ) | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 |
| Fuel Truck | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 2 |
| Service Truck | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| Mobile Crane | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| Low Boy Truck | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| Tire Handler | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 |
| Light Plant | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 10 |Table 16-6 (Continued): Mine Equipment Requirements

|  | 21 | 22 | 23 | 24 | 25 | 26 | 27 |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Installed Fleet |  |  |  |  |  |  |  |
| Shovel Electric $\left(50 \mathrm{yd}^{3}\right)$ | 6 | 5 | 3 | 2 | 1 |  |  |
| Shovel Diesel ( $50 \mathrm{yd}^{3}$ ) | 1 | 1 | 1 | 1 |  |  |  |
| Front-End Loader (53 yd3) | 2 | 2 | 2 | 2 | 2 | 2 | 1 |
| Front-End Loader (25 yd3) | 1 | 1 | 1 | 1 | 1 |  |  |
| Haul Truck (400 st) | 60 | 31 | 23 | 23 | 6 | 4 | 4 |
| Haul Truck (150 st) | 8 | 5 | 5 | 5 | 5 |  |  |
| Rotary Drill $97 / 8^{\prime \prime}$ | 5 | 4 | 3 | 1 | 1 |  |  |
| Rotary Drill $77 / 8^{\prime \prime}$ | 14 | 11 | 7 | 7 | 2 |  |  |
| Top Hammer Drill $51 / 2^{\prime \prime}$ | 5 | 5 | 3 | 3 | 1 |  |  |
| Track Dozer (850 hp) | 6 | 6 | 5 | 5 | 4 |  |  |
| Track Dozer (580 hp) | 4 | 4 | 3 | 3 | 2 |  |  |
| Wheel Dozer (800 hp) | 6 | 5 | 4 | 4 | 3 |  |  |
| Grader (533 hp) | 2 | 1 | 1 | 1 | 1 |  |  |
| Grader (297 hp) | 6 | 3 | 3 | 3 | 1 |  |  |
| Water Truck | 4 | 3 | 2 | 2 | 1 |  |  |
| Excavator ( $6.5 \mathrm{yd}^{3}$ ) | 1 | 1 | 1 | 1 | 1 |  |  |
| Excavator ( $16 \mathrm{yd}^{3}$ ) | 2 | 1 | 1 | 1 | 1 |  |  |
| Fuel Truck | 2 | 2 | 2 | 2 | 2 |  |  |
| Service Truck | 1 | 1 | 1 | 1 | 1 |  |  |
| Mobile Crane | 1 | 1 | 1 | 1 | 1 |  |  |
| Low Boy Truck | 1 | 1 | 1 | 1 | 1 |  |  |
| Tire Handler | 2 | 2 | 2 | 2 | 2 |  |  |
| Light Plant | 10 | 10 | 10 | 10 | 10 |  |  |

[[%~%]]
## 16.13 Work Schedule

The work schedule assumes mine production will operate $24 \mathrm{~h} / \mathrm{d}, 7 \mathrm{~d} / \mathrm{wk}, 365 \mathrm{~d} / \mathrm{a}$. Operations personnel will work on two $12 \mathrm{~h} / \mathrm{d}$ shifts. All hourly (non-exempt) personnel assigned to the mine will work a 2 -weeks-in/1-week-out rotation, while all salaried (exempt) personnel will work a $12 \mathrm{~h} / \mathrm{d}$ shift on an 8 -days-in/ 6-days-out rotation, a 2 -weeks-in/ 1-week-out rotation, or a 2 -weeks-in/2-weeks-out rotation.

[[%~%]]
## 16.14 Comments On Section 16

In the opinion of the QP, the following conclusions and interpretations are appropriate:

- The pit design adds 2 Mt of ore and 194 Mt of waste compared to the 2020 optimization shell. These tonnages represent an additional $0.4 \%$ of ore and $7.5 \%$ of waste. Although high, the increase in waste is considered acceptable according to current design guidelines; consequently, the 2020 optimization work supports the feasibility study pit designs that were summarized in the Donlin 2011 Technical Report, and are considered as still current.- The proposed Project will be a conventional, large-tonnage, open-pit operation designed to provide for a nominal process throughput of $19.5 \mathrm{Mt} / \mathrm{a}$, or $53,500 \mathrm{t} / \mathrm{d}$. The operating mine life is estimated at 25 years based on the planned processing rate.
- The mine design, complete with haulage access, includes 504.8 Mt of ore containing 33.8 Moz of in-situ gold and has a strip ratio of 5.48:1. The mine design is considered appropriate to the quantity of Proven and Probable Mineral Reserves estimated for the Project.
- The mine plan developed for the Project envisages mining nine pit phases at ACMA, and six pit phases at Lewis.
- Pit phase designs were based on optimized nested pit shell guidance, gold grade, strip ratio, access, and backfilling of the ACMA phases. Ramps in the final walls have a design width of 40 m and a gradient of $10 \%$. A nominal minimum mining width of 150 m was used for phase designs.
- The SMUman process used to dilute the block model adds diluting waste blocks to the mineral inventory. Globally, all of these blocks are processed over the LOM.
- Donlin will be mined by a combination of bulk and selective mining. The SMU block size of four contiguous blocks of $6 \mathrm{~m} \times 6 \mathrm{~m} \times 6 \mathrm{~m}$ reflects the selectivity of the selective mine areas. The SMU block size of four contiguous blocks of $6 \mathrm{~m} \times 6 \mathrm{~m} \times 12 \mathrm{~m}$ reflects the selectivity of the bulk mine areas. The bench height will be either 6 m or 12 m , depending on mining selectivity requirements. The risk associated with split-bench mining is that operations may choose to abandon the practice, potentially increasing dilution.
- The processing rate is variable from period to period as a function of sulphur grade and ore hardness. To maximize overall plant utilization, long-term ore stockpiling and blending strategy is required to balance sulphur feed grades. Short-term stockpiling will also be required to handle crusher downtime and production fluctuations in the pit.
- Short-term ore stockpile rehandle to achieve process feed sulphur grade targets was assumed for this study to be $45 \%$, but this could potentially be up to $100 \%$ (worst case). In the 2007 feasibility study, the assumed rehandle level was only $25 \%$. The estimate for this study is based on short-term planning simulations and expectations of fleet interactions.
- Mining will be carried out using a mixed shovel fleet and trucks. Mining equipment requirements are based on the mine production schedule and equipment productivities and include considerations for workforce and operating hours. The fleet is appropriate to the planned production schedule.- The mine design incorporates geotechnical and hydrogeological considerations. Geotechnical information was collected by BGC, who provided the slope design parameters for the open pit.
- Surface ditches, a contact water pond (CWP) immediately upstream of the pit and downstream of the WRF, plus diversion systems further upstream of the CWP, will control surface waters in the pit and the WRF areas. Dewatering systems consisting of perimeter and in-pit vertical dewatering wells, horizontal drains, and in-pit sump pumps will be required to manage groundwater.
- A total of 2,232 Mt of waste will be stored in a single ex-pit WRF in the American Creek Valley, east of the pit area. Another 425 Mt of waste rock will be backfilled in the ACMA pit and 17 Mt of overburden in the overburden stockpiles for reclamation use. The remaining 191 Mt is used as construction material, of which 89 Mt is for tailings dam wall construction.
- The waste rock is characterized by its potential for acid generation and has been assigned reactivity categories. Categories 1 to 4 are NAG, and 5 to 7 are PAG. PAG7 rock will potentially start producing acid in less than a few years, PAG6 in less than a decade, and PAG5 after several decades.

[[@~@]]
# 17.0 Recovery Methods

[[%~%]]
## 17.1 Plant Design

The process design criteria have remained consistent with what was used in the Donlin 2011 Technical Report.

The numbers shown in the criteria below indicate conditions of a plant operating at full capacity. They are appropriate for plant design, but they do not take into account variation introduced during facility start-up or tapering off of production near the end of mine life. As the design criteria is not based on mine schedule, it is not appropriate to use for overall metallurgical accounting or the financial plan.

Conversely, the values used in the financial models were generated based on mine plan projections as part of the operating cost compilation. These operating costs were calculated separately from the design criteria document. The process operating costs in this Report were updated with 2020 power unit costs, reagent and consumables pricing, maintenance and maintenance supplies, and labor rates.

Additional optimization testwork was carried out in 2017 and 2018 that may represent some opportunities to improve on the existing process design but requires additional testwork and analysis before considering any re-design. The process design summarized in this Report has no changes to what was included in the Donlin 2011 Technical Report.

[[%~%]]
### 17.1.1 General

The process is based on conventional and proven technology for the concentrator, flotation, POX, and cyanidation facilities for large, modern gold processing plants. A simplified flow diagram of the overall process is shown in Figure 17-1. All process equipment, except for thickening, neutralization tanks, and concentrate storage tanks, will be enclosed in buildings. Installed standby pump spares are provided for all critical process streams.Figure 17-1: Donlin Gold Project Process Plant Simplified Flow Diagram
![img-43.jpeg](img-43.jpeg)

[[%~%]]
### 17.1.2 Crushing And Coarse Ore Stockpile

Mine haul trucks (with capacities to 360 t ) will dump ROM open-pit ore directly into dump hoppers ahead of a $60^{\prime \prime} \times 89^{\prime \prime}$ gyratory crusher. The maximum design crushing capacity of the crusher is $4,630 \mathrm{t} / \mathrm{h}$ producing a crusher product at P80 125 mm . The discharge of the crusher will be to a covered coarse ore stockpile with a live capacity of $38,000 \mathrm{t}$ of ore, representing 16 hours of process plant operation, and a total capacity of approximately $174,000 \mathrm{t}$, representing 3.2 days of process plant operation.

The reclaim tunnel with feeders will be used to reclaim material from the stockpile discharging onto the SAG mill feed conveyor. The normal SAG mill feed rate will be $2,397 \mathrm{t} / \mathrm{h}$. SAG mill critical size material will report to the pebble crusher. The discharge from the pebble crusher will join the new feed from the coarse ore stockpile.

[[%~%]]
### 17.1.3 Grinding And Pebble Crushing

The overall grinding configuration will consist of an open-circuit SAG mill followed by the MCF2 circuit. The MCF2 circuit will entail a primary ball mill followed by primary rougher flotation; the tailings produced from primary flotation will be sent to a secondary ball mill, followed by a secondary rougher flotation. The two individual ball mills will operate in a closed circuit with their respective classification cyclones.

SAG mill discharge will be screened, and oversized pebbles are conveyed to two large pebble cone crushers. Crushed pebbles will normally be returned to the SAG mill. Typical SAG mill discharge will have a $\mathrm{P}_{80}$ of $1,700 \mu \mathrm{~m}$. After primary ball mill grinding, the $\mathrm{P}_{80}$ is anticipated to be $121 \mu \mathrm{~m}$; after secondary grinding, the $\mathrm{P}_{80}$ is anticipated to be $50 \mu \mathrm{~m}$. The total system throughput is expected to average $53,500 \mathrm{t} / \mathrm{d}$ at $93 \%$ availability.

The SAG mill feed conveyor will discharge into the SAG mill feed chute and then into the SAG mill. Process solution will be added at this point to flush the ore into the mill and provide the correct dilution for grinding. Copper sulphate will be added to the feed end of the SAG mill to activate sulphide mineralization. The SAG mill discharge will be screened with undersize from the trommel screen and vibrating discharge screen prior to flowing into the primary cyclone feed pumpbox. The 38 ft diameter X 22 ft long SAG mill will be powered by a 20 MW ) wraparound variable-speed drive.

Optimum economics are expected to be achieved by using the fewest, largest equipment units available. The 26 ft diameter $\times 45 \mathrm{ft}$ long ball mills will be trunnion-supported units with $24,000 \mathrm{hp}$ (18 MW) wrap-around drive configurations. Discharge from the primary ball mill will exit the discharge trunion into a trommel screen attached to the ball mill. Oversize material willdrop from the end of the trommel screen into a rejects hopper. Undersize material will pass through the trommel screen into the primary cyclone feed pumpbox along with the SAG mill screen underflow. The primary cyclone feed pump will be variable-speed and will transport slurry to the cyclone cluster, which will classify particles by size to return coarse particles to the ball mill for further size reduction.

The primary cyclone overflow will be designed to operate at $40 \%$ solids, with an anticipated average $80 \%$ passing particle size of $121 \mu \mathrm{~m}$; the cyclone circulating load is estimated to be $210 \%$. The fresh feed for the secondary ball mill will be a combination of the slurry from the rougher tailings pumpbox and the cleaner scavenger concentrate. These streams will flow into the secondary grinding cyclone feed pumpbox, where they will join the secondary ball mill discharge.

Discharge from the secondary ball mill will exit in the same manner as for the primary mill. Oversize material will be dropped from the end of the trommel screen into a rejects hopper, as undersize material will pass through the trommel screen and into the secondary cyclone feed pumpbox, together with the rougher tailings and the cleaner scavenger concentrate. The secondary cyclone feed pump (variable-speed) will transport slurry to the secondary cyclone clusters. The secondary cyclone overflow will be anticipated to be $27.2 \%$ solids with an average $80 \%$ passing particle size of $50 \mu \mathrm{~m}$; the cyclone circulating load is estimated at $210 \%$.

[[%~%]]
### 17.1.4 Flotation

Donlin ore contains a mixture of intrusive and sedimentary rock hosted sulphide mineralization. The optimum gold recovery will be achieved by maximizing sulphide recovery. Producing a bulk flotation concentrate in two rougher flotation steps with relatively low selectivity and high mass pulls has been determined to provide the best results. The secondary rougher concentrate will be sent to a cleaner flotation circuit; the concentrate obtained from cleaner flotation will be combined with the primary rougher concentrate. The tails obtained from the cleaner flotation will be sent to a cleaner scavenger flotation train. The cleaner scavenger concentrate will be sent to the secondary grinding cyclone feed pumpbox, and the tails will be mixed with rougher tailings flow by gravity to the flotation tailings thickener. The primary rougher concentrate and the concentrate produced from the cleaner flotation will report to the concentrate thickener.

Overflow slurry from the primary grinding circuit cyclone will be fed through a flotation safety screen before entering conditioning tank No. 1. Oversized material will be sent to a hopper, and undersize material will pass through to conditioning tank No. 1.

Acidic solution from the POX CCD washing circuit, as well as flotation process water and copper sulphate, will be added to the first conditioning tank. The slurry then will then pass toconditioning tank No. 2 where potassium amyl xanthate (PAX), dispersant Cytec E-40, and methyl isobutyl carbinol (MIBC) frother will be added. The discharge from the second conditioning tank will be pumped to a distributor box, which will split the feed to two parallel rows of $300 \mathrm{~m}^{3}$ primary rougher cells. The rougher flotation feed pump system will include an installed spare. Each bank of cells will have 11 individual units and provide 57 minutes of residence time.

Primary rougher concentrate from the rougher portion will be sent directly to the concentrate thickener. Primary rougher tailings will be sent to the secondary grinding cyclone feed pumpbox as part of the MCF2 circuit.

The secondary rougher flotation circuit will be fed from the secondary rougher conditioning tank where copper sulphate and MIBC will be added. The flow will be divided into two trains; each train will have 11 individual $300 \mathrm{~m}^{3}$ secondary rougher cells providing a total residence time of 57 minutes. Additional MIBC, PAX, Cytec E-40, soda ash, and a second frother, F-549, will be added throughout the secondary rougher trains.

Secondary rougher concentrate will be sent to the cleaner flotation cells bank. Secondary rougher tailings will be sent directly to the flotation tailings thickener.

The secondary flotation concentrate will be cleaned in a bank of six $300 \mathrm{~m}^{3}$ tank-type flotation cells, with a bank residence time of 100 minutes. The concentrate will be sent to the cleaner concentrate pumpbox, from where it will be pumped to the concentrate thickener. The cleaner tailings will flow by gravity to the cleaner scavenger flotation cell bank.

The cleaner scavenger bank will have four $300 \mathrm{~m}^{3}$ cells with a combined residence time of 150 minutes. The cleaner scavenger concentrate will be sent to the secondary grinding cyclone feed pumpbox. The tailings will be sent to the flotation tails thickener by gravity. Flotation streams will be sampled automatically for metallurgical accounting and control purposes.

An on-stream x-ray fluorescent analyzer (on Fe and As) will provide continuous data to enable operators and supervisory control systems to optimize flotation and to respond to upset conditions.

A slip stream from each of the two cyclone overflow streams will be passed through a particle size analyzer to provide information for grinding control.

[[%~%]]
### 17.1.5 Thickening, Concentrate Storage, Acidulation, And Ccd Washing

Concentrate from flotation will pass to a $3.5 \times 5 \mathrm{~m}$ concentrate thickener de-aeration tank and then to a 45 m diameter concentrate thickener. Thickener overflow will be returned to the grinding and flotation areas as process water while underflow at an estimated $46 \%$ solids will be pumped to the concentrate storage tank circuit. A total of 36 hours of concentrate storage will be provided. In normal operation material will be withdrawn from this circuit and sent to the acidulation circuit. A bypass line will be provided to pump slurry directly from thickening to acidulation, where acidic solution recovered from the POX counter-current decantation (CCD) wash circuit will be mixed with the concentrate with the aim of consuming $85 \%$ to $100 \%$ of the carbonate gangue component of the concentrate.

The acidulated material will be washed in a three-thickener CCD circuit that will displace the solution with raw water to reduce the overall levels of soluble mineral species reporting to the POX circuit in the slurry.

[[%~%]]
### 17.1.6 Autoclave Plant

Acidulated feed slurry will be stored in one agitated autoclave feed storage tank adjacent to the POX area. This tank will provide the autoclave plant with a continuous feed unaffected by shortterm upstream throughput variations. When full, it will allow the autoclave circuit to continue operating for four hours when upstream equipment is not operating. Slurry will be transferred from the feed tank by two parallel lines, each equipped with a slurry heater feed pump. Slurry will be transferred to the heater vessels that will pre-heat the incoming slurry to varying temperatures, depending on the sulphide sulphur grade of the feed material. Pre-heat temperature will be optimized based on maintaining autogenous conditions in the autoclave while minimizing cooling water addition. Slurry pre-heating will be accomplished with the use of flash steam produced in the pressure letdown flash vessels on the autoclave discharge. Each autoclave train will discharge to two flash vessels and two vent gas cyclones via parallel slurry discharge lines. Slurry heater discharge temperature control will be achieved by bypassing a portion of the feed to each heater to the heater sump. From each heater discharge, a single feed line will feed each autoclave, each with a charge pump to create sufficient pressure for the suction side of the autoclave slurry feed pump; a slurry strainer to remove any scale or oversize particles that could damage the autoclave slurry feed pumps; and a high-pressure pistondiaphragm feed pump with suction accumulator and discharge dampener. The autoclave will be supplied with high-pressure oxygen gas, high-pressure cooling water, and high-pressure steam. Oxygen will be produced at an on-site air separation plant. Cooling water will be distributed to the autoclave from a cooling water tank located locally in the POX area. High-pressure, horizontal multi-stage centrifugal pumps will supply the cooling water to allcompartments of the autoclave. A common piping system (and spargers) will be utilized for both the oxygen and high-pressure steam to the autoclave.

High-pressure steam (produced from de-mineralized water) will not be required for normal operation, but is required for autoclave heat-up. De-mineralized water will also be used for the agitator seal water system and the oxygen plant boiler system. The autoclave building will be serviced by an overhead crane, allowing any of the agitators to be removed without need for disc disassembly (impeller blades require removal).

Each autoclave is approximately 5 m diameter x 33 m long (tan-tan) and will discharge into two flash vessels in parallel. The flash vessels are approximately 5 m diameter x 5 m long (tan-tan). Autoclave discharge slurry will be depressurized to near-atmospheric pressure, generating flash steam in the process. Flash vessel underflows will be directed by gravity to an oxidized slurry seal tank. Slurry from this tank will be transferred by gravity to the downstream hot cure tanks. Steam generated at the hot cure tanks will be condensed using a spray tree condenser vessel. Vent-gas from the autoclave will be passed into the vent gas quench vessel. Flotation tails will be used as quenching medium, as the steam will be condensed across a baffle arrangement inside the vessel. The quench vessel will reduce the temperature of the vent-gas and the quantity of steam (through condensation) that will be fed to downstream equipment. The quench vessel will also facilitate additional removal of carryover from the autoclave and slurry heater, and pre-heat the flotation tails ahead of the downstream neutralization process, thereby improving kinetics. Vent gas from the quench vessel will be piped to a secondary spray tree condenser vessel where raw water will further cool the gas and steam condenses. The gas will then pass through a venturi scrubber where the gas will be further cleaned of particulates by pressure drop and the addition of fresh water.

Gas will exit the venturi scrubber saturated with water vapor and at a temperature of $40^{\circ} \mathrm{C}$. The process off-gas temperature will be reduced to a target of $4^{\circ} \mathrm{C}$. The gas volume will also be reduced by water vapor condensation. The wet-gas condenser will promote the condensation of elemental mercury during periods of upset conditions with higher than normal gaseous mercury levels. The overall mercury loading on the downsteam carbon adsorption process will be reduced as a result. Gas will then enter a wet gas coalescer to drop out any remaining entrained mercury. Gas will be first subjected to cyclonic separation and then will enter a coalescer prior to the carbon pre-cleaning section.

The combined gas will enter a pre-cleaning carbon bed. The relatively inexpensive activated carbon contained in the pre-cleaning bed will be used to remove volatile organic compounds (VOCs). Exiting gases will immediately enter the mercury removal carbon bed, which will contain sulphur-impregnated carbon, specifically designed to adsorb vapour-phase mercury. Oxidized and particulate forms of mercury will also be collected. The carbon bed vessels are4.5 m diameter $\times 2.5 \mathrm{~m}$ high (tan-tan). Cleaned gas will be discharged to atmosphere. The mercury-loaded carbon will be removed periodically in an environmentally safe manner and sent off site for disposal. A standby series of carbon beds will be available so that neither production nor mercury removal will be interrupted when a bed will be taken off line for carbon change-out or maintenance.

A common mercury collection tank will receive all the condensate and scrubber water from the POX gas handling systems. The tank will be designed to settle mercury and separated solids removed from the gas, clarifying the water. The clarified water will be passed through coalescing filters to remove any remaining elemental mercury prior to being recycled to the chloride wash circuit. Coalesced elemental mercury will be returned to the mercury collection tank for settling. The resulting sludge will then be drained from the mercury collection tank as contaminated waste.

[[%~%]]
### 17.1.7 Ccd Pox Thickening And Washing

Slurry flow from the POX circuit will be washed in a four-thickener CCD circuit. The thickeners are 50 m . Reclaim water will be added to the last thickener in a flow direction counter to the solids in order to decrease the acidity of the pulp.

Washed slurry in the underflow from the final thickener will be pumped to the CIL solids neutralization circuit. Thickener overflow will be treated in a clarifier and used within the plant to provide acidification of the concentrate fed to the POX circuit, and to the flotation feed to assist in promotion of the sulphide mineral floatability. The remainder will report to neutralization. Clarifier sludge will be intermittently returned to the first thickener in the circuit.

[[%~%]]
### 17.1.8 Flotation Tailings Neutralization

In this circuit, flotation tailing will be pre-heated to $55^{\circ} \mathrm{C}$ through the autoclave quench vessel and then combined with the excess diluted acidic wash liquor from the chloride CCD wash circuit in a series of large aerated and agitated tanks. The flotation tailings will act as neutralizing material (source of natural carbonates) for reaction with the acidic liquor. All neutralization tanks will be insulated for heat conservation.

Flotation tailings will be collected, sampled, and passed to the flotation tailings thickener. Thickener overflow will be pumped to the flotation process water tank. Thickener underflow will be pumped to the POX circuit autoclave scrubber.

Acidic solution from the POX CCD wash and spent acid from the elution circuit will be combined with autoclave quench tails in the solution neutralization circuit. The circuit will consist of fivemechanically-agitated and aerated tanks in series. Enough reaction time will be provided in the front-end portion of the circuit to bring the pH of the solution up to five, utilizing the quench tails. Tailings from the cyanide destruction circuit will be introduced into a lime neutralization tank where lime will be added in the presence of air to bring the pH to seven. This material will then flow by gravity to the final tailings pumpbox. Owing to their size, the Flotation Tailings neutralization tanks will be installed outdoors.

[[%~%]]
### 17.1.9 Solids Cil Neutralization

Underflow from the final POX CCD wash circuit thickener will be neutralized in the solids CIL neutralization circuit. The circuit will consist of two mechanically-agitated tanks where lime will be added to the slurry in the presence of oxygen to bring the pH of the slurry to approximately 11.0. This material will then be pumped to the CIL circuit.

[[%~%]]
### 17.1.10 Carbon-In-Leach Cyanidation Circuit

A nominal tonnage of $365 \mathrm{t} / \mathrm{h}$ at $35 \%$ solids will be pumped to the first of six CIL tanks. The slurry, with a retention time of four hours per tank, will flow by gravity through each of the six tanks, ultimately reporting to the cyanide destruction reactor tank.

The slurry will flow by gravity from the sixth, or final, CIL tank to the safety screen feed distribution box. A distribution box will direct the slurry to either one or both of two carbon safety screens. The safety screens will prevent carbon that passes through the screen in the last CIL tank from leaving the circuit to the tailings storage facility. Screen undersize will flow by gravity to the cyanide destruction reactor tank and will then be pumped to flotation tailings neutralization tank No. 5 by centrifugal slurry pumps. Sodium cyanide solution will be pumped to the CIL circuit for cyanide leaching of gold. A lime loop will allow for lime addition to each of the six CIL tanks. The pH will be monitored, and lime added as needed to maintain a pH set point of approximately 11.0 .

Oxygen required for cyanide leaching will be supplied as pure oxygen from the oxygen plant.
The CIL tanks and cyanide destruction reactor tank will be covered to contain any HCN gas that evolves during cyanide leaching. The tanks will be ventilated, and the gas is passed to an HCN scrubber caustic solution to recycle HCN.

A carbon concentration of $15 \mathrm{~g} / \mathrm{L}$ will be maintained in each of the CIL tanks. Each tank will be equipped with a carbon retention screen to allow the slurry to pass through to the next tank and will prevent the carbon from passing through. A vertical carbon advance pump with a recessed impeller installed in each tank will pump the carbon upstream, counter-current to theflow of slurry, at a rate of $23 \mathrm{t} / \mathrm{d}$. Barren carbon from the carbon transfer tank in the carbon stripping and regeneration circuit will be pumped to the sixth CIL tank to replace the carbon pumped upstream. Loaded carbon will be pumped from CIL tank No. 1 over the loaded carbon screen. The screen oversize will be washed carbon and will report to one of the two carbon acid-wash vessels.

[[%~%]]
### 17.1.11 Cyanide Destruction System

Slurry from CIL tank 6 will flow by gravity through the carbon safety screens, and the screen undersize will report to the cyanide destruction reactor tank. This will be a covered, agitated tank where the residual weakly acid-dissociable (WAD) cyanide concentration will be reduced from nominally 100 ppm to the cyanide levels required by permit. Air and $\mathrm{SO}_{2}$ will combine to oxidize the cyanide to carbon dioxide and ammonia. Copper sulphate solution will be added to top of the tank and will serve as a reaction catalyst to maintain the reaction kinetics. Lime will be added as necessary to maintain an approximate pH level to ensure adequate reaction kinetics. The destruction reactor tank will be sized for one hour of retention time.

[[%~%]]
### 17.1.12 Carbon Elution, Electrowinning, Reactivation, And Gold Refining

Loaded carbon, at a nominal gold loading of $4,800 \mathrm{~g} / \mathrm{t}$, will report to one of two 12 t capacity carbon acid-wash vessels by gravity from the loaded carbon screen. The two acid wash vessels will process $36 \mathrm{t} / \mathrm{d}$ of carbon. After the acid wash and neutralization processes are complete, the carbon will be pumped from the acid wash vessel to one of two strip vessels. A carbon strip will begin as soon as the carbon is transferred to the strip vessel and the transport water has completely drained out of the vessel. For ease of operation, the two strip vessels will be the same size as the two acid wash vessels. Barren solution, at a concentration of $1 \% \mathrm{NaOH}$ and $0.1 \% \mathrm{NaCN}$, will be pumped through the bottom of the strip vessel. The pregnant solution will exit the strip vessel and flow through the heat exchanger before reporting to the pregnant tank. The barren solution will be pumped through the strip vessel for a nominal eight hours to complete each strip. When the strip is complete one bed volume of raw water will be pumped through the strip vessel. This solution will rinse the residual solution from the carbon and cool the carbon in preparation for transfer.

After the carbon is rinsed, it will be pumped to the carbon dewatering screen before the kiln. Carbon will be processed through the kiln at the rate of $1.5 \mathrm{t} / \mathrm{h}$ for reactivation. The kiln will be sized to process $100 \%$ of the carbon stripped to maintain high carbon activity levels throughout the carbon circuit.The pregnant solution will be pumped through two parallel trains of two electrowinning cells at a nominal flow rate of $48 \mathrm{~m}^{3} / \mathrm{h}$. On exiting the cells, the solution will report to the barren solution discharge tank and is pumped to the barren tank.

The electrowinning cells will be taken out of service for cleaning three times each week. One cell will be shut down and cleaned at a time, allowing the electrowinning circuit to function normally while the cell is cleaned. The precious-metal-bearing sludge will be washed from the bottom of the cell. The cathodes will either be washed in place or removed to a wash tank and power-washed to release the sludge. The sludge from the electrowinning cell and the cathode wash tank will report to the electrowinning sludge tank by gravity and be pumped through one of two sludge filter presses. The solution discharged from the sludge press reports to the barren solution discharge tank for return to the barren tank.

The sludge filter presses will be taken down and cleaned after the electrowinning cells are cleaned. The sludge will be placed in pans, loaded into a mercury retort, and heated to remove mercury. Most of the mercury will report as elemental mercury and be collected in 34.5 kg flasks, which will be shipped off site. The remaining mercury collected in the retort will adsorb onto activated carbon within the retort. Periodically the activated carbon will become loaded with mercury and will be replaced with new carbon. The carbon loaded with mercury will be shipped off site.

Smelting fluxes will be mixed with the sludge after the retort, and the mixture will be charged to the induction smelting furnace. Doré bars will be poured from the smelting furnace and shipped off site for further refining.

[[%~%]]
### 17.1.13 Mercury Abatement Systems

The mercury abatement circuits in gas handling have been improved and designed in more detail. Mercury abatement systems will be required at the following locations:

- Carbon reactivation - kiln feed and discharge
- Electrowinning cell fume hoods
- Gold refinery area
- POX vent gas (designed by Hatch and described in the autoclave section).

In each area, mercury will be expected to volatilize into the gas stream exiting the circuit because of the elevated temperatures. Fume hoods and ducting will be used to transport the gas to mercury scrubbing systems and other mercury removal equipment. Mercury will becollected and disposed of in two forms: condensed liquid, which will be collected in specialized flasks, and mercury-loaded carbon. Both will be shipped off site.

The mercury recovery system for the regeneration kiln will consist of a spray wet scrubber, a venturi scrubber, a wet gas condenser, a coalescer, and carbon columns. The resulting clean gas will be exhausted through a stack to atmosphere. The spent carbon from the carbon filters will be periodically replenished with fresh carbon. Spent carbon transferred out of the columns will be securely packaged and is transported off site to a certified hazardous waste facility.

Raw water will be used as the quenching and scrubbing solution. In the process, various condensate streams will be collected from the scrubbing circuit. In the regeneration abatement system, the excess condensates can be sent directly to the POX blowdown area or via a coalescer to recover remaining amounts of mercury down to regulatory limits before being pumped to the POX area for reuse in the process.

In the electrowinning area, vapor and air from the electrowinning cells and other equipment in the gold recovery area will be discharged at a rate of approximately $227 \mathrm{~m}^{3} / \mathrm{min}$ and at temperatures up to $80^{\circ} \mathrm{C}$. The mercury in this stream will be recovered using two wet spray scrubbers, a venturi scrubber, a wet gas condenser, and a coalescer. Carbon columns set up in a lead-lag fashion will serve as the final capture for mercury down to regulatory limits in this area.

A booster fan will funnel the final air stream out through an exhaust stack to the atmosphere. The carbon from the carbon filters will be periodically disposed of to a certified hazardous waste facility.

Raw water will be used throughout the scrubber system. Overflow water will be sent to a coalescer and settling tank combination to capture elemental mercury before proceeding to cyanide destruction. The underflow discharge of these systems will be sent to a solution collection tank in the cyanide area mercury treatment facilities. The heavier mercury that settles to the bottom of the tank will be pulled out for disposal. The discharge water closer to the top of the tank will be pumped to a recirculating coalescer, from which treated scrubber solution will be pumped to the cyanide destruction circuit.

In the refinery, gas discharge from the induction furnace will leave the unit at an elevated temperature of $80^{\circ} \mathrm{C}$ and low mercury content, but with potential for dusting. Therefore, the mercury entrainment system in this area will consist of a dust capture cyclone and carbon columns. The cyclone will capture gold particulate that has drifted out in the gas stream, which will then pass through two sets of carbon column sets, both filled with sulphur-impregnatedcarbon. These will pull out any remaining mercury before a booster fan releases the gas to atmosphere through an exhaust stack.

[[%~%]]
### 17.1.14 Reagent Preparation

All reagent mixing will take place in a designated area within the mill building. The design of this area will incorporate such features as section bunding with dedicated sump pumps for individual reagent types, and segregated ventilation and dust control for areas with potential for dust or fume release. The design of the reagent preparation area aims to be consistent with the general intent of the International Cyanide Management Code.

Reagents will be received in the followed forms:

- Xanthate - will be received as pellets in 850 kg bulk bag.
- Frother 1 (Methyl isobutyl carbinol, MIBC) - will be received in 20 t bulk isotainers as a high-strength solution.
- Frother 2 (F549) - will be received in 1 t reagent totes as a high-strength solution.
- Dispersant - will be received in 23 t bulk isotainers as a high-strength solution.
- Soda Ash - will be received as granules in bulk in 18.1 t lined sea containers.
- Flocculant - will be received as powder in 6 m lined containers.
- Cyanide - will be received as briquettes in bulk 22 t isotainers. To minimize personnel exposure to the reagent mixing process, each isotainer will be pre-piped to serve as a cyanide mix tank.
- Carbon - will be received in 454 kg bulk bags.
- Nitric acid - will be received in 25 t bulk isotainers as a high-strength solution.
- Caustic soda - will be received as dry beads in 1 t bulk bags.
- Copper sulphate - will be received in crystal form in 1.25 t bulk bags.
- Antiscalant (Millsperse 813) - will be received in 1 t tote tanks as a high-strength solution.
- Mercury suppressant (UNR 829) - will be received in 1 t tote tanks as a high-strength solution.


## Lime

Lime is received as pebble lime in 6 m lined containers and will be transferred to a lime silo beside the reagent area. The pebble lime will be slaked in a grinding-mill-type slaker and will then be held in two holding tanks in the reagent area inside the building. The lime will be usedfor pH control at various points. Lime addition will be by means of a pressurized lime loop distribution system.

# Sulphur Dioxide 

Sulphur dioxide will be added to the cyanide destruction process. Bulk sulphur will be delivered to site in 1 t bulk bags. The sulphur will be transferred to the molten sulphur tank, where it will be melted by heat from the carbon elution circuit. The molten sulphur will be pumped to a furnace where it will be mixed with air and combust to yield a discharge gas containing $17 \% \mathrm{SO}_{2}$ by volume. Discharge $\mathrm{SO}_{2}$ gas will pass through the induced draft (ID) fan / blower for dilution to $2 \%$ to $3 \% \mathrm{SO}_{2}$ and will be pressurized to feed the cyanide destruction tanks.

[[%~%]]
## 17.2 Process Services

[[%~%]]
### 17.2.1 Air And Gaseous Oxygen

The air separation unit (ASU) will produce $\sim 99.5 \%$ purity high-pressure oxygen. Its design production capacity is $1,750 \mathrm{t} / \mathrm{d}$ of contained oxygen gas. By design, the ASU will have a production turndown of $50 \%$, or $875 \mathrm{t} / \mathrm{d}$, by shutting down one of the main air compressors. With low-pressure liquid oxygen tanks completely full, the LP-LOX facility will be able to supply another 24 hours, or $1,710 \mathrm{t}$, of stored liquid oxygen before having to shut down.

Waste nitrogen from the ASU will be pressurized with a compressor and will be used in the autoclave gas handling circuit to reduce the oxygen content of the off-gas prior to mercury scrubbing. When completely full, the LP-LIN tanks will be able to supply another 24 hours, or 660 t , of stored liquid nitrogen.

Plant air and instrument air will be provided by three sets of compressors and an air receiver. Plant air will be delivered directly from this receiver, while instrument air will be further filtered and dried before distribution.

Low-pressure process air compressors will be provided for solution neutralization, cyanidation and cyanide destruction service. Low-pressure air blowers will be supplied for flotation, where air will be supplied directly through manifolds to each flotation cell.

[[%~%]]
### 17.2.2 Plant Water Distribution

Water for the plant distribution system will come from the following sources: contact water from the contact water pond, raw water from peripheral pit dewatering, reclaim water fromthe tailings storage facility (TSF), and fresh water from interception ponds as required to make up shortfalls.

Contact water will come from the mine facilities and waste dump runoff that collects in the contact water pond. Typically, it will be of fairly high quality with low levels of suspended and dissolved solids, and would be used for:

- Elution
- Electrowinning and refining
- Autoclave process water system (quench and gland)
- Concentrate CCD wash glands and wash water
- Cyanide, caustic, and other reagent systems
- Primary flocculant mixing
- Make-up water to cooling systems including the oxygen plant.

The distribution system will consist of the contact water tank and a pump distribution system.

During periods of high runoff into the contact pond, when quality degrades and quantities are excessive, contact water will substitute for reclaim water in flotation and throughout the plant. In turn, raw water and fresh water can be substituted for normal contact water uses if the quality of the contact water suffers from high suspended solids.

The highest-quality water for use in the plant will be raw water which comes from the peripheral dewatering wells in the pit. As long as contact water will be of sufficient quality and quantity, the raw water will be treated in the water treatment plant and discharged to the environment. When required to replace contact water, it will be suitable for all contact water usages. Raw water will also be important as the source of water for charging mill cooling and heat transfer systems. The raw water distribution system will consist of a single raw water tank and two distribution pumps.

When the quantity of pit dewatering water is insufficient, runoff water recovered from the diversion system around the TSF will be pumped from the diversion dams to a fresh / firewater tank and from there to the raw water tank.

The reclaim water system will supply water to processes that do not need high-quality water. Water will be reclaimed from the TSF and pumped to a reclaim water head tank. The water will be passed through a double-pipe heat exchanger (the heat being recovered from plant tailings during winter) and will then flow by gravity for distribution to the following areas:

- POX CCD- CIL feed neutralization and CIL
- carbon regeneration
- Cyanide destruction tails safety screens.

Reclaim water will also be supplied as the feed to the gland water system and flotation process water system.

Reclaim water used in CIL will first be treated for magnesium removal by an ion exchange vendor package.

POX blowdown water has been adopted as the terminology for raw water that has been used in the POX process, but is still relatively clean and, more importantly, has not been contaminated by chlorides (above levels in the original raw water). Within the POX area, raw water will be supplied to the gas handling systems-secondary condenser, venturi scrubber, mist eliminator-where it will be used to cool and clean particulates from the off-gas. Raw water will also be used as feed to the demineralized water system and in turn as feed to the boiler.

Demineralized water will be produced as a utility in both the POX and concentrator areas serving the POX plant and the combined requirements of the carbon elution circuit and power plant respectively. Demineralized water will be produced from plant raw water using multimedia filters and reverse osmosis system (concentrator/power plant) or ion exchange (POX).

[[%~%]]
## 17.3 Process Ventilation

Carbon dioxide will be produced during the acidulation of concentrate. The principal concern for ventilation will be to control the discharge of this gas away from tankage, as it will pose a safety hazard for operations personnel. As a result, the tops of the acidulation tanks will be covered, and the gas produced will be vented to a dispersion stack.

Vent gas from the autoclave will contain superheated steam, unconsumed oxygen, and in small quantities, nitrogen, carbon dioxide, carbon monoxide, volatile organic compounds (VOCs), gaseous sulphur, and mercury. In addition, flash steam produced in the discharge flash vessels that is not consumed in the slurry heater vessels will report to the off-gas system. The ventilation in the pressure oxidation off-gas system is included in the description of the autoclave.

Carbon dioxide will be produced in the neutralization of acidic solution in the FT neutralization circuit (these tanks are located outdoors). The principal concern for ventilation will be tocontrol the discharge of this gas away from tankage, as it will pose a safety hazard for operations personnel. As a result, the tops of the acidulation tanks will be covered, and the gas produced will be vented to a dispersion stack. The stack will be located away from the immediate areas of personnel travel and will allow the dispersion of the carbon dioxide to the general environment.

The CIL tanks will be located in a dedicated plant building to provide year-round weather protection for operators in the area. The pH set point for cyanide leaching in CIL will be approximately 11.0. The tank will therefore be covered to contain the gases. A scrubber fan will pull air from above the CIL tanks through an HCN scrubber, maintaining good ventilation in the working area above each tank.

In the acid wash area, ventilation will minimize acid vapor from the acid wash process. In carbon elution and regeneration systems, ventilation will be installed to control the evolution of mercury vapors present from the carbon in these areas. The gas stream will report to a mercury abatement system as previously described.

The principal concern for ventilation in electrowinning, sludge retort and refining is to control the potential presence of mercury. This has been previously described.

[[%~%]]
## 17.4 Control System

The process control system (PCS) for the plant will consist of a network of distributed controllers and human-machine-interface (HMI) equipment. The PCS, HMI stations, and all associated communications equipment will be of current technology that has been proven efficient and reliable in similar installations. The system will be capable of direct expansion to control all equipment required to meet possible future requirements of the mine.

Overall control of the plant will be provided from a centralized control room adjacent to the grinding area. Subsidiary control rooms will be installed in the crusher area, POX area, oxygen (air separation) plant, and water treatment (operations) plant. The control system will perform a wide variety of functions, including analog and motor control and sequencing, process control graphics operator interface, historical trending, and alarm displays / logging. Where necessary, operators in communication with the control room will provide control.

Key process parameters will be measured by instrumentation, with regulatory control (valves, for example) adjusted as required to maintain desired process values. Provision will be made to incorporate supervisory control and other advanced control methods in the process control system. In addition to the control system providing stability within the various processes,automatic sampling will be incorporated in the plant to acquire samples of a quality sufficient for metallurgical accounting.

Industry-standard interlocks within the control system and control points will be employed to ensure the safety of personnel and equipment by protecting equipment against overload or damage and preventing improper operation.

The POX area will be equipped with a Safety Instrumented System (SIS), which performs the safety functions intended to achieve or maintain safe conditions for the process with respect to a specific hazardous event. The oxygen plant will be equipped with an SIS independent from the Distributive Control System (DCS).

[[%~%]]
## 17.5 Laboratories

Laboratory facilities, including the assay, metallurgical, and environmental laboratories, will be constructed on the ground floor of the office complex within the process plant building.

The metallurgical laboratory is designed for bottle roll tests, grinding tests, screen analysis, flotation testwork, titration, and filtering. The environmental laboratory will be used to digest environmental samples for base metal or cyanide analysis under a fume hood. Mill offices will be provided in the administration.

[[%~%]]
## 17.6 Process Feed Schedule

The detailed process feed schedule for the LOM and overall recovery for each production period, including both flotation and POX/CIL recoveries, is shown in Table 17-1. Figure 17-2 shows the planned gold production by year.Table 17-1: Projected Process Schedule and Recoveries

| Parameter | Unit | Years |  |  |  |  |  |  |  |  |  |  |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  |  | YR1 | YR2 | YR3 | YR4 | YR5 | YR6 | YR7 | YR8 | YR9 | YR10 | YR11 | YR12 | YR13 | YR14 |
| Oxidized (partially) | kt | 1,987 | 1,762 | 1,504 | 3,146 | 3,553 | 2,646 | 637 | 448 | 422 | 230 | 1,118 | 54 | 138 | 122 |
| Greywacke | kt | 1,054 | 2,142 | 3,009 | 2,063 | 3,247 | 2,784 | 4,176 | 3,555 | 2,209 | 6,779 | 3,871 | 4,443 | 5,194 | 4,563 |
| Shale | kt | 177 | 1,118 | 835 | 592 | 582 | 550 | 706 | 1,164 | 1,762 | 948 | 928 | 1,377 | 1,119 | 1,266 |
| ACMA Intrusive | kt | 1,635 | 7,739 | 7,252 | 5,215 | 4,551 | 1,550 | - | 14 | 3,171 | 4,503 | 5,326 | 4,618 | 258 | 369 |
| Lewis Intrusive | kt | 390 | 782 | 2,927 | 3,705 | 2,049 | 4,643 | 4,073 | 2,109 | 1,753 | 4,528 | 6,779 | 7,202 | 5,686 | 4,868 |
| Vortex Intrusive | kt | 94 | 216 | 2 | 763 | 1,319 | 4,375 | 3,764 | 1,780 | 577 | 398 | 1,346 | 1,109 | 5,061 | 4,829 |
| Akivik Intrusive | kt | 645 | 1,899 | 433 | 131 | 2,890 | 54 | 13 | 732 | 1,291 | 598 | 47 | 102 | 2,403 | 2,778 |
| 400 Intrusive | kt | 1,254 | 1,774 | 1,920 | 1,564 | 1,137 | 2,464 | 3,950 | 3,809 | 3,332 | 534 | 39 | 409 | - | - |
| Aurora Intrusive | kt | 361 | 1,263 | 1,325 | 2,234 | 230 | 469 | 1,400 | 5,011 | 5,067 | 1,143 | 1 | 6 | - | - |
| Feed Contained Ounces | Au koz | 600 | 1,522 | 1,518 | 1,688 | 1,705 | 1,686 | 1,732 | 1,412 | 1,502 | 1,733 | 1,375 | 1,588 | 1,257 | 1,028 |
| Plant Feed Grade | Au g/t | 2.47 | 2.53 | 2.46 | 2.70 | 2.71 | 2.68 | 2.88 | 2.36 | 2.39 | 2.74 | 2.20 | 2.56 | 1.97 | 1.70 |
| Float Recovery | \% | 89.48 | 94.67 | 94.56 | 91.47 | 93.03 | 92.80 | 94.09 | 94.14 | 95.29 | 93.95 | 94.06 | 94.39 | 94.09 | 93.80 |
| Float Tail | Au g/t | 0.24 | 0.13 | 0.13 | 0.23 | 0.19 | 0.19 | 0.17 | 0.14 | 0.11 | 0.17 | 0.13 | 0.14 | 0.12 | 0.11 |
| POX Recovery | \% | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 |
| Recovered Grade | Au g/t | 2.15 | 2.32 | 2.25 | 2.39 | 2.44 | 2.41 | 2.62 | 2.15 | 2.20 | 2.49 | 2.00 | 2.33 | 1.79 | 1.54 |
| Overall Recovery | \% | 86.4 | 91.5 | 91.3 | 88.4 | 89.9 | 89.6 | 90.9 | 90.9 | 92.0 | 90.8 | 90.9 | 91.2 | 90.9 | 90.6 |
| Final Tail Grade | Au g/t | 0.32 | 0.21 | 0.21 | 0.31 | 0.27 | 0.28 | 0.26 | 0.21 | 0.19 | 0.25 | 0.20 | 0.23 | 0.18 | 0.16 |
| Recovered Ounces | Au koz | 522 | 1,393 | 1,387 | 1,491 | 1,532 | 1,511 | 1,574 | 1,284 | 1,383 | 1,573 | 1,249 | 1,448 | 1,143 | 932 |
|  |  | Years |  |  |  |  |  | Years |  |  |  |  |  |  | Total / Average |
| Oxidized (partially) | kt | 484 | 2,465 | 769 | 1,070 | 731 | 1,071 | 1,137 | 1,127 | 1,147 | 24 | 2,319 | 5,309 | 3,690 | 39,110 |
| Greywacke | kt | 4,911 | 3,146 | 2,801 | 4,052 | 3,256 | 2,876 | 2,745 | 4,270 | 3,989 | 3,525 | 4,430 | 4,715 | 3,173 | 96,977 |
| Shale | kt | 663 | 989 | 1,639 | 821 | 793 | 1,337 | 1,546 | 602 | 803 | 558 | 1,270 | 1,205 | 689 | 26,036 |
| ACMA Intrusive | kt | 3,475 | 5,379 | 4,256 | 5 | 1,627 | 6,718 | 6,815 | 1,955 | 159 | - | 323 | 1,600 | 2,970 | 81,484 |
| Lewis Intrusive | kt | 3,676 | 5,900 | 7,977 | 8,761 | 7,891 | 3,734 | 2,996 | 3,304 | 7,564 | 13,515 | 6,206 | 3,673 | 2,935 | 129,628 |
| Vortex Intrusive | kt | 3,770 | 743 | 1,804 | 3,345 | 4,101 | 2,857 | 2,619 | 4,264 | 2,169 | 1,569 | 2,825 | 1,807 | 974 | 58,419 |
| Akivik Intrusive | kt | 1,354 | 215 | 180 | 478 | 1,067 | 904 | 759 | 1,176 | 669 | - | 1,206 | 153 | 1,192 | 23,370 |
| 400 Intrusive | kt | 62 | 180 | 8 | 447 | 31 | 48 | - | 1,228 | 2,152 | - | 786 | 422 | 941 | 28,491 |
| Aurora Intrusive | kt | - | 42 | 1 | 521 | 40 | 83 | - | 366 | 548 | - | 125 | 664 | 392 | 21,291 |
| Feed Contained Ounces | Au koz | 970 | 990 | 1,069 | 959 | 1,027 | 1,296 | 1,505 | 1,227 | 912 | 1,100 | 773 | 828 | 848 | 33,847 |
| Plant Feed Grade | Au g/t | 1.64 | 1.62 | 1.71 | 1.53 | 1.64 | 2.05 | 2.52 | 2.09 | 1.48 | 1.78 | 1.23 | 1.32 | 1.56 | 2.09 |
| Float Recovery | \% | 93.54 | 92.36 | 93.56 | 92.20 | 93.60 | 93.98 | 94.24 | 92.64 | 91.39 | 93.66 | 89.06 | 81.06 | 87.48 | 92.99 |
| Float Tail | Au g/t | 0.11 | 0.12 | 0.11 | 0.12 | 0.10 | 0.12 | 0.14 | 0.15 | 0.13 | 0.11 | 0.13 | 0.25 | 0.19 | 0.15 |
| POX Recovery | \% | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 | 96.6 |
| Recovered Grade | Au g/t | 1.48 | 1.44 | 1.55 | 1.36 | 1.48 | 1.86 | 2.29 | 1.87 | 1.30 | 1.61 | 1.06 | 1.03 | 1.31 | 1.87 |
| Overall Recovery | \% | 90.4 | 89.2 | 90.4 | 89.1 | 90.4 | 90.8 | 91.0 | 89.5 | 88.3 | 90.5 | 86.0 | 78.3 | 84.5 | 89.8 |
| Final Tail Grade | Au g/t | 0.16 | 0.17 | 0.16 | 0.17 | 0.16 | 0.19 | 0.23 | 0.22 | 0.17 | 0.17 | 0.17 | 0.29 | 0.24 | 0.21 |
| Recovered Ounces | Au koz | 876 | 883 | 966 | 854 | 929 | 1,176 | 1,370 | 1,098 | 805 | 995 | 665 | 648 | 716 | 30,405 |# NOVAGOLD 

Figure 17-2: Planned Gold Production by Year
![img-44.jpeg](img-44.jpeg)

[[%~%]]
## 17.7 Comments On Section 17

In the opinion of Wood QP, the following conclusions are appropriate:

- The process as currently envisaged will consist of sulphide flotation pre-concentration with POX followed by CIL to produce gold at acceptable recoveries through the application of autoclave sulphide oxidation technology.
- A semi-autogenous grinding circuit followed by pebble crushing and in-series ball milling has been selected for the comminution requirements based on the ability to handle the variable hardness and quality of the ore.
- The flotation flowsheet will provide a circuit design that will maximize sulphide recovery, as demonstrated during numerous bench and pilot plant metallurgical tests.
- POX of the flotation concentrate will allow higher recoveries in CIL cyanidation, as demonstrated through extensive pilot-plant testing. Controlling autoclave residence time to match the requirements of the concentrate feed will be important.- Effective neutralization of acidic solutions can be carried out through the efficient use of the natural carbonate content of the flotation tailings, thereby reducing the amount of lime or limestone that must be transported to site.
- Effective detoxification of WAD cyanide species in CIL tails through $\mathrm{SO}_{2} /$ Air destruction.
- Effective management of arsenic in the processed ore is possible through using the POX circuit. The ore has sufficient iron content to permit precipitation of arsenic with iron to form acceptable forms of arsenic precipitation products, suitable for long-term storage in the TSF.
- Mercury emissions can be effectively controlled with the proposed mercury abatement systems on the POX, carbon regeneration, electrowinning, retort, and bullion smelting processing equipment. The proposed mercury recovery technology for the autoclave offgas systems achieves current known best practices for this application.
- The final tailings stream will be a combination of WAD CN detoxified CIL tails and neutralized acidic liquors generated from the autoclave, using flotation tails and lime, for final pH adjustment to a pH of 7 . The tailings will be non-acid generating. The circuit design as described will permit maximum recycle of tailings decant water back to the plant to potentially eliminate the need for discharge of process waters. The operations WTP is designed and permitted to treat process water to meet discharge water quality standards, if required.

[[@~@]]
# 18.0 Project Infrastructure

[[%~%]]
## 18.1 Access And Logistics

[[%~%]]
### 18.1.1 Port-To-Mine Access Road

The port-to-mine access road (Jungjuk route) will traverse varied terrain from the Kuskokwim River port site near the mouth of Jungjuk Creek to the mine site (Figure 18-1).

The port site is located on the north bank of the Kuskokwim River, 13 km downriver of the village of Crooked Creek; there is currently no road connection between the two locations. To the mine site battery limits, the road will be 44 km long.

The entire road will be new construction in an untracked region, with no passage through or near any settlements or communities, and no junctions with any existing road system. The road route will traverse mostly upland terrain. A 4.8 km long spur road, beginning at route km 8.7 from the mine site, will serve the Project airstrip. The mine permanent camp facilities will be located at 3.9 km from the mine site.

There are 50 identified stream or drainage crossings along the road route, but only six of them are significant and will require bridging. Bridge lengths vary from 7.5 m to 25 m .

[[%~%]]
### 18.1.2 Road Construction

Road construction activities will be divided among three distinct areas: the site access roads to ancillary facilities (explosives storage, airstrip, haul roads); the port site permanent access road; and the Crooked Creek winter construction access road. In general, roads will be constructed using conventional cut-and-fill techniques, except for the winter construction access road, which will be developed as an "ice road".

Simple fill-type embankments will be constructed on most of the ridge-line sections to preclude surface disturbance and reduce snow-drifting on the roadway. In general, material sites have been located at regular intervals along the alignment, precluding the need for extended haulage of construction rock.

A geofabric underlay will be provided in areas identified as having significant amounts of permafrost or wet soils.# NOVAGOLD 

Figure 18-1: Basic Route of Mine Access Road
![img-45.jpeg](img-45.jpeg)

[[%~%]]
### 18.1.3 Airstrip

The airstrip will be approximately 14 km by road west of the mine site. The airstrip design is based on U.S. Department of Transportation, Federal Aviation Administration (FAA) standards. The specified aircraft are the DHC Dash 8 and the Hercules C-130. The design was governed by the needs of the Hercules C-130. A gravel runway is suitable for both types of aircraft. A single airstrip was considered sufficient to accommodate the predominant wind directions.

[[%~%]]
### 18.1.4 Cargoes

General cargoes sourced globally will be shipped in containers or as break-bulk to marine terminals in Seattle and Vancouver where they will be loaded onto ocean barges for transport to Bethel. Because the Kuskokwim River begins to freeze up in October and the mouth of the river does not usually clear of ice until late May, the shipping season for both ocean and river barges will be limited to 1 June to 1 October each year. The first general cargo barge of each shipping season will load and leave Seattle or Vancouver in early-May to be at the mouth of the river by the beginning of June.

Because of draft restrictions on the river downriver of Bethel later in the season, fully-laden ocean barges will discharge part of their cargo direct to river barges at Oscarville Crossing about 10 km downriver from Bethel. Those cargoes unloaded at Bethel will be placed into temporary storage or transferred directly to river barges for shipment to Jungjuk, about 312 km upriver. At Jungjuk general cargo will be off-loaded and either placed in temporary storage to await transport or loaded directly onto trucks for transport to the mine site.

Empty container storage yards, local transport, marine terminals in Seattle and Vancouver, and the ocean and river general cargo barge fleets will be operated by third parties.

[[%~%]]
### 18.1.5 Fuel

The fuel supply chain will include the following major components:

- Ocean transport by double-hull barge from refineries located in the Pacific Northwest
- Fuel storage and transfer terminal at Dutch Harbor
- 49 ML fuel storage tanks at Dutch Harbor
- Ocean transport by double-hull barge from Dutch Harbor to Bethel
- Fuel storage and transfer terminal at Bethel
- 38 ML of dedicated fuel storage tanks at Bethel
- River transport by double-hull low draft barges from Bethel to Jungjuk
- Storage and transfer terminal at Jungjuk
- 9.9 ML capacity storage tanks at Jungjuk
- Transport by tanker truck from Jungjuk to the mine site
- 146 ML fuel storage tanks at the mine site.

Fuel sourced at refineries in the Pacific Northwest will be delivered by ocean barge to Dutch Harbor, where it will be stored to await onward transport to Bethel. The first shipments should leave the refineries in early May. Fuel will be transported from Dutch Harbor to Bethel in a11 ML capacity ocean barge, which will be loaded so that it would not have to lighter fuel to reduce draft prior to crossing shallower reaches downriver of Bethel. At Bethel fuel will either be placed in storage or loaded direct to a river barge for transport to Jungjuk. At Jungjuk fuel will be unloaded to storage tanks. Fuel will be transported by a fleet of 0.51 ML capacity tanker trucks to the mine site. The fuel terminals at Dutch Harbor and Bethel and the ocean and river barge fleets will be operated by third parties.

[[%~%]]
## 18.2 Site Facilities

[[%~%]]
### 18.2.1 Site Investigations

The site investigation work carried out at the Project site includes evaluations in the technical areas of geotechnical engineering, surficial geology, hydrogeology, climate, hydrology, and seismicity. Evaluations for the plant site and associated facilities, contact water, freshwater and diversion dams, tailings storage facility, open pit, and waste rock facility were performed by BGC.

RECON, LLC (RECON) conducted the evaluation for the port site and the access corridors between the port site and the mine site. Both BGC and RECON contributed to an assessment of potential borrow sources for construction materials.

Key findings from the work performed between 2004 and 2010 were:

- The bedrock beneath the primary crusher, truck shop, plant site, and fuel farm facilities consist of interbedded, blocky, and weathered siltstones, shales, and greywackes (sandstones) with some minor igneous intrusions (dykes and sills). Geotechnical logging of drill core indicates average rock mass rating (RMR '76) and geological strength index (GSI) values ranging between 35 and 45, corresponding with "poor" to "fair" bedrock, respectively.
- Hydraulically, the bedrock unit is considered undifferentiated. The hydraulic conductivity of the bedrock tends to decrease with depth, although it has been found to vary over approximately three orders of magnitude at any given depth. Numerous faults are present in the bedrock; however, to date there is no strong evidence to suggest any fault has a significant control on groundwater flow.
- Average annual precipitation at the Project site is estimated at 500 mm , consisting of 345 mm of rainfall (69\%) and 155 mm as snow (31\%). Snow typically starts to accumulate in mid-October, while snowmelt occurs on average between early April and early May.- Discontinuous permafrost is expected at the Project site. Observations to date have confirmed the presence of discontinuous permafrost. Data collected to date also indicate localized warm permafrost.
- The Project site lies in a seismically active region. The hazard potential classifications for the main tailings dam and the Snow Gulch freshwater dam are rated as "high" in view of the potential for loss of life and severe environmental damage that could result from uncontrolled release of the stored tailings and supernatant water in the event of an earthquake. The seismic hazard for the Donlin site area has been evaluated using both deterministic and probabilistic methods of analysis. The recommended MDE for the tailings dam design is characterized by a peak horizontal ground acceleration on rock of 0.36 g from a magnitude 7.8 earthquake for the deterministic analysis and 0.44 g for the 1 in 10,000-year earthquake for the probabilistic analysis; both were evaluated for the TSF. The recommended MDE for ancillary structures is the 2,475-year return period event characterized by a peak horizontal ground acceleration on rock of 0.25 g .
- For the design of plant site buildings and other structures, the seismic design provisions of the 2006 International Building Code have been adopted, and appropriate design response spectra have been developed based on ground motion parameters with a 2\% frequency of exceedance in 50 years.


[[%~%]]
### 18.2.2 Plant Site Design Considerations

The plant site and fuel tank farm will be in the Anaconda valley on the ridge just northwest of the TSF at a nominal elevation of 300 m . The proposed facility layout contains the entire process area within the Anaconda and American Creek valleys and therefore minimizes any direct impact on Crooked Creek.

The layout of the plant site was designed to take maximum advantage of the topography, ranging from an elevation of 305 m at the grinding area and stepping down through the process to elevation 260 m at the flotation tailings thickener. The layout also provides for efficient movement of equipment and material products around the site.

The locations of other facilities relative to the process plant are as follows:

- The fuel tank farm is 2 km to the east, at elevation 299 m .
- The open pit(s) are approximately 3 km to the northwest, at elevation 160 m (top of ramp).Figure 18-2: Plant Site Layout
![img-46.jpeg](img-46.jpeg)- The crusher is approximately 1.5 km to the northwest, at elevation 230 m at the dump pocket and 197.5 m at the low end of the primary feed conveyor.
- The tailings pond is approximately 1 km to the southeast, initially at elevation 170 m and ultimately at 254 m , permitting gravity-flow of tailings from the process plant.

The layout of the plant site takes advantage of the prevailing wind direction from the southeast. The flow of air will mostly be from the oxygen plant to the coarse ore stockpile (COS) and then toward the pit. As such, any dust from the plant site and the COS will be blown toward the ore stockpile, contact water pond, open pit, and adjacent waste dump.

The plant platform will be graded to allow for gravity flow through the process plant area and southwest to the thickeners, then southeast down to the TSF. The primary crusher will be constructed on a ridge on the south side of American Creek, orientated to make use of the southern slope of the ridge, minimize the length of the coarse ore conveyor to the plant site, and permit the vertical and horizontal alignment to tie into the coarse ore stockpile at the plant site. The crusher structure will be a concrete tower founded on a raft-type foundation with a reinforced earth wall around three sides. Crushed ore will be fed to a 2.3 km long coarse ore conveyor running to a COS at the process plant.

The truckshop will be on the ridge east of the primary crusher to provide easy access for maintenance and refuelling of the haul trucks. The truckshop will house ten heavy vehicle repair bays, various specialty service bays, a warehouse, changerooms, and offices. The mine rescue truck, fire truck, and first aid facility will also be housed within this building. The layout has been designed to allow the building to be extended in the future by up to four bay-lines, for a total of eight additional maintenance bays.

To eliminate the transport of explosives through the plant area, the explosives plant will be located north of the pit. Access to the site will utilize the service road out to the Snow Gulch dam. The site will be located just behind a ridgeline to protect the explosives plant from potential flyrock from mining activities in the pit.

[[%~%]]
### 18.2.3 Plant Site Facilities

Plant site facilities will include:

- Crusher
- Coarse ore conveyor
- Coarse ore stockpile
- Pebble crusher# NOVAGOLD 

- Conveyor galleries
- Concentrator
- Utilidors and access walkways
- Power plant
- Truckshop
- Road fleet truckshop
- Truck wash
- Cold storage building
- Warehouse
- Administration Offices / Changerooms / Assay Laboratory
- Construction camp
- Permanent accommodation complex.

With the supply of natural gas to the mine site, heating for the plant site buildings and modules, including the truckshop and permanent accommodation complex, will be provided by natural-gas-fired air unit heaters and makeup air units. The accommodation complex will be heated by natural gas furnaces with a forced-air system and supplemental baseboard heaters.

Continuous ventilation will be provided for all human-occupied and selected unoccupied spaces. Ventilation rates will vary depending upon the level of occupancy and the intended use of the space as per ASHRAE, OSHA, and the State of Alaska building code and standards. Ventilation systems will include make-up air units for continuous supply of tempered air, summer supply fans to provide extra cooling during the warmer months, and general exhaust fans.

Dust control systems will include hoods, ductwork, dust collectors, and enclosures designed to prevent fugitive dust or fume emissions at their source. Dust collectors will be designed and selected to reduce particulate emissions from the discharge air to meet the applicable air pollution control regulations.

[[%~%]]
## 18.3 Camps And Accommodation

The construction camp will be built on a bench near the process plant. The camp will include 14 stand-alone, three-storey dormitories designed to accommodate 2,560 people and a stand-alone, single-storey core services facility.

The permanent accommodation complex will be located just off the main access road, approximately 6 km west of the plant site. The complex will house an estimated 434 people inYear -2 and be expanded in Years 1 and 6 to accommodate a maximum of 638 people during operations.

Two modular sewage treatment plants (STPs) will be provided: one for the permanent accommodations facility, and one for the construction camp immediately west of the plant site. The sewage treatment plant for the construction camp will later be reduced in size to accommodate the operational requirements of the plant site area.

[[%~%]]
## 18.4 Waste Storage Facilities

[[%~%]]
### 18.4.1 Location

The WRF will be located in the American Creek valley, east of the open pit. The ultimate footprint of the WRF covers an area of approximately $9 \mathrm{~km}^{2}$. Approximately 2,222 Mt of waste rock and 42 Mt of overburden will be placed in the WRF. The top lift of the WRF will be at an elevation of approximately 520 masl, resulting in a maximum dump height of about 340 m and thickness of about 300 m . Most of the WRF will be constructed in 30 m lifts. The toe of each subsequent lift will be set back 47 m from the crest of the previous lift, resulting in an overall dump slope of $3 \mathrm{H}: 1 \mathrm{~V}$.

A plan showing the layout of the ultimate WRF is given as Figure 18-3.

[[%~%]]
### 18.4.2 Acid-Base Accounting

ABA indicates that the potential for acid rock drainage (ARD) will be highly variable; however, most of the waste rock has low potential because of the excess neutralization potential of calcium and carbonate minerals. Sulphur concentrations vary from near detection limit ( $0.01 \%$ ) to above $3 \%$. Sulphur distribution is bimodal with typical modes at about $0.1 \%$ and $1 \%$, depending on rock type. The rhyodacites tend to be more mineralized than the sedimentary rocks. Laboratory tests have confirmed that rock containing higher sulphur concentrations will generate ARD.Figure 18-3: Plan of Ultimate Waste Rock Facility
![img-47.jpeg](img-47.jpeg)In addition to sulphur mineralization, arsenic concentrations (occurring mainly as arsenopyrite) are elevated throughout the rock and are broadly correlated with sulphur content. Arsenic concentrations vary from near $10 \mathrm{mg} / \mathrm{kg}$ to over $1 \%$ in highly mineralized rock. Laboratory and field experiments have demonstrated that arsenic and several other elements (sulphate, antimony, selenium) leach at elevated levels with respect to Alaska water quality standards. Arsenic leaching is likely to vary but is expected to be generated from all types of waste rock. As a result of the identified variable potential for ARD and leaching of arsenic, seven WRMCs were initially identified, then reduced to five because significant arsenic leaching occurs for all categories.

Three of the initial WRMCs (designated 5, 6, and 7) were defined as having significant potential for ARD but with different timeframes for ARD generation. WRMC 4 has lower ARD potential, and WRMC 2 is defined as having negligible ARD potential.

Categories 5, 6, and 7 are considered PAG waste rock. Shortly after production begins some of these materials will be placed in the WRF. The PAG 5 category waste rock will be blended with NAG materials to provide buffering capacity and can then be disposed of in the WRF following typical dumping procedures. The PAG 7 waste rock will either be sent to the process or temporarily stockpiled and then placed back into the open pit where it will eventually be submerged. The PAG 6 waste rock will be kept as dry as possible, isolated from the other waste rock within the WRF.

A dumping plan has been developed that separates the PAG 6 materials from the NAG materials within the dump by placing them into isolated "cells" within the Rob's Gulch area of the WRF. Each cell will be placed in 10 m high intermediate lifts to an overall lift height of 30 m . The PAG 6 cell will then be capped with a 1 m thick layer of lower-permeability natural materials consisting of colluvium or terrace gravels. NAG materials will be dumped around the PAG 6 rock, isolating it from the final surface of the dump and from the surrounding natural ground.

[[%~%]]
### 18.4.3 Construction Plan

The waste rock facility will be constructed from the bottom up. Close attention must be paid to construction of the rock drains and initial lifts as they will serve as the foundation for the remainder of the WRF. The results of the stability analyses of the overall WRF indicate that under static and pseudo-static conditions the WRF meets or exceeds the design criteria.

Waste rock will initially be developed from both the Lewis and ACMA pit areas in the preproduction years. In terms of geotechnical stability, preproduction (Year -1) and the first few years of production are likely to be the most critical in the development of the WRF. During this time there will be little variety in the types of waste rock available for placement,minimizing flexibility in material selection for specific construction purposes. This also represents the time when personnel will have the least experience in handling waste materials and seasonal issues affecting waste rock placement will become apparent. As a result, close attention will need to be paid to the development of the WRF during this period.

The WRF will be built from the bottom up along the American Creek valley, with construction of the first lift initiated along the north side of American Creek and into Rob's Gulch at the beginning of the preproduction period. A 83 m wide section of the foundation along the toe of the WRF will be prepared by pre-stripping the organic and ice-rich overburden in areas considered important for dump stability. The foundations for the downstream facilities (Lower CWD) will be cleared, the first stage of the upstream water collection and diversion measures will be constructed, and the first phases of the rock drains in Rob's Gulch and the Unnamed Gulch will also be established during this time.

The mine plan establishes the northwestern area of the ultimate WRF in Year -1. Subsequent WRF development generally progresses upward until hauls for dump construction become restrictive and it is more cost effective to progress up the American Creek valley. Near the end of Year 2 waste rock will be placed in the bottom of the valley. The WRF then advances eastward, covering most of the valley bottom by Year 4. By the end of Year 6 the waste rock will reach the Upper CWD. The WRF will then be built upward in lifts until reaching its full height in Year 21. Placement of waste rock as backfill in the ACMA pit will begin in Year 20.

Before advancing the WRF into the main drainages (American Creek, Rob's Gulch, the Unnamed Gulch) portions of the primary rock drains will need to be constructed to stay ahead of the WRF development.

[[%~%]]
## 18.5 Tailings Storage Facilities

The TSF will be constructed in the Anaconda Creek valley, 3.5 km south of the open pit and 3 km east of the confluence of Anaconda and Crooked creeks (Figure 18-4). Anaconda Creek flows west through the gently sloping valley bottom before joining Crooked Creek.Figure 18-4: Location of Tailings Storage Facility
![img-48.jpeg](img-48.jpeg)The starter dam is sized to store one year of tailings plus the 200-year return period snowmelt, 24-hour PMP rainfall event, excess water accumulation under average conditions in the site water balance, and emergency freeboard. To meet these requirements, the starter and ultimate dam will be 54 m and 141.5 m high, respectively, as measured from the crest to the downstream toe. The ultimate capacity of the lined tailings impoundment will be $412.35 \mathrm{Mm}^{3}$.

Construction of the TSF will need to be scheduled with special allowances for seasonal constraints and effects on earthworks and liner placement productivity. Construction will take at least two years and will commence no later than two years before process plant commissioning, starting in a winter construction period, assumed to be from November to March. The summer construction period is from May to October. The month of April is assumed to be non-trafficable as the ground thaws. November is also likely to be a transition month from summer to winter, but the trafficability is expected to be adequate to maintain some construction activities.

Surface water management will be required during construction and will comprise conventional best-management practices such as cofferdams, sumps, sediment traps, and pumped diversions.

The proposed hazard classification of the tailings dam in Anaconda Creek is Class I, or "High," according to the Dam Safety Guidelines (ADNR, 2005).

[[%~%]]
### 18.5.1 Design Considerations

Standard procedures from the following agencies were also applied for the design of the TSF and appurtenant structures, where appropriate:

- U.S. Bureau of Reclamation (USBR)
- U.S. Army Corps of Engineers (USACE)
- Federal Emergency Management Administration (FEMA)
- International Congress on Large Dams (ICOLD)
- Canadian Dam Association (CDA).

Key features of the TSF design are as follows:

- In accordance with FEMA (2004), the Inflow Design Flood (IDF) is the Probable Maximum Flood (PMF), including allowance for snowmelt, for dams of significant hazard classification. The corresponding IDF is the 200-year snowmelt plus runoff from a 24-hour PMP. The PMP is assumed to occur at the end of the 200-year snowmelt with the groundfully saturated; therefore, the entire PMP runs off the catchment area. The TSF will store the full volume of the IDF without discharge.

- The TSF will store water in excess of the site water balance under average operating and flood conditions with consideration for the potential of ice loading on the liner.
- The TSF is designed to contain the IDF without release from the impoundment. Consequently, no spillway will be required during operations. A spillway will be required upon closure, with the peak design flow based on the PMP rainfall event.
- The freeboard above the IDF allows for wind-generated wave height, setup, and run-up; for estimated settlements and seismic deformation; and for hydrologic uncertainty, evaluated according to USBR (1981), USACE (1991), and CDA (2013).
- The Maximum Design Earthquake (MDE) for the tailings dam is based on the Maximum Credible Earthquake (MCE) determined following the procedures described in USACE (1995). The seismic hazard for the Project site area has been evaluated using both deterministic and probabilistic methods of analysis. The recommended MDE for the tailings dam design is characterized by a peak horizontal ground acceleration on rock of 0.36 g from a magnitude 7.8 earthquake for the deterministic analysis and 0.44 g for the 1 in 10,000-year earthquake for the probabilistic analysis; both were evaluated for the TSF. The recommended MDE for ancillary structures is the 2,475-year return period event characterized by a peak horizontal ground acceleration on rock of 0.25 g .
- The minimum factors of safety summarized in Table 18-1 were used for evaluating suitable dam side-slopes following CDA (2013) and USACE (2003). The criteria outlined in Seed (1979) were used to evaluate the suitability of the dam side slopes under seismic loading conditions. Seed (1979) recommends a horizontal seismic coefficient (kh) of 0.15 g for Magnitude 7.8 earthquakes, satisfying a pseudostatic factor of safety greater than 1.15. The Bray and Travasarou (2007) simplified procedure for estimating earthquakeinduced slope displacement was used to estimate mean seismic displacements for the tailings dam.

Table 18-1 Factors of Safety for Tailings Dam Side-Slopes under Static Conditions

| Analysis Condition | Required Minimum <br> Factor of Safety | Slope |
| :-- | :--: | :--: |
| End of construction | 1.3 | Upstream and Downstream |
| Long term (steady state seepage, maximum storage pool) | 1.5 | Downstream |
| Temporary excavation and rapid drawdown (maximum storage <br> pool) | 1.3 | Upstream |A full dynamic analysis for the ultimate tailings dam was completed using the numerical modelling program FLAC. The maximum allowable deformation used for evaluating suitable dam side-slopes corresponds to a maximum crest settlement on the upstream face of 1.0 m .

The tailings dam will be constructed of compacted rockfill using the downstream-raised method, with a 1.5 mm LLDPE liner on the upstream face. The tailings will be transported to the TSF at a slurry density of $36 \%$ solids by weight and will be discharged via piping and spigots. Tailings beach slopes of $0.5 \%$ above the water surface and $1 \%$ below the water surface have been assumed for capacity and deposition planning purposes. Multiple subaerial spigotting deposition locations would form embankment and "force" the supernatant pool, via selected or cyclical point deposition, to initially flow towards reclaim collection (i.e., decant) barge located in the center on the north side of the impoundment, and ultimately towards the southeast end of the impoundment at the end of process operations (SRK, 2016a).

Filter zones are required between the tailings and the rockfill that constitutes the body of the dam for protection in the event of a puncture in the liner. The dimension and gradation of the filters and the flow capacity of the filter zones are designed according to USACE (2000). The flow capacity of the underdrain has been designed according to the Wilkins Equation (1956). A factor of safety of 10 is generally considered acceptable for the underdrain design flow to account for uncertainties in the flows and drain construction and has been applied to the TSF impoundment drains.

Two freshwater diversion dams are required to limit surface water reporting to the tailings dam and are in place during the first three years of operation. During construction, these diversion dams will divert fresh water from the impoundment to facilitate construction of the TSF starter dam and liner placement. The dams will also minimize runoff to the TSF during operations and thus provide a significant control on impoundment volumes during the first three years of operations. Following Year 3, their liners will be removed and the dams re-graded.

A seepage recovery system (SRS), consisting of a pond excavated into bedrock, lined rockfill berms, diversion ditches, and monitoring / collection wells, will be installed immediately downstream of the closure footprint of the tailings dam. The seepage recovery pond and collection wells will provide secondary and tertiary containment, respectively, while the TSF liner provides primary containment.

[[%~%]]
## 18.6 Water Management

[[%~%]]
### 18.6.1 Water Balance

The site-wide water balance model (WBM) was calibrated to predict the precipitation / runoff relationships observed at site. This model uses precipitation and potential evapotranspiration as input parameters and provides volumetric discharge as output.

The WBM for operations assumes that when the tailings slurry is initially deposited in the TSF the settled dry density is $0.82 \mathrm{t} / \mathrm{m}^{3}$, increasing to $1.249 \mathrm{t} / \mathrm{m}^{3}$ by the end of operations. The model accounts for the concurrent, slow release of water from the tailings void space as the tailings load increases and pore pressures dissipate (consolidation). Another 52 years is required at closure for full consolidation of the tailings to a final settled density of $1.30 \mathrm{t} / \mathrm{m}^{3}$. During operations, the average void loss is $1,006 \mathrm{~m}^{3} / \mathrm{h}$.

[[%~%]]
### 18.6.2 Construction Water Management Strategy

Water management objectives during construction are to:

- Treat and discharge all pit dewatering groundwater to prevent the excessive build-up of water in the Lower CWD
- Minimize the need to treat and discharge contact water
- Provide an adequate supply of water to the process plant for commissioning
- Provide adequate pit depressurization
- Eliminate the need to store water in the TSF facility until immediately before process plant start-up.

The American Creek drainage flows, pit dewatering water, ore stockpile berm water, stormwater runoff from overburden stockpiles, construction camp potable water wells and domestic WTP discharge, Snow Gulch Reservoir, and the TSF (Anaconda runoff) are the primary components of the water supply and management during construction and are further described in the following subsections.

Water infrastructure required for the construction phase is illustrated in Figure 18-5.Figure 18-5: Construction Water Management Layout
![img-49.jpeg](img-49.jpeg)# American Creek Runoff 

Runoff from mine facilities in the American Creek drainage, including the pre-stripping excavations for the open pits, the WRF, and other mine facilities would be managed as contact water unless suitable for coverage under an Alaska Pollutant Discharge Elimination System (APDES) general permit for stormwater discharges.

## Lower and Upper Contact Water Dams

The first of two contact water dams, the Lower CWD, will be constructed in the American Creek drainage and will be complete at the end of the first quarter of Year -1. NAG waste rock with metal leaching potential could be used for construction of the Lower CWD. There is potential for the generation of seepage and runoff with elevated metals concentrations derived from metal leaching; however, this seepage would be collected by the Ore Stockpile Berm and later by the pit dewatering system, so the seepage and runoff cannot migrate off site.

The Lower CWD would intercept an approximate drainage area of 690 ha. The dam also receives runoff from the pre-stripped ground of the two pit areas that are being advanced and the intervening undisturbed ground. This area is 355 ha after pre-stripping is complete.

The Upper CWD will be constructed at the ultimate upstream extent of the WRF in the American Creek drainage and will provide additional capacity for storage of contact water. The Upper CWD will retain surface water and stormwater from undisturbed areas in the upper American Creek drainage and water pumped from the Lower CWD. The Upper CWD will be complete at the end of Year -1 .

## American Creek Fresh Water Diversion Dam

To limit inflows to the Lower CWD during construction, a freshwater diversion dam is proposed on American Creek (American Creek FWDD) upstream of the WRF and would be completed in LOM Year -2. Excess fresh water (non-contact) accumulating in the American Creek FWDD would be stored up to a maximum capacity of $1.07 \mathrm{Mm}^{3}$, with the excess discharged to Crooked Creek at Omega Gulch. To minimize the potential for overflows to occur, the installed pumping capacity will be capable of a maximum flow rate of $900 \mathrm{~m}^{3} / \mathrm{h}$. Appropriate energy dissipation structures would be installed to control erosion at the American Creek FWDD spillway and at the discharge site to Crooked Creek. The diversion dam would only be utilized until the end of the first year of operations. After the first year of operations, the process plant would be at full capacity and the diverted water would be required in the process.# Open Pit Pre-Stripping Areas 

Pre-stripping excavations for the open pits commence LOM Year -2, fourth quarter excavations are limited to the ACMA Pit area in Year -1 and by the end of fourth quarter of LOM Year -1 the pit footprint is approximately 40 ha. Initial excavations occur on the north side slopes of American Creek, where relatively dry soil conditions are anticipated relative to the valley bottom. Because of the terrain, the pit footprint at the end of fourth quarter of LOM Year -1 is a sidehill cut rather than a pit excavation. Runoff from this pit footprint will be managed as contact water.

## Initial Pit Dewatering

Pre-stripping begins in ACMA and Lewis Pits, approximately 15 months prior to commencement of process plant operation. To achieve pit depressurization targets, pumping from perimeter dewatering wells would begin six months before the start of pre-stripping. Construction of the operations WTP would be completed prior to pre-stripping. Twelve perimeter dewatering wells will be operational for this purpose by LOM Year -1.75; five additional perimeter dewatering wells will be required during LOM Year -1 (SRK 2017). Pit dewatering water collected during construction would be treated in the operations WTP and discharged to Crooked Creek near the confluence of Omega Gulch under an APDES permit.

## Ore Stockpile Berm

Immediately downstream of the Lower CWD, contact water will be generated from the ore stockpile, shallow seepage from the Lower CWD, and the lower reaches of Rob's Gulch below a proposed diversion. To capture this contact runoff, a 3 m high berm will be constructed on American Creek, immediately downstream of the proposed ore stockpile.

## Waste Rock Facility

Waste rock would be placed in the WRF beginning in LOM Year -1. Runoff from the WRF will be retained in the Lower CWD or treated and released.

## Snow Gulch Fresh Water Dam

The Snow Gulch freshwater dam (FWD) is a contingency source of fresh water to the process plant during operations and as such is required for the start of operations. This freshwater dam will be constructed and completed in Year -2, allowing at least 18 months for runoff to accumulate in the dam before it becomes operational. Except when water is being withdrawnfrom the pond for use in process, the dam will be kept at its maximum storage capacity of $4 \mathrm{Mm}^{3}$.

# Anaconda Creek Runoff 

The water management structures to control runoff in the Anaconda Creek drainage are described below.

## TSF Temporary Fresh Water Diversion Dam

Two temporary FWDDs would be constructed upstream of the TSF in Anaconda Creek and completed in LOM Year -2. The diversion dams would minimize runoff to the TSF from undisturbed ground and also divert fresh water (surface water and noncontact stormwater) during construction of the TSF starter dam and placement of the impoundment liner.

Water levels behind the temporary FWDDs will be controlled by pumping water out of the ponds into diversion channels that would be constructed on either side of the TSF. The North FWDD would have an approximate maximum pumping capacity of $500 \mathrm{~m}^{3} / \mathrm{h}$ to the North Diversion Channel, and the South FWDD would have an approximate pumping capacity of $250 \mathrm{~m}^{3} / \mathrm{h}$ to the South Diversion Channel. The dams would be in use until LOM Year 3 of operation, at which time both the TSF North and South FWDD would be decommissioned and the area would be regraded and incorporated into the ultimate TSF impoundment to allow for additional tailings storage.

## TSF SRS

A rock fill underdrain capable of handling the base flow through the Anaconda Creek valley is to be placed beneath the liner system to prevent the build-up of pore pressures beneath the TSF. The underdrain will be placed prior to installing the impoundment liner. The underdrain will be placed in the main drainage paths of significant tributaries and connect to a main underdrain trunk along the base of Anaconda Creek. Base flows from outside the liner footprint will pass through the rock underdrain and report to the SRS pond located at the toe of the TSF Dam (SRK 2017). During construction, discharge from the SRS may require treatment prior to discharge and if needed would be treated in the operations WTP and discharged to Crooked Creek near the confluence of Omega Gulch under an APDES permit. An average annual discharge of $340 \mathrm{~m}^{3} / \mathrm{h}$ from the SRS is anticipated during late construction (SRK 2017).# NovagOLD 

## Overburden Stockpiles

A number of overburden stockpiles are required to store material that will be used to reclaim the TSF and WRF. All of these stockpiles lie beyond areas that drain into proposed dams and will need sediment control structures. Overburden stockpiles requiring sediment control include:

- The north overburden (NOB) stockpile north of American Creek on the east side of Crooked Creek
- The south overburden (SOB) stockpile between the American Creek and Anaconda Creek valleys on the east side of Crooked Creek
- Three stockpiles downstream of the TSF dam.

Runoff from these stockpiles will be managed by intercepting and directing surface runoff toward sediment ponds sized to contain the 10-year return period, 24-hour duration storm. The diversion channels will be sized for the 100-year rainfall event. Two sets of diversion channels are proposed. Upslope diversions will limit runoff to the overburden dumps, while channels on the downslope side will direct surface runoff to the sediment ponds.

## Construction Camp Potable Water Supply \& Domestic Waste Water

The source of water supply for the construction camp and, later, the plant site potable water systems, would be an array of eight wells south of Omega Gulch, near Crooked Creek.

Wastewater from the construction camp will be treated in a conventional waste water treatment system and discharged under an APDES general permit.

## Fire Water

Fire protection water supplies for the construction camp and permanent accommodation facility will be provided from the freshwater storage tanks. The tanks will have a reserve supply for fire protection capable of providing $1,900 \mathrm{~L} / \mathrm{min}$ for one hour, in accordance with NFPA requirements for ordinary hazard occupancies.

## Plant Start-Up Water Supply

Approximately $0.23 \mathrm{Mm}^{3}$ of non-turbid water would be required for process plant commissioning, and $3.1 \mathrm{Mm}^{3}$ would be required at process plant start-up (SRK 2017). This startup volume would be based on the ability to meet the process water requirements until reclaimwater from the TSF can be relied on (i.e., sediment content / clarity is suitable for process use). The deterministic and stochastic water balance model results indicate this volume would be met by the Lower CWD, even in dry years. In extreme dry years, the remaining water requirement could be supplied from the FWD and/or the American FWDD.

[[%~%]]
### 18.6.3 Operations Water Management Strategy

The water supply and management concept during operations is designed to provide sufficient fresh water for process during operations, ensure that treated water discharged to the environment meets water quality standards, and minimize the TSF pond volume during operation and at closure. A number of structures and operating rules have been designed to meet these objectives. Operations water management components and structures are shown in Figure 18-6.

## Process Water Requirements

Water requirements for the process facilities are summarized below. Water requirements depend on process plant feed rates, which vary annually (SRK 2017):

- During the active operating period of the mine, the process plant requires an average water supply of $4,088 \mathrm{~m}^{3} / \mathrm{h}$
- Process plant water loss averages approximately $62 \mathrm{~m}^{3} / \mathrm{h}$
- The process plant requires a minimum $568 \mathrm{~m}^{3} / \mathrm{h}$ of makeup water; this includes water from the contact water ponds, pit dewatering water, water from the TSF SRS and, if required, from the FWD.
- Reclaim water from the TSF is pumped back to the process plant at an average rate of approximately $3,213 \mathrm{~m}^{3} / \mathrm{h}$.Figure 18-6: Operations Water Management Layout
![img-50.jpeg](img-50.jpeg)# NOVAGOLD 

Reclaim water is maximized at approximately $3,520 \mathrm{~m}^{3} / \mathrm{h}$ when TSF pond volumes exceed $6.0 \mathrm{Mm}^{3}$. During operations active water treatment would use a WTP with a maximum treatment rate of approximately $1,080 \mathrm{~m}^{3} / \mathrm{h}$, treating water from the following sources:

- Dewatering well water would be treated at a maximum rate of approximately $540 \mathrm{~m}^{3} / \mathrm{h}$ and an average rate of approximately $181 \mathrm{~m}^{3} / \mathrm{h}$.
- Contact water from the CWDs would be treated at a maximum rate of $250 \mathrm{~m}^{3} / \mathrm{h}$ and an average rate of approximately $101 \mathrm{~m}^{3} / \mathrm{h}$.
- It is assumed that TSF reclaim water would be treated at a maximum rate of approximately $10 \mathrm{~m}^{3} / \mathrm{h}$ and an approximate average rate of $5 \mathrm{~m}^{3} / \mathrm{h}$ based on conservative estimates of water quality.
- SRS water would be treated at an approximate maximum annual rate of $235 \mathrm{~m}^{3} / \mathrm{h}$ and an approximate average rate of $95 \mathrm{~m}^{3} / \mathrm{h}$.

In years with below average precipitation, the Lower and Upper CWDs, SRS and pit dewatering system would not be able to meet the year-round fresh water requirements for the plant. In this case, additional water would be obtained from the FWD.

## Tailings Storage Facility

Runoff to the TSF will be minimized by the construction of staged diversion channels and two upstream diversion dams. The diversion channels will remain in operation until Year 17, while the diversion dams will be removed after Year 3. Without diversions, the TSF has a total catchment area of 1,520 ha. Even with the diversion structures, however, water is expected to build up in the TSF under average precipitation conditions. This water will be managed through storage during mine operations and by pumping the excess to ACMA pit at closure. Flood storage for the TSF includes runoff from the 200-year snowmelt and 24-hour Probable Maximum Precipitation (PMP)—a total of $8.25 \mathrm{Mm}^{3}$. An additional freeboard of 2 m is added to this flood storage.

A SRS downstream of the TSF dam will serve as backup to the TSF liner. The SRS pond water would be sent directly to the process plant as part of the process freshwater requirement or pumped to the WTP for treatment and discharge. The collection pond would be designed to accommodate three days' worth of underflow drain and bedrock seepage flow at a maximum rate of approximately $272 \mathrm{~m}^{3} / \mathrm{h}$. The total SRS pond storage volume required is $20,000 \mathrm{~m}^{3}$.# Lower and Upper Contact Water Dams 

The Lower and Upper CWD will be located in American Creek with the objective of managing contact water runoff from the WRF and open pit. The Lower CWD will receive runoff from a variety of sources:

- Surface and seepage runoff from the waste rock
- Runoff from undisturbed ground upgradient of the WRF
- Surface runoff within the open pit footprint
- In-pit dewatering wells and horizontal drains from the open pit
- Runoff collected behind the ore stockpile berm
- Runoff collected in a sediment pond downstream of the SOB stockpile.

During operations, the Lower CWD would have sufficient storage to contain the following flood events without spilling (and hence potentially inundating the ACMA Pit): an operating pond of $0.5 \mathrm{Mm}^{3}$, plus the PMP of $4.77 \mathrm{Mm}^{3}$. No spillway would be constructed given the conservative storage volume.

The Upper and Lower CWD would also be designed to store water that would be used throughout the year as a source of makeup water for the process plant. Peak runoff would be limited to the spring and summer months, with negligible runoff volumes between mid October and the beginning of April. These variable flows would be in contrast to the constant fresh water demand. During the former period, runoff volumes would be in excess of fresh water requirements and this excess water will be stored. The stored water would be a useful source of water during the fall and winter, when inflows would be minimal.

## Open Pit

Runoff into the open pit will be managed with a combination of horizontal drains, surface water ditches, pumps, and sumps. The proposed pit drainage system consists of two major components. The first system will be constructed around the rim of the ultimate pit and includes a perimeter ditch and three pumping stations.

The second system will consist of pumps for lifting water out of the pit. Ditches will be constructed along all roads and on other strategically located benches while excavating the pits. These ditches will intercept surface and horizontal drain runoff and direct the water into sumps. The sump water will then be picked up with a primary pump and discharged into the perimeter system.Additional information on the pit water management system is provided in Section 16.9 of this Report.

# Waste Rock Facility 

The American Creek WRF would ultimately cover an approximate area of $9 \mathrm{~km}^{2}$. Runoff from the WRF would be captured by the Lower CWD, immediately upstream of the pit area. A single diversion dam is included in the mid- to upper-reaches of American Creek to minimize runoff to the Lower CWD until the Upper CWD is operational in the first quarter of LOM Year 1.

## Ore Stockpile Berm

Downstream of the Lower CWD, contact water will be generated from the ore stockpile. To prevent this catchment area from discharging into the open pit, a small berm will be constructed on American Creek immediately downstream of the proposed ore stockpile. Runoff from the ore stockpile, as well as shallow seepage from the Lower CWD, will be captured by the ore stockpile berm and pumped back to the Lower CWD.

[[%~%]]
### 18.6.4 Closure Water Management Strategy

The overall site plan for closure includes the following components presented in Figure 18-7.

- Reclaimed TSF surface that would direct surface water drainage toward the southeast corner of the TSF.
- A spillway would be excavated in the ridge dividing Anaconda and Crevice Creek catchments to allow surface runoff from the TSF cover system to flow into Crevice Creek (once suitable for discharge).
- Reclaimed WRF with surface and seepage flows draining into the ACMA and Lewis Pits.
- A lake in the partially backfilled ACMA and Lewis Pits with a constructed emergency spillway.Figure 18-7: Closure Water Management Layout
![img-51.jpeg](img-51.jpeg)

[[%~%]]
## 18.7 Bethel Marine Terminal

Bethel is about 105 km upriver from the mouth of the Kuskokwim River where it empties into Kuskokwim Bay. It is the only port on the Kuskokwim River accessible to ocean barges.

The Knik Construction Yard site, which is downstream from the Port of Bethel, has been identified as the site for a general cargo barge terminal dedicated to the Project. It has road access and could be connected to the local power grid.

Ocean barges will be unloaded of their cargoes, which will either be transhipped directly to river barges or placed in storage to wait for an available river barge. The salient features of the terminal will include:

- A berth for ocean barges
- A berth for river barges
- A roll on/roll-on berth
- A storage area for containers and break-bulk cargoes
- Buildings and ancillary infrastructure and services.

To provide enough space for five ocean barge loads, the terminal yard will need to be about 5.1 ha in area. With a further 1.4 ha required for the wharf, buildings, access roads, and ancillary services and facilities, the terminal will have a total area of 6.5 ha.

Two years prior to operations, the peak construction year, up to 30 ocean barges will call at Bethel and unload construction cargoes.

The wharf structures, fender systems, and mooring systems will be designed for a minimum service life of 25 years. Other conditions factored into the design of the wharf include site conditions, ice, environmental conditions, a corrosion allowance, and the vessels that will use the terminal.

Electrical power for yard lighting and office needs at the port will be provided from the local grid. Potable water will be obtained from a well, and sewage will be sent to a septic field. Water for fire protection will be pumped from the river through a temporarily deployed pump and hose into a heated, insulated, above-ground $900 \mathrm{~m}^{3}$ dedicated firewater storage tank.

To accommodate the increase of about 151.42 ML in annual throughput attributable to the Project, storage capacity at the existing tank farms in Bethel will be increased by 22.71 ML.The following mobile equipment will be required at the Bethel port:

- 2 mobile harbour cranes
- 1 wheel loader
- 1 forklift
- 6 forklift - 30 t capacity
- 2 crew cab $4 \times 4$ pickup trucks
- 6 container tractors
- 12 container trailers
- 1 highboy trailer
- 1 vehicle maintenance truck.


[[%~%]]
## 18.8 Jungjuk Port Site

The Jungjuk port site is located on the north bank of the Kuskokwim River, 13 km downriver of the village of Crooked Creek and 312 km upriver of Bethel. A viable site has been identified 305 m upriver of the mouth of Jungjuk Creek. A staging area of up to 10 ha can be developed on adjacent uplands immediately north of the dock site.

The port will be developed on a south-facing slope rising from the Kuskokwim River to ridges that crest at an elevation roughly 305 m above river level at a distance approximately 3.2 km from the river's north bank. Elevation at the port site is roughly 40 m above sea level, on the "high ground" between the Jungjuk Creek drainage to the west and a minor stream that discharges into the Kuskokwim River about 500 m upriver of the mouth of Jungjuk Creek.

Facilities at Jungjuk will include two river barge berths, a barge ramp, container-handling equipment, seasonal storage for containers, break-bulk cargo, and fuel, and barge-season office / lunchroom facilities.

The wharf structures, fender systems, and mooring systems will be designed for a minimum service life of 25 years. The river barges will arrive in tows of four (two-by-two configuration). River barges will be unloaded of their cargoes, which will be placed in storage to await onward transport to the mine site by truck.

The terminal yard will be capable of storing about 1,000 TEU containers.
Containers and other cargo will be trucked to the mine throughout the summer barging season. Fuel will be off-loaded from barges and temporarily held in a storage tank before being pumped to B-train trucks for transport to the main fuel storage facility at the mine site.Electrical power for yard lighting and office needs at the port will be provided by diesel generators. Potable water will be obtained from a well, and sewage will be sent to a septic field. Water for fire protection will be pumped from the river through a temporarily deployed pump and hose into a heated, insulated, above-ground $900 \mathrm{~m}^{3}$ dedicated firewater storage tank.

The following mobile equipment is required for port operations:

- 2 mobile harbour cranes
- 1 wheel loader
- 4 container forklifts
- 4 crew-cab pickup trucks
- 5 semi-trailer tractors
- $14 \times 4$ pickup truck
- 8 container trailers (bomb carts)
- 4 terminal tractors
- 1 highboy trailer
- 1 fire truck.


[[%~%]]
## 18.9 Power And Electrical

Electric power for the Project site will be generated from a dual-fuelled, (natural gas and diesel) reciprocating engine power plant with a steam turbine utilizing waste heat recovery from the engines. The power plant consists of two equal halves, each consisting of six reciprocating engines, and a separate steam turbine. Ancillary equipment will include engine halls, electrical room, control room, station service transformers, black-start gensets, exhaust stacks, radiators, lube systems, waste oil handling, waste heat recovery, turbine halls, electrical distribution equipment, and control and protection. The two parts of the plant will be separated by a blast wall such that either half can provide emergency power to the site in the event of a catastrophic failure.

The total generation facility is nominally rated at 182 MW initially. This will increase to 215 MW after four years with the addition of two more gensets (one in each half) to allow for $\mathrm{N}+2$ redundancy, thus permitting planned maintenance and predicted outages without cutting back production.

The conceptual design of the generating station does not provide thermal energy for building or process heating; the waste heat is used to generate electricity.To minimize electrical distribution costs and load losses, the power generation facility will be strategically located adjacent to the two major process electrical loads: the oxygen plant and the grinding mills.

The total connected electric load is estimated to be 227 MW, the average running load approximately 153 MW, and the peak load 182 MW. Motors constitute most of the electrical loading. The largest are the grinding mill motors, which are gearless (wrap around) type that use cyclo converter variable-speed drives with soft-start features. The oxygen plant will have three large synchronous motors that use a load-commutated inverter (LCI) controller to provide motor soft-start to minimize the stress on the power supply during starting and to reduce voltage flicker.

Power will be distributed to the main process areas by metal-clad cable feeders in trays mounted on racks routed to the local electrical rooms through utilidors, process buildings, and conveyor galleries. This will include the grinding, POX, CIL leach, refinery, and coarse ore reclaim areas. Overhead power lines will be run to the more remote areas, including the primary crusher, the water system, pumping, tailings, mine open pit electric shovels, and pit dewatering sites. Each process area load centre will have associated electrical rooms, distribution transformer(s) to bring the voltage down to utilization levels, secondary distribution centres and switchgear, and motor / feeder distribution equipment. To minimize costs the electrical rooms will be pre-fabricated off-site with all electrical equipment installed, pre-wired, and tested prior to shipping to site.

Power will be provided to the permanent accommodation facility from the mine / process plant site on a 34.5 kV power line. In addition, a local emergency power diesel genset will be installed to provide backup power in the event of a failure of the pole line. There are no major facilities located at the airport. The airstrip will have a 100 kW genset to run fuel pumps and lights as needed and will not be connected to the site power supply.

The Jungjuk port site will have an independent, stand-alone power generation facility equipped with two 600 kW (one backup) gensets. The power station will be supplied completely self-contained with all controls and ancillary equipment, ready for installation on site. The unit will include all accessories, radiators, cooling fans, exhaust systems, air and fuel filters, engine control panels, alternators, controls, starting batteries, and chargers within a modular enclosure suitable for shipping and travel on standard highways. The module will be complete with mounting skids, access (maintenance, equipment, and man-doors), ventilation, interior and exterior lighting, general power receptacles, provision for grounding, fuel day tank, supply and return fuel lines to engines, and circuit breaker with control, protection, indication, and alarms.The port site will also include a control module unit to house the electrical switchgear, synchronization controls, and operator interface equipment. The three modular units will be arranged together and will be installed on concrete foundations.

[[%~%]]
## 18.10 Natural Gas Pipeline

The 14-inch ( 356 mm ) natural gas pipeline proposed for the Project would be approximately 507 km long. It would commence at the west end of the Beluga Gas Field, approximately 53 km west of Anchorage at a tie-in near Beluga and would run to the Project site. Donlin Gold LLC advised Wood that the proposed pipeline route crosses an area with no significant pre-existing infrastructure and does not follow any existing utility corridors.

The pipeline would receive booster compression supplied by one compressor station located at approximately mile post 0.4 . No additional compression along the pipeline route would be required. The pipeline would transport approximately $1,553,868 \mathrm{~m}^{3} / \mathrm{d}$.

The pipeline would be regulated by the US Department of Transportation (DOT) under Title 49 of the Code of Federal Regulations, Part 192 - Transportation of Natural Gas and Other Gas by Pipeline: Minimum Federal Safety Standards (49 CFR 192). The pipeline would be designed, constructed, and operated in accordance with the applicable requirements of 49 CFR 192 and would incorporate pig launching and receiving facilities (receipt, midpoint, and delivery), approximately 16 mainline block valves (MLVs) spaced at32 km intervals along the line, cathodic protection, leak detection, a supervisory control and data acquisition (SCADA) system, and a fiber optics cable along the full length of the route, from origin to the mine site.

The design life of the proposed pipeline is 30 years; however, design life can be extended with additional maintenance and repair.

[[%~%]]
## 18.11 Fuel

[[%~%]]
### 18.11.1 Diesel

The maximum diesel fuel storage capacity at the plant site is estimated to be 142 ML . Storage for 9.5 ML of fuel will be provided at the Jungjuk port site, but this is only intended for shortterm use while the fuel barges are being unloaded during the summer and is not included in the design of the overall site storage capacity.

The plant site fuel storage facilities are sized for a ten-month supply plus one month of contingency for the mine fleet and site mobile equipment. Fifteen fuel tanks, each having a capacity of 9.5 ML will be installed within a HDPE-lined and bunded tank farm approximately600 m east of the plant site and at an elevation of approximately 299 m . This arrangement provides gravity-assisted flow to the plant area at an average elevation of 290 m and to the truckshop at elevation 207 m .

During the summer shipping season, fuel tanker trucks will transfer diesel fuel from the 9.5 ML temporary storage tanks at the Jungjuk port to the plant site fuel farm. From there, the fuel will be distributed to various day tanks around the site.

[[%~%]]
### 18.11.2 Natural Gas

Natural gas will be supplied to the various buildings at the plant site for heating through an underground network of pipes. The main distribution line will extend 7.2 km along the main access road to the permanent accommodation complex and supply fuel for the forced-air heating system and for the cooking appliances in the camp kitchen.

The supply of construction diesel fuel and propane will be delivered during the summer shipping season. The diesel fuel will be stored in temporary $500 \mathrm{~m}^{3}$ tanks until the first two 9.5 ML storage tanks are completed and can be filled with fuel. The propane will be stored in fourteen 38,000 L mobile tanks.

[[%~%]]
## 18.12 Comment On Section 18

In the opinion of the QPs, the infrastructure requirements and current designs for such infrastructure for the Project are appropriate to the mine and process plant, and to the Project setting:

- In general, the design and construction of the mine site infrastructure will be relatively straightforward, although the scope of the work is extensive, especially in terms of the water systems. In addition, the Project involves several development sites considerable distances apart, incurring high infrastructure costs to provide interconnecting roads, pipelines, services, and utilities. The decision to use material from the plant site excavation as a borrow source for constructing the starter tailings dam is an effective way to reduce the site preparation costs.
- There are known to be intermittent areas of permafrost and poor ground conditions at the various facility sites that could affect foundation design and site preparation. This risk can be mitigated by carrying out more thorough geotechnical investigations at all sites.
- Off-site infrastructure will be arranged, designed, and constructed using techniques that are proven to result in functional and durable facilities suited to their remote location andcold environment. For the detailed design phase of the Project, further geotechnical investigations should be done along the access road and at Jungjuk and the Bethel cargo terminals. In addition, river water levels should be monitored through future barge seasons to gain a better understanding of year-to-year variability.

- Prior to final design, the TSF and water dam designs will need to be checked for compliance with most current state and federal guidelines. A geotextile has been proposed for filter protection of the TSF underdrain system that extends under the TSF dam. Use of geotextile in the locations that are critical to the safety of dam is not recommended by FEMA (2008) and is not in compliance with recent draft state dam safety guidelines (ADNR, 2017), which have not yet been made final. Moreover, geomembrane lined zigzag dam cores are proposed for all water dams of the Project; this design practice of geomembrane-lined dam cores is not recommended by USBR (2018).
- The TSF design needs to be advanced to the next stage and be revised as needed to be in full compliance with the recently published global tailings standard (GISTM, 2020).
- The construction schedules for the TSF starter dam and other dams at the initial phase of the Project are aggressive, particularly related to activities of dam foundation preparations and liner system installations. Any significant weather or permitting-related delays could affect successful completion of these facilities on schedule and lead to delay of mine start-up. This risk can be managed by proper detailed preconstruction planning and with detailed execution plan and construction schedules.
- Water management is required during construction, operations (27 years), and closure. For the construction phase the critical infrastructure components are the WRF and the ACMA and Lewis pits, which begin development in Year -1. Runoff from these areas is contact water that cannot be discharged to Crooked Creek unless it meets discharge water quality standards. This runoff must therefore be stored in the Lower CWD for use during operations or treated and discharged as per the APDES permit. An upstream FWDD will minimize the area draining to the Lower CWD during construction and the first year of operations. Water impounded behind the Lower CWD will be the primary source of water to the process plant during the start-up period. Start-up water requirements are $3.1 \mathrm{Mm}^{3}$ of non-turbid water. Under very dry conditions, there could be a shortage of fresh water supply during the first few years of operations. To mitigate this potential, runoff water will be impounded behind a FWD constructed in Snow Gulch during the preproduction period.
- The construction schedule for the Lower CWD is aggressive, with a great deal of work to be completed in a short duration. Weather delays could affect completion of the dam on schedule. The consequences of not meeting the current construction schedule aredeferral of any construction activity upstream of the Lower CWD that generates contact water and possible delays in revenue generation.

- In the American Creek watershed, a lake will be allowed to develop in the mined-out pits. The pit lake will receive runoff from the TSF reclamation activities (including the supernatant pond volume remaining at the end of operations), the covered WRF, and undisturbed areas upslope of the WRF. Seepage from the reclaimed WRF will be collected and piped to the bottom of the pit lake to encourage pit lake stratification. Modelling of the pit lake geochemistry indicates that treatment is required before ACMA pit lake water can be discharged to Crooked Creek. The WTP has been designed for a maximum capacity of $1,700 \mathrm{~m}^{3} / \mathrm{h}$ based on an average annual operating period of six months; longer operating periods will be required in years when precipitation is above average.
- Seasonal constraints on construction of the PAG cover could limit the ability to use this portion of the WRF during certain periods of the year. This could require temporary stockpiling of the PAG materials and changes to the mine plan.
- Although the terrain is diverse and severe through the Alaskan Range, the pipeline route has been field verified by construction and survey personnel.
- Further confirmation of hydraulic modeling is recommended to optimize the flow demand / pattern scenarios, i.e., 14" diameter versus 16" diameter pipeline with various compression options.
- The electrical power generation and distribution system has been designed to meet the requirements of the proposed loads, the site location, and facility layout. Electric power for the Project site will be generated from a dual-fuelled, (natural gas and diesel) reciprocating engine power plant with a steam turbine utilizing waste heat recovery from the engines.
- In a typical year, the Donlin mine will consume about 105,000 t of general cargoes and 152 ML of fuel. Utilizing Liquid Natural Gas (LNG) propulsion for the mine truck fleet would substantially reduce the annual diesel requirements.

[[@~@]]
# 19.0 Market Studies And Contracts

[[%~%]]
## 19.1 Marketing Partnership Agreement

The Limited Liability Company Agreement of Donlin Creek LLC dated 1 December 2007 as amended (the LLC Agreement) provides for the members of DCLLC (the Members) to take in kind their respective shares of the gold production, which they can then sell for their own benefit.

The LLC agreement further provides that neither Member shall have any obligation to account to the other Member for, nor have any interest or right of participation in, any profits or proceeds, nor have any obligation to share in any losses from futures contracts, forward sales, trading in-puts, calls, options or any similar hedging, price protection or marketing mechanism employed by the other Member with respect to its proportionate share of the production.

[[%~%]]
## 19.2 Gold Marketing

NOVAGOLD's portion of gold production is likely to be sold on the spot market, by marketing experts retained by or on behalf of NOVAGOLD. Gold can be readily sold on numerous markets throughout the world and it is not difficult to ascertain its market price at any time. Since there are many available gold purchasers, NOVAGOLD would not be dependent upon the sale of gold to any one customer. Gold could be sold to various gold bullion dealers or smelters on a competitive basis at spot prices.

NOVAGOLD expects that terms contained within any sales contract that could be entered into would be typical of, and consistent with, standard industry practices, and be similar to contracts for the supply of gold elsewhere in the world.

[[%~%]]
## 19.3 Comments On Section 19

In the opinion of the QPs, NOVAGOLD will be able to market their attributable share of the gold produced from the Project. Sales contracts that could be negotiated would be expected to be within industry norms. However, most of the production would be expected to be spot marketed.

[[@~@]]
# 20.0 Environmental Studies, Permitting, And Social Community Impact

[[%~%]]
## 20.1 Baseline Studies

Baseline studies completed in support of Project development and ongoing monitoring are identified in Table 20-1.

Baseline data were collected to support Project design; to determine and implement environmental controls to mitigate impacts; and to sufficiently characterize the environment in support of permit applications and environmental impact assessments. The environmental baseline data will also provide a reference point against which environmental conditions can be evaluated during operations to facilitate early detection of potential changes that may occur during Project development and future operation.

Additional baseline studies are ongoing as a mitigation and regulatory component associated with some of the permits (e.g., Aquatic Resource Management, Fish Surveys).

[[%~%]]
## 20.2 Environmental Issues

Based on Project design concepts developed through the prefeasibility and feasibility engineering work, years of community interaction, and coordination with regulatory agencies, several key environmental issues of concern have been identified for the Project; these areas and a portion of the mitigation measures are summarized in Table 20-2. These issues have been analyzed and addressed during the development of the Environmental Impact Study (EIS) and the issuance of the Joint Record of Decision (JROD), which includes a number of mitigation measures to address potential environmental impacts. A complete list of the mitigation measures was detailed in the JROD and the associated project permits.

Ongoing potential issues are being addressed and mitigated through a combination of baseline data collection, diligent engineering and Project design, construction Best Management Practices (BMPs) and Mitigation Measures, and thorough public consultation.Table 20-1: Environmental Baseline Studies (1995 - 2020)

| Baseline Study | 1995 | 1996 | 1997 | 1998 | 1999 | 2000 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Water Quality |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Surface Water Quality | X | X | X | X | X | X |  | X | X | X | X | X | X | X | X | X |  |  |  |  |  |  |  |  |  | X | X |
| Groundwater Quality |  |  |  |  |  |  |  |  | X | X | X | X | X | X | X | X |  |  |  |  |  |  |  |  |  |  |  |
| Deep Well Pump Testing to evaluate streambed hydraulic conductivity |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | X |  |  |  |  |  |  |  |  |
| Air Quality |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Meteorological Data | X | X | X | X | X | X |  |  | X | X | X | X | X | X | X | X | X |  |  |  |  |  |  |  |  | X | X |
| Precipitation |  |  |  | X | X | X |  |  |  | X | X | X | X | X | X | X | X |  |  |  |  |  |  |  |  |  |  |
| Ambient Air |  |  |  |  |  |  |  |  | X | X |  | X | X | X | X | X |  |  |  |  |  |  |  |  |  |  |  |
| SOGAR |  |  |  |  |  |  |  |  |  |  |  |  |  | X | X |  |  |  |  |  |  |  |  |  |  |  |  |
| Aquatic Studies |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Biomonitoring / Tissue Sampling |  |  | X | X |  |  |  |  |  | X | X | X | X | X | X | X |  |  |  |  |  |  |  |  |  |  | X |
| Spawning Surveys | X | X | X | X |  |  |  |  |  | X | X | X | X | X | X | X |  |  |  |  |  |  |  |  |  |  |  |
| Resident Fish Surveys |  | X | X | X |  |  |  |  |  | X | X | X | X | X | X | X |  |  |  |  | X | X |  |  |  |  | X |
| Terrestrial Wildlife |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Habitat Mapping |  |  |  |  |  |  |  |  |  | X | X |  | X |  |  | X |  |  |  |  |  |  |  |  |  |  |  |
| Wildlife Surveys |  |  |  |  |  |  |  |  |  | X |  | X | X | X | X | X |  |  |  |  |  |  |  |  |  |  |  |
| Avian Studies |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Avian Surveys |  |  |  |  |  |  |  |  |  | X |  | X | X | X | X | X |  |  |  |  |  |  |  |  |  |  |  |
| Wetlands Program |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Wetlands Delineation |  | X | X | X |  |  |  |  | X | X | X | X | X | X | X | X | X | X | X | X |  | X | X |  |  |  |  |
| Waste Rock Characterization |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ARD / ML Studies |  |  | X | X | X |  |  |  |  | X | X | X | X | X | X | X | X | X | X | X | X | X | X | X | X | X | X |
| Cultural Studies |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cultural Site Surveys |  |  |  |  |  |  |  |  |  | X |  | X | X | X | X | X |  |  |  |  |  |  |  |  |  |  |  |
| Socioeconomics |  |  |  |  |  |  |  |  | X |  |  | X | X | X | X |  |  |  |  |  |  |  |  |  |  |  |  |
| River Studies |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| River Use / Fishing Activity Surveys |  |  |  |  |  |  |  |  |  |  |  | X | X | X | X | X |  |  |  | X | X | X | X |  | X | X |
| Marine / River Wildlife Surveys |  |  |  |  |  |  |  |  |  |  |  | X | X | X | X | X |  |  |  |  |  |  |  |  |  |  |  |
| Erosion Studies |  |  |  |  |  |  |  |  |  |  |  | X | X |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Barge Studies |  |  |  |  |  |  |  |  |  |  |  |  | X |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Programs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mercury Baseline |  |  |  |  |  |  |  |  |  |  |  | X | X | X | X | X |  |  |  |  |  |  |  |  |  |  |  |
| Noise Surveys |  |  |  |  |  |  |  |  |  |  | X |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |Table 20-2: Key Environmental Issues

| Issue Identified | Mitigation Measures Proposed |
| :--: | :--: |
| Mercury | - Collection of detailed mercury baseline information; the Kuskokwim region has naturally elevated levels of mercury. <br> - Ongoing modelling studies based on a combination of local, regional, and global mercury measurements. <br> - State-of-the-art engineered mercury abatement controls have been designed for the processing operations. These include emission controls on the autoclave, carbon regeneration kiln, electrowinning cells, and mercury retort. <br> - Stakeholder discussions in ongoing community outreach efforts. |
| Cyanide | The Project is designed to adhere to the International Cyanide Management Code (ICMC) for the transport and use of cyanide. Engineering criteria include use of purpose-built stainless steel ISO (International Standards Organization) containers for the transport of solid sodium cyanide briquettes, incorporation of a cyanide detoxification system and specific cyanide containment areas, and monitoring plans. ICMC adherence will begin at the start of operations. |
| Water Resources | - The Project design has addressed specific water management areas, including a detailed water balance model, design of containment structures with appropriate freeboard allocations, freshwater diversion structures, water treatment systems, a fully lined tailings storage facility, and inclusion of flexibility in water management designs and for treating excess water during operations, as necessary. <br> - Following closure, a pit lake will develop over a period of many decades. The current design provides for water treatment in perpetuity following the filling of the pit lake to ensure compliance with water quality standards. <br> - Develop a sampling and analysis plan to ensure Potentially PAG rock and other sources of contaminants are not used for construction at the mine or for road surfacing where such construction could lead to surface water quality impacts. |
| Waste Rock and Stormwater Management | - The engineering design includes classification and segregation of waste rock. Rock classified as having high ARD potential (PAG7 material and some quantities of other PAG material) will be backfilled into the pit at a location below the eventual water table and a dedicated cell constructed within the WRF will handle additional quantities of waste that cannot be blended or backfilled into the pit (PAG5 and PAG6 material). <br> - Concurrent reclamation will be practiced over the WRF. <br> - All stormwater runoff from related facilities will be captured in a CWP, or pumped to it, and be used during operations or treated prior to discharge. <br> - At closure, all runoff and seepage will be collected and managed in the pit. |
| Hazardous Waste | Prior to pipeline construction, identify and map potentially contaminated soil. Contaminated soil should be avoided where possible in the final grading plan. || Issue Identified | Mitigation Measures Proposed |
| :--: | :--: |
|  | Specifically, at the Farewell airstrip, North Foreland barge landing, Tyonek-Beluga pipeline trench segment, and the Puntilla airstrip. |
| Cultural Resources | - Mitigate impacts to known cultural sites such as a narrower construction Right-ofWay (ROW) and using horizontal directional drilling (HDD) under a sensitive site. <br> - Follow the National Historic Preservation Act (NHPA) Section 106 Programmatic Agreement which includes but is not limited to the Final Cultural Resource Management Plan, the Treatment of Historic Properties, and procedures for the Treatment of Human Remains. |
| Transportation | - Engineering considerations include incorporating a natural gas pipeline component into the project design to fuel power generation at site; using shipping containers that exceed industry standards for the transport of hazardous materials; using custom-designed double-hull barges for fuel transport; implementing modern scheduling and navigation aids on the Kuskokwim River; developing detailed ocean, river, and land spill response plans including training of personnel. <br> - Additional considerations include developing communication strategies to provide timely advance warning of barge passage on the river. <br> - Clear signage distinguishing trails from the pipeline ROW. |
| Flora and Fauna | - Consideration of impacts on wildlife from the tailings storage facility include incorporation of high-density polyethylene (HDPE) or synthetic netting material, and regular inspection and sampling protocols. <br> - Avoid vegetation clearance during bird nesting season. <br> - Employ seasonal timing restrictions on blasting, as stipulated by resource agencies, to reduce noise related effects of blasting during sensitive subsistence hunting activities. Implement an Aquatic Resource Monitoring Plan and the Rainbow Smelt Monitoring Program. |
| Water Resources | - Wetlands and riparian areas will be avoided where practicable. When not practicable, construction BMPs will be followed such as storing wetland topsoil to be used in temporarily impacted areas. <br> - Implement Compensatory Mitigation Plan and associated requirements such as, deed restrictions, financial assurances, and performance standards. |

[[%~%]]
## 20.3 Closure Plan

Reclamation will begin during construction when topsoil and overburden stockpiles and cut-and-fill slopes are stabilized. Significant reclamation will be carried out immediately after construction, particularly at material borrow sites and where opportunities exist to replace disturbed wetland and enhance aquatic and terrestrial habitat. Reclamation will also be performed concurrently with mining and with the cessation of mining and processing operations.

Area and component specific reclamation plans governing actual reclamation activities will be developed further throughout the life of the project and as the Project nears the end of the mine life. Alternatives will be evaluated and incorporated into the final reclamation plan where appropriate near the end of the mine life.

The design of long-term water management systems is an integral part of planning for site closure, particularly with regard to the TSF, WRF, and CWDs. Closure of these facilities, in turn, involves post-closure water monitoring, maintenance, and treatment systems to ensure that water discharged to the environment meets all applicable water quality criteria. The lake to be formed in the mined-out ACMA pit is the central feature of all post-closure water management in the foreseeable future.

Surface water and groundwater monitoring systems for process components will remain in place up to and likely beyond 30 years, depending on compliance history and until each specific facility has been stabilized, physically and chemically, to the satisfaction of the applicable state and federal regulatory agencies. Once physical reclamation begins, temporary diversions and sedimentation control systems will be constructed and routinely monitored. These systems will be cleaned, repaired, and modified as necessary.

Long-term or permanent diversions, water treatment, physical barriers, and signage will be monitored and maintained as needed until all closure standards are met, reclamation surety has been released, and property management reverts to the landowner. The decision on what constitutes final closure and the release of any outstanding financial surety will require the concurrence of Alaska Department of Natural Resource (ADNR), Alaska Department of Environmental Conservation (ADEC), BLM and other applicable federal agencies.

[[%~%]]
### 20.3.1 Water Treatment Plant

A post-closure water treatment plant (WTP) will be built at the site. The proposed post-closure WTP is based on the projected pit lake water quality and design water flows and is essentially similar to that proposed during the Donlin 2011 Technical Report. Current information regarding forecasted water quality and water quantity has resulted in treating post-closure water to meet applicable water quality standards.

Except for selenium, all metals exceeding standards will be removed through conventional technology. Treatment for sulphate has been eliminated because updated predictions of pit lake water quality by Lorax have found that sulphate concentrations will be well below the most stringent Alaskan water quality standards and therefore will not require treatment. Selenium will be treated in an Octolig resin column package. The sludge from the post-closure WTP will be chemically stable and will be sent to the bottom of the pit lake for final disposal.

More testwork will be conducted as the Project approaches the end of operations to support the final design and flowsheet selection for, and final permitting of the post-closure WTP. The results of ongoing bench and pilot testing, in addition to operational water treatment data, will be used to update the water treatment process design for the post-closure WTP.

[[%~%]]
### 20.3.2 Tailings Storage Facility

Several years before the end of operations, the tailings deposition procedure will be modified to direct the operating pond toward the southeast corner of the TSF. This will be done in anticipation of closure, when the tailings runoff will be directed to Crevice Creek through the closure spillway after runoff water meets water quality standards; this is anticipated to take approximately five years. Construction of the closure cover on the TSF is expected to take approximately five years after initial tailings consolidation (approximately one year after operations have ceased), and final tailings consolidation is expected to take approximately 52 years. At closure, the TSF water will be pumped to the pit through the reclaim pipeline.

A closure cover over the tailings impoundment will be required to minimize groundwater interaction and reduce salt mobilization and subsequent transpiration. Surface runoff on the cover will be directed to a lined pond in the southeast corner of the reclaimed TSF.

[[%~%]]
### 20.3.3 Waste Rock Facility

The WRF has been designed to maximize concurrent reclamation, minimize the effects of PAG materials, add flexibility to the site water balance, and optimize the cost of closure. The facility will be constructed in lifts and will be reclaimed as soon as practical after each lift or portion ofthe facility is complete. After active dumping ceases on each lift, the slopes will be regraded to less than or equal to an overall $3 \mathrm{H}: 1 \mathrm{~V}$ slope.

A series of channels is required to collect and convey runoff from the surface of the reclaimed WRF to the pit lake during the closure period. In addition, seepage from the WRF will be collected and piped to the bottom of the pit lake.

[[%~%]]
### 20.3.4 Roads And Airstrip

Under both Donlin's corporate standards and regulatory standards, the mine site roads will need to be reclaimed. However, the Jungjuk port to mine access road and on-site access roads required for use by monitoring personnel will remain into the foreseeable future after mine closure is initiated. The airstrip will also remain as a long-term asset and is therefore not proposed to be reclaimed and is not included in the reclamation cost estimate.

[[%~%]]
### 20.3.5 Foundations And Buildings

With the exception of the post-closure WTP, buildings must be removed from their foundations and the debris buried on site or transported elsewhere, per regulatory requirements. Once the buildings are demolished, the foundations will either be broken up and removed or broken up and buried to prevent them from being an impermeable impediment to natural percolation of meteoric waters. A minimum thickness of cover will be established over the buried debris to ensure that it remains below surface into the foreseeable future.

[[%~%]]
### 20.3.6 Waste Disposal

Non-hazardous construction debris will be placed in the pits or used to fill subsurface voids exposed during the demolition of facilities.

[[%~%]]
### 20.3.7 Port Facilities, Access Road, Airstrip, And Personnel Camp

The Jungjuk port facilities will be reclaimed, leaving only a small barge landing area and the access road to the mine site. All mine support facilities except the airstrip and a small camp to support post-closure activities will be removed and reclaimed.

[[%~%]]
### 20.3.8 Mobile Equipment

Logistical constraints (access road and barge) preclude the decommissioning and removal of the mobile equipment fleet from the site for the purposes of this update. Therefore, this equipmentwill be buried in the WRF at closure. Prior to burial of the equipment, all fluids will be removed and properly disposed.

[[%~%]]
### 20.3.9 Trust Fund And Financial Assurance

The Report assumes that Donlin Gold LLC will establish a Trust Fund to fund closure and postclosure obligations as allowed by State statutes. That fund must be sufficient to generate sufficient cash flow to cover all reclamation, closure, and post- closure costs, including (but not limited to) construction and maintenance of the spillway from the TSF, employee severance payments, capital to construct the post-closure WTP and operating costs for perpetual water treatment, and associated facility and access maintenance.

A model was developed for the Trust Fund calculation. The funding amount is estimated at $\$ 7.8$ million provided annually over the construction and operating period, for a total of $\$ 412$ million accrued to the trust fund at the start of closure. The following assumptions were made in determining this annual funding requirement:

- Income of 5\% per annum is estimated to be earned on the cumulative trust fund.
- All operating expenditures for monitoring, water treatment, etc., and all capital expenditures are adjusted for estimated annual inflation of $2 \%$.
- The post-closure WTP will operate about six months of the year.
- Annual costs are estimated for approximately 220 years after closure of the mine.

In addition to the trust fund, financial assurance in the form of letters of credit and/or surety bonds will be required to construct and operate the mine. Per the Donlin Gold Project Reclamation Plan Approval from ADNR, financial assurance in the amount of approximately $\$ 322$ million must be submitted in a form and substance approved by ADNR. The cost to maintain this financial assurance is assumed to be $0.40 \%$ of the total assured amount, annually. This equates to approximately $\$ 1.3$ million per year, paid from the start of construction through the end of operations.

[[%~%]]
### 20.3.10 Closure Cost Estimate

The final reclamation cost estimate for this update is as shown in Table 20-3. An independent cost estimate was developed, which was within one percent of the ADNR approved reclamation and closure cost estimate.

The additional cost of closure / abandonment of the natural gas pipeline is estimated at $\$ 9.6$ million.Table 20-3: Estimated Reclamation Costs

| Item | Total <br> (SM) |
| :-- | --: |
| Reclamation, Closure \& Post-Closure SRCE Estimate | 424.2 |
| Indirect Costs | 290.6 |
| Post-Closure Monitoring | 8.0 |
| Very Long-Term Water Treatment | 638.2 |
| Total | $\mathbf{1 , 3 6 1 . 0}$ |

[[%~%]]
## 20.4 Permitting

The Project requires a considerable number of permits and authorizations from both federal and state agencies. During the permitting process, the agencies have been reviewing the proposed Project, evaluating impacts associated with each facet of the Project, considering alternatives, identifying compliance conditions, and ultimately deciding whether or not to issue the requested permits. Much of the groundwork to support a successful permitting process is done before the permit applications are submitted, so that issues can be identified and resolved, supporting baseline data can be acquired, and regulators and stakeholders can become familiar with the proposed Project.

To support successful application for the considerable number of permits, this Project has collected extensive baseline environmental information, and completed scientific analysis and extensive engineering. The Project has invested significant resources and time in acquiring this information over more than 25 years. Acquisition of this baseline data in parallel with design, and in advance of filing permit applications, has resulted in a Project that is designed to mitigate impacts on the environment where practicable, affording due consideration to all environmental concerns. Most of permits needed for the start of operations have been obtained and are identified in Table 20-4. Table 20-4 also identifies the permits, plans and approvals that are still outstanding.

Throughout the preceding 16 years, Donlin Gold LLC has conducted extensive communication with a wide variety of regulatory agencies, stakeholder representatives, and recognized technical experts to ensure that all required information is collected appropriately. Agency update meetings and regulatory reviews of reports and documents ensure that the baseline data has met the permitting process requirements, while giving regulators the opportunity to become familiar with the Project. This open communication has assisted in evaluating andaddressing concerns and in minimizing potential changes during the permitting and NEPA processes.

The comprehensive permitting process for the Project can be divided into three phases, all of which are important to the successful establishment of a future mining operation:

- Exploration stage permitting - required to obtain approval for exploration drilling, environmental baseline studies, and feasibility level studies
- Pre-application phase - conducted in parallel with feasibility studies; includes the collection of environmental baseline data and consultation with stakeholders and regulators
- The National Environmental Policy Act (NEPA) process and formal permit applications formal agency review and analysis of the Project, resulting in the issue or denial of permits.

To date, Donlin Gold LLC has completed nearly all of these stages and is in the process of completing remaining State permitting. As of January 2021, permit requirements are being addressed as required. The JROD lists a number of mitigation measures that are required as part of the federal land management approval, most of which have not been completed as of January 2021. Some of these are required prior to the start of operations, some during operation, and other at closure.Table 20-4: Status of Federal, State and Local Permits

| Agency | Application Type | Facility or Activity | Application Number / <br> Submittal Date | Approval Date | Status |
| :--: | :--: | :--: | :--: | :--: | :--: |
| ADEC | Integrated Waste <br> Management Permit | Waste Management Permit for TSF, WRF, inert landfills, and overburden stockpiles | 2017DB0001 / <br> 9/16/2015 | 1/18/2019; <br> Reissued <br> 6/25/2019 | Approved with Modifications <br> Expires 1/17/2024 |
| ADEC | Alaska Pollutant Discharge Elimination System (APDES) | Treated Water Discharge from Mine Dewatering Activities and Water Management | AK0055867 / <br> $4 / 4 / 2017$ | $5 / 24 / 2018$ | Approved, <br> Expires 6/20/2023 |
| ADEC | Air Quality Control Construction Permit Application | Air Emissions from Mine Operations | AQ0934CPT01 / <br> 0/15/2015 | 6/30/2017, <br> Extension <br> Granted <br> 5/18/2020 | Approved, Permit has indefinite term as long as construction begins within a fixed timeframe for the permit to remain in place. |
| ADEC | 401 Certification | Donlin Gold Mine | POA-1995-120 / <br> July 2012, Revised in <br> December 2014, <br> August 2015, <br> December 2017 | Issued <br> 4/4/2019; <br> Reissued <br> 8/10/2019 | Approved, <br> Expires 8/31/2038 |
| ADEC | Septic System | - | - | - | - |
| ADEC | Multisector Stormwater General Permit | - | - | - | - |
| ADF\&G | Fish Habitat Permit <br> Application | American Creek Area <br> Facilities | FH18-III-0191 / <br> 12/29/2017 | 08/30/2018 | Approved, <br> Expires upon removal of Dam || Agency | Application Type | Facility or Activity | Application Number / <br> Submittal Date | Approval Date | Status |
| :--: | :--: | :--: | :--: | :--: | :--: |
| ADF\&G | Fish Habitat Permit Application | Anaconda Creek Area Facilities | FH18-III-0190 / <br> $12 / 29 / 2017$ | 08/30/2018 | Approved, <br> Expires upon Mine Closure and Rehabilitation of the Site |
| ADF\&G | Fish Habitat Permit Application | Snow Gulch Area Facilities | FH18-III-0189 / <br> $12 / 29 / 2017$ | 08/30/2018 | Approved, <br> Expires upon removal of Dam |
| ADF\&G | Fish Habitat Permit Application | Ruby Creek / Queen Gulch Area Aquatic Mitigation | FH18-III-0192 / <br> $12 / 29 / 2017$ | 08/30/2018 | Approved, <br> Expires upon Closure |
| ADF\&G | Fish Habitat Permit <br> Application | Alaska Pollution Discharge <br> Elimination System <br> Discharge Point <br> Construction (Crooked <br> Creek) | FH18-III-0188 / <br> $12 / 29 / 2017$ | 08/30/2018 | Approved, <br> Expires upon removal |
| ADF\&G | Fish Habitat Permit <br> Application | Crooked Creek Bridge <br> Construction | FH18-III-0187 / <br> $10 / 8 / 2015$ | 08/30/2018 | Approved, <br> Expires upon removal of bridge and rehabilitation of the stream crossing |
| ADF\&G | Fish Habitat Permit Application | Getmuna North Fork Bridge Construction | FH18-III-0186 / <br> $10 / 8 / 2015$ | 08/30/2018 | Approved, <br> Expires upon removal of bridge and rehabilitation of the stream crossing || Agency | Application Type | Facility or Activity | Application Number / <br> Submittal Date | Approval Date | Status |
| :--: | :--: | :--: | :--: | :--: | :--: |
| ADF\&G | Fish Habitat Permit Application | Getmuna South Fork Bridge Construction | FH18-III-0185 / <br> $10 / 8 / 2015$ | 08/30/2018 | Approved, <br> Expires upon removal of bridge and rehabilitation of the stream crossing |
| ADF\&G | Fish Habitat Permit <br> Application | Unnamed Getmuna South <br> Tributary Bridge <br> Construction | FH18-III-0184 / <br> $10 / 8 / 2015$ | 08/30/2018 | Approved, <br> Expires upon removal of bridge and rehabilitation of the stream crossing |
| ADF\&G | Fish Habitat Permit <br> Application | Fish Habitat Permit - Lower Jungjuk Creek Bridge Construction | FH18-III-0182 / <br> $10 / 8 / 2015$ | 08/30/2018 | Approved, <br> Expires upon removal of bridge and rehabilitation of the stream crossing |
| ADF\&G | Fish Habitat Permit <br> Application | Fish Habitat Permit - Upper Jungjuk Creek Bridge Construction | FH18-III-0183 / <br> $10 / 8 / 2015$ | 08/30/2018 | Approved, <br> Expires upon removal of bridge and rehabilitation of the stream crossing |
| ADF\&G | Fish Habitat Permit <br> Application | Jungjuk (Anyaruaq) Port <br> Wharf Construction | FH18-III-0181 / <br> $10 / 8 / 2015$ | 08/30/2018 | Approved |
| ADF\&G | Title 16 Permits | Pipeline | - | - | Not completed |
| ADF\&G | Special Use Permits | Pipeline Infrastructure in Susitna Flats Game Refuge (SFGR) | 2016 (initial Submittals) | - | In Process: Preparing Revised Applications |
| ADNR | Certificate of Approval to Construct a Dam | 7 dams within the Mine Area | $4 / 12 / 2013$ | - | In Process, initial applications submitted || Agency | Application Type | Facility or Activity | Application Number / <br> Submittal Date | Approval Date | Status |
| :--: | :--: | :--: | :--: | :--: | :--: |
| ADNR | Water Rights Application | TSF Interceptor and <br> Seepage Collection Wells | LAS 29175 / <br> $5 / 16 / 2013$ | - | In Process, water rights were released for public comment on 11/20/2020 |
| ADNR | Water Rights Application | Upper CWD | LAS 29168 / <br> $5 / 16 / 2013$ | - | In Process, water rights were released for public comment on 11/20/2020 |
| ADNR | Water Rights Application | Snow Gulch FWD | LAS 29169 / <br> $5 / 16 / 2013$ | - | In Process, water rights were released for public comment on 11/20/2020 |
| ADNR | Water Rights Application | Lower CWD | LAS 29170 / <br> $5 / 16 / 2013$ | - | In Process, water rights were released for public comment on 11/20/2020 |
| ADNR | Water Rights Application | Jungjuk (Anyaruaq) Port Site <br> Surface Water-Kuskokwim <br> River | LAS 29171 / <br> $5 / 16 / 2013$ | - | In Process, water rights were released for public comment on 11/20/2020 |
| ADNR | Water Rights Application | Construction Camp/Shop, Office, Warehouse, \& Process | LAS 29172 / <br> $5 / 16 / 2013$ | - | In Process, water rights were released for public comment on 11/20/2020 |
| ADNR | Water Rights Application | Pit Perimeter \& In-Pit <br> Dewatering Wells \& Drains | LAS 29173 / <br> $5 / 16 / 2013$ | - | In Process, water rights were released for public comment on 11/20/2020 |
| ADNR | Water Rights Application | Getmuna Creek Surface Water | LAS 29174 / <br> $5 / 16 / 2013$ | - | In Process, water rights were released for public comment on 11/20/2020 || Agency | Application Type | Facility or Activity | Application Number / <br> Submittal Date | Approval Date | Status |
| :--: | :--: | :--: | :--: | :--: | :--: |
| ADNR | Water Rights Application | Jungjuk (Anyaruaq) Port Site Well | LAS 29176 / <br> $5 / 16 / 2013$ | - | In Process, water rights were released for public comment on 11/20/2020 |
| ADNR | Water Rights Application | TSF | LAS 29177 / <br> $5 / 16 / 2013$ | - | In Process, water rights were released for public comment on 11/20/2020 |
| ADNR | Water Rights Application | Permanent Camp Potable Water Well Field | LAS 29178 / <br> $5 / 16 / 2013$ | - | In Process, water rights were released for public comment on 11/20/2020 |
| ADNR | Water Rights Application | Crooked Creek Surface Flows and Associated Diversion Structures | LAS 31477 / <br> $9 / 23 / 2016$ |  | In Process, water rights were released for public comment on 11/20/2020 |
| ADNR | Application for Pipeline <br> Right-of-Way Lease | Natural Gas Pipeline ROW (State of Alaska Lands) | ADL 231908 / <br> $4 / 9 / 2014$ | Issued Offer to Lease <br> 1/17/20, <br> Donlin <br> accepted <br> 2/20; <br> however, <br> placed on hold <br> following <br> additional <br> comment <br> period. | In Process |
| ADNR | Application for Easement | Fiber Optic ROW (State of Alaska Lands) | ADL 232368 / <br> $11 / 16 / 2015$ | $1 / 02 / 20$ | Approved, expires 1/02/50 || Agency | Application Type | Facility or Activity | Application Number / <br> Submittal Date | Approval Date | Status |
| :--: | :--: | :--: | :--: | :--: | :--: |
| ADNR | Application for Lease or Purchase of State Land | Airstrip Land Lease (on State Land) | ADL 232199 / <br> $10 / 9 / 2015$ | $1 / 02 / 20$ | Approved, expires 1/02/50 |
| ADNR | Application for Lease or Purchase of State Land | Land Lease for Submerged State of Alaska Lands at Jungjuk (Anyaruaq) | ADL 232200 / <br> $10 / 9 / 2015$ | $1 / 02 / 20-$ | Approved, expires 1/02/50 |
| ADNR | Land Use Permit <br> Application | Temporary Access Road to Donlin-Jungjuk Road Material Site-8 | ADL 232361 / <br> $5 / 19 / 2016$ | $1 / 02 / 20$ | Approved |
| ADNR | Land Use Permit <br> Application | Temporary Access Road to Donlin-Jungjuk Road Material Site-16 | ADL 232366 / <br> $5 / 19 / 2016$ | $1 / 02 / 20$ | Approved |
| ADNR | Application for Easement | Donlin-Jungjuk Road (State <br> Land Portions) | ADL 232346 / <br> $10 / 9 / 2015$ | $1 / 02 / 20$ | Approved, expires 1/02/50 |
| ADNR | Material Sites and <br> Reclamation Plan | Donlin-Jungjuk Road <br> Material Site-04 | ADL 232334 / <br> $10 / 9 / 2015$ | $1 / 02 / 20$ | Approved, expires 1/02/50 |
| ADNR | Material Sites and Reclamation Plan | Donlin-Jungjuk Road <br> Material Site-08 | ADL 232335 / <br> $10 / 9 / 2015$ | $1 / 02 / 20$ | Approved, expires 1/02/50 |
| ADNR | Material Sites and Reclamation Plan | Donlin-Jungjuk Road Material Site-09 | ADL 232336 / <br> $10 / 9 / 2015$ | $1 / 02 / 20$ | Approved, expires 1/02/50 |
| ADNR | Material Sites and Reclamation Plan | Donlin-Jungjuk Road Material Site-10 | ADL 232337 / <br> $10 / 9 / 2015$ | $1 / 02 / 20$ | Approved, expires 1/02/50 |
| ADNR | Material Sites and Reclamation Plan | Donlin-Jungjuk Road Material Site-12 | ADL 232338 / <br> $10 / 9 / 2015$ | $1 / 02 / 20$ | Approved, expires 1/02/50 |
| ADNR | Material Sites and Reclamation Plan | Donlin-Jungjuk Road Material Site-13 | ADL 232339 / <br> $10 / 9 / 2015$ | $1 / 02 / 20$ | Approved, expires 1/02/50 || Agency | Application Type | Facility or Activity | Application Number / <br> Submittal Date | Approval Date | Status |
| :--: | :--: | :--: | :--: | :--: | :--: |
| ADNR | Material Sites and <br> Reclamation Plan | Donlin-Jungjuk Road <br> Material Site-16 | ADL 232340 / <br> 10/9/2015 | 1/02/20 | Approved, expires 1/02/50 |
| ADNR | Reclamation and Closure <br> Plan Approval | Donlin Gold Project | A20196226 | 1/18/2019; <br> re-affirmed <br> 06/25/2019 | Approved, expires 1/17/2024 |
| ADNR | Reclamation Plan Approval | Donlin-Jungjuk Road <br> Material Site-01 | LAS 30533 / <br> 10/9/2015 | 1/18/2019 <br> Re-affirmed <br> 06/25/2019 | Approved |
| ADNR | Reclamation Plan Approval | Donlin-Jungjuk Road <br> Material Site-02 | LAS 30534 / <br> 10/9/2015 | 1/18/2019 <br> Re-affirmed <br> 06/25/2019 | Approved |
| ADNR | Reclamation Plan Approval | Donlin-Jungjuk Road <br> Material Site-03 | LAS 30535 / <br> 10/9/2015 | 1/18/2019 <br> Re-affirmed <br> 06/25/2019 | Approved |
| ADNR | Reclamation Plan Approval | Donlin-Jungjuk Road <br> Material Site-05 | LAS 30536 / <br> 10/9/2015 | 1/18/2019 <br> Re-affirmed <br> 06/25/2019 | Approved |
| ADNR | Reclamation Plan Approval | Donlin-Jungjuk Road <br> Material Site-06 | LAS 30537 / <br> 10/9/2015 | 1/18/2019 <br> Re-affirmed <br> 06/25/2019 | Approved |
| ADNR | Reclamation Plan Approval | Donlin-Jungjuk Road <br> Material Site-07 | LAS 30538 / <br> 10/9/2015 | 1/18/2019 <br> Re-affirmed <br> 06/25/2019 | Approved |
| ADNR | Public Easement Re- <br> location | Donlin Mine. Involves re- <br> location existing public | Draft Application <br> Summer 2020 | - | In Process || Agency | Application Type | Facility or Activity | Application Number / <br> Submittal Date | Approval Date | Status |
| :--: | :--: | :--: | :--: | :--: | :--: |
|  |  | ROWs to account for the need to restrict public access in certain areas. |  |  |  |
| BLM | Application for Transportation and Utility Systems and Facilities on Federal Lands | Natural Gas Pipeline ROW (Bureau of Land Management Lands) | AA-92403 / <br> $3 / 11 / 2010$ | 8/13/2018 | Approved, No Expiration Date. |
| BLM | Application for Transportation and Utility Systems and Facilities on Federal Lands | Fiber Optic ROW (Bureau of Land Management Lands) | AA-93815 / <br> $1 / 8 / 2014$ | - | Paused |
| BLM | ANCSA 17(b) Easement Modification | Mine and Transportation Area | - | - | In Process |
| DOT | Special Permit | Natural Gas Pipeline Special Permit Strain-based Design | PHMSA-2016-0149 / <br> $11 / 11 / 2016$ | 6/5/20018 | Approved, <br> No Expiration Date |
|  |  | Final Waste Management Permit | - | - | - |
| Federal Aviation Administration | Landing Area | - | - | - | - |
| USACE | Individual 404 | Mine Site, Transportation, and Pipeline Facilities | - | - | Approved, <br> Expires 8/31/2038 |
| Cook Inlet Region, Inc | Pipeline Authorization on Cook Inlet Region, Inc. (CIRI) Lands | Construction Easement for Pipeline | 2020 | - | In Process |# NOVAGOLD 

N| 43-101 Technical Report on the DonLIN GOLD PROJect
Alaska, USA

| Agency | Application Type | Facility or Activity | Application Number / <br> Submittal Date | Approval Date | Status |
| :-- | :-- | :-- | :-- | :-- | :-- |
| Matanuska- <br> Susitna Borough | Matanuska-Susitna Borough <br> Land Authorizations | Land Use Authorization for <br> the Pipeline | Ongoing | - | In Process |

Source: DOA 2018; Rimelman 2020

[[%~%]]
### 20.4.1 Exploration Stage Permitting

From the start of exploration activities in 1995 through advanced exploration and feasibility engineering, numerous permits or authorizations have been issued by federal agencies, state agencies, and Native Corporations to support ongoing operations. These include:

- Approximately 34 permits issued or modified by USACE
- 3 permits / authorizations issued or reviewed by the Environmental Protection Agency (EPA)
- 6 land use or right-of-way permits from the BLM
- 4 airstrip authorizations from the Federal Aviation Administration (FAA)
- 22 mineral exploration or temporary water use permits issued or modified by the ADNR
- 8 permits certified, issued, or modified by the ADEC
- 8 Fish Habitat (Title 16) Stream Crossing Permits issued or modified by the Alaska Department of Fish and Game (ADF\&G)
- Multiple Land Entry Agreements with Calista
- Multiple Land Entry Permits with TKC.


[[%~%]]
### 20.4.2 Pre-Application Phase

The Project has conducted a comprehensive stakeholder interaction and consultation process. This process was an important component of the pre-permit application phase of the Project and has been crucial to successful completion of the permitting and NEPA processes.

An equally important component of this phase has been ongoing interaction with permitting agencies and individual regulators who have been responsible for reviewing the Project's permit applications. This process began in 1995 when Placer Dome Inc., then the Project operator, first met with State of Alaska regulators and industry personnel to develop an understanding of the regulatory process in the state.

The concept of the state's Large Mine Permitting Team (LMPT) was developed in the process of permitting the Fort Knox gold mine near Fairbanks, and this model has been used successfully in the permitting of all major mining projects in the state since that time. Under this concept a company with a major project can enter into a reimbursable services agreement (RSA) with ADNR (and separately with ADEC) to compensate the state for expenses incurred in permitting and consultation activities related to the project. ADNR is responsible for administering the RSA, and the LMPT coordinator assigned to the project is responsible for coordinating all State regulatory input and for coordinating with federal regulatory personnel. This process isspecifically structured to be implemented early in the Project life so that agencies can provide input into Project design and baseline data collection ahead of the permitting and NEPA process.

The LMPT coordinator works with the company to organize inter-agency Project update meetings and identify required expertise in regulatory agencies. The coordinator also works with stakeholders to provide mining education and to address questions about the State regulatory process. Formal Project consultation with the LMPT began in 2003, and the first RSA was implemented in 2004. Since that time, State regulators have been continuously involved in reviewing Project data collection, participating in Project update meetings, providing input to Project design decisions, participating in stakeholder meetings related to the Project throughout the Kuskokwim region, and providing interagency coordination of State permitting activities.

In addition to the LMPT interaction, Project personnel have regularly consulted with federal agency personnel, principally with the EPA, USACE, U.S. Fish and Wildlife Service (USFWS), and BLM. Meetings have also been held with the National Marine Fisheries Service, (NMFS) and the U.S. Coast Guard (USCG).

[[%~%]]
### 20.4.3 The Nepa Process And Permit Applications

In July 2012, Donlin Gold LLC submitted an application to the USACE for a permit pursuant to Section 10 of the Rivers and Harbors Act of 1899 and Section 404 of the Clean Water Act. Permits issued by federal agencies constitute "federal actions." Any major federal action requires review under NEPA, once Donlin Gold LLC initiated the permitting process the USACE issued a Notice of Intent to prepare an EIS. As such, all elements of the Project and their cumulative impacts are considered and evaluated in the NEPA review. In addition, alternatives to the proposed action are evaluated and mitigation measures are identified. The federal agency with the predominant federal permit is designated the lead for the NEPA process; for the Project the lead agency was the USACE; however, the Record of Decision (ROD) was issued as a joint effort between the USACE and the BLM. The Notice of Availability for the Final EIS was published in the Federal Register on 27 April 2018 and a JROD was made 13 August 2018.

The JROD supports issuance of the permit for the North Route Pipeline Option referred to as Alternative 2 in the EIS. The EIS and JROD describe the conditions of the decision to issue the permit and explain the basis for the decision. Each federal and State permit will have compliance stipulations or mitigation requirements requiring review and possibly negotiation by the applicant and appropriate agency. A list of some of the mitigation requirements identifiedthrough the NEPA process are identified in Table 20-2. The full list of mitigation requirements is found in the JROD and with associated State permits.

[[%~%]]
### 20.4.4 Laws, Regulations, And Permit Requirements

Table 20-4 lists the federal and State permits and authorizations that Donlin Gold LLC has obtained for the Project and their status.

[[%~%]]
## 20.5 Considerations Of Social And Community Impacts

Donlin Gold LLC is committed to corporate social responsibility, strong collaboration with communities, and leaving a positive, sustainable legacy in the Yukon-Kuskokwim ( $\mathrm{Y}-\mathrm{K}$ ) region. This requires a well-founded understanding of the social and economic relationships between the mine and the surrounding communities. Donlin Gold LLC is focusing on sustainable development to benefit local communities over the long term by providing opportunities for direct employment, local procurement, and community development projects. Associated with these examples are efforts to develop lasting capacities that will continue after mine closure. The following principles, which underpin Donlin Gold LLC's approach to community engagement activities, have been actively applied since early exploration and will continue throughout the life cycle of the mine:

- Engage with communities in a respectful and culturally sensitive manner
- Develop long-term mutually beneficial relationships.
- Be responsive to stakeholders' concerns and questions
- Build trust and confidence through accountability and transparency
- Understand the complex interests among diverse communities
- Adapt Project activities to fit with local needs and contexts
- Plan activities with closure in mind
- Monitor results and impacts
- Donlin Gold LLC and the Native Corporation partners held more than 200 engagement meetings in 2019 with individual stakeholders and community organizations.
- Donlin Gold LLC provided community support during the Covid-19 pandemic. This included food and supplies. They also participate in ongoing community engagement in environmental management, safety, training, education, health, and cultural initiatives.- Donlin Gold LLC continues to foster a relationship with the Y-K region communities and include local communities in all aspects of the Project. Over the years, many direct hires for field programs, as well as full-time employees, have been Alaska Native.

Donlin Gold LLC has a community relations team dedicated to understanding the concerns and issues facing the local communities. The Project's approach is to build trust and mutually beneficial relationships to help guide the development of mitigation plans and to manage risks responsibly. This engagement ensures that the potential impact of mining is adequately addressed while fostering community empowerment and self- sufficiency. Since the completion of the EIS and issuance of the JROD, mitigation measures related to stakeholders have been defined. Donlin Gold LLC will continue to engage the stakeholders throughout the development of the mine, during operations, and through closure and post-closure.

Donlin Gold LLC has clearly defined responsibilities and commitments that outline policies, standards, and management systems. Donlin Gold LLC's stakeholder groups vary at the local, regional, and national level. Stakeholder mapping has been undertaken to identify stakeholders at each level and what the key issues are for each group. Stakeholder mapping continues to form the foundation for Donlin Gold LLC's community engagement programs.

Stakeholder identification and issues mapping will continue throughout the remainder of the permitting, construction, operation, closure and post-closure phases of the Project, and results will be updated annually. Cultural awareness is one of the many keys to identifying all relevant stakeholders, including possible vulnerable and minority groups.

Donlin Gold LLC adheres to the principles in the International Council on Mining \& Metals Position Statement on Mining and Indigenous Peoples (ICMM). The statement promotes constructive relationships between the mining and metals industry and indigenous peoples based on respect, meaningful engagement, and mutual benefit. Donlin Gold LLC recognizes and respects that Alaska Native groups have strong attachments to their traditional lands and livelihoods. Donlin Gold LLC's engagement with these communities is based on honest, open dialogue and providing information in a fair, timely manner that is culturally appropriate.

Donlin Gold LLC promotes economic self-reliance among these Native communities through employment opportunities, business enterprise support, economic diversification, and where possible, preferential contract consideration for Native owned suppliers. As the Project progresses, Donlin Gold LLC will continue to focus on developing programs that benefit local communities, including improved infrastructure, support for education and health services, cultural heritage preservation, employment and business opportunities, increased income flows through royalty streams and compensation payments, and environmental restoration and protection.The NEPA process, including the EIS assessed the social and environmental impacts of the proposed Project. As part of that process, a Social Baseline Report was completed providing information to support assessment of social impacts in the completed EIS. A comprehensive social impacts assessment includes a solid baseline; stakeholder and community engagement; analysis of direct, indirect, and cumulative impacts; and development of mitigation and monitoring plans. In addition, as the Project moves forward, Donlin Gold LLC plans to produce a Community Engagement and Sustainable Development Plan that will comprehensively address all aspects of stakeholder participation in the Project, from the remaining permitting and construction through operations to post-closure.

[[%~%]]
### 20.5.1 Stakeholders

The region has a complex political and social structure, represented by a diverse group of social, business, and governmental entities. Relationships between these various entities are often complex and are influenced by competing political and economic interests.

Entities within the region can be split into two primary categories: non-profit organizations (tribal / cultural / social) and for-profit corporations. Tribal organizations played an important role in the NEPA process, as the NEPA process included government-to-government consultation requirement for the federal agency leading the permitting. Calista and TKC, the two primary Native business entities of the region, each have a financial interest in the Project. A variety of other Native business entities and associations are also interested in the Project and its potential impact on the region.

With the addition of the natural gas pipeline, the area of influence increased outside of the region and with it, a wider group of stakeholders. A Project-wide stakeholder database is maintained to help manage Project communications and continue consultation efforts.

## Calista Corporation

Calista is one of the 13 regional Alaska Native corporations established as part of the Alaska Native Claims Settlement Act (ANCSA) of 1971. As part of this settlement, Native residents of much of southwest Alaska became shareholders of Calista, a "for- profit" corporation that was given title to large areas of subsurface estate in the region. Calista has over 33,000 shareholders. The Project is located on Calista mineral lands, and the Project operates under a mining lease with the Calista. Calista is a partner in the Project, having contractual rights and obligations related to Project development.# The Kuskokwim Corporation 

While ANCSA established the regional corporations, it established local "village" corporations to take title to the surface estate of lands granted to the regional corporations at the same time. TKC is a "for-profit" corporation formed from the amalgamation of the 10 village corporations on the middle Kuskokwim River region between Lower Kalskag and Sleetmute, plus the village of Stony River. The Project operates under a SUA with TKC. Authorization for use of TKC lands includes provisions that ensure the protection of subsistence activities.

## Village Corporations

Individual "for-profit" village corporations exist for each village not included in TKC consortium and were formed to serve the same function as TKC does for the villages closest to the Project. Many of these entities are interested in pursuing a business relationship with the Project.

## Local Government and Non-profit Native Business Entities and Associations

The following non-profit entities also represent region stakeholders:

- Kuskokwim Native Association (KNA) - A non-profit association formed to provide social and other services to the villages of the TKC region. KNA represents the interests of people in the immediate area surrounding the Project.
- Association of Village Council Presidents (AVCP) - A non-profit association formed to provide social and other services to residents of the Calista region.
- Village Tribal Councils - Each village within the region has a tribal council, sometimes referred to as a traditional council, to represent tribal interests and provide services to residents of the village. There are 56 villages in the Calista region, many along the Yukon River.
- Crooked Creek Tribal Council - The village of Crooked Creek is closest to the Project and has a long history of involvement in project activities. Many of the Project's earliest and longest-term employees are residents of Crooked Creek. As representatives of the closest village, the Crooked Creek Tribal Council was an important participant in the NEPA process.
- City councils - Larger towns within the region, such as Bethel and Aniak, have a formally established government and an elected council that is separate from the tribal or "traditional" councils.- Various boards and councils - These include entities such as subsistence advisory boards, watershed councils, and similar organizations, many of which receive government funding to promote their activities, and which participated during the permitting process.

To successfully acquire the support and "social license" required to develop and operate this Project, a process of ongoing engagement and consultation will be continued with all of these entities throughout the remaining permitting process, construction, operation, closure and post-closure of the Project.

[[%~%]]
### 20.5.2 Community Development And Sustainability

Donlin Gold LLC has defined three major components to its sustainable community development process.

## Local Workforce Development and Training

A workforce training and development plan will be produced for the Project in advance of any construction or operating deadlines to allow enough time to implement the required training programs. The Operational Readiness Plan describes the mechanics of this process.

In addition to providing the required training, Donlin Gold LLC will need to implement a work schedule and environment that recognizes the unique nature of the Alaskan Native culture in the region. Issues that will need to be addressed, not all of which are unique to this region, include:

- The importance of subsistence harvesting activities
- Cross-cultural training for all employees and supervisors
- The importance of family relationships and participation in family events
- The historically seasonal nature of employment in the region
- Support for employees with family and dependency issues.

The success of the local hire program initiated during the exploration phase clearly demonstrates that development of a skilled local workforce is an achievable goal. Some of the Project employees have been working on the exploration program for many years and may be available to form the nucleus of future workforce development and training efforts.# Local Procurement 

The Calista agreement grants a contracting preference to Calista with respect to procurement of services provided for the Project, subject to suitable qualifications. The success of various service providers throughout the exploration phase clearly demonstrates the Project's commitment to this process. In addition, Donlin Gold LLC's policies clearly address the need to offer business and procurement opportunities for other entities and individuals within the region. Such opportunities have produced some of the most visible and direct benefits to local communities.

## Community Development Activities

The Project has had ongoing discussions with village leaders in Crooked Creek to identify, and complete potential community development projects that have benefitted the village, its residents, and future employees. Numerous other community development projects have been planned and undertaken in villages throughout the Y-K region in areas such as infrastructure development, housing, health, and education.

[[%~%]]
## 20.6 Comments On Section 20

In the opinion of the QP, the following conclusions are appropriate:

- There has been a focused effort for more than 25 years to collect comprehensive environmental baseline data which has led to the successful completion of the NEPA process with the publishing of the JROD. In addition, successful state permitting is almost complete, supporting the development of a large-scale mining operation at the Project.
- Development and operation of the Project will require a considerable number of permits and authorizations from both Federal and State agencies, most of which have been obtained.
- With completion of the NEPA process, a JROD has been issued that approves the preferred alternative for the Project, describes the conditions of the approval, and explains the basis for the decision.
- The State permitting process typically is not finalized until the NEPA process is completed. Most of the State permitting for the project is complete. Each remaining State permit will have compliance stipulations requiring review and possibly negotiation by the applicant and appropriate agency.
- Upon final issuance of permits and authorizations, the Environmental Management System (EMS) for the Project will be fully implemented.- The comprehensive permitting process will determine the exact number of management plans required to address all aspects of the Project to ensure compliance with environmental design and permit criteria.
- A Prevention of Significant Deterioration (PSD) air quality permit to construct has been obtained to allow construction and initial operation of the mine, process, and power plant facilities. Due to the proposed plans to site a large power generation facility adjacent to the mine and process facilities, estimated emissions are significant enough to trigger permitting under the PSD program. PSD requires modelling of potential air quality impacts and demonstrating that the applicant has necessary control of the land tenure to prevent public access to the area where air quality impacts occur. The permit requires construction to begin within a specific timeframe. Several extensions to the start of construction have been granted by the ADEC, with the current start of construction required before 31 December 2021. Donlin Gold LLC is collecting updated additional meteorological data that will support the anticipated need for another extension.
- The prevention of unregulated discharge of water that does not meet water quality standards is a primary criterion for overall Project design. The current ADPES permit identifies water quality standards and how they are met and regulated. Additionally, this risk will be managed by continuing to optimize the use of process and contact water during operations and ensuring that the capacity of the WTP is sufficiently flexible to handle excess water during increased precipitation scenarios.
- The Standardized Reclamation Cost Estimator (SRCE) was used to develop reclamation and closure cost estimates. The final reclamation cost estimate is $\$ 1,361$ million of which $\$ 693$ million is allocated for long-term water treatment costs. This amount is included in a Trust Fund for Reclamation, Closure costs and Post-Closure Obligations model prepared to determine the funding required to generate sufficient cash flow to cover the following costs: spillway construction from the TSF to Crevice Creek; capital to construct the closure WTP; perpetual water treatment; long-term monitoring; and associated facility and access maintenance.
- Donlin Gold LLC is focusing on sustainable development to benefit local communities over the long term by providing opportunities for direct employment, local procurement, and community development projects.

[[@~@]]
# 21.0 Capital And Operating Costs

[[%~%]]
## 21.1 Capital Cost Estimates

The capital cost estimate is based on updated, first quarter 2020 pricing applied to the engineering designs and material take-offs from the 2011 feasibility study. With the exception of the following two design changes, no changes to engineering or material take offs (MTOs) were made:

- The operations WTP was changed from a High Density Sludge (HDS) plant to a Reverse Osmosis (RO) plant.
- The natural gas pipeline was updated for an increase in pipe diameter from 12" to 14" and for modifications made to the route (i.e., the North Route Alignment) between mile post (MP) 85 and 112.

Wood QPs were responsible for updating the initial and sustaining capital estimates for all areas except the autoclave, autoclave support facilities, and oxygen plant (Hatch Ltd.) and the indirect costs associated with those areas. Closure and reclamation costs were prepared by SRK Consulting and checked by Wood's QPs. Warehouse inventory is excluded from the capital cost estimate but is included in Donlin Gold LLC's financial model.

Following the updates, the total initial capital cost estimate is $\$ 7,402$ million, increasing by $\$ 723$ million, a $10.8 \%$ increase, compared to the 2011 initial capital estimate. Figure 21-1 shows the step changes by Major Area for the 2020 capital cost update.

Likewise, the total sustaining capital estimate is $\$ 1,723$ million, increasing by $\$ 219$ million, a $14.6 \%$ increase, compared to the 2011 sustaining capital estimate. Figure 21-2 shows the step changes by Major Area for the 2020 update.Figure 21-1: 2011 to 2020 Initial Capital Cost Changes by Major Area
![img-52.jpeg](img-52.jpeg)

Figure 21-2: 2011 to 2020 Sustaining Capital Cost Changes by Major Area
![img-53.jpeg](img-53.jpeg)

[[%~%]]
### 21.1.1 Basis Of Estimate

Cost indexes published in InfoMine's Cost Indexes and Metal Prices - July 2020 report (InfoMine, 2020), were used to first bring the capital cost estimate current to March 2020. Following this initial update where all capital items were escalated by $14.25 \%$, the estimate was refined for current commodity pricing and equipment quotes. The commodities updated include:

- Construction Labour Rates
- Concrete Supply Unit Cost
- Fabricated Steel Supply Unit Cost.

The construction labour update is based on current data from an Alaskan Mining project in the construction stage. Table 21-1 provides a comparison of the 2011 and 2020 construction labour rates.

Cost of cement and reinforcing steel were updated from previous suppliers. Formwork pricing was updated based on a material price index. Labour details/hours to install have remained unchanged. Table 21-2 provides a comparison of the 2011 and 2020 concrete material supply unit costs.

Table 21-1: Construction Labour Rates

| Description | $\begin{gathered} 2011 \\ (\$ / h) \end{gathered}$ | $\begin{gathered} 2020 \\ (\$ / h) \end{gathered}$ | Variance <br> (\$/h) | Approximate Percentage Change <br> (\%) |
| :--: | :--: | :--: | :--: | :--: |
| Earthworks | 109.00 | 133.60 | 24.60 | 22.60 |
| Concrete | 119.00 | 117.30 | $-1.70$ | $-1.50$ |
| Architectural | 117.00 | 117.40 | 0.40 | 0.03 |
| Structural Steel | 125.00 | 141.40 | 16.40 | 13.10 |
| Mechanical | 124.00 | 146.30 | 22.30 | 17.90 |
| Piping | 124.00 | 140.00 | 16.00 | 12.90 |
| Electrical | 127.00 | 169.20 | 42.20 | 33.20 |
| Instrumentation | 127.00 | 169.20 | 42.20 | 33.20 |
| Insulation and Coatings | 115.00 | 113.90 | $-1.10$ | $-1.00$ |Table 21-2: Concrete Material Supply Unit Cost

| Description | 2011 Cost <br> $\left(\$ / \mathrm{m}^{3}\right)$ | 2020 Cost <br> $\left(\$ / \mathrm{m}^{3}\right)$ | Variance <br> $\mathbf{( \mathbf { S } )}$ | Approximate Percentage Change <br> $\mathbf{( \% )}$ |
| :-- | :--: | :--: | :--: | :--: |
| Slab on Grade - Regular Duty | 390 | 421 | 31 | 7.9 |
| Slab on Grade - Heavy Duty | 415 | 451 | 36 | 8.7 |
| Concrete Foundations - Buildings | 483 | 532 | 49 | 10.1 |
| Piers / Pedestals | 564 | 630 | 66 | 11.7 |
| Concrete Walls 10" (<300 mm tk) | 620 | 700 | 80 | 12.9 |
| Elevated Slab on Steel Deck, 4" thick | 591 | 625 | 34 | 5.8 |
| Reclaim Tunnel Walls, 36" thick | 545 | 607 | 62 | 11.4 |
| Reclaim Elevated Slab, 60" thick | 517 | 576 | 59 | 11.4 |
| Mill Mats | 450 | 493 | 43 | 9.6 |
| Mill Piers | 545 | 607 | 62 | 11.4 |
| Mat Foundations | 450 | 493 | 45 | 10.0 |
| Crusher Elevated Slab | 593 | 659 | 66 | 11.1 |
| Crusher Base Slab | 450 | 473 | 40 | 9.2 |
| Crusher Walls | 547 | 608 | 61 | 11.2 |
| Equipment Foundations | 517 | 576 | 59 | 11.4 |
| Grade Beams | 613 | 693 | 80 | 13.1 |
| Curbs \& Sumps | 598 | 674 | 76 | 12.7 |

The 2020 structural steel supply pricing is based on the most competitive U.S. supplier from 2011 feasibility study with updated pricing from the same supplier for 2020 costs. Table 21-3 provides a comparison of the 2011 and 2020 fabricated steel supply unit costs.

Targeted cost index factors were used within the capital cost estimate to update pricing globally for piping, electrical and instrumentation. The cost indexes are based on Federal Reserve Economic Data (FRED) for cost differences between 2011 and 2020. The indexes are based on first quarter 2020 data to avoid any abnormal consequences or price fluctuations caused from the COVID-19 pandemic.Table 21-3: Fabricated Steel Supply Unit Cost

| Description | Unit | 2011 Cost per Unit | 2020 Cost per Unit | Variance | Approximate <br> Percentage <br> Change <br> (\%) |
| :--: | :--: | :--: | :--: | :--: | :--: |
| Light Structural Steel (0-30 kg/m) | \$/t | 3,496 | 5,317 | 1,821 | 52.1 |
| Medium Structural Steel (31-60 kg/m) | \$/t | 3,056 | 4,041 | 985 | 32.2 |
| Heavy Structural Steel (61-90 kg/m) | \$/t | 2,783 | 3,401 | 618 | 22.2 |
| Steel Floor Grating 32 mm Deep | $\$ / \mathrm{m}^{2}$ | 146 | 117 | 29 | $-19.9$ |
| Steel Handrail with Toe Plate | $\$ / \mathrm{Im}$ | 132 | 173 | 40 | 31.1 |
| Stair c/w 2 Handrails and Kickplate | $\$ / \mathrm{vIm}$ | 746 | 1,344 | 598 | 80.2 |
| Steel Ladder \& Cage | $\$ / \mathrm{m}$ | 250 | 488 | 238 | 95.2 |
| Steel Checker Plate | $\$ / \mathrm{m}^{2}$ | 210 | 348 | 138 | 65.7 |

[[%~%]]
### 21.1.2 Initial Capital Direct Cost Updates

The mining initial capital cost estimate was updated from the 2011 feasibility estimate using the existing mine plan, mine schedule, and equipment fleet. The mining costs were updated using current labour rates, fuel and consumable costs and updated budgetary quotations for mining equipment. Ninety-five percent of the value of mine equipment from the 2011 feasibility study was updated with current budget pricing with the remainder factored.

The operations WTP costs are included in the Mining costs (WBS 1000). The 2020 operations WTP direct capital cost estimate of $\$ 42.7$ million is based on the Hatch 2015 direct capital cost estimate of $\$ 33.1$ million escalated to 2020 and adjusted for subsequent design updates. The direct cost has increased by approximately $28.9 \%$ since the 2015 estimate. The increase is due to both an increase in major equipment pricing and an increase to major equipment size/numbers based on a 2017 Hatch design update. Wood's QPs requoted approximately 69\% of the value of the major equipment. For cost areas not requoted, Wood's QPs applied an index of 1.057 to bring the cost current from 2015 to 2020 according to information published by InfoMine.

The mining initial capital, inclusive of the operations WTP, increased by $22.4 \%$ from 2011 to 2020 primarily due to the increase in mine equipment pricing.

Site preparation and roads initial capital costs have been updated using current labour rates, commodity unit rates, and index factors applied against the same scope as outlined in the feasibility capital estimate. Overall, the site preparation and road costs increased by $14 \%$.The process plant initial capital was updated by applying current labour rates, commodity unit rates, index factors, and updated budgetary equipment quotations to the existing 2011 feasibility design criteria, flowsheets, mechanical equipment list and material quantity take-offs. Eighty percent of the value of mechanical equipment from the 2011 feasibility study was updated with current budget pricing with the remainder factored based on the Project index of 1.142. The process initial capital, including the Hatch Ltd. estimate, increased by $8.3 \%$.

Hatch Ltd. estimated the 2011 direct capital costs for the POX plant and associated support facilities, and oxygen plant at $\$ 455.4$ million. For the 2020 estimate update, Hatch Ltd. used the 2011 designs, equipment, and productivities unchanged from 2011. In completing the update, Hatch Ltd. repriced approximately ninety percent of the value of equipment. Hatch Ltd.'s 2020 updated estimate is $\$ 503.3$ million, a $11.0 \%$ increase.

The TSF initial capital cost update is based on the same scope as the 2011 feasibility study. The TSF costs have been updated using current construction labour rates for updated construction unit costs. Construction equipment portions of the unit costs have been updated based on recalculated pre-production mining fuel and consumable costs and applied as a factor/index to previous unit costs. Overall, TSF initial capital costs have increased by $17.3 \%$.

Site utilities initial capital costs have been updated using current construction labour rates, commodity rates, and index factors applied against the same scope as outlined in the 2011 feasibility capital estimate. Included within the utility costs centre (5000) are costs for the natural gas pipeline estimated in 2011 by CH2MHill and updated in 2020 by Wood's subject matter experts under Wood's QP supervision. The Overall utilities cost including the natural gas pipeline increased by $13.2 \%$.

The current natural gas pipeline cost estimate of $\$ 1,103$ million is based on the CH2MHILL's 2011 cost estimate of $\$ 973.0$ million escalated by Wood to 2020 and adjusted for the following changes:

- Modifications made to the route (i.e., the North Route Alignment) between MP 85 and 112 during the permitting process
- Increase in pipe diameter from 12" to 14"
- Addition of a fibre optic cable along the entirety of the route.

The cost updates included current material pricing for pipes and valves and a budgetary construction estimate for construction costs prepared by personnel with prior experience in Alaska's North Slope and Kenai Peninsula.

Following the updates, the costs for the natural gas pipeline increased by approximately $13.4 \%$.On-site infrastructure initial capital costs have been updated using current construction labour rates, commodity unit rates, and index factors applied against the same scope as outlined in the 2011 feasibility capital estimate. Overall, the on-site infrastructure cost increased by $15.4 \%$.

Off-site infrastructure initial capital costs have been updated using current construction labour rates, commodity unit rates, and index factors applied against the same scope as outlined in the 2011 feasibility study capital estimate. Overall, the off-site infrastructure cost increased by $14.6 \%$.

[[%~%]]
### 21.1.3 Owner'S Initial Capital Costs

The 2011 feasibility study Owner's cost models were updated for current energy pricing and labour rates. For non-energy and labour costs, an appropriate cost index was applied to bring costs current. Additionally, the environmental and land costs were adjusted to account for funds already spent to procure permits and to advance the environmental programs. These costs are considered sunk and will not be spent again. The last adjustment involved removing Year -7 costs because they are part of the Project study work and not part of the Project construction costs.

In total, the Owner's costs decreased by $15.1 \%$ to $\$ 348$ million (excluding the pipeline land owner cost allocation). The adjustment most responsible for the decrease was the removal of environmental permitting costs due to the significant progress made in environmental permitting over the last eight years. Many of the permits and costs for permits envisioned in the 2011 feasibility study have been obtained and the money has been spent.

[[%~%]]
### 21.1.4 Indirect Initial Capital Costs

The Indirect cost update is based on the change in direct costs from 2011 to 2020 (+12.47\%) applied to most of the Wood portion of the 2011 Indirect estimate. Following the adjustment to Wood's indirects, the Hatch Ltd. indirect costs and natural gas pipeline indirect costs were added to the Wood estimate to get a total indirect cost of $\$ 1,567$ million. Total indirect costs increased by $11.5 \%$ from the 2011 estimate.

[[%~%]]
### 21.1.5 Initial Capital Contingency

The blended Project contingency is $17.7 \%$ (Table 21-4). Because engineering and MTOs have not change since 2011, the Wood $17.9 \%$ contingency was maintained for the 2020 update. The Hatch Ltd. contingency has increased from 2020: 13.9\% in 2011 compared to 15\% in 2020. Toreflect the two pipeline design changes, the natural gas pipeline contingency was increased from $16.7 \%$ to $18.6 \%$.

Table 21-4: Initial Capital Cost Contingency

| Contingency Area | Total Project Cost <br> Including Contingency <br> (\$M) | Contingency <br> (\$M) | Contingency <br> (\%) |
| :-- | :--: | :--: | :--: |
| Wood, Donlin Gold | 5,451 | 828 | 17.9 |
| Hatch | 848 | 110 | 15.0 |
| Wood, CH2M Hill | 1,103 | 173 | 18.6 |
| Total | $\mathbf{7 , 4 0 2}$ | $\mathbf{1 , 1 1 1}$ | $\mathbf{1 7 . 7}$ |

[[%~%]]
### 21.1.6 Sustaining Capital

The 2020 sustaining capital estimate was updated for 2020 pricing. No changes to the mine plan or Project engineering were made. Figure 21-3 shows the step changes by Major Areas for the 2020 update. The total sustaining capital increased by $\$ 219$ million, a $14.6 \%$ increase, compared to the 2011 sustaining capital estimate.

Figure 21-3: 2011 to 2020 Sustaining Capital Cost Changes by Major Area
![img-54.jpeg](img-54.jpeg)The 2020 sustaining capital requirements total $\$ 1,723$ million and include the following considerations:

- Mining sustaining capital includes replacement of mining equipment based on hours of equipment use. Also included are the costs of purchasing additional units of equipment to match the mining plan.
- Mining dewatering sustaining capital includes provisions for additional well drilling, pumps, and pipelines to match the requirements of the mine pit.
- TSF sustaining capital comprises the associated costs for overburden excavation, peat clearing, liner bedding, HPDE liner, filter zone material, and rockfill required to increase the capacity of the TSF.
- Airstrip sustaining capital includes an allowance for replacing regular maintenance gear.
- Plant mobile equipment sustaining capital covers scheduled replacement of equipment based on age.
- Administration building sustaining capital is an allowance for replacement of office equipment and furniture.
- Truckshop sustaining capital allows for an expansion.
- Accommodation complex sustaining capital costs allows for expansion.


[[%~%]]
### 21.1.7 Initial Capital Cost Summary

The total estimated initial capital cost to design and build the Project described in this Report is $\$ 7,402$ million, including an Owner provided mining fleet and Owner performed mining pre-development. The updated initial capital cost estimate was developed in accordance with Association for the Advancement of Cost Engineering (AACE) Class 3 requirements, consisting of semi-detailed unit costs and assembly line items. The level of accuracy for the estimate is $\pm 25 \%$ of estimated final costs, per AACE Class 3 definition.

Table 21-5 shows the initial capital costs broken out by major area.Table 21-5: Summary of Initial Capital Costs by Major Area

| Area | Description | Estimate <br> (\$M) |
| :-- | :-- | :--: |
| 1000 | Mining | 422.1 |
| 2000 | Site Preparation and Roads | 268.4 |
| 3000 | Process Facilities | $1,435.7$ |
| 4000 | Tailings Storage Facility and Reclaim Systems | 140.4 |
| 5000 | Utilities | $1,473.4$ |
| 6000 | Ancillary Buildings and Facilities | 351.3 |
| 7000 | Off Site Facilities | 278.7 |
|  | Estimated Total Direct Cost | $4,370.2$ |
| 9000 | Estimated Total Indirect Cost | $1,566.9$ |
| 8000 | Total Owner's Cost | 353.6 |
| 9900 | Contingency | $1,111.4$ |
|  | Total Initial Capital Cost | $\mathbf{7 , 4 0 2 . 0}$ |

[[%~%]]
## 21.2 Operating Cost Estimates

Wood's cost estimating group, under the supervision of Wood's QPs, updated the 2011 feasibility study operating costs to bring them current to 2020 by updating key cost drivers like energy, labour, consumables, and freight. No changes to designs, schedules, or productivities were made, consequently the manning schedules and consumables remain unchanged.

Compared to 2011, the 2020 operating costs excluding royalties have decreased by 3.0\% primarily due to lower energy and process consumable prices. Figure 21-4 shows the step changes by major area for the 2020 update.# NOVAGOLD 

Figure 21-4: 2011 to 2020 Operating Cost Changes by Major Area Excluding Royalties
![img-55.jpeg](img-55.jpeg)

[[%~%]]
### 21.2.1 Basis Of Estimate

The 2020 Project labour rates are consensus rates based on the following sources:

- McDowell Survey, 2013 escalated to 2020 using an annual 2\% increase
- 2019 Cost Mine Labour rates for Alaska
- 2019 labour rates from an open pit mining project in Alaska.

The work schedules assume that production will operate $24 \mathrm{~h} / \mathrm{d}, 7 \mathrm{~d} / \mathrm{wk}, 365 \mathrm{~d} / \mathrm{a}$. All hourly (non-exempt) personnel assigned to positions that form part of continuous operations will work a two-weeks-in/one-week-out rotation. These operations personnel will work on two $12 \mathrm{~h} / \mathrm{d}$ shifts.

Hourly personnel assigned to positions required only during the 12-hour day shift will work a two-weeks-in/two-weeks-out rotation. Hourly personnel working at the Bethel port site will work on three $8 \mathrm{~h} / \mathrm{d}$ shifts: seven-days-on/two-days-off, seven-days-on/ two-days-off, seven-days-on/three-days-off. All salaried (exempt) personnel and a few hourly personnel will work a $12 \mathrm{~h} / \mathrm{d}$ shift on an eight-days-in/six-days-out rotation.An estimated West Texas Intermediate (WTI) fuel guidance price of $\$ 65.00$ per barrel was used, as provided by Donlin Gold LLC. Based on this calculation, the price of diesel for the Project was set $\$ 0.69 / \mathrm{L}$, including delivery costs but excluding any taxes.

Natural gas fuel price is based on the WTI guidance of $\$ 65.00$ per barrel of oil. The pricing assumes the import of LNG to Anchorage; total delivery costs associated with purchase, delivery, transportation, and regasification of the LNG; delivery through the Cook Inlet pipeline network; and operating costs for the Cook Inlet-to-Project site pipeline. The delivered cost of gas is $\$ 11.12 / \mathrm{MMBtu}$.

The estimated cost of electricity from a gas-fired dual-fuelled, (natural gas and diesel) reciprocating engine power plant is $\$ 0.1013 / \mathrm{kWh}$, not including capital costs.

Table 21-6 provides a comparison of energy prices from 2011 to 2020.
The total unit operating cost of the general cargo supply chain was estimated to be equivalent to $\$ 304.6 / \mathrm{t}$, a $15 \%$ increase from 2011. The unit operating cost for delivery of diesel fuel to the mine site was estimated to be $\$ 0.18 / \mathrm{L}$.

Table 21-6: Comparison of 2011 and 2020 Energy Prices

| Energy Type | Unit | 2011 Donlin FS | 2020 Donlin <br> Update | Percentage Change <br> $(\%)$ |
| :-- | :--: | :--: | :--: | :--: |
| Crude Oil Price | $\$ / \mathrm{bbl}$ | 85.00 | 65.00 | -24 |
| Diesel Price (delivered to site) | $\$ / \mathrm{L}$ | 0.80 | 0.69 | -14 |
| Natural Gas | $\$ /$ million btu | 13.33 | 11.12 | -17 |
| Site Electric Power | $\$ / \mathrm{kWh}$ | 0.1198 | 0.1013 | -15 |

The unit costs for process consumables are based on vendor quotations obtained in 2020. Table 21-7 provides a comparison of the 2011 and 2020 process consumables.Table 21-7: Process Consumable Unit Cost

| Reagent | Unit Cost 2011 <br> (\$/kg) | Unit Cost 2020 <br> (\$/kg) | Percentage Difference (\%) |
| :--: | :--: | :--: | :--: |
| Anti-scalant - Millsperse 8220 | 2.62 | 4.28 | 63 |
| Borax | 1.08 | 1.20 | 11 |
| Carbon - activated | 2.47 | 3.39 | 37 |
| Carbon - sulphur impregnated | 4.67 | 4.71 | 1 |
| Coagulant (in $\left.\$ / \mathrm{m}^{3}\right)^{*}$ | 7.36 | 1.88 | $-74$ |
| Copper Sulphate | 3.36 | 2.30 | $-32$ |
| Cyanide | 3.03 | 2.98 | $-2$ |
| Dispersant - Cytec E40 | 3.96 | 0.98 | $-75$ |
| Elemental Sulphur | 0.72 | 1.20 | 68 |
| Filter media (Cellite) | 1.05 | 1.09 | 4 |
| Flocculant - Magnafloc 351 | 4.26 | 2.90 | $-32$ |
| Frother - F549 | 4.76 | 3.08 | $-35$ |
| Frother - MIBC | 2.91 | 2.25 | $-23$ |
| Lime | 0.61 | 0.52 | $-15$ |
| Mercury Precipitant - UNR 829 | 1.92 | 2.06 | 8 |
| Natural Gas (\$/million BTU)* | 13.33 | 11.40 | $-14$ |
| Nitric Acid | 0.91 | 0.72 | $-21$ |
| Potassium Amyl Xanthate (PAX) | 2.66 | 2.73 | 3 |
| Primary Ball Mill Balls - 2.5 in ( 63.5 mm ) diameter | 1.92 | 1.23 | $-36$ |
| SAG Mill Balls - 4.9 in ( 125 mm ) diameter | 1.52 | 1.38 | $-9$ |
| Secondary Ball Mill Balls - 1.46 in ( 37 mm ) diameter | 1.91 | 1.23 | $-36$ |
| Silica Sand | 0.86 | 0.75 | $-12$ |
| Soda Ash | 0.72 | 0.80 | 11 |
| Sodium Hydroxide | 1.17 | 0.49 | $-58$ |
| Sodium Hypochlorite (in $\$ /$ /metre cubed)* | 0.96 | 0.78 | $-19$ |
| Sodium Nitrate | 1.37 | 1.55 | 14 |
| Sulphuric Acid | 1.22 | 0.52 | $-57$ |

Note: 2011 prices include freight cost of $\$ 264.89 / \mathrm{t}$ and additional freight cost of $\$ 20 / \mathrm{t}$ for grinding media; and 2020 prices include freight cost of $\$ 304.6 / \mathrm{t}$ and additional freight cost of $\$ 23 / \mathrm{t}$ for grinding media. The freight cost is not applied to natural gas since it is piped to site.

* Reagents with different unit cost

[[%~%]]
### 21.2.2 Mine Operating Costs

The mine operating cost estimate accounts for updated pricing and incorporates costs for operating and maintenance labour, staff, and supplies for each year. Operating and maintenance supplies are based on North American supply and include an allowance for freight and delivery to marshalling yards at the ports of Vancouver or Seattle, as appropriate, and then to site. Taxes are not included. Consumables (fuel, explosives, supplies) were calculated from expected use, unit consumptions, and allowances for minor items. All mining costs are based on production Years 1 to 25. Pre-production costs have been capitalized and included in the initial capital cost estimate.

The mining cost averages $\$ 2.59 / \mathrm{t}$ mined during mine operations (excludes tonnes and costs from the pre-production period). Table 21-8 provides a breakdown of mining costs by cost item.

Following the cost updates, the 2020 mine costs are estimated to average \$2.59/t mined, a 2.8\% increase compared to 2011 (see Figure 21-5).

Table 21-8: LOM Mining Operating Cost by Cost Item

| Item | Total <br> (\$M) | \$/t Mined Expit |
| :-- | :--: | :--: |
| Labour | $2,015.9$ | 0.62 |
| Electricity | 155.4 | 0.05 |
| Diesel | $1,781.6$ | 0.55 |
| Lube | 31.0 | 0.01 |
| Drilling Supplies | 73.7 | 0.02 |
| GET | 39.3 | 0.01 |
| Blasting Accessories | 114.5 | 0.04 |
| Emulsion | $1,042.6$ | 0.32 |
| Tires | 590.1 | 0.18 |
| Maintenance Parts \& Supplies | $2,118.8$ | 0.65 |
| Other | 467.1 | 0.14 |
| Total | $\mathbf{8 , 4 2 9 . 8}$ | $\mathbf{2 . 5 9}$ |# NOVAGOLD 

Figure 21-5: 2020 Mine Operating Cost Adjustments
![img-56.jpeg](img-56.jpeg)

[[%~%]]
### 21.2.3 Process Operating Costs

The processing costs account for updated pricing and cover operation and maintenance of the processing facilities, from the coarse ore dump pocket at the primary crusher through to the bullion room, as well as process and reclaim water pumping. The processing costs account for the expenses associated with purchasing consumables, equipment maintenance, personnel, and power consumption. Costs are summarized in Table 21-9.

The list of updated process consumables is shown in Table 21-7. Freight-associated charges were based on a rate of $\$ 304.6 / t$ for cargo transport from Vancouver and Seattle. An additional $\$ 23 / t$ was added for the grinding media freight; grinding media needs to be shipped in special gondola barges, which resulted in a higher cost.

Equipment maintenance (including liners) was developed for all areas from first principles for major equipment and from relative factors for minor equipment and was then expressed as a percentage of the capital cost of equipment for all areas except POX and the oxygen plant. Annual estimated maintenance costs for these two areas were developed from first principles by Hatch Ltd. The maintenance costs are also divided by area according to the Project's asset naming convention.

Power consumption was derived from the estimated load of individual pieces of equipment on the equipment list combined with power requirements for the crushing and grinding circuits. Power consumption was estimated to average 1,049,496 MWh/a. The cost of power wasprovided at $\$ 0.1013 / \mathrm{kWh}$. The calculation of primary crusher power consumption was based on the crusher running at $80 \%$ of full power, available $65 \%$ of the time.

Following the cost updates, the 2020 process costs are estimated to average \$13.70/t processed, an 11.4\% decrease form 2011 costs (see Figure 21-6).

Table 21-9: LOM Process Operating Costs

| Item | Total <br> (\$M) | \$/t Processed |
| :-- | :--: | :--: |
| Labour | 663.9 | 1.32 |
| Reagents and Consumables | $2,049.9$ | 4.06 |
| Power | $2,960.1$ | 5.86 |
| Maintenance Supplies | 942.1 | 1.87 |
| Subtotal | $6,616.0$ | 13.11 |
| G\&A Reallocation | 299.9 | 0.59 |
| Total | $\mathbf{6 , 9 1 5 . 9}$ | $\mathbf{1 3 . 7 0}$ |

Figure 21-6: 2020 Process Operating Cost Adjustments
![img-57.jpeg](img-57.jpeg)

[[%~%]]
### 21.2.4 General And Administrative Operating Costs

The LOM G\&A operating costs account for updated pricing and are expenses for cost centres not directly linked to the mining and process disciplines, and include management, safety, security, environmental, information services, warehouse and other overheads. The G\&A for each cost centre was estimated either from first principles or was based on experience at Barrick operations.

Some costs included in the G\&A have been allocated back to the mine and process departments to the extent that these costs can be reasonably related to the respective department, i.e., based on direct usage, percentage of total labour hours, or percentage of volumes shipped. Approximately $\$ 137.6$ million and $\$ 175.8$ million in LOM G\&A operating costs (logistics) were allocated to mining and processing respectively. Table 21-10 shows the LOM G\&A operating costs by cost item. The LOM G\&A operating costs averages $\$ 3.49 / \mathrm{t}$ processed after the G\&A allocation.

Table 21-10: LOM G\&A Operating Cost Estimate by Cost Item

| Item | Total <br> (\$M) | \$/t Processed |
| :-- | --: | :--: |
| Aviation | 100.1 | 0.20 |
| Site Maintenance \& Mobile Equipment | 164.9 | 0.33 |
| Camp \& Catering | 363.6 | 0.72 |
| Clinic | 37.0 | 0.07 |
| Community Relations | 153.0 | 0.30 |
| Emergency Response | 5.2 | 0.01 |
| Environmental | 74.8 | 0.15 |
| Finance \& Accounting | 42.9 | 0.09 |
| Health \& Safety | 21.4 | 0.04 |
| Human Resources | 26.5 | 0.05 |
| Insurance | 182.7 | 0.36 |
| IT | 224.8 | 0.45 |
| Legal | 39.5 | 0.08 |
| Logistics | 113.1 | 0.22 |
| Management | 15.2 | 0.03 |
| Land | 18.5 | 0.04 |
| Security | 54.2 | 0.11 |
| Training \& Recruiting (ORP) | 17.2 | 0.03 |
| Waste Management | 11.8 | 0.02 |
| Power | 95.8 | 0.19 |
| Total | $\mathbf{1 , 7 6 2 . 2}$ | $\mathbf{3 . 4 9}$ |Following the cost updates, the 2020 LOM G\&A operating costs are estimated to average \$3.49/t processed, an 8.4\% increase from 2011 (see Figure 21-7).

Figure 21-7: 2020 LOM G\&A Operating Cost Adjustments
![img-58.jpeg](img-58.jpeg)

[[%~%]]
### 21.2.5 Operating Cost Summary

Operating costs over the LOM are shown in Table 21-11. A breakdown by operating year is included in Table 21-12. Operating costs were prepared in first quarter 2020 U.S. dollars with no allowances for escalation, sales tax, import duties, or contingency.

LOM operating costs were estimated at $\$ 38.21 /$ t processed, $\$ 5.90 /$ t mined, and $\$ 635 /$ oz sold.

Table 21-11: LOM Operating Costs

| Area | Total LOM <br> (\$M) | \$t Processed | \$t Mined | \$/oz |
| :-- | :--: | :--: | :--: | :--: |
| Mine Operations | 8,430 | 16.70 | 2.58 | 278 |
| Processing Operations | 6,916 | 13.70 | 2.12 | 228 |
| Administration | 1,762 | 3.49 | 0.54 | 58 |
| Land \& Royalty Payments | 2,182 | 4.32 | 0.67 | 72 |
| Total | $\mathbf{1 9 , 2 8 9}$ | $\mathbf{3 8 . 2 1}$ | $\mathbf{5 . 9 0}$ | $\mathbf{6 3 5}$ |Table 21-12: Annual Operating Costs

| Year | Mining | Processing | Admin | Land / Royalty | Total | \$1 Processed | \$1 Mined | \$/oz |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| 1 | 209 | 114 | 44 | 33 | 399 | 52.99 | 3.34 | 766 |
| 2 | 257 | 264 | 70 | 81 | 671 | 35.89 | 5.59 | 482 |
| 3 | 284 | 270 | 67 | 83 | 704 | 36.64 | 5.69 | 508 |
| 4 | 313 | 265 | 67 | 84 | 728 | 37.52 | 5.50 | 489 |
| 5 | 333 | 267 | 66 | 85 | 751 | 38.41 | 5.27 | 491 |
| 6 | 359 | 268 | 66 | 84 | 776 | 39.75 | 5.09 | 514 |
| 7 | 355 | 261 | 66 | 81 | 764 | 40.81 | 4.93 | 486 |
| 8 | 376 | 260 | 67 | 80 | 784 | 42.11 | 5.18 | 606 |
| 9 | 402 | 264 | 67 | 85 | 818 | 41.78 | 5.45 | 599 |
| 10 | 368 | 270 | 66 | 85 | 789 | 40.11 | 5.26 | 522 |
| 11 | 356 | 269 | 66 | 84 | 775 | 39.85 | 5.17 | 625 |
| 12 | 374 | 264 | 67 | 83 | 789 | 40.84 | 5.26 | 539 |
| 13 | 380 | 266 | 67 | 86 | 798 | 40.20 | 5.32 | 641 |
| 14 | 397 | 257 | 67 | 81 | 803 | 42.72 | 5.35 | 846 |
| 15 | 416 | 254 | 68 | 79 | 817 | 44.43 | 5.45 | 921 |
| 16 | 434 | 255 | 68 | 82 | 839 | 44.05 | 5.60 | 849 |
| 17 | 421 | 260 | 67 | 84 | 832 | 42.81 | 5.55 | 1,062 |
| 18 | 416 | 263 | 67 | 84 | 830 | 42.59 | 6.24 | 901 |
| 19 | 419 | 262 | 67 | 84 | 832 | 42.59 | 6.60 | 741 |
| 20 | 429 | 266 | 67 | 85 | 846 | 43.09 | 5.64 | 598 |
| 21 | 404 | 262 | 66 | 80 | 812 | 43.63 | 5.41 | 901 |
| 22 | 259 | 259 | 63 | 79 | 661 | 36.12 | 5.53 | 633 |
| 23 | 188 | 264 | 62 | 83 | 597 | 31.12 | 8.05 | 576 |
| 24 | 172 | 261 | 63 | 83 | 579 | 30.15 | 10.15 | 671 |
| 25 | 75 | 258 | 61 | 84 | 479 | 24.55 | 36.85 | 834 |
| 26 | 20 | 260 | 62 | 84 | 426 | 21.80 | N/A | 665 |
| 27 | 15 | 231 | 68 | 73 | 388 | 22.88 | N/A | 536 |
| Total/Avg | 8,430 | 6,916 | 1,762 | 2,182 | 19,289 | 38.21 | 5.90 | 635 |

[[%~%]]
## 21.3 Comments On Section 21

The QPs have reached the following conclusions regarding the capital and operating cost estimates:

- With the exception of the natural gas pipeline and the operations WTP, no changes to engineering or material take offs (MTOs) were made for the 2020 update.
- All costs are expressed in first quarter2020 U.S. dollars. No allowances are included for escalation, interest during construction, taxes, or duties.- The total estimated initial capital cost to design and build the Project described in this Report is $\$ 7,402$ million, a $10.8 \%$ increase, compared to the 2011 capital estimate.
- The blended Project contingency in the initial capital estimate is $17.7 \%$. Because engineering and MTOs have not change since 2011, the Wood 17.9\% contingency was maintained for the 2020 update. The Hatch Ltd. contingency has increased slightly from 2020: $13.9 \%$ in 2011 compared to $15 \%$ in 2020. To reflect the two pipeline design changes, the natural gas pipeline contingency was increased from $16.7 \%$ to $18.6 \%$.
- The 2011 initial capital cost estimate and 2020 initial capital cost update were developed in accordance with Association for the Advancement of Cost Engineering (AACE) Class 3 requirements, consisting of semi-detailed unit costs and assembly line items. The level of accuracy for the estimate is $\pm 25 \%$ of estimated final costs, per AACE Class 3 definition.
- Sustaining capital costs are estimated at \$1,723 million.
- Wood's cost estimation group updated the 2011 feasibility operating costs, under Wood's QPs' supervision, to bring them current to 2020 by updating key cost drivers like energy, labour, consumables, and freight. No changes to designs, schedules, or productivities were made, consequently the manning schedules and consumables remain unchanged.
- West Texas Intermediate (WTI) fuel guidance price of $\$ 65$ per barrel is $\$ 20$ per barrel lower than the $\$ 85$ per barrel price assumed for the 2011 feasibility study, a $23.5 \%$ decrease.
- Based on supplier quotes, 2020 process consumable pricing is $21 \%$ lower than 2011 consumable pricing.
- Maintenance and Repairs costs, labour costs, and explosive costs have all increased since 2011.
- The estimated LOM operating costs are $\$ 5.90 /$ t mined, $\$ 38.21 /$ t processed, or $\$ 635 /$ oz sold.
- Compared to 2011, the 2020 operating costs excluding royalties have decreased by $3.0 \%$ primarily due to lower energy and process consumable prices.

[[@~@]]
# 22.0 Economic Analysis

The results of the economic analysis represent forward-looking information that are subject to a number of known and unknown risks, uncertainties, and other factors that may cause actual results to differ materially from those presented here. Forward-looking information includes Mineral Reserve estimates, commodity prices and exchange rates, the proposed mine production plan, projected recovery rates, uncertainties and risks regarding the estimated capital and operating costs, uncertainties and risks regarding the cost estimates and completion schedule for the proposed Project infrastructure, in particular the need to obtain permits and governmental approvals.

[[%~%]]
## 22.1 Valuation Methodology

The overall economic viability of the Project has been assessed using both undiscounted and discounted cash flow techniques. Undiscounted techniques include total net cash flow and payback period (measured from start of production). Discounted cash flow techniques include NPV and IRR. Discounted values are calculated using a 5\% discount rate and a discrete end-ofyear convention relative to Year -6, the start of basic and detailed engineering.

Estimates have been prepared for all the individual elements of cash receipts and cash expenditures for ongoing operations. Capital cost estimates have been prepared for initial development and construction of the Project (initial capital) and for ongoing operations (sustaining capital). Cost estimates have also been prepared for reclamation and closure of the mine and for post-closure obligations. These form the basis for the annual trust funding requirements over the LOM required to meet these obligations.

[[%~%]]
## 22.2 Financial Model Parameters

Parameters assumed for the financial model included the following areas.

[[%~%]]
### 22.2.1 Production Forecast

The production plan is based on a 53,500 t/d open pit gold mine with ore processing by means of flotation, POX, and CIL cyanidation. The pit designs and Mineral Reserves were based on the Measured and Indicated Mineral Resource estimates that were verified as remaining current. Annual LOM gold production averages 1.13 Moz per year, including 1.46 Moz per year for the first five full years of production.

[[%~%]]
### 22.2.2 Metallurgical Recoveries

Recovery is estimated to average $89.8 \%$ over the LOM based on work and testing performed for feasibility study purposes.

[[%~%]]
### 22.2.3 Smelting And Refining Terms

Doré refining and shipping charges were estimated at $\$ 1.21 /$ oz of gold sold based on escalating to 2020 the actual refining charges for Barrick's Goldstrike operations and a quotation for transportation and insurance costs from the planned Donlin mine site to a U.S.-based refinery utilized in 2011. In addition, $0.1 \%$ of gold produced at the mine is deducted as a cost of refining.

The current hydrometallurgical process selection renders any contained silver into a greater refractory state, which provides less than 10\% silver recovery through standard metal leaching. As a consequence, silver is not included in the Mineral Resource and Mineral Reserve estimates, and no silver credit has been applied to the Project.

[[%~%]]
### 22.2.4 Metal Prices

Estimated cash flows from revenue are based on a gold price of $\$ 1,500 /$ oz as provided by Donlin Gold LLC and are considered by the QP as consistent with industry consensus on long term price assumptions for gold.

[[%~%]]
### 22.2.5 Capital Costs

The initial capital costs for the Project are estimated at \$7,402 million, \$244/oz gold sold. Sunk costs (all costs incurred prior to Year -6), are excluded from the cash flow calculation. Sustaining capital costs over the LOM are estimated at \$1,723 million, \$57/oz gold sold. Total capital is estimated at \$9,125 million, \$300/oz gold sold. Figure 22-1 shows the distribution of initial and sustaining capital included within the financial model.

[[%~%]]
### 22.2.6 Operating Costs

LOM operating costs (including mining, processing, G\&A and royalties) are estimated at $\$ 19,289$ million, $\$ 5.90 /$ t mined, $\$ 38.21 /$ t processed, or $\$ 635 /$ oz gold sold. Figure 22-2 provides an annual distribution of operating costs.Figure 22-1: Distribution of Initial Capital and Sustaining Capital
![img-59.jpeg](img-59.jpeg)

Figure 22-2: Operating Costs
![img-60.jpeg](img-60.jpeg)

[[%~%]]
### 22.2.7 Royalties

Calista, TKC, and the Lyman family receive payments for land access and use. Over the LOM the land and royalty payments amount to $\$ 2,182$ million. Annual royalties paid per ounce of gold payable are included in Figure 22-2.

[[%~%]]
### 22.2.8 Working Capital

Inventory of consumables plus working capital are included in the cash flow. They are expenditures in the early years and are recovered in the final years.

## First Fills Inventory

- Included in capital costs.


## Initial Inventory

- Initial Inventory = 100.0 Days of Non-Labour Operating Costs.


## Working Capital

- Accounts Payable $=30.0$ Days of Non-Labour Operating Costs
- In-Process Inventory = 3.0 Days of Revenue
- Finished Products Inventory = 10.0 Days of Revenue
- Accounts Receivable = 10.0 Days of Revenue.


[[%~%]]
### 22.2.9 Taxes

Wood is not an expert in taxation matters. The following taxation summary was prepared by NOVAGOLD for the Project.

## U.S. Federal Corporate Income Tax

In accordance with the Tax Cuts and Jobs Act ("TCJA") enacted in December 2017 and effective January 1, 2018:

- Corporate income tax rate is $21 \%$.
- Net operating loss (NOL) carryovers are limited to $80 \%$ of taxable income.- The TCJA changed the NOL rules by limiting NOL deductions to $80 \%$ of taxable income, disallowing NOL carry backs, and lifting the 20-year limit on NOL carryovers.
- The alternative minimum tax (AMT) was eliminated.
- A percentage depletion deduction is applied upon the commencement of production and sale of gold. Cost depreciation is not applicable as there is no Project tax basis for the mineral property.
- Bonus depreciation is not considered in the tax depreciation calculation.


# Alaska Corporate Income Tax 

- Alaska corporate income tax rate is $9.4 \%$.
- Alaska conforms to U.S. federal tax treatment and does not collect AMT.


## Alaska Mining License Tax

- Alaska mining license tax rate is $7 \%$.
- Alaska mining license tax holiday is applied for the first $31 / 2$ years from the start of production.


[[%~%]]
### 22.2.10 Closure Costs And Salvage Value

To fund the $\$ 1,361$ million reclamation and closure costs, the Project provides $\$ 412$ million at closure by contributing to a Trust Fund commencing in Year -5 and continuing through the end of operations with annual contributions of $\$ 7.8$ million. In addition to the Trust Fund, financial assurance in the form of letters of credit and/or surety bonds is required to construct and operate the mine. Per the Donlin Gold Project Reclamation Plan Approval from ADNR, financial assurance in the amount of approximately $\$ 322$ million must be submitted in a form and substance approved by ADNR. The cost to maintain this financial assurance is assumed to be $0.40 \%$ of the total assured amount, annually. This equates to approximately $\$ 1.3$ million per year, paid from the start of construction through the end of operations. Additional discussion on closure costs is included in Section 20.

No salvage is assumed at the end of operations.

[[%~%]]
### 22.2.11 Financing

Financing has been assumed on a 100\%, all equity, stand-alone basis.

[[%~%]]
### 22.2.12 Inflation

Escalation / inflation has been excluded. Escalation has been included in the determination of the funding requirements for the Trust Fund, but the Trust Fund values in the cash flow are expressed on an un-escalated (real) basis.

[[%~%]]
## 22.3 Economic Results

Based on the economic evaluation, the Project generates positive before and after-tax economic results. After tax $\mathrm{NPV}_{5}$ is $\$ 3,040$ million and the after tax IRR is $9.2 \%$. After tax payback is achieved 7.3 years following the start of production. Table 22-1 provides a summary of key evaluation metrics, Table 22-2 shows the cash flow, and Figure 22-3 shows the distribution of after-tax cash flows and $\mathrm{NPV}_{5}$.

Table 22-1: Summary of Key Evaluation Metrics

| Item | Unit | Value |
| :--: | :--: | :--: |
| Total Mined | Mt | 3,270 |
| Ore Treated | Mt | 505 |
| Strip Ratio | W/O | 5.5:1 |
| Gold Recovered | Moz | 30.40 |
| Gold Recovery | \% | 89.8 |
| Gold Price | \$/oz | 1,500 |
| Total After Tax Cash Flow | \$M | 13,145 |
| Total After Tax NPV5 | \$M | 3,040 |
| After Tax IRR | \% | 9.2 |
| Payback Period | years | 7.3 |
| Operation Life | years | 27 |
| Operating Costs | \$M | 19,289 |
|  | \$/oz | 635 |
| Closure Costs (Trust fund/assurance) | \$M | 292 |
|  | \$/oz | 10 |
| Initial Capital | \$M | 7,402 |
| Sustaining Capital | \$M | 1,723 |
| Total LOM Capital | \$M | 9,125 |
|  | \$/oz | 300 |
| Total Operating, Closure, and Capital Costs | \$M | 28,707 |
|  | \$/oz | 945 |Table 22-2: Cash Flow Analysis

| Item | Unit | Total | PP-6 | PP-5 | PP-4 | PP-3 | PP-2 | PP-1 | Yr 1 | Yr 2 | Yr 3 | Yr 4 | Yr 5 | Yr 6 | Yr 7 | Yr 8 | Yr 9 | Yr 10 | Yr 11 | Yr 12 | Yr 13 | Yr 14 |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Net Revenue (NSB) | SM | 45,519 | - | - | - | - | - | - | 782 | 2,086 | 2,076 | 2,233 | 2,295 | 2,262 | 2,357 | 1,939 | 2,048 | 2,263 | 1,859 | 2,194 | 1,867 | 1,422 |
| Mining | SM | $(8,430)$ | - | - | - | - | - | - | (209) | (257) | (284) | (313) | (333) | (359) | (355) | (376) | (402) | (368) | (356) | (374) | (380) | (397) |
| Processing | SM | $(6,916)$ | - | - | - | - | - | - | (114) | (264) | (270) | (265) | (267) | (268) | (261) | (260) | (264) | (270) | (269) | (264) | (266) | (257) |
| G&A | SM | $(1,762)$ | - | - | - | - | - | - | (44) | (70) | (67) | (67) | (66) | (66) | (66) | (67) | (67) | (66) | (66) | (67) | (67) | (67) |
| Land \& Royalty Payments | SM | $(2,182)$ | (3) | (5) | (8) | (15) | (17) | (15) | (5) | (27) | (41) | (44) | (45) | (113) | (113) | (110) | (99) | (106) | (108) | (101) | (106) | (89) |
| Total Operating Costs | SM | $(19,289)$ | (3) | (5) | (8) | (15) | (17) | (15) | (372) | (617) | (662) | (688) | (711) | (805) | (796) | (814) | (833) | (809) | (799) | (806) | (819) | (811) |
| Operating Cash Flow Before Tax | SM | 26,230 | (3) | (5) | (8) | (15) | (17) | (15) | 410 | 1,469 | 1,414 | 1,545 | 1,583 | 1,457 | 1,561 | 1,126 | 1,215 | 1,454 | 1,060 | 1,387 | 1,048 | 611 |
| Alaska State Income Tax | SM | $(1,038)$ | - | - | - | - | - | - | - | (32) | (48) | (64) | (72) | (64) | (79) | (37) | (40) | (63) | (33) | (58) | (30) | (6) |
| Alaska Mining License Tax | SM | $(668)$ | - | - | - | - | - | - | - | - | - | - | (54) | (48) | (59) | (28) | (30) | (47) | (25) | (43) | (22) | (4) |
| Federal Income Tax | SM | $(1,961)$ | - | - | - | - | - | - | (3) | (61) | (97) | (130) | (135) | (120) | (148) | (69) | (75) | (118) | (62) | (108) | (56) | (11) |
| Operating Cash Flow After Tax | SM | 22,562 | (3) | (5) | (8) | (15) | (17) | (15) | 407 | 1,376 | 1,269 | 1,350 | 1,322 | 1,225 | 1,275 | 991 | 1,070 | 1,225 | 939 | 1,179 | 941 | 590 |
| Initial Capital | SM | $(7,402)$ | (128) | (241) | (697) | (1,854) | (2,216) | (1,935) | (331) | - | - | - | - | - | - | - | - | - | - | - | - | - |
| Sustaining Capital | SM | $(1,723)$ | - | - | - | - | - | - | (383) | (78) | (35) | (12) | (175) | (63) | (32) | (85) | (178) | (14) | (32) | (23) | (168) | (28) |
| Closure Costs - Trust Fund | SM | (292) | - | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) |
| Working Capital | SM | - | - | - | - | - | - | - | (106) | (115) | (4) | (15) | (8) | (2) | (4) | 23 | (12) | (9) | 28 | (24) | 20 | 26 |
| Net After Tax Cash Flow | SM | 13,145 | (131) | (255) | (714) | (1,878) | (2,242) | (1,959) | (423) | 1,174 | 1,221 | 1,314 | 1,129 | 1,150 | 1,229 | 921 | 871 | 1,193 | 926 | 1,123 | 783 | 579 |
| Gold Price | $5 / 10$ | 1,500 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| After Tax NPV | SM | 3,040 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| IBR | \% | 9.2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Payback Period | years | 7.3 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |Table 22-2: Cash Flow Analysis (Continued)

| Item | Unit | Yr 15 | Yr 16 | Yr 17 | Yr 18 | Yr 19 | Yr 20 | Yr 21 | Yr 22 | Yr 23 | Yr 24 | Yr 25 | Yr 26 | Yr 27 |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| Net Revenue (NSR) | SM | 1,329 | 1,482 | 1,174 | 1,381 | 1,682 | 2,119 | 1,352 | 1,566 | 1,555 | 1,293 | 860 | 961 | 1,084 |
| Mining | SM | (416) | (434) | (421) | (416) | (419) | (429) | (404) | (259) | (188) | (172) | (75) | (20) | (15) |
| Processing | SM | (254) | (255) | (260) | (263) | (262) | (266) | (262) | (259) | (264) | (261) | (258) | (260) | (231) |
| G\&A | SM | (68) | (68) | (67) | (67) | (67) | (67) | (66) | (63) | (62) | (63) | (61) | (62) | (68) |
| Land \& Royalty Payments | SM | (74) | (74) | (74) | (68) | (79) | (95) | (96) | (76) | (82) | (78) | (64) | (52) | (97) |
| Total Operating Costs | SM | (812) | (831) | (822) | (814) | (827) | (855) | (827) | (657) | (597) | (574) | (458) | (394) | (412) |
| Operating Cash Flow Before Tax | SM | 517 | 651 | 352 | 567 | 855 | 1,263 | 524 | 908 | 958 | 719 | 401 | 567 | 713 |
| Alaska State Income Tax | SM | - | (11) | (12) | (22) | (47) | (81) | (28) | (55) | (53) | (41) | (14) | (18) | (30) |
| Alaska Mining License Tax | SM | - | (11) | (9) | (16) | (35) | (60) | (21) | (41) | (39) | (30) | (10) | (13) | (22) |
| Federal Income Tax | SM | - | (21) | (23) | (41) | (88) | (151) | (53) | (102) | (99) | (76) | (25) | (33) | (55) |
| Operating Cash Flow After Tax | SM | 517 | 608 | 307 | 488 | 685 | 972 | 422 | 711 | 767 | 571 | 352 | 503 | 606 |
| Initial Capital | SM | - | - | - | - | - | - | - | - | - | - | - | - | - |
| Sustaining Capital | SM | (108) | (31) | (126) | (16) | (2) | (12) | (88) | (1) | (2) | (2) | (29) | - | - |
| Closure Costs - Trust Fund | SM | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) | (9) |
| Working Capital | SM | 3 | (13) | 21 | (13) | (19) | (30) | 53 | 10 | 10 | 19 | 43 | (0) | (3) |
| Net After Tax Cash Flow | SM | 404 | 556 | 193 | 449 | 656 | 921 | 378 | 711 | 766 | 580 | 358 | 493 | 593 |
| Gold Price | $/ / / o t$ | 1,500 |  |  |  |  |  |  |  |  |  |  |  |  |
| After Tax NPV, | SM | 3,040 |  |  |  |  |  |  |  |  |  |  |  |  |
| IRR | \% | 9.2 |  |  |  |  |  |  |  |  |  |  |  |  |
| Payback Period | years | 7.3 |  |  |  |  |  |  |  |  |  |  |  |  |# NOVAGOLD 

Figure 22-3: After Tax Cash Flow and $\mathrm{NPV}_{5}$ (\$1,500/oz Gold Price)
![img-61.jpeg](img-61.jpeg)

[[%~%]]
## 22.4 Sensitivity Analysis

Sensitivity analyses have been performed on the Project on a range of $-30 \%$ to $+30 \%$ on gold price, gold grade, operating costs, and capital costs. Sensitivities are illustrated in a spider graph shown in Figure 22-4.

The Project is particularly sensitive to changes in the gold price. The Project requires a gold price of approximately $\$ 930 /$ oz to break even on an undiscounted cash flow basis and a gold price of approximately $\$ 1,180 /$ oz to break even on a $5 \%$ discounted basis.

Table 22-3 list the sensitivities of after-tax cash flow, $\mathrm{NPV}_{5}$, IRR, and payback to variations in gold price from a range of $\$ 1,000 /$ oz to $\$ 2,500 /$ oz.# NOVAGOLD 

Figure 22-4: After-Tax $\mathrm{NPV}_{5}$ Sensitivity Analysis
![img-62.jpeg](img-62.jpeg)

Table 22-3: Base Case Project Sensitivity to Gold Price (Base Case is highlighted)

| Gold Price <br> (\$/oz) | After Tax Cash Flow <br> (SM) | After Tax NPV5 <br> (SM) | After Tax IRR <br> (\%) | Payback <br> (years) |
| :-- | :--: | :--: | :--: | :--: |
| 1,000 | 1,855 | $(1,832)$ | 1.7 | 20.0 |
| 1,100 | 4,297 | $(784)$ | 3.7 | 12.0 |
| 1,200 | 6,556 | 202 | 5.3 | 10.3 |
| 1,300 | 8,773 | 1,161 | 6.8 | 9.2 |
| 1,400 | 10,974 | 2,109 | 8.1 | 8.1 |
| 1,500 | 13,145 | 3,040 | 9.2 | 7.3 |
| 1,600 | 15,308 | 3,967 | 10.4 | 6.7 |
| 1,700 | 17,455 | 4,887 | 11.4 | 6.2 |
| 1,800 | 19,125 | 5,696 | 12.4 | 5.9 |
| 1,900 | 20,728 | 6,454 | 13.2 | 5.5 |
| 2,000 | 22,465 | 7,229 | 14.1 | 5.2 |
| 2,100 | 24,257 | 8,016 | 14.9 | 4.9 |
| 2,200 | 26,074 | 8,808 | 15.7 | 4.7 |
| 2,300 | 27,908 | 9,606 | 16.5 | 4.5 |
| 2,400 | 29,747 | 10,402 | 17.2 | 4.3 |
| 2,500 | 31,590 | 11,199 | 17.9 | 4.1 |

[[%~%]]
## 22.5 Comment On Section 22

The QP has used the following assumptions and reached the following conclusions regarding the economic analysis:

- Cost prior to project Year -6, the start of basic and detailed engineering, are considered sunk.
- Financing has been assumed on a 100\%, all equity, stand-alone basis and Escalation / inflation has been excluded.
- All operating and capital costs have been updated to first quarter 2020 U.S. dollars.
- Taxation was updated in accordance with the Tax Cuts and Jobs Act ("TCJA") enacted in December 2017 and effective January 1, 2018.
- NOVAGOLD's accounting firm completed a review of the tax assumptions used in calculating the U.S. income tax, Alaska State income tax and Alaska Mining tax for the financial model to determine if the assumptions are reasonable and are in accordance with current (2020) federal and state tax rules.
- Using the economic parameters and assumptions set out in this Report, including a gold price of $\$ 1,500 /$ oz Au , the after-tax Project NPV at a discount rate of $5 \%$ is $\$ 3,040 \mathrm{M}$ and the IRR is $9.2 \%$. The cumulative, undiscounted, after-tax cash flow value for the Project is $\$ 13,145$ million and the after-tax payback period is 7.3 years.
- Sensitivity analyses have been performed on the Project on a range of $-30 \%$ to $+30 \%$ on gold price, gold grade, operating costs, and capital costs to determine that the Project is most sensitive to variations in the gold price and is less sensitive to variation in operating cost or capital cost.# NOVAGOLD 

[[@~@]]
# 23.0 Adjacent Properties

There are no adjacent properties that are relevant to this Report.

[[@~@]]
# 24.0 Other Relevant Data And Information

There is no additional information or explanation necessary to make the Report understandable and not misleading.

[[@~@]]
# 25.0 Interpretation And Conclusions

Based on the review of the key parameters and assumptions contained in the feasibility study, the QPs have reached the following interpretations and conclusions.

[[%~%]]
## 25.1 Agreements, Mineral Tenure, Surface Rights, And Royalties

Information from NOVAGOLD and their legal experts supports that the mining tenure held is valid and is sufficient to support declaration of Mineral Resources and Mineral Reserves. Mineral tenures have not been surveyed. State mining claims held by Donlin Gold LLC show as active on Alaska Department of Natural Resources online records, indicating that appropriate claim payments and required expenditure commitments are current.

Information from NOVAGOLD and their legal experts indicates that most surface rights are held by either TKC or Calista. This information supports that Donlin Gold LLC has agreements with both parties. Calista owns the surface estate on 27 of the 72 complete sections that make up the Project. TKC has granted Donlin Gold LLC non-exclusive surface use rights to at least 64 complete sections overlying the mineral deposit and on additional lands for access and infrastructure in the vicinity of the mine site, with provisions allowing for adjusting that area in conjunction with adjustments to the subsurface rights included in the Calista Lease. The Lyman family owns a small (approximately 5.7 hectares) private parcel in the vicinity of the deposit and holds a placer mining lease from Calista that covers approximately four square miles (partially covering six sections), currently leased and assigned, respectively, to Donlin Gold LLC. The currently identified resource and the bulk of the primary infrastructure (process and waste rock facilities) are located on the leased lands. Additional lands required for the Jungjuk port site, access road from the port site to the mine site, natural gas pipeline, and TSF in Anaconda Creek are located on a combination of Native, State of Alaska conveyed, and Federal (BLM) lands. Rights-of-way, leases, and easements have been issued by the State for the access road where it crosses State lands. The BLM has authorized the natural gas pipeline right-of-way for those portions on federal lands. The remaining land authorization required for the portions of the natural gas pipeline on State lands is currently in process.

Exploration to date has been conducted in accordance with Alaskan regulatory requirements.
Additional permits will be required for Project development.

[[%~%]]
## 25.2 Geology And Mineralization

Knowledge of the deposit settings, lithologies, and structural and alteration controls on mineralization is sufficient to support Mineral Resource and Mineral Reserve estimation.The deposit models as used in the exploration programs have been appropriate to the style and setting of the mineralization.

[[%~%]]
## 25.3 Exploration, Drilling, And Data Analysis

The exploration programs completed to date are appropriate to the style of the deposits and prospects within the Project.

Additional exploration potential remains in the Project area.
The quantity and quality of the lithological, geotechnical, collar and downhole survey data collected in the exploration and infill drill programs completed by Placer Dome Inc., NOVAGOLD, Barrick, the DCJV, DCLLC and DGLLC are sufficient to support Mineral Resource and Mineral Reserve estimation for the following reasons:

- Core logging meets industry standards for gold exploration.
- Collar surveys have been performed using industry-standard instrumentation.
- Downhole surveys were performed using industry-standard instrumentation.
- Recovery data from core drill programs are acceptable.
- Geotechnical logging of drill core meets industry standards for planned open pit operations.
- Drill hole orientations are generally appropriate for the mineralization style and have in most cases been drilled at orientations that are optimal for the orientation of mineralization for the bulk of the deposit area.
- Drill hole orientations are shown in the example cross-sections included as Figure 10-4 to Figure 10-7, and can be seen to appropriately test the mineralization
- In the bottom of the ACMA pit, the preferred orientation of the drill holes and the trend of the mineralization are both northwest. Figure 10-5 illustrates that although the contacts of the mineralized intrusions are well defined at higher elevations, the location of the mineralized intrusions are subjective at the bottom of the pit. This "bottom of the pit" mineralization would be mined late in the mine plan and the interpretation and location of this deeper mineralization can be refined through ore control drilling as the pit progresses to those depths.Sample collection, preparation, analysis and security for all Placer Dome Inc., NOVAGOLD, Barrick, the DCJV, DCLLC and DGLLC core drill programs are in line with industry-standard methods for gold deposits:

- Drill programs included insertion of blank, duplicate and standard reference material samples
- QA/QC program results do not indicate any problems with the analytical programs (refer to discussion in Section 12)
- Data were subject to validation, which includes checks on surveys, collar coordinates, lithology data, and assay data. The checks are appropriate, and consistent with industry standards (refer to discussion in Section 12).
- Independent data audits have been conducted and indicate that the sample collection and database entry procedures are acceptable.
- All core has been catalogued and stored in designated areas.
- The quality of the gold analytical data from the Placer Dome Inc., NOVAGOLD, Barrick, the DCJV, DCLLD and DGLLC drill programs are sufficiently reliable to support Mineral Resource and Mineral Reserve estimation without limitations on Mineral Resource and Mineral Reserve confidence categories.


[[%~%]]
## 25.4 Metallurgical Testwork

The quantity and quality of the metallurgical testwork are sufficient to support Mineral Resource and Mineral Reserve estimation for the following reasons:

- The metallurgical test results and process design described in this report are essentially the same as those presented in the Donlin 2011 Technical Report prepared on the Project.
- Metallurgical testwork and associated analytical procedures were performed by recognized testing facilities, and the tests performed were appropriate to the mineralization type.
- Samples selected for testing were representative of the various types and styles of mineralization at the Project. Samples were selected from a range of depths within the deposit. Sufficient samples were taken so that tests were performed on sufficient sample mass.
- Testwork completed by SGS-Lakefield, Hazen, and G\&T under Barrick's supervision has shown that the Donlin ore requires pre-treatment prior to cyanidation to recover the gold.Process development work has determined that POX is the preferred method of pretreatment. Extensive testwork on composites has shown that acceptable gold recoveries can be produced through a combination of flotation pre-concentration, POX, and CIL cyanidation.

- Additional metallurgical testwork was completed since 2011 including the programs in 2017 and 2018 at AuTec, FLSmidth, and TOMRA. Results show opportunity for plant optimization and potential reductions to process operating and capital costs. However, the recommendations from the testwork include the need for further testing, locked-cycle testing and continuous pilot plant, and more detailed economic evaluation of impacts of any new design parameters. Therefore, the results of the 2017 and 2018 testwork programs are not yet definitive and were not incorporated into the feasibility study summarized into this Report.
- The average Bond work index for the ore is in the range of $15 \mathrm{kWh} / \mathrm{t}$. Flotation work has shown that kinetics was initially rapid, but to achieve high recoveries, a combined primary and secondary rougher residence time over 100 minutes, together with a high reagent loading in the system, is required. Clay-like minerals will affect slurry viscosity and settling. Slurry density in the underflow will be less than $50 \%$ solids for the concentrate thickeners.
- Partially geologically oxidized (altered) ore in the deposit, up to 7\% of the process feed, is the key non-performing ore type in the flotation circuit. Degradation of the sulphide ore via oxidation in the stockpile will also affect the flotation recovery, applied as 5\% recovery loss within flotation on all ores stockpiled for longer than one year.
- POX has been shown to be successful in releasing the valuable constituents, under certain conditions. To optimize oxidation conditions, the water systems design has been modified to use the highest-quality water in the POX circuit. The autoclave design incorporates variable level control to provide better control over operating residence time.
- Air flotation using the MCF2 flowsheet provides an estimated LOM average of 93.0\% recovery, with CIL recoveries after POX at approximately $96.6 \%$ for an estimated combined plant total gold recovery of $89.8 \%$. The concentrate pull will vary from $15 \%$ to $17 \%$ and that will result in a concentrate grade of 11 to $15 \mathrm{~g} / \mathrm{t} \mathrm{Au}$.


[[%~%]]
## 25.5 Mineral Resource Estimation

The Mineral Resources for the Project, which have been estimated using core drill data, have been prepared in accordance with industry best practices as described in CIM Estimation of Mineral Resource and Mineral Reserve Best Practice Guidelines (CIM 2019) and 2014 CIMDefinition Standards. Validation checks on the Mineral Resource estimates using latest technical and economic inputs have determined the estimates remain current and are suitable to support Mineral Reserve estimation in the feasibility study.

Factors which may affect the Mineral Resource estimates include:

- Gold price
- Pit slope angles
- Changes to the assumptions used to generate the block value cut-off
- Changes to the $0.25 \mathrm{~g} / \mathrm{t} \mathrm{Au}$ threshold for defining the indicator mineralized shells
- Changes in interpretations of fault geometry, in particular the Vortex and Lo faults
- Changes to the search orientations used for grade estimation
- Changes to the geological model; in general, all geological models are simplified presentation of what occurs in nature. With more data, the geological models reflect more of the actual complexity of the deposit
- Changes to the Mineral Resource confidence classification criteria.


[[%~%]]
## 25.6 Mineral Reserve Estimation

The Mineral Reserves for the Project appropriately consider modifying factors and have been estimated using industry best practices (CIM 2019) and are in accordance with 2014 CIM Definition Standards.

Factors which may affect the Mineral Reserve estimates include: effectiveness of the dilution model, gold price, metallurgical recoveries, geotechnical characteristics of the rock mass, ability of the mining operation to meet the planned annual throughput rate assumptions for the process plant, capital and operating cost estimates, effectiveness of surface and ground water management, and likelihood of obtaining required permits and social licenses. These potential modifying factors have been adequately accounted for using the assumptions in this Report, at this feasibility level of study.

Risk factors which may affect the assumptions in this Report include:

- Unrecognized structural complications in areas with relatively low drill hole density could introduce unfavourable pit slope stability conditions.
- The stability of the south walls of the ultimate ACMA and Lewis pits is sensitive to the interpreted orientations of the Vortex and Lo faults, respectively. The current overallslope designs of these two walls may need to be modified if the interpretations of these faults change.

- Given the natural variations in the bedding dips, parts of footwall slopes may need to be excavated with flatter bench face angles than estimated for the feasibility design. This could potentially decrease the overall slope angle for the footwall slope(s) and increase the strip ratio.
- The residual friction angles of the ash beds are estimated to be $14^{\circ}$. If these low-strength layers are identified within footwall slopes, then, combined with bedding thicknesses of less than 2 m , artificial support may be required for the footwall bench faces.
- Trench and other surface exposures show complex intrusive rock contacts on an ore polygon scale that cannot be accounted for in wireframe interpretations. The ore control plan, which includes angled drill hole delineation of ore zones, should mitigate these uncertainties.
- If the mining rate results in the pit walls encountering the water table, producing extensive seepage into the pit, then additional horizontal drains and pumping wells will be required. Similarly, if the bulk bedrock hydraulic conductivity is lower in some areas of the pit than assumed for the base case, then the density of vertical wells / horizontal drains will need to be increased.
- An estimation of the likely duration required to obtain the permits and social licenses to construct the natural gas pipeline and operate the planned mine is incorporated in this study; any changes to that timeframe may impact the assumptions used in the economic analysis, and therefore the declaration of Mineral Reserves.
- The pit design adds 2 Mt of ore and 194 Mt of waste compared to the 2020 optimization shell. These tonnages represent an additional $0.4 \%$ of ore and $7.5 \%$ of waste. Although high, the increase in waste is considered acceptable according to current design guidelines; consequently, the 2020 optimization work supports the feasibility study pit designs that were summarized in the Donlin 2011 Technical Report and are considered as still current.


[[%~%]]
## 25.7 Process Design

The process equipment and current designs for the Project are appropriate to the mine plan, and to the Project setting for the following reasons:- The process as currently envisaged will consist of sulphide flotation pre-concentration with POX followed by CIL to produce gold at acceptable recoveries through the application of autoclave sulphide oxidation technology.
- A semi-autogenous grinding circuit followed by pebble crushing and in-series ball milling has been selected for the comminution requirements based on the ability to handle the variable hardness and quality of the ore.
- The flotation flowsheet will provide a circuit design that will maximize sulphide recovery, as demonstrated during numerous bench and pilot plant metallurgical tests.
- POX of the flotation concentrate will allow higher recoveries in CIL cyanidation than direct cyanidation of the flotation concentrate, as demonstrated through extensive pilot-plant testing. Controlling autoclave residence time to match the requirements of the concentrate feed will be important.
- Effective neutralization of acidic solutions can be carried out through the efficient use of the natural carbonate content of the flotation tailings, thereby reducing the amount of lime or limestone that must be transported to site.
- Effective detoxification of WAD cyanide species in CIL tails through $\mathrm{SO}_{2} /$ Air destruction.
- Effective management of arsenic in the processed ore is possible through using the POX circuit. The ore has sufficient iron content to permit precipitation of arsenic with iron to form acceptable forms of arsenic precipitation products, suitable for long term storage in the TSF.
- Mercury emissions can be effectively controlled with the proposed mercury abatement systems on the POX, carbon regeneration, electrowinning, retort, and bullion smelting processing equipment. The proposed mercury recovery technology for the autoclave offgas systems achieves current known best practices for this application.
- The final tailings stream will be a combination of WAD CN detoxified CIL tails and neutralized acidic liquors generated from the autoclave, using flotation tails and lime, for final pH adjustment to a pH of 7 . The tailings will be non-acid generating. The circuit design as described will permit maximum recycle of tailings decant water back to the plant to potentially eliminate the need for discharge of process waters. The operations WTP is designed and permitted to treat process water to meet discharge water quality standards, if required.

[[%~%]]
## 25.8 Infrastructure Considerations

The infrastructure requirements and current designs for such infrastructure for the Project are appropriate to the mine plan, and to the Project setting for the following reasons:

- In general, the design and construction of the mine site infrastructure will be relatively straightforward, although the scope of the work is extensive, especially in terms of the water systems. In addition, the Project involves several development sites considerable distances apart, incurring high infrastructure costs to provide interconnecting roads, pipelines, services, and utilities. The decision to use material from the plant site excavation as a borrow source for constructing the starter tailings dam is an effective way to reduce the site preparation costs.
- Off-site infrastructure will be arranged, designed, and constructed using techniques that are proven to result in functional and durable facilities suited to their remote location and cold environment.
- Although the terrain is diverse and severe through the Alaskan Range, the pipeline route has been field verified by construction and survey personnel.
- The electrical power generation and distribution system has been designed to meet the requirements of the proposed loads, the site location, and facility layout. Electric power for the Project site will be generated from a dual-fuelled, (natural gas and diesel) reciprocating engine power plant with a steam turbine utilizing waste heat recovery from the engines.

Risk factors which may affect the assumptions in this Report include:

- There are known to be intermittent areas of permafrost and poor ground conditions at the various facility sites that could affect foundation design and site preparation. This risk can be mitigated by carrying out more thorough geotechnical investigations at all sites.
- A geotextile has been proposed for filter protection of the TSF underdrain system that extends under the TSF dam. Use of geotextile in the locations that are critical to the safety of dam is not recommended by FEMA (2008) and is not in compliance with recent draft state dam safety guidelines (ADNR, 2017), which have not yet been made final. Moreover, geomembrane lined zigzag dam cores are proposed for all water dams of the Project; this design practice of geomembrane-lined dam cores is not recommended by USBR (2018).
- The construction schedules for the TSF starter dam and other dams at the initial phase of the Project are aggressive, particularly related to activities of dam foundationpreparations and liner system installations. Any significant weather or permitting-related delays could affect successful completion of these facilities on schedule and lead to delay of mine start-up. This risk can be managed by proper detailed preconstruction planning and with detailed execution plan and construction schedules.

- Water management is required during construction, operations (27 years), and closure. For the construction phase the critical infrastructure components are the WRF and the ACMA and Lewis pits, which begin development in Year -1. Runoff from these areas is contact water that cannot be discharged to Crooked Creek unless it meets discharge water quality standards. This runoff must therefore be stored in the Lower CWD for use during operations or treated and discharged as per the APDES permit. An upstream FWDD will minimize the area draining to the Lower CWD during construction and the first year of operations. Water impounded behind the Lower CWD will be the primary source of water to the process plant during the start-up period. Start-up water requirements are $3.1 \mathrm{Mm}^{3}$ of non-turbid water. Under very dry conditions, there could be a shortage of freshwater supply during the first few years of operations. To mitigate this potential, runoff water will be impounded behind the FWD constructed in Snow Gulch during the preproduction period.
- The construction schedule for the Lower CWD is aggressive, with a great deal of work to be completed in a short duration. Weather delays could affect completion of the dam on schedule. The consequences of not meeting the current construction schedule are deferral of any construction activity upstream of the Lower CWD that generates contact water and possible delays in revenue generation.
- In the American Creek watershed, a lake will be allowed to develop in the mined-out pits. The pit lake will receive runoff from the TSF reclamation activities (including the supernatant pond volume remaining at the end of operations), the covered WRF, and undisturbed areas upslope of the WRF. Seepage from the reclaimed WRF will be collected and piped to the bottom of the pit lake to encourage pit lake stratification. Modelling of the pit lake geochemistry indicates that treatment is required before ACMA pit lake water can be discharged to Crooked Creek. The closure WTP has been designed for a maximum capacity of $1,700 \mathrm{~m}^{3} / \mathrm{h}$ based on an average annual operating period of six months; longer operating periods will be required in years when precipitation is above average.
- Seasonal constraints on construction of the PAG cover could limit the ability to use this portion of the WRF during certain periods of the year. This could require temporary stockpiling of the PAG materials and changes to the mine plan.

Recommendations to mitigate risk factors:- For the detailed design phase of the Project, further geotechnical investigations should be done along the access road and at Jungjuk and the Bethel cargo terminals. In addition, river water levels should be monitored through future barge seasons to gain a better understanding of year-to-year variability.
- Prior to final design, the TSF and water dam designs will need to be checked for compliance with most current state and federal guidelines.
- The TSF design needs to be advanced to the next stage and be revised as needed to be in full compliance with the recently published global tailings standard (GISTM, 2020).
- Further confirmation of hydraulic modeling for the natural gas pipeline is recommended to optimize the flow demand / pattern scenarios, i.e., 14 " diameter versus 16 " diameter natural gas pipeline with various compression options.
- In a typical year, the Project will consume about 105,000 t of general cargoes and 152 ML of diesel. Utilizing LNG propulsion for the mine truck fleet would substantially reduce the annual diesel requirements.


[[%~%]]
## 25.9 Environmental, Social Issues And Permitting

The environmental, social issues, and permitting requirements and current closure designs for the Project are appropriate to the Project for the following reasons:

- There has been a focused effort for more than 25 years to collect comprehensive environmental baseline data which has led to the successful completion of the NEPA process with the publishing of the JROD. In addition, successful state permitting is almost complete, supporting the development of a large-scale mining operation at the Project.
- Development and operation of the Project will require a considerable number of permits and authorizations from both Federal and State agencies, most of which have been obtained.
- With completion of the NEPA process, a JROD has been issued that approves the preferred alternative for the Project, describes the conditions of the approval, and explains the basis for the decision.
- The State permitting process typically is not finalized until the NEPA process is completed. Most of the State permitting for the Project is complete. Each remaining State permit will have compliance stipulations requiring review and possibly negotiation by the applicant and appropriate agency.- Upon final issuance of permits and authorizations, the Environmental Management System (EMS) for the Project will be fully implemented.
- The comprehensive permitting process will determine the exact number of management plans required to address all aspects of the Project to ensure compliance with environmental design and permit criteria.
- A PSD air quality permit to construct has been obtained to allow construction and initial operation of the mine, process, and power plant facilities. Due to the proposed plans to site a large power generation facility adjacent to the mine and process facilities, estimated emissions are significant enough to trigger permitting under the PSD program. PSD requires modelling of potential air quality impacts and demonstrating that the applicant has necessary control of the land tenure to prevent public access to the area where air quality impacts occur. The permit requires construction to begin within a specific timeframe. Several extensions to the start of construction have been granted by the ADEC, with the current start of construction required before 31 December 2021. Donlin Gold LLC is collecting updated additional meteorological data that will support the anticipated need for another extension.
- The prevention of unregulated discharge of water that does not meet water quality standards is a primary criterion for overall Project design. The current ADPES permit identifies water quality standards and how they are met and regulated. Additionally, this risk will be managed by continuing to optimize the use of process and contact water during operations and ensuring that the capacity of the WTP is sufficiently flexible to handle excess water during increased precipitation scenarios.
- The SRCE was used to develop reclamation and closure cost estimates. The final reclamation Phase Detail Cost Spreadsheet cost estimate is $\$ 1,361$ million of which $\$ 693$ million is allocated for long-term water treatment costs. This amount is included in a Trust Fund for Reclamation, Closure costs and Post-Closure Obligations model prepared to determine the funding required to generate sufficient cash flow to cover the following costs: spillway construction from the TSF to Crevice Creek; capital to construct the closure WTP; perpetual water treatment; long-term monitoring; and associated facility and access maintenance.
- Donlin Gold LLC is focusing on sustainable development to benefit local communities over the long term by providing opportunities for direct employment, local procurement, and community development projects.

[[%~%]]
## 25.10 Capital And Operating Cost Estimates

Capital and operating costs have been adequately accounted for using the assumptions in this Report, at this feasibility level of study for the following reasons:

- Except the natural gas pipeline and the operations WTP, no changes to engineering or MTOs were made for the 2020 update.
- All costs are expressed in first quarter 2020 U.S. dollars. No allowances are included for escalation, interest during construction, taxes, or duties.
- The total estimated initial capital cost to design and build the Project described in this Report is $\$ 7,402$ million, a $10.8 \%$ increase, compared to the 2011 capital estimate.
- The blended project contingency is $17.7 \%$. Because engineering and MTOs have not changed since 2011, the Wood 17.9\% contingency was maintained for the 2020 update. The Hatch Ltd. contingency has increased slightly from 2020: 13.9\% in 2011 compared to $15 \%$ in 2020. To reflect the two pipeline design changes, the natural gas pipeline contingency was increased from $16.7 \%$ to $18.6 \%$.
- Sustaining capital costs are estimated at $\$ 1,723$ million. The total sustaining capital increased by $\$ 219$ million, a $14.6 \%$ increase, compared to the 2011 sustaining capital estimate.
- The 2011 capital cost estimate and 2020 capital cost update were developed in accordance with Association for the Advancement of Cost Engineering (AACE) Class 3 requirements, consisting of semi-detailed unit costs and assembly line items. The level of accuracy for the estimate is $\pm 25 \%$ of estimated final costs, per AACE Class 3 definition.
- Wood updated the 2011 feasibility study operating costs to bring them current to 2020 by updating key cost drivers like energy, labour, consumables, and freight. No changes to designs, schedules, or productivities were made, consequently the manning schedules and consumables remain unchanged.
- Compared to 2011, the 2020 operating costs excluding royalties have decreased by 3.0\% primarily due to lower energy and process consumable prices. A description of some of the cost drivers follows:
- Based on supplier quotes, 2020 process consumable pricing is $21 \%$ lower than 2011 consumable pricing.
- Maintenance and Repairs costs, labour costs, and explosive costs have all increased since 2011.- WTI oil guidance price of $\$ 65$ per barrel is $\$ 20$ per barrel lower than the $\$ 85$ per barrel price assumed for the 2011 feasibility study, a $23.5 \%$ decrease.


[[%~%]]
## 25.11 Economic Analysis

The economic analysis is supportive of current Mineral Reserves at the feasibility level of study. The following assumptions and basis were made to support the economic analysis:

- Costs prior to project Year -6, the start of basic and detailed engineering, are considered sunk.
- Financing has been assumed on a 100\%, all equity, stand-alone basis and Escalation / inflation has been excluded.
- All operating and capital costs have been updated to first quarter 2020 U.S. dollars.
- Taxation was updated in accordance with the Tax Cuts and Jobs Act ("TCJA") enacted in December 2017 and effective January 1, 2018.
- NOVAGOLD's accounting firm completed a review of the tax assumptions used in calculating the U.S. income tax, Alaska State income tax and Alaska Mining tax for the financial model to determine if the assumptions are reasonable and are in accordance with current (2020) federal and state tax rules.
- Using the economic parameters and assumptions set out in this Report, including a gold price of $\$ 1,500 /$ oz Au , the after-tax Project NPV at a discount rate of $5 \%$ is $\$ 3,040$ million and the IRR is $9.2 \%$. The cumulative, undiscounted, after-tax cash flow value for the Project is $\$ 13,145$ million and the after-tax payback period is 7.3 years.
- Sensitivity analyses have been performed on the Project on a range of $-30 \%$ to $+30 \%$ on gold price, gold grade, operating costs, and capital costs to determine that the Project is most sensitive to variations in the gold price and is less sensitive to variation in operating cost or capital cost.


[[%~%]]
## 25.12 Conclusions

Wood QPs consider the scientific and technical information available on the Project can support proceeding with additional data collection, trade-off and engineering work and preparation of more detailed studies. However, the decision to proceed with a mining operation on the Project is at the discretion of NOVAGOLD and its partners on the Project.

[[@~@]]
# 26.0 Recommendations

Donlin Gold LLC has completed a feasibility study and two updates of the study, the last being completed in 2011. Donlin Gold LLC has also substantially progressed the federal and state permitting of the project and has received a final EIS and JROD from the ACOE and BLM. A decision to proceed with Project construction would be made by the partners upon the completion of a final feasibility study update and potentially some level of basic and detailed engineering. Market conditions would also factor into a construction decision.

As a consequence, Wood's QPs recommend commencing and completing a final feasibility study update and to continue permitting activities required for Project construction and operation. A final feasibility study update should incorporate all recent data acquisition from the targeted drill programs in 2017 and 2020, plus the results of the planned 2021 drilling, such as geologic and geotechnical information; any relevant optimization findings, such as potential process flowsheet optimization, potential enhancements to project execution strategy (modularization), and potential infrastructure optimizations; all permitting advancements, the receipt of key permits and mitigation requirements; and those engineering changes noted in this document, the natural gas pipeline sizing and re-route and operations WTP and strategy. Permits still required and in progress include Dam Safety Certificates for seven planned dams and water diversion structures, and water rights.

The estimated cost of a final feasibility study update on a 100\% project ownership basis is in the range of $\$ 30$ million to $\$ 45$ million, including any remaining field work and test work required for study completion, and Donlin Gold LLC owner costs. The estimated cost of the remaining major permitting activities required for the Project, also on a 100\% basis, is in the range of $\$ 20$ million to $\$ 35$ million. Neither of these estimates include corporate G\&A costs incurred by the Project partners while these activities are ongoing, nor do they include Donlin Gold LLC project costs not directly associated with the final feasibility study update or permitting.

Donlin Gold LLC is undertaking additional confirmation and extension drilling in 2021 to expand upon 2020 drill results into the continuity and structural controls of the higher-grade mineralization. The 2021 drill program is estimated to cost approximately $\$ 22$ million with a potential to spend an additional $\$ 8$ million on field work and studies ( $100 \%$ basis).

[[@~@]]
# 27.0 References

AMEC, 2003: Prefeasibility Study - Status Report, Donlin Creek Project: unpublished draft report prepared for Placer Dome Inc

AMEC Americas Ltd., 2011: Donlin Creek Gold Project, Alaska, Feasibility Study Update 2, Effective Date 7 October 2011: feasibility study update prepared by AMEC for Donlin Creek LLC, dated 9 October 2011

Associated Mining Consultants, 2005: Donlin Creek Geophysical Survey, Alaska: unpublished report prepared for BGC, 17 June 2005

Brazier, N., 2020: Review of Hatch Design and Updated Cost Estimates for the Autoclave and Oxygen Plant. Technical memo authored by Nicole Brazier of Wood plc for NOVAGOLD RESOURCES INC., 13 January 2021

Buchanan, L.J., 2009: Donlin Creek, Alaska, Estimation of Potential Lode Ounces Gold: unpublished internal NovaGold memorandum, 10 August 2009, 17 p

Bundtzen, T.K., and Miller, M.L., 1997: Precious Metals Associated with Late Cretaceous-Early Tertiary Igneous Rocks of Southwestern Alaska: Econ. Geol., Monograph 9, pp 242-286

Cady, W.M., Wallace, R.E., Hoare, J.M., and Webber, E.J., 1955: The Central Kuskokwim Region, Alaska: USGS Professional Paper 268, 132 p

Canadian Dam Association (CDA), 2007: Dam Safety Guidelines: Edmonton, Alberta, 2007
Canadian Institute of Mining, Metallurgy and Petroleum (CIM), 2014: CIM Definition Standards for Mineral Resources and Mineral Reserves: CIM, 19 May 2014, https://mrmr.cim.org/media/1128/cim-definition-standards 2014.pdf

Canadian Institute of Mining, Metallurgy and Petroleum (CIM), 2019: Estimation of Mineral Resources and Mineral Reserves, Best Practice Guidelines: CIM, 29 November 2019, https://mrmr.cim.org/media/1129/cim-mrmr-bp-guidelines_2019.pdf.

Canadian Securities Administrators (CSA), 2016: National Instrument 43-101, Standards of Disclosure for Mineral Projects, CSA, 9 May 2016

Chamois, P., 2009: Donlin Creek Exploration Potential: unpublished report prepared by Scott Wilson Roscoe Postle Associates Inc. for NOVAGOLD, 2 September 2009, 6 p.

DOA. 2018. Block 26. Other Certificate/Approvals/Denials. Donlin Gold Project, Department of the Army Permit POA-1995-120 Updated Une 2018. United State De. Available from http://dnr.alaska.gov/mlw/mining/largemine/donlin/pdf/dg.404_b26update.pdf (accessed 16 October 2020).Dodd, S., 2006: Donlin Creek Project 43-101 Technical Report: NI 43-101 Technical Report filed on SEDAR by NOVAGOLD RESOURCES INC., effective date 20 January 2006

Dodd, S., Francis, K. and Doerksen, G., 2006: Preliminary Assessment Donlin Creek Gold Project, Alaska, USA: NI 43-101 Technical Report prepared by SRK Consulting (US), Inc., filed on SEDAR, effective date 22 August 2006 (filed date 25 September 2006)

Donlin Gold. 2018. Plan of Operations Reclamation and Closure Plan: Donlin Gold Project: 568
Donlin Gold. 2020, August 6. 2020-08-06_Donlin-Gold-Project-Provides-Update-on-Recent-Drilling-and-Ongoing-Community-Support-in-Alaska_FINAL-2.pdf. Available from https://donlingold.com/wp-content/uploads/2020/08/2020-08-06_Donlin-Gold-Project-Provides-Update-on-Recent-Drilling-and-Ongoing-Community-Support-in-Alaska_FINAL2.pdf (accessed 28 September 2020).

Drexler, H.L. 2010: A Comparison of Geochemistry, Carbonate Mineralogy, and Argillic Alteration Between the Dome Prospect and the Main Gold Resource of the Donlin Creek Project in Southwest Alaska: University of Nevada, Reno, M.S. thesis, 152 p.

Ebert, S.W., Miller, L., Petsel, S., Kowalczyk, P., Tucker, T.L., and Smith, M.T., 2000: Geology, Mineralization, and Exploration at the Donlin Creek Project, Southwestern Alaska: British Columbia and Yukon Chamber of Mines, v. Special 2, p. 99-114

Ebert S.W., Tosdal, R., Goldfarb, R., Dodd, S., Petsel, S., Mortensen, J., and Gabites, J., 2003a: The 25 Million Ounce Donlin Creek Gold Deposit, Southwest Alaska: A Possible Link Between Reduced Porphyry Au And Sub-Epithermal Au-As-Sb-Hg Mineralization: in Regional Geologic Framework and Deposit Specific Exploration Models For Intrusion Related Gold Mineralization, Yukon and Alaska, ed. S. Ebert: MDRU Special Publication 3, the Mineral Deposit Research Group, University of British Columbia

Ebert, S.W., Dodd, S., Miller, L., and Petsel, S., 2003b: The Donlin Creek Au-As-Sb-Hg Deposit, Southwestern Mineralization, Yukon and Alaska: in Regional Geologic Framework and Deposit Specific Exploration Models For Intrusion Related Gold Mineralization, Yukon and Alaska, ed. S. Ebert: MDRU Special Publication 3, the Mineral Deposit Research Group, University of British Columbia

Ebert, S.W., Baker, T., and Spencer, R.J., 2003c: Fluid Inclusion Studies at the Donlin Creek Gold Deposit, Alaska, Possible Evidence for Reduced Porphyry-Au To Sub Epithermal Transition: in Mineral Exploration and Sustainable Development, Proceedings of the Seventh Biennial SGA Meeting 24-28 August 2003: Athens, Greece, p. 263-266

Francis, K., 2008: Donlin Creek Project, NI 43-101 Technical Report, Southwest Alaska, U.S.: NI 43-101 technical report prepared filed on SEDAR by NOVAGOLD RESOURCES INC., effective date 5 February 2008Francis, K., 2011: Donlin Creek - Geologic Framework, Resources and Exploration Upside: unpublished PowerPoint presentation prepared for NOVAGOLD RESOURCES INC., dated 21 September 2011

Goldfarb, R. J., Ayuso, R., Miller, M.L., Ebert, S.W., Marsh, E.E., Petsel, S.A., Miller, L.D., Bradley, D., Johnson, C., and McClelland, W., 2004: The Late Cretaceous Donlin Creek Gold Deposit, Southwestern Alaska: Controls on Epizonal Ore Formation: Economic Geology, v. 99, p. 643-671

Hart, C.J.R., 2007: Reduced intrusion-related gold systems, in Goodfellow, W.D., (ed), Mineral deposits of Canada: A Syntesis of Major Deposit Types, District Metallogeny, the Evoloution of Geological Provinces, and Exploration Methods: Geological Association of Canada, Mineral Deposits Division, Special Publication No. 5, p. 95 - 112.

Hart, C.J.R., McCoy, D.T., Goldfarb, R.J.Smith, M., Roberts, P., Hulstein, R. Bakke, A.A., and Bundtzen, T.K., 2002: Geology, exploration and discovery in the Tintina Gold Province, Alaska and Yukon. In: Integrated Methods of Discovery: Global Exploration in the $21^{\text {st }}$ Century. Goldfarb, R.J., Nielson, R.L., (eds) Society of Economic Geologists Special Publication 9, pp. 241 - 274.

Hwang, M.J. and Tuckwood, G, 2020: Natural Gas Pipeline, 314 Miles x 14" Diameter. Technical memo authored by Wood plc for NOVAGOLD RESOURCES INC., 12 November 2020.

InfoMine, 2020: Cost Indexes and Metal Prices - July 2020
Juras, S., 2002: Technical Report, Donlin Creek Project, Alaska, NI 43-101F1 Technical Report to NOVAGOLD RESOURCES INC. by MRDI, effective date 24 January 2002 and filed on SEDAR

Juras, S. and Hodgson, S., 2002: Technical Report, Preliminary Assessment, Donlin Creek Project, Alaska: NI 43-101 Technical Report prepared by AMEC, filed on SEDAR by NOVAGOLD RESOURCES INC. report date March 2002

Jutras, M., 2006: Donlin Creek Project - Exploratory Data Analysis - Drill Hole Orientations: unpublished internal memorandum for DCLLC, June 5, 2006, 5 pp and figures

Kimball, B, and Srinivasa, R, technical memo titled "Water Treatment Plant Review", dated December 17, 2020

Lipiec, T., Seibel, G., and Hanson, K., 2012: Donlin Creek Gold Project Alaska, USA, NI 43-101 Technical Report on Second Updated Feasibility Study; prepared by AMEC and filed on SEDAR by NOVAGOLD RESOURCES INC., effective date 18 November 2011, amended 20 January 2012MacNeil, D., 2009: The Timing and Structural Evolution of the Donlin Creek Gold Deposit, Southwest Alaska: unpublished M.Sc. thesis, University of British Columbia

Manzer, D.S., 2020: Donlin Gold Project, Updated Abstract of Record Title, Effective 11 September 2020: title search prepared by Alaska Land Status Inc. for Perkins Coie LLP and addressed to Robert Maynard of Perkins Coie LLP, dated 16 October 2020

Maynard, R.M., 2020: Update of October 10, 2011 Title Report Letter for Donlin Creek Project Real Property Interests: confidential legal opinion prepared by Perkins Coie LLP for Donlin Gold LLC, and addressed to Dan Graham, General Manager for Donlin Gold LLC, dated 26 October 2020.

NOVAGOLD RESOURCES INC., 2021: Reliance on Other Expert for Tax Information. Re: Taxation information and tax inputs to the financial model used in the Donlin Gold Project Feasibility Study National Instrument 43-101 Technical Report prepared by Wood Canada Limited ("Wood") for NOVAGOLD RESOURCES INC. ("NOVAGOLD") Reliance letter provided to by D. Ottewell, NOVAGOLD's Vice President and CFO, 27 April 2021

NOVAGOLD RESOURCES INC., 2021: Email with attachment of the content for inclusion as Section 4 in the NI 43-101 Technical Report on the Donlin Gold Project, Alaska, USA. Email from Cliff Krall, Manager, Mine Engineering, NOVAGOLD RESOURCES INC. to Kirk Hanson, Technical Director, Open Pit Mining, Wood Group USA, Inc., dated 16 July 2021

O'Dea, M., and Bartch, M., 1997: Structural Controls on Gold Mineralization at The Donlin Creek Deposit, Southwest Alaska: unpublished report prepared by Etheridge Henley Williams consultants for Placer Dome Exploration Inc., September 1997

Pacific Rim Geological Consulting Inc., 2004: Assessment of Calcium Carbonate Resource Potential near Donlin Creek Project, Iditarod A-5 Quadrangle, Alaska: Final report prepared for Placer Dome U.S., dated 24 September 2004

Piekenbrock, J.R., and Petsel, S.A., 2003: Geology and Interpretation of the Donlin Creek Gold Deposit: NovaGold internal report, April 2003, 58 pp with appendices

Rimelman R. 2020. Donlin Gold Major Federal and State Permit Approval/Retention Strategy as of 7 October 2020. NovaGold

SRK Consulting (US), Inc., 2017: Plan of Operations, Water Resources Management Plan, Donlin Gold Project, February 2017

Szumigala, D.J., 1997: Donlin Creek Project - 1996 summary report of exploration activities: unpublished Placer Dome Exploration Inc. report, 2 vols., 5 sheets, 114 p.

Szumigala, D.J., Dodd, S.P., and Arribas, A., Jr., 2000: Geology and gold mineralization of the Donlin Creek prospects, southwestern Alaska: in Short Notes on Alaska Geology,Professional Report 119, ed. M.A. Wiltse: State of Alaska Department of Natural Resources Division of Geological and Geophysical Surveys, pp 91-115

Water Management Consultants, 2004: Summary of Field Activities: draft technical memorandum prepared for Placer Dome US, 21 May 2004

Wilkins, J.K., 1956: The flow of water through rockfill and its application to the design of dams. Proc. $2^{\text {nd }}$ Australia-New Zealand Conference on Soil Mechanics and Foundation Engineering, pp. 141 - 149. (Wilkins Equation, 1956).

Yuan, Peter, 2020: Phase II Donlin Gold NI 43-101 FS Technical Report Update - Donlin Gold Project: TSF, WRF, and Water Dam Review. Technical memo authored by Peter Yuan of Wood plc for NOVAGOLD RESOURCES INC.